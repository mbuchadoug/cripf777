//chatbotEngine

import { ACTIONS } from "./actions.js";
import { startInvoiceFlow } from "./invoiceFlow.js";
import { startReceiptFlow } from "./receiptFlow.js";
import { continueTwilioFlow } from "./twilioStateBridge.js";
import { showUnpaidInvoices } from "./paymentAdapters.js";
import Invoice from "../models/invoice.js";
import Product from "../models/product.js";
import { startQuoteFlow } from "./quoteFlow.js";
import { sendList } from "./metaSender.js";
import { SUBSCRIPTION_PLANS } from "./subscriptionPlans.js";
import { PACKAGES } from "./packages.js";
import mongoose from "mongoose";
import { logSearchCommand } from "./searchCommandLogger.js";
import SubscriptionPayment from "../models/subscriptionPayment.js";
import paynow from "./paynow.js";
import PhoneContact from "../models/phoneContact.js";
import { sendDocument } from "./metaSender.js";
import { sendImage }    from "./metaSender.js";
import {
  canUseFeature,
  requiredPackageForFeature,
  promptUpgrade
} from "./accessGuards.js";
import { generatePDF } from "../routes/twilio_biz.js";

import { sendPackagesMenu } from "./metaMenus.js";
import { startClientFlow } from "./clientFlow.js";
import { sendButtons } from "./metaSender.js";
import Business from "../models/business.js";

import Branch from "../models/branch.js";
import UserRole from "../models/userRole.js";
import UserSession from "../models/userSession.js";
import {
  handleChooseSavedClient,
  handleNewClientFromInvoice,
  handleClientPicked,
  handleSkipClient
} from "./invoiceAdapters.js";

import {
  sendMainMenu,
  sendSalesMenu,
  sendClientsMenu,
  sendPaymentsMenu,
  sendBusinessMenu,
  sendSettingsMenu,
  sendReportsMenu,
  sendUsersMenu,
  sendBranchesMenu,
  sendProductsMenu,
  sendStockMenu,
  sendSubscriptionMenu,
  sendBranchSelectorInvoices,
  sendBranchSelectorQuotes,
  sendBranchSelectorReceipts,
  sendBranchSelectorProducts,
  sendBranchSelectorNewDoc,
  sendBranchSelectorAddProduct,
  sendBranchSelectorPaymentIn,
  sendBranchSelectorExpense,
  sendBranchSelectorBulkExpense,
  sendBranchSelectorViewExpenses,
  sendBranchSelectorPaymentHistory,
  sendBranchSelectorAddClient,
  sendBranchSelectorViewClients,
  sendSuppliersMenu,
  sendSupplierUpgradeMenu,
  sendSupplierAccountMenu,
  sendSupplierMoreOptionsMenu,
  sendRecurringBillingMenu,
  sendRbAccountPicker,
} from "./metaMenus.js";

import { getBizForPhone, saveBizSafe } from "./bizHelpers.js";
import { sendText } from "./metaSender.js";
import { importCsvFromMetaDocument } from "./csvImport.js";
import axios from "axios";

// ─── Supplier Platform Imports ────────────────────────────────────────────────
import SupplierProfile from "../models/supplierProfile.js";
import SupplierOrder from "../models/supplierOrder.js";
import SupplierSubscriptionPayment from "../models/supplierSubscriptionPayment.js";
import BuyerRequest from "../models/buyerRequest2.js";
import {
  SUPPLIER_PLANS,
  SUPPLIER_CITIES,
  SUPPLIER_CATEGORIES,
SERVICE_COLLAR_GROUPS
} from "./supplierPlans.js";
import {
  startSupplierRegistration,
  handleSupplierRegistrationStates
} from "./supplierRegistration.js";
import {
  startSupplierSearch,
  runSupplierSearch,
  runSupplierOfferSearch,
  formatSupplierResults,
  formatSupplierOfferResults,
  parseShortcodeSearch,
  scoreSupplierMatch
} from "./supplierSearch.js";
import { sendNumberedSellerResults } from "./sellerSearchList.js";
import {
  notifySupplierNewOrder,
  handleOrderAccepted,
  handleOrderDeclined,
  handleBookingAccepted
} from "./supplierOrders.js";
import {
  trackSupplierResponseSpeed,
  getBuyerOpenRequests,
  formatBuyerQuoteComparison,
  formatRequestSummary,
  parseBuyerRequestLineWithQty,
  parseItemListWithQty
} from "./buyerRequests.js";
import {
  notifySupplierNewRequestTemplate,
  sendClarificationRequestToBuyer,
  sendClarificationReplyToSeller
} from "./buyerRequestNotifications.js";
import { findSuppliersForRequest, getVagueTermClarification, notifyNewSellerOfUnmatchedRequests, extractNaturalLanguageRequest } from "./requestMatchEngine.js";
import { sendRatingPrompt, updateSupplierCredibility } from "./supplierRatings.js";

import SchoolProfile from "../models/schoolProfile.js";
import {
  startSchoolRegistration,
  handleSchoolRegistrationStates,
  handleSchoolRegistrationActions
} from "./schoolRegistration.js";
import {
  startSchoolSearch,
  handleSchoolSearchActions,
  handleSchoolAdminStates,
  runSchoolShortcodeSearch,
  handleSchoolFreeTextSearch,
  handleZqDeepLink,
  handleSchoolSlugSearch,
  handleSmartCardMenu,
  handleSmartCardSourceLink,
  handleMyLeads,
  handleFollowUpLead
} from "./schoolSearch.js";

import {
  showSchoolFAQMenu,
  handleSchoolFAQAction,
  handleSchoolFAQState
} from "./schoolFAQ.js";

import {
  showSellerMenu,
  handleSellerChatAction,
  handleSellerChatState,
  handleSellerPriceReply
} from "./sellerChat.js";
import { handleGroupSmartLink, handleGroupSellerTap, handleGroupAdminCommand } from "./groupSmartLink.js";
import { handleStaffDeepLink, handleStaffCardSelfMenu, handleStaffCardAction } from "./staffSmartLink.js";
 

import {
  parseCommaNames,
  parsePickEntries,
  findUnpricedIndexes,
  buildUnpricedPromptText,
  applyBulkPrices,
  buildDocPreviewText,
  sendDocPreview,
  preserveSessionCore,
  sendAddItemPrompt,
  buildSavePreviewText,
  parsePriceUpdates,
  buildPriceUpdatePreviewText,
  formatServiceRate,
  buildFastAddHelpText
} from "./invoiceHelpers.js";
// ─── Helpers ──────────────────────────────────────────────────────────────────

function msDays(ms) { return ms / (1000 * 60 * 60 * 24); }
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function round2(n) { return Math.round(n * 100) / 100; }

// Display a Zimbabwean phone nicely, e.g. "263773123456" → "+263 77 312 3456".
// Used when revealing buyer/visitor phone numbers to permitted sellers.
function _zqFmtPhone(raw = "") {
  let d = String(raw).replace(/\D+/g, "");
  if (d.startsWith("0") && d.length === 10) d = "263" + d.slice(1);
  if (d.startsWith("263") && d.length >= 12) {
    return `+263 ${d.slice(3, 5)} ${d.slice(5, 8)} ${d.slice(8)}`;
  }
  return d ? `+${d}` : "";
}

// ── School contact-list renderer (Applications / Enquiries / Who Viewed) ──────
// One helper powers all three school-admin lists. They all read from the same
// SchoolContact store, filtered by intent. Parent phone numbers are revealed only
// when the school has the contact-viewer enabled (canViewContacts, admin-granted);
// otherwise counts, names and dates still show so the tool stays useful, with a
// clear prompt to unlock direct contact. Read-only: no text state, so it can never
// hit the "which city?" search hijack. Always returns to the school menu.
async function _renderSchoolContactList(from, phone, { filter = "all", title, emptyMsg }) {
  const SchoolProfile = (await import("../models/schoolProfile.js")).default;
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  const school = await SchoolProfile.findOne({ phone }).lean();
  if (!school) return sendMainMenu(from);

  let SchoolContact;
  try { SchoolContact = (await import("../models/schoolContact.js")).default; }
  catch (_) { await sendText(from, emptyMsg); return sendSchoolAccountMenu(from, school); }

  const q = { schoolId: school._id };
  if (filter === "applications")  q.$or = [{ converted: true }, { source: "apply" }];
  else if (filter === "enquiries") q.source = "enquiry";

  const total = await SchoolContact.countDocuments(q);
  if (!total) { await sendText(from, emptyMsg); return sendSchoolAccountMenu(from, school); }

  const rows = await SchoolContact.find(q).sort({ lastSeen: -1 }).limit(15).lean();
  const canSeePhone = school.canViewContacts === true;
  const srcLabel = { profile: "Profile", apply: "Apply", enquiry: "Enquiry", brochure: "Brochure" };

  const lines = rows.map((c, i) => {
    const d    = new Date(c.lastSeen || c.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
    const name = c.parentName || c.name || "Parent";
    const ph   = canSeePhone
      ? (String(c.phone).startsWith("263") ? "0" + String(c.phone).slice(3) : c.phone)
      : "🔒";
    return `${i + 1}. ${name} · ${ph} · ${srcLabel[c.source] || c.source} · ${d}${c.converted ? " ✅" : ""}`;
  }).join("\n");

  let msg = `${title} (${total})\n${"─".repeat(20)}\n${lines}`;
  if (!canSeePhone) {
    msg += `\n\n🔒 Parent phone numbers are hidden on your plan.\nContact ZimQuote to unlock the contact viewer and follow up with parents directly.`;
  } else if (total > 15) {
    msg += `\n\n_Showing the latest 15 of ${total}._`;
  }
  await sendText(from, msg);
  return sendSchoolAccountMenu(from, school);
}

// ── findSupplierByPhone ───────────────────────────────────────────────────────
// Checks all 3 phone formats: "263773...", "+263773...", "0773..."
async function findSupplierByPhone(rawPhone) {
  const digits = String(rawPhone || "").replace(/\D+/g, "");
  if (!digits || digits.length < 9) return null;
  let intl, intlPlus, local;
  if (digits.startsWith("263") && digits.length >= 12) {
    intl = digits; intlPlus = "+" + digits; local = "0" + digits.slice(3);
  } else if (digits.startsWith("0") && digits.length === 10) {
    local = digits; intl = "263" + digits.slice(1); intlPlus = "+263" + digits.slice(1);
  } else {
    intl = digits; intlPlus = "+" + digits; local = digits;
  }
  // Primary lookup - phone is the registered number
  const direct = await SupplierProfile.findOne({ phone: { $in: [intl, intlPlus, local] } }).lean();
  if (direct) return direct;
  // Secondary lookup - phone is a notification contact (extra line)
  // This allows notification contacts to View & Quote just like the primary phone
  return SupplierProfile.findOne({
    notificationContacts: { $in: [intl, intlPlus, local] }
  }).lean();
}


function calculateUpgradeCost(currentPrice, nextPrice, daysRemaining, totalDays) {
  if (nextPrice <= currentPrice) return 0;
  if (daysRemaining <= 0 || totalDays <= 0) return round2(nextPrice - currentPrice);
  return round2((nextPrice - currentPrice) * (daysRemaining / totalDays));
}

function currencySymbol(cur) {
  const c = (cur || "").toUpperCase();
  if (c === "USD") return "$";
  if (c === "ZWL") return "Z$";
  if (c === "ZAR") return "R";
  return c ? c + " " : "";
}

function formatMoney(amount, currency) {
  const sym = currencySymbol(currency);
  const n = Number(amount);
  if (Number.isNaN(n)) return `${sym}${amount}`;
  return `${sym}${n}`;
}

async function findBuyerRequestByIdOrRef(value) {
  const raw = String(value || "").trim();
  if (!raw) return null;

  if (mongoose.Types.ObjectId.isValid(raw)) {
    return BuyerRequest.findById(raw);
  }

  // FIX: try uppercase first (refs are stored uppercase like "RFQ-M5Q5TN"),
  // then case-insensitive regex fallback for any mixed-case variants.
  // This handles the case where WhatsApp lowercases the button payload.
  const upper = raw.toUpperCase();
  const exact = await BuyerRequest.findOne({
    $or: [
      { ref: upper },
      { reference: upper },
      { requestRef: upper },
      { ref: raw },
      { reference: raw },
      { requestRef: raw }
    ]
  });
  if (exact) return exact;

  // Case-insensitive regex fallback
  const pattern = new RegExp(`^${raw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i");
  return BuyerRequest.findOne({
    $or: [
      { ref: pattern },
      { reference: pattern },
      { requestRef: pattern }
    ]
  });
}

// ── Invoice/quote/receipt preview with edit option ────────────────────────
async function _sendInvoicePreview(from, biz, extraNote = "") {
  const items = biz.sessionData.items || [];
  const currency = biz.currency || "USD";
  const docType = biz.sessionData.docType || "invoice";
  const label = docType === "invoice" ? "Invoice" : docType === "quote" ? "Quotation" : "Receipt";

  const discountPercent = Number(biz.sessionData.discountPercent || 0);
  const vatPercent = Number(biz.sessionData.vatPercent || 0);

  const subtotal = items.reduce((s, i) => s + (Number(i.qty) * Number(i.unit)), 0);
  const discountAmount = subtotal * (discountPercent / 100);
  const vatAmount = (subtotal - discountAmount) * (vatPercent / 100);
  const total = subtotal - discountAmount + vatAmount;

  const itemLines = items
    .map((i, idx) =>
      `${idx + 1}. *${i.item}* × ${i.qty} @ ${formatMoney(i.unit, currency)} = *${formatMoney(i.qty * i.unit, currency)}*`
    )
    .join("\n");

  const discountLine = discountPercent > 0 ? `\n💸 Discount: ${discountPercent}% = -${formatMoney(discountAmount, currency)}` : "";
  const vatLine = vatPercent > 0 ? `\n🧾 VAT: ${vatPercent}% = +${formatMoney(vatAmount, currency)}` : "";

  const preview =
`🧾 *${label} Preview*${extraNote}

${itemLines}
─────────────────
Subtotal: ${formatMoney(subtotal, currency)}${discountLine}${vatLine}
*Total: ${formatMoney(total, currency)}*`;

  return sendInvoiceConfirmMenu(from, preview);
}

function unpricedCursor(n) { return n; } // tiny helper to avoid inline confusion
function normalizeProductName(value = "") {
  return String(value)
    .toLowerCase()
    .trim()
    .replace(/[^\w\s]/g, "")
    .replace(/\s+/g, " ");
}


const GENERIC_REQUEST_TERMS = new Set([
  "item",
  "items",
  "product",
  "products",
  "service",
  "services",
  "thing",
  "things",
  "material",
  "materials",
  "equipment",
  "supplies",
  "parts",
  "spares",
  "uniform",
  "uniforms",
  "laptop",
  "laptops",
  "phone",
  "phones",
  "tv",
  "tvs",
  "fridge",
  "fridges",
  "stove",
  "stoves",
  "pipe",
  "pipes",
  "valve",
  "valves",
  "tap",
  "taps",
  "tile",
  "tiles",
  "cement",
  "sand",
  "paint",
  "chair",
  "chairs",
  "table",
  "tables",
  "desk",
  "desks",
  "bed",
  "beds",
  "sofa",
  "sofas",
  "shoe",
  "shoes",
  "dress",
  "dresses",
  "shirt",
  "shirts",
  "builder",
  "builders",
  "plumber",
  "plumbers",
  "electrician",
  "electricians",
  "welder",
  "welders",
  "carpenter",
  "carpenters",
  "cleaner",
  "cleaners",
  "mechanic",
  "mechanics",
  "lawyer",
  "lawyers",
  "accountant",
  "accountants",
  "doctor",
  "doctors",
  "dentist",
  "dentists",
  "transport",
  "delivery"
]);

const REQUEST_FILLER_WORDS = new Set([
  "a",
  "an",
  "the",
  "for",
  "of",
  "and",
  "with",
  "in",
  "on",
  "to",
  "my",
  "need",
  "want",
  "looking"
]);

function getBuyerRequestLabel(item = {}) {
  return String(item?.product || item?.service || item?.raw || "").trim();
}

function getMeaningfulRequestTokens(value = "") {
  return normalizeProductName(value)
    .split(" ")
    .filter(Boolean)
    .filter(token => !REQUEST_FILLER_WORDS.has(token));
}

function isGenericBuyerRequestName(value = "") {
  const normalized = normalizeProductName(value);
  if (!normalized) return true;

  const tokens = getMeaningfulRequestTokens(normalized);

  if (!tokens.length) return true;
  if (tokens.length === 1 && GENERIC_REQUEST_TERMS.has(tokens[0])) return true;
  if (tokens.length === 1) return true;

  // Hospitality exception: "lodge night", "hotel room", "guesthouse 2 nights", "lodge rest" etc.
  // These are 2-token requests that are specific enough for hospitality suppliers to quote.
  // Without this exception they would be rejected as vague (2 tokens but one is a number/night).
  const HOSPITALITY_ANCHORS = new Set(["lodge","hotel","guesthouse","chalet","accommodation","resort","campsite","safari","cruise","houseboat"]);
  const HOSPITALITY_QUALIFIERS = new Set(["night","nights","rest","day","days","room","rooms","double","twin","single","family","suite","overnight","guests","adults","people","person"]);
  const hasAnchor    = tokens.some(t => HOSPITALITY_ANCHORS.has(t));
  const hasQualifier = tokens.some(t => HOSPITALITY_QUALIFIERS.has(t) || /^\d+$/.test(t));
  if (hasAnchor && hasQualifier) return false;

  return false;
}

function getVagueBuyerRequestItems(items = []) {
  return (items || []).filter(item => isGenericBuyerRequestName(getBuyerRequestLabel(item)));
}

function buildBuyerSpecificityPrompt(vagueItems = []) {
  const vagueLines = vagueItems.length
    ? vagueItems.map(i => `• ${getBuyerRequestLabel(i)}`).join("\n")
    : "• Your request";

  return (
    `❌ *Please use the full product or service name.*\n\n` +
    `These are too general for sellers to quote correctly:\n` +
    `${vagueLines}\n\n` +
    `Please include type, size, model, brand, class, material, or exact service needed.\n\n` +
    `Examples:\n` +
    `_ball valve brass 20mm harare_\n` +
    `_school uniform size 8 chitungwiza_\n` +
    `_hp laptop core i7 cbd harare_\n` +
    `_geyser installation avondale harare_\n\n` +
    `🏨 *For lodge / hotel / tourism requests:*\n` +
    `_lodge night harare 2 adults_\n` +
    `_double room overnight kariba 3 nights_\n` +
    `_game drive hwange 4 people_\n` +
    `_guesthouse bulawayo 2 nights_`
  );
}

function parseSupplierItemsInput(text = "") {
  return String(text || "")
    .split(/[,\n]+/)
    .map(s => s.trim())
    .filter(Boolean);
}

function dedupeSupplierItems(items = []) {
  const seen = new Set();
  const out = [];

  for (const raw of items) {
    const clean = raw.trim();
    const key = normalizeProductName(clean);
    if (!clean || !key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(clean);
  }

  return out;
}

function findSupplierItemIndexes(input = "", currentItems = []) {
  const tokens = String(input || "")
    .split(/[,\n]+/)
    .map(s => s.trim())
    .filter(Boolean);

  const indexes = new Set();
  const names = [];

  for (const token of tokens) {
    // support single numbers like 2, 5, 19
    if (/^\d+$/.test(token)) {
      const idx = Number(token) - 1;
      if (idx >= 0 && idx < currentItems.length) indexes.add(idx);
      continue;
    }

    // support ranges like 5-8
    const rangeMatch = token.match(/^(\d+)\s*-\s*(\d+)$/);
    if (rangeMatch) {
      const start = Number(rangeMatch[1]) - 1;
      const end = Number(rangeMatch[2]) - 1;
      for (let i = Math.min(start, end); i <= Math.max(start, end); i++) {
        if (i >= 0 && i < currentItems.length) indexes.add(i);
      }
      continue;
    }

    names.push(normalizeProductName(token));
  }

  if (names.length) {
    currentItems.forEach((item, i) => {
      const normalized = normalizeProductName(item);
      if (names.includes(normalized)) indexes.add(i);
    });
  }

  return [...indexes].sort((a, b) => a - b);
}

function parseQuickPriceUpdates(input = "", currentItems = [], isService = false) {
  const groups = String(input || "")
    .split(/[;\n]+/)
    .map(s => s.trim())
    .filter(Boolean);

  const updatesMap = new Map();
  const failed = [];
  let matchedAny = false;

  for (const group of groups) {
    // Group format:
    // 5,7,9 x 3.50
    // 20-30 x 1.25
    // 3 x 20/job
  const grouped = group.match(
  /^([\d,\-\s]+)\s*(?:x|=|@)\s*(\d+(?:\.\d+)?)(?:\s*\/\s*([a-zA-Z]+))?$/i
);

    if (grouped) {
      matchedAny = true;

      const selector = grouped[1].trim();
      const amount = Number(grouped[2]);
      const unit = (grouped[3] || (isService ? "job" : "each")).toLowerCase();
      const indexes = findSupplierItemIndexes(selector, currentItems);

      if (!indexes.length) {
        failed.push(group);
        continue;
      }

      for (const idx of indexes) {
        updatesMap.set(idx, {
          index: idx,
          product: currentItems[idx],
          amount,
          unit,
          inStock: true
        });
      }
      continue;
    }

    // Mixed single commands separated by commas:
    // 5 x 3.50, 7 x 4.20
    const parts = group.split(",").map(s => s.trim()).filter(Boolean);

    for (const part of parts) {
    const single = part.match(
  /^(\d+)\s*(?:x|=|@)\s*(\d+(?:\.\d+)?)(?:\s*\/\s*([a-zA-Z]+))?$/i
);

      if (!single) {
        failed.push(part);
        continue;
      }

      matchedAny = true;

      const idx = Number(single[1]) - 1;
      if (idx < 0 || idx >= currentItems.length) {
        failed.push(part);
        continue;
      }

      updatesMap.set(idx, {
        index: idx,
        product: currentItems[idx],
        amount: Number(single[2]),
        unit: (single[3] || (isService ? "job" : "each")).toLowerCase(),
        inStock: true
      });
    }
  }

  return {
    updates: [...updatesMap.values()].sort((a, b) => a.index - b.index),
    failed,
    matchedAny
  };
}



function parseSupplierPriceInput(raw = "", products = [], isService = false) {
  const parts = String(raw || "")
    .split(/[,\n]+/)
    .map(s => s.trim())
    .filter(Boolean);

  const allNumbers = parts.length > 0 && parts.every(s => /^\d+(\.\d+)?$/.test(s));
  const updated = [];
  const failed = [];

  // New quick syntax:
  // 75 x 3.50
  // 5,7,9 x 3.50
  // 20-30 x 1.25
  // 3 x 20/job
  const quick = parseQuickPriceUpdates(raw, products, isService);

  if (quick.matchedAny) {
    quick.updates.forEach(u => {
      updated.push({
        product: u.product.toLowerCase(),
        amount: u.amount,
        unit: u.unit,
        inStock: true
      });
    });
    failed.push(...quick.failed);
    return { updated, failed };
  }

  if (allNumbers) {
    if (parts.length !== products.length) {
      return {
        updated: [],
        failed: [`count_mismatch:${parts.length}:${products.length}`]
      };
    }

    parts.forEach((numStr, i) => {
      updated.push({
        product: products[i].toLowerCase(),
        amount: parseFloat(numStr),
        unit: isService ? "job" : "each",
        inStock: true
      });
    });

    return { updated, failed };
  }

  // Named pricing / named rate parsing
  for (const line of parts) {
    const clean = line
      .replace(/^[-•*►▪✓]\s*/, "")
      .replace(/^\d+[.)]\s*/, "")
      .replace(/\$/g, "")
      .trim();

    if (!clean) continue;

    // number/unit only e.g. 20/job
    const rateOnlyMatch = clean.match(/^(\d+(?:\.\d+)?)\/([a-zA-Z]+)$/);
    if (rateOnlyMatch) {
      const posIdx = updated.length;
      if (posIdx < products.length) {
        updated.push({
          product: products[posIdx].toLowerCase(),
          amount: parseFloat(rateOnlyMatch[1]),
          unit: rateOnlyMatch[2].toLowerCase(),
          inStock: true
        });
      } else {
        failed.push(line);
      }
      continue;
    }

    const match =
      clean.match(/^(.+?)\s*[:]\s*(\d+(?:\.\d+)?)\s*([a-zA-Z/]*)$/) ||
      clean.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z/]*)$/);

    if (!match) {
      failed.push(line);
      continue;
    }

    const product = match[1].replace(/[$@\-:,]+$/, "").trim().toLowerCase();
    const amount = parseFloat(match[2]);
    const rawUnit = (match[3] || "").trim().toLowerCase();
    const unit = rawUnit ? rawUnit.replace(/^\//, "") : (isService ? "job" : "each");

    if (!product || isNaN(amount)) {
      failed.push(line);
      continue;
    }

    updated.push({
      product,
      amount,
      unit,
      inStock: true
    });
  }

  return { updated, failed };
}


function parseQuickRenameCommand(input = "", currentItems = []) {
  const raw = String(input || "").trim();

  // format: 5=new product name
  const m = raw.match(/^(\d+)\s*=\s*(.+)$/);
  if (!m) return null;

  const idx = Number(m[1]) - 1;
  const newName = (m[2] || "").trim();

  if (idx < 0 || idx >= currentItems.length) return null;
  if (!newName) return null;

  return { index: idx, newName };
}

function parseQuickDeleteCommand(input = "", currentItems = []) {
  const raw = String(input || "").trim();

  // formats:
  // del 5
  // del 5,8,10
  // del 20-30
  const m = raw.match(/^del\s+(.+)$/i);
  if (!m) return [];

  return findSupplierItemIndexes(m[1], currentItems);
}

function parseQuickAddCommand(input = "") {
  const raw = String(input || "").trim();

  // formats:
  // add screw driver
  // add hammer, pliers
  const m = raw.match(/^add\s+(.+)$/i);
  if (!m) return [];

  return parseSupplierItemsInput(m[1]);
}


async function sendSupplierItemsInChunks(from, items, heading = "📦 Current Items") {
  const cleanItems = (items || []).filter(p => p && p !== "pending_upload");

  if (!cleanItems.length) {
    return sendText(from, "No items listed yet.");
  }

  const CHUNK = 25;
  for (let i = 0; i < cleanItems.length; i += CHUNK) {
    const chunk = cleanItems.slice(i, i + CHUNK);
    const lines = chunk
      .map((p, j) => `${i + j + 1}. ${p}`)
      .join("\n");

    const isFirst = i === 0;
    const isLast = i + CHUNK >= cleanItems.length;

    await sendText(
      from,
      isFirst
        ? `${heading} (${cleanItems.length})\n\n${lines}${isLast ? "" : "\n_(continued...)_"}`
        : `${lines}${isLast ? "" : "\n_(continued...)_"}`
    );
  }
}


async function sendSupplierQuickEditHelp(from, isService = false) {
  return sendText(
    from,
`Use these quick commands:

*Rename one item:*
_5=new name_

*Delete items:*
_del 5_
_del 5,8,10_
_del 20-30_

*Add new items:*
_add ${isService ? "geyser fitting" : "screw driver"}_
_add ${isService ? "blocked drain, toilet installation" : "hammer, pliers"}_

Type *cancel* to go back.`
  );
}

async function sendSupplierQuickPriceHelp(from, products = [], isService = false) {
  return sendText(
    from,
`─────────────────
*Fastest way: update by item number*

*Single item:*
_75x3.50_
_75 x 3.50_
${isService ? `_3x20/job_` : ""}

*Same price for selected items:*
_5,7,9x3.50_
_5,7,9 x 3.50_

*Same price for a range:*
_20-30x1.25_
_20-30 x 1.25_

*Mixed updates:*
_5x3.50,7x4.20_
_5 x 3.50, 7 x 4.20${isService ? ", 9 x 15/job" : ""}_

*Other options still work:*

*Update ALL in order:*
_${products.slice(0, 4).map((_, i) => (((i + 1) * 3) + 2).toFixed(2)).join(", ")}${products.length > 4 ? ", ..." : ""}_

*Update selected items by name:*
_${products.slice(0, 2).map(p => `${p}: 6.00`).join(", ")}_

Type *cancel* to go back.`
  );
}

function filterPricesForRemainingProducts(prices = [], remainingProducts = []) {
  const allowed = new Set(remainingProducts.map(p => normalizeProductName(p)));
  return (prices || []).filter(pr => allowed.has(normalizeProductName(pr.product)));
}

function filterRatesForRemainingServices(rates = [], remainingProducts = []) {
  const allowed = new Set(remainingProducts.map(p => normalizeProductName(p)));
  return (rates || []).filter(r => allowed.has(normalizeProductName(r.service)));
}

function getSupplierCategoriesForType(profileType = "product") {
  return SUPPLIER_CATEGORIES.filter(cat =>
    Array.isArray(cat.types) ? cat.types.includes(profileType) : true
  );
}
function parseSupplierRateValue(rate = "") {
  const raw = String(rate || "").trim();
  if (!raw) return null;

  // examples: "10/hr", "$10/hr", "50/trip", "15"
  const m = raw.match(/^\$?\s*(\d+(?:\.\d+)?)/);
  if (!m) return null;

  return Number(m[1]);
}

function parseSupplierRateUnit(rate = "") {
  const raw = String(rate || "").trim();
  const parts = raw.split("/");
  if (parts.length < 2) return "each";
  return parts[1].trim() || "each";
}


function formatSupplierRateDisplay(rate = "") {
  const raw = String(rate || "").trim();
  if (!raw) return "";

  // If it already starts with $, keep it
  if (raw.startsWith("$")) return raw;

  const value = parseSupplierRateValue(raw);
  const unit = parseSupplierRateUnit(raw);

  if (typeof value === "number" && !Number.isNaN(value)) {
    return `$${value}/${unit}`;
  }

  return raw;
}
function scoreLooseMatch(a = "", b = "") {
  const left = normalizeProductName(a);
  const right = normalizeProductName(b);

  if (!left || !right) return 0;
  if (left === right) return 100;

  const leftTokens = left.split(" ").filter(Boolean);
  const rightTokens = right.split(" ").filter(Boolean);

  let score = 0;

  if (left.includes(right) || right.includes(left)) {
    score += 40;
  }

  const overlap = leftTokens.filter(t => rightTokens.includes(t)).length;
  if (overlap) {
    score += Math.round((overlap / Math.max(leftTokens.length, rightTokens.length)) * 50);
  }

  if (leftTokens[0] && rightTokens[0] && leftTokens[0] === rightTokens[0]) {
    score += 10;
  }

  return score;
}

function findMatchingSupplierPrice(supplier, requestedProduct) {
  if (!requestedProduct || !supplier) return null;

  const isServiceSupplier = supplier?.profileType === "service";

  if (isServiceSupplier) {
    const validRates = (supplier.rates || []).filter(r => {
      const serviceName = normalizeProductName(r?.service || "");
      return serviceName;
    });

    let exact = validRates.find(r =>
      normalizeProductName(r.service) === normalizeProductName(requestedProduct)
    );

    if (exact) {
      return {
        product: exact.service,
        amount: parseSupplierRateValue(exact.rate),
        unit: parseSupplierRateUnit(exact.rate),
        source: "rates"
      };
    }

    const scored = validRates
      .map(r => ({
        row: r,
        score: scoreLooseMatch(r.service, requestedProduct)
      }))
      .sort((a, b) => b.score - a.score);

    const best = scored[0];
    const second = scored[1];

    if (best && best.score >= 55 && (!second || best.score - second.score >= 10)) {
      return {
        product: best.row.service,
        amount: parseSupplierRateValue(best.row.rate),
        unit: parseSupplierRateUnit(best.row.rate),
        source: "rates"
      };
    }

    return null;
  }

  const allowedNames = new Set(
    (supplier.listedProducts || [])
      .map(name => normalizeProductName(name))
      .filter(Boolean)
  );

  if (!allowedNames.size) return null;

  const validPrices = (supplier.prices || []).filter(p => {
    const productName = normalizeProductName(p?.product || "");
    return productName && p?.inStock !== false && allowedNames.has(productName);
  });

  let exact = validPrices.find(p =>
    normalizeProductName(p.product) === normalizeProductName(requestedProduct)
  );

  if (exact) {
    return {
      product: exact.product,
      amount: Number(exact.amount),
      unit: exact.unit || "each",
      source: "prices"
    };
  }

  const scored = validPrices
    .map(p => ({
      row: p,
      score: scoreLooseMatch(p.product, requestedProduct)
    }))
    .sort((a, b) => b.score - a.score);

  const best = scored[0];
  const second = scored[1];

  if (best && best.score >= 55 && (!second || best.score - second.score >= 10)) {
    return {
      product: best.row.product,
      amount: Number(best.row.amount),
      unit: best.row.unit || "each",
      source: "prices"
    };
  }

  return null;
}


const PLUMBING_PRESET_PRICES = Object.freeze({
  "110mm pvc pipe":         { amount: 10, unit: "each" },
  "110mm pvc ug pipe":      { amount: 10, unit: "each" },
  "110mm ac pvc pipe":      { amount: 12, unit: "each" },
  "50mm waste pipe":        { amount: 6,  unit: "each" },

  "32mm p trap":            { amount: 5,  unit: "each" },
  "40mm p trap":            { amount: 5,  unit: "each" },
  "50mm p trap":            { amount: 5,  unit: "each" },
  "32mm bottle trap":       { amount: 10, unit: "each" },
  "100mm floor drain":      { amount: 10, unit: "each" },

  "110mm inspection eye":   { amount: 15, unit: "each" },
  "110mm plain bend":       { amount: 3,  unit: "each" },
  "110mm h t bend":         { amount: 3,  unit: "each" },
  "110mm plain tee":        { amount: 4,  unit: "each" },
  "110mm access tee":       { amount: 12, unit: "each" },
  "110mm y junction":       { amount: 4,  unit: "each" },
  "110-50 reducer tee":     { amount: 4,  unit: "each" },
  "110mm vent valve":       { amount: 3,  unit: "each" },
  "110mm boss connector":   { amount: 3,  unit: "each" },

  "50mm plain bend":        { amount: 1,   unit: "each" },
  "50mm ie bend":           { amount: 0.5, unit: "each" },
  "50mm ic tee":            { amount: 1,   unit: "each" },
  "gulley p":               { amount: 2.5, unit: "each" },
  "gulley heads":           { amount: 4,   unit: "each" },

  "15mm pipe clip":         { amount: 0.5, unit: "each" },
  "20mm pipe clip":         { amount: 1,   unit: "each" },
  "15mm male connector":    { amount: 1.5, unit: "each" },
  "15mm cap elbow":         { amount: 0.5, unit: "each" },
  "22mm cap elbow":         { amount: 1.5, unit: "each" },
  "3/4 cu elbow":           { amount: 1.5, unit: "each" },

  "22mm cu pipe":           { amount: 35, unit: "each" },
  "15mm cu pipe":           { amount: 20, unit: "each" },

  "solvent cement":         { amount: 10, unit: "each" },
  "soldering wire":         { amount: 10, unit: "each" },
  "nasco flux":             { amount: 5,  unit: "each" },
  "gas canister":           { amount: 3,  unit: "each" },
  "masonry disk":           { amount: 10, unit: "each" },

  "basin pedestal":         { amount: 30, unit: "each" },
  "basin waste":            { amount: 5,  unit: "each" },
  "toilet lid":             { amount: 10, unit: "each" },
  "shower rose and arm":    { amount: 8,  unit: "each" }
});

function getBestPlumbingPresetPrice(requestedProduct = "") {
  const normalized = normalizeProductName(requestedProduct);
  if (!normalized) return null;

  if (PLUMBING_PRESET_PRICES[normalized]) {
    return {
      product: requestedProduct,
      amount: Number(PLUMBING_PRESET_PRICES[normalized].amount),
      unit: PLUMBING_PRESET_PRICES[normalized].unit || "each",
      source: "preset_exact"
    };
  }

  const scored = Object.entries(PLUMBING_PRESET_PRICES)
    .map(([name, price]) => ({
      name,
      price,
      score: scoreLooseMatch(name, normalized)
    }))
    .sort((a, b) => b.score - a.score);

  const best = scored[0];
  const second = scored[1];

  if (best && best.score >= 70 && (!second || best.score - second.score >= 10)) {
    return {
      product: requestedProduct,
      amount: Number(best.price.amount),
      unit: best.price.unit || "each",
      source: "preset_fuzzy",
      matchedPreset: best.name
    };
  }

  return null;
}

function supplierLooksLikePlumbingSeller(supplier) {
  const categories = Array.isArray(supplier?.categories) ? supplier.categories : [];
  return categories.includes("plumbing_supplies");
}

function getSupplierStockNames(supplier) {
  return [
    ...(supplier?.listedProducts || []),
    ...(supplier?.products || [])
  ]
    .map(p => normalizeProductName(p))
    .filter(Boolean);
}

function supplierStocksRequestedItem(supplier, requestedProduct = "") {
  const requested = normalizeProductName(requestedProduct);
  if (!requested) return false;

  const stockNames = getSupplierStockNames(supplier);
  if (!stockNames.length) return false;

  if (stockNames.includes(requested)) return true;

  const scored = stockNames
    .map(name => ({ name, score: scoreLooseMatch(name, requested) }))
    .sort((a, b) => b.score - a.score);

  return Boolean(scored[0] && scored[0].score >= 70);
}

function findMatchingSupplierPriceOrPreset(supplier, requestedProduct) {
  const supplierPrice = findMatchingSupplierPrice(supplier, requestedProduct);
  if (supplierPrice) {
    return {
      ...supplierPrice,
      source: "supplier_saved"
    };
  }

  if (!supplierLooksLikePlumbingSeller(supplier)) return null;
  if (!supplierStocksRequestedItem(supplier, requestedProduct)) return null;

  return getBestPlumbingPresetPrice(requestedProduct);
}

function buildDraftQuoteFromRequest(supplier, request) {
  const items = Array.isArray(request?.items) ? request.items : [];
  const isServiceSupplier = supplier?.profileType === "service";

  const responseItems = [];
  const missingItems  = [];
  // Items the service supplier offers but has no fixed price for (rate on request)
  const rorItems      = [];

  for (const item of items) {
    const match = findMatchingSupplierPriceOrPreset(supplier, item.product);

    if (!match || typeof match.amount !== "number") {
      // ── For service suppliers: check if this service is in their rates list ──
      // If so, it's "rate on request" not "not available"
      if (isServiceSupplier) {
        const norm = (s = "") => String(s).toLowerCase().replace(/[^a-z0-9]/g, " ").trim();
        const reqNorm = norm(item.product);
        const hasService = (supplier.rates || []).some(r =>
          norm(r.service || "").includes(reqNorm) || reqNorm.includes(norm(r.service || ""))
        ) || (supplier.listedProducts || supplier.products || []).some(p =>
          norm(p).includes(reqNorm) || reqNorm.includes(norm(p))
        );

        if (hasService) {
          rorItems.push(item.product);
          // Include as a $0 line item so it appears in the quote
          responseItems.push({
            product:      item.product,
            quantity:     Number(item.quantity || 1),
            unit:         item.unitLabel || "service",
            pricePerUnit: 0,
            total:        0,
            available:    true,
            rateOnRequest: true,
            autoSource:   "service_listed"
          });
          continue;
        }
      }
      missingItems.push(item.product);
      continue;
    }

    const qty       = Number(item.quantity || 1);
    const unitPrice = Number(match.amount);
    const total     = Number((qty * unitPrice).toFixed(2));
    // Use seller's catalogue name as the display name in the quote.
    // If buyer typed a sentence ("geyser leaking"), we show the seller's clean
    // service name ("Geyser Repair & Service") in the quote instead.
    const displayName = (match.product && match.product !== item.product)
      ? match.product
      : item.product;
    // Store buyer's original text as a note if it differs from the catalogue name
    const buyerNote = (match.product && match.product.toLowerCase() !== item.product.toLowerCase())
      ? item.product
      : "";

    responseItems.push({
      product:      displayName,
      buyerNote,
      quantity:     qty,
      unit:         match.unit || item.unitLabel || "each",
      pricePerUnit: unitPrice,
      total,
      available:    true,
      autoSource:   match.source || "unknown"
    });
  }

  const totalAmount = Number(
    responseItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2)
  );

  return {
    responseItems,
    missingItems,
    rorItems,
    totalAmount
  };
}
function parseBulkOrderInput(text = "") {
  const raw = String(text || "").trim();
  if (!raw) return [];

  const lines = raw
    .split(/\n+/)
    .map(s => s.trim())
    .filter(Boolean)
    .filter(line => {
      const normalized = line.toLowerCase();

      // ignore headings / section labels
      if (/^stage\s*\d+\b/i.test(normalized)) return false;
      if (/^section\s*\d+\b/i.test(normalized)) return false;
      if (/^phase\s*\d+\b/i.test(normalized)) return false;
      if (/^[a-z\s]+material\s*:?$/i.test(normalized)) return false;
      if (/^[a-z\s]+items?\s*:?$/i.test(normalized)) return false;

      return true;
    });

  return lines.map(part => {
    const clean = part
      .replace(/^[-•*]\s*/, "")
      .replace(/\s+/g, " ")
      .trim();

    // examples:
    // 110 access tees x2
    // vent valves x 2
    // cement 20 bags
    // rice 5kg
    // bath tub standard x1
    let m =
      clean.match(/^(.+?)\s+x\s*(\d+(?:\.\d+)?)\s*([a-zA-Z]+)?$/i) ||
      clean.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z]+)?$/i);

    if (!m) {
      return {
        raw: clean,
        product: clean,
        quantity: 1,
        unitLabel: "units",
        valid: false
      };
    }

    return {
      raw: clean,
      product: m[1].trim(),
      quantity: Number(m[2]),
      unitLabel: (m[3] || "units").trim(),
      valid: true
    };
  });
}


function normalizeEcocashNumber(input, fallbackWhatsApp) {
  const raw = (input || "").replace(/\D+/g, "");
  const fb = (fallbackWhatsApp || "").replace(/\D+/g, "");
  let phone = (input || "").trim().toLowerCase() === "same" ? fb : raw;
  if (phone.startsWith("263") && phone.length === 12) return "0" + phone.slice(3);
  if (phone.startsWith("0") && phone.length === 10) return phone;
  if (phone.length === 9 && phone.startsWith("7")) return "0" + phone;
  return null;
}

function getSupplierCatalogueSourceItems(supplier) {
  if (!supplier) return [];

  if (supplier.profileType === "service") {
    // Use rates[] if available - they have prices
    const rateItems = (supplier.rates || [])
      .filter(r => normalizeProductName(r?.service || ""))
      .map(r => ({
        name: String(r.service).trim(),
        priceLabel: formatSupplierRateDisplay(r.rate || ""),
        rawPrice: parseSupplierRateValue(r.rate || ""),
        unit: parseSupplierRateUnit(r.rate || "") || "job"
      }));

    if (rateItems.length) return rateItems;

    // No rates yet - fall back to products[] and listedProducts[]
    const seen = new Set();
    const fallbackItems = [];
    const allServiceItems = [
      ...(supplier.listedProducts || []),
      ...(supplier.products || [])
    ];
    for (const svcName of allServiceItems) {
      if (!svcName || svcName === "pending_upload") continue;
      const clean = String(svcName).trim();
      const norm = normalizeProductName(clean);
      if (!norm || seen.has(norm)) continue;
      seen.add(norm);
      fallbackItems.push({
        name: clean,
        priceLabel: "",
        rawPrice: null,
        unit: "job"
      });
    }
    return fallbackItems;
  }

  const listedProducts = (supplier.listedProducts || [])
    .filter(p => p && p !== "pending_upload")
    .filter(p => normalizeProductName(p));

  if (!listedProducts.length) return [];

  const pricedMap = new Map();
  for (const p of (supplier.prices || [])) {
    const key = normalizeProductName(p?.product || "");
    if (!key) continue;
    if (p?.inStock === false) continue;
    pricedMap.set(key, p);
  }

  return listedProducts.map(name => {
    const match = pricedMap.get(normalizeProductName(name));
    return {
      name: String(name).trim(),
      priceLabel: match ? `$${Number(match.amount).toFixed(2)}/${match.unit || "each"}` : "",
      rawPrice: match ? Number(match.amount) : null,
      unit: match?.unit || "each"
    };
  });
}

function getFilteredSupplierCatalogueItems(supplier, searchTerm = "") {
  const items = getSupplierCatalogueSourceItems(supplier);
  const q = normalizeProductName(searchTerm || "");

  if (!q) return items;

  return items.filter(item => {
    const n = normalizeProductName(item.name);
    return n.includes(q) || q.includes(n);
  });
}


function formatCatalogueHeader({
  supplier,
  page,
  totalPages,
  totalItems,
  searchTerm = "",
  cartCount = 0,
  selectionMode = "catalogue"
}) {
  const label = supplier?.businessName || "Supplier";
  const itemWord = supplier?.profileType === "service" ? "service" : "product";

  const title =
    selectionMode === "search_pick" && searchTerm
      ? `🎯 *Choose exact ${itemWord} for: ${searchTerm}*`
      : `🛍 *${label} Catalogue*`;

  const supplierLine =
    selectionMode === "search_pick" ? `\n🏪 ${label}` : "";

  const searchLine =
    searchTerm ? `\n🔎 Search: *${searchTerm}*` : "";

  const cartLine =
    cartCount > 0 ? `\n🛒 Cart: ${cartCount} item${cartCount === 1 ? "" : "s"}` : "";

  const helperLine =
    selectionMode === "search_pick"
      ? `\nTap the exact ${itemWord} you want before it is added to cart.`
      : "";

  return (
    `${title}` +
    `${supplierLine}` +
    `${searchLine}` +
    `${cartLine}` +
    `${helperLine}\n\n` +
    `Page ${page + 1} of ${totalPages} • ${totalItems} item${totalItems === 1 ? "" : "s"}`
  );
}



function isCategoryBrowseContext({ biz, sess }) {
  const search = biz?.sessionData?.supplierSearch || {};
  const sessType = sess?.tempData?.supplierSearchType || null;
  const sessCategory = sess?.tempData?.supplierSearchCategory || null;
  const sessProduct = sess?.tempData?.supplierSearchProduct || null;

  const category = search.category || sessCategory || null;
  const product = search.product || sessProduct || null;
  const type = search.type || sessType || null;

  return Boolean(type && category && !product);
}

async function _sendSupplierShoppingHub(from, supplier, cart = [], opts = {}) {
  const isService = supplier?.profileType === "service";
  const cartCount = Array.isArray(cart) ? cart.length : 0;

  const subtitle =
    opts.fromCategory
      ? `Browse this ${isService ? "service provider" : "supplier"} before choosing exact ${isService ? "service" : "item"}.`
      : `Choose how you want to shop from this ${isService ? "provider" : "supplier"}.`;

  const addressLine = supplier.address
    ? `\n📍 ${supplier.address}`
    : `\n📍 ${supplier.location?.area || ""}${supplier.location?.area && supplier.location?.city ? ", " : ""}${supplier.location?.city || ""}`;

  const contactLine = supplier.contactDetails
    ? `\n📞 ${supplier.contactDetails}`
    : "";
  const websiteLine = supplier.website
    ? `\n🌐 ${supplier.website}`
    : "";

  const rows = [
    {
      id: `sup_catalog_page_open_${supplier._id}`,
      title: "📚 View Catalogue"
    },
    {
      id: `sup_catalogue_search_${supplier._id}`,
      title: isService ? "🔎 Search Services" : "🔎 Search Products"
    },
    {
      id: `sup_number_page_open_${supplier._id}`,
      title: "⚡ Quick Order"
    },
    {
      id: `sup_request_quote_supplier_${supplier._id}`,
      title: "📋 Request Quote"
    },
    {
      id: `sup_ask_availability_${supplier._id}`,
      title: isService ? "❓ Ask Availability" : "❓ Ask Stock"
    },
    {
      id: `sup_cart_view_${supplier._id}`,
      title: `🛒 View Cart${cartCount ? ` (${cartCount})` : ""}`
    },
    {
      id: "sup_back_to_search_results",
      title: "⬅ Back to Results"
    }
  ];

  return sendList(
    from,
    `🛍 *${supplier.businessName}*` +
      `${addressLine}` +
      `${contactLine}` +
      `${websiteLine}` +
      `\n🛒 Cart: ${cartCount} item${cartCount === 1 ? "" : "s"}\n\n` +
      `${subtitle}`,
    rows
  );
}
function upsertCartItemToFront(cart = [], nextItem = {}) {
  const nextCart = Array.isArray(cart) ? [...cart] : [];
  const existingIndex = nextCart.findIndex(
    item => String(item.product || "").toLowerCase() === String(nextItem.product || "").toLowerCase()
  );

  if (existingIndex >= 0) {
    const existing = nextCart[existingIndex];
    const merged = {
      ...existing,
      quantity: Number(existing.quantity || 0) + Number(nextItem.quantity || 1)
    };

    if (typeof merged.pricePerUnit === "number" && !Number.isNaN(merged.pricePerUnit)) {
      merged.total = Number((merged.quantity * merged.pricePerUnit).toFixed(2));
    }

    nextCart.splice(existingIndex, 1);
    nextCart.unshift(merged);
    return nextCart;
  }

  const fresh = {
    ...nextItem,
    quantity: Number(nextItem.quantity || 1),
    total:
      typeof nextItem.pricePerUnit === "number" && !Number.isNaN(nextItem.pricePerUnit)
        ? Number((Number(nextItem.quantity || 1) * nextItem.pricePerUnit).toFixed(2))
        : null
  };

  nextCart.unshift(fresh);
  return nextCart;
}

async function _sendSelectedSearchItemPreview(from, supplier, selectedItem, cart = [], opts = {}) {
  const isService = supplier?.profileType === "service";
  const priceLine =
    typeof selectedItem?.pricePerUnit === "number" && !Number.isNaN(selectedItem.pricePerUnit)
      ? `💵 Price: $${Number(selectedItem.pricePerUnit).toFixed(2)}/${selectedItem.unit || (isService ? "job" : "each")}`
      : `💵 Price: To be confirmed by supplier`;

  const cartCount = Array.isArray(cart) ? cart.length : 0;
  const moreMatchesId = opts.moreMatchesId || "find_supplier";
  const fullCatalogueId = `sup_catalog_page_open_${supplier._id}`;

  await sendList(
    from,
    `✅ *Selected ${isService ? "Service" : "Item"}*\n\n` +
      `🏪 Supplier: ${supplier.businessName}\n` +
      `${isService ? "🔧" : "📦"} ${selectedItem.product}\n` +
      `${priceLine}\n` +
      `🔢 Quantity: ${Number(selectedItem.quantity || 1)}\n` +
      `🛒 Cart: ${cartCount} item${cartCount === 1 ? "" : "s"}`,
    [
      {
        id: `sup_item_preview_add_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: "➕ Add to Cart"
      },
      {
        id: `sup_item_preview_order_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: "⚡ Order This Now"
      },
      {
        id: moreMatchesId,
        title: "🔎 View More Similar"
      },
      {
        id: fullCatalogueId,
        title: "📚 Full Catalogue"
      },
      {
        id: `sup_cart_view_${supplier._id}`,
        title: "🛒 View Cart"
      }
    ]
  );

  return _sendSelectedItemExtraActions(from, supplier, selectedItem, opts);
}
async function _sendSelectedSupplierItemPreview(from, supplier, selectedItem, cart = [], opts = {}) {
  const isService = supplier?.profileType === "service";
  const quantity = Number(opts.quantity || 1);
  const priceLine =
    typeof selectedItem?.pricePerUnit === "number"
      ? `💵 Price: $${Number(selectedItem.pricePerUnit).toFixed(2)}/${selectedItem.unit || (isService ? "job" : "each")}`
      : `💵 Price: To be confirmed by supplier`;

  const cartCount = Array.isArray(cart) ? cart.length : 0;
  const searchTerm = opts.searchTerm || "";

  await sendButtons(from, {
    text:
      `✅ *Selected ${isService ? "Service" : "Item"}*\n\n` +
      `🏪 Supplier: ${supplier.businessName}\n` +
      `${isService ? "🔧" : "📦"} ${selectedItem.product}\n` +
      `${priceLine}\n` +
      `🔢 Quantity: ${quantity}\n` +
      `🛒 Cart: ${cartCount} item${cartCount === 1 ? "" : "s"}` +
      (searchTerm ? `\n🔎 Search: ${searchTerm}` : "") +
      `\n\nWhat would you like to do next?`,
    buttons: [
      {
        id: `sup_item_preview_order_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: isService ? "✅ Confirm Booking" : "✅ Place Order"
      },
      {
        id: `sup_item_preview_add_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: isService ? "➕ Add Service" : "➕ Add to Cart"
      },
      {
        id: `sup_cart_view_${supplier._id}`,
        title: "🛒 View Cart"
      }
    ]
  });

  return _sendSelectedItemExtraActions(from, supplier, selectedItem, opts);
}


async function _sendSupplierQuantityPicker(from, supplier, selectedItem, cart = [], opts = {}) {
  const isService = supplier?.profileType === "service";
  const priceLine =
    typeof selectedItem?.pricePerUnit === "number" && !Number.isNaN(selectedItem.pricePerUnit)
      ? `\n💵 Price: $${Number(selectedItem.pricePerUnit).toFixed(2)}/${selectedItem.unit || (isService ? "job" : "each")}`
      : `\n💵 Price: To be confirmed by supplier`;

  const rows = [1, 2, 3, 5, 10].map(q => ({
    id: `sup_qty_pick_${supplier._id}_${encodeURIComponent(selectedItem.product)}_${q}`,
    title: `Qty ${q}`
  }));

  rows.push({ id: `sup_cart_view_${supplier._id}`, title: "🛒 View Cart" });

  if (opts.backId) {
    rows.push({ id: opts.backId, title: "⬅ Back" });
  } else {
    rows.push({ id: `sup_catalog_page_open_${supplier._id}`, title: "⬅ Back to Catalogue" });
  }

  return sendList(
    from,
    `🔢 *Choose Quantity*\n\n` +
    `🏪 ${supplier.businessName}\n` +
    `${isService ? "🔧" : "📦"} ${selectedItem.product}` +
    `${priceLine}\n` +
    `🛒 Cart: ${cart.length} item${cart.length === 1 ? "" : "s"}`,
    rows
  );
}

async function getCurrentOrderCart({ biz, phone }) {
  if (biz) return biz.sessionData?.orderCart || [];
  const sess = await UserSession.findOne({ phone });
  return sess?.tempData?.orderCart || [];
}

async function persistOrderFlowState({ biz, phone, patch = {}, unset = {} }) {
  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), ...patch };
    for (const key of Object.keys(unset)) delete biz.sessionData[key];
    await saveBizSafe(biz);
  }

  const setDoc = {};
  const unsetDoc = {};

  for (const [k, v] of Object.entries(patch)) {
    setDoc[`tempData.${k}`] = v;
  }

  for (const k of Object.keys(unset)) {
    unsetDoc[`tempData.${k}`] = "";
  }

  const update = {};
  if (Object.keys(setDoc).length) update.$set = setDoc;
  if (Object.keys(unsetDoc).length) update.$unset = unsetDoc;

  if (Object.keys(update).length) {
    await UserSession.findOneAndUpdate({ phone }, update, { upsert: true });
  }
}




async function clearBuyerOrderContext({ biz, phone, keepSupplierSearch = true }) {
  if (biz) {
    const nextSessionData = { ...(biz.sessionData || {}) };

    delete nextSessionData.orderSupplierId;
    delete nextSessionData.orderCart;
    delete nextSessionData.orderItems;
    delete nextSessionData.orderProduct;
    delete nextSessionData.orderQuantity;
    delete nextSessionData.orderIsService;
    delete nextSessionData.orderBrowseMode;
    delete nextSessionData.orderCataloguePage;
    delete nextSessionData.orderCatalogueSearch;

    if (!keepSupplierSearch) {
      delete nextSessionData.supplierSearch;
      delete nextSessionData.searchResults;
      delete nextSessionData.searchPage;
    }

    biz.sessionData = nextSessionData;

    // only reset state if it was part of buyer ordering
    if (
      biz.sessionState === "supplier_order_picking" ||
      biz.sessionState === "supplier_order_product" ||
      biz.sessionState === "supplier_order_address"
    ) {
      biz.sessionState = "ready";
    }

    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.orderState": "",
        "tempData.orderSupplierId": "",
        "tempData.orderCart": "",
        "tempData.orderItems": "",
        "tempData.orderProduct": "",
        "tempData.orderQuantity": "",
        "tempData.orderIsService": "",
        "tempData.orderBrowseMode": "",
        "tempData.orderCataloguePage": "",
        "tempData.orderCatalogueSearch": ""
      }
    },
    { upsert: true }
  );
}



async function _sendPostSearchActions(from, opts = {}) {
  const isOfferResults = opts.resultMode === "offers";
  const label = opts.product ? ` for *${opts.product}*` : "";

  return sendButtons(from, {
    text:
      `What would you like to do next${label}?`,
    buttons: [
      {
        id: isOfferResults ? "sup_request_quote_search" : "sup_request_quote_search",
        title: "📋 Request Quote"
      },
      {
        id: "sup_save_search_current",
        title: "💾 Save Search"
      },
      {
        id: "find_supplier",
        title: "🔍 Search Again"
      }
    ]
  });
}

async function _sendSelectedItemExtraActions(from, supplier, selectedItem, opts = {}) {
  const isService = supplier?.profileType === "service";

  return sendButtons(from, {
    text:
      `${isService ? "Need pricing first or want to ask before ordering?" : "Need pricing first or want to ask before ordering?"}`,
    buttons: [
      {
        id: `sup_request_quote_supplier_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: "📋 Request Quote"
      },
      {
        id: `sup_ask_availability_${supplier._id}_${encodeURIComponent(selectedItem.product)}`,
        title: isService ? "❓ Ask Availability" : "❓ Ask Stock"
      },
      {
        id: `sup_cart_view_${supplier._id}`,
        title: "🛒 View Cart"
      }
    ]
  });
}

async function _saveCurrentSearchForBuyer({ phone, biz, fallback = {} }) {
  const product =
    biz?.sessionData?.supplierSearch?.product ||
    fallback.product ||
    null;

  const city =
    biz?.sessionData?.supplierSearch?.city ||
    fallback.city ||
    null;

  const area =
    biz?.sessionData?.supplierSearch?.area ||
    fallback.area ||
    null;

  const profileType =
    biz?.sessionData?.supplierSearch?.type ||
    fallback.profileType ||
    null;

  const payload = {
    product,
    city,
    area,
    profileType,
    savedAt: new Date()
  };

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $push: {
        "tempData.savedSearches": {
          $each: [payload],
          $slice: -20
        }
      }
    },
    { upsert: true }
  );

  return payload;
}

async function notifySuppliersOfLiveDemand({
  product,
  city = null,
  area = null,
  profileType = null,
  results = []
}) {
  try {
    const cleanProduct = normalizeProductName(product || "");
    if (!cleanProduct) return;

    const supplierIds = [
      ...new Set(
        (results || [])
          .map(r =>
            r?.supplierId ||
            r?.supplier?._id ||
            r?._id ||
            null
          )
          .filter(Boolean)
          .map(String)
      )
    ];

    if (!supplierIds.length) return;

    const suppliers = await SupplierProfile.find({
      _id: { $in: supplierIds },
      active: true
    }).lean();

    for (const supplier of suppliers) {
      try {
        const locationLine = area
          ? `📍 ${area}${city ? `, ${city}` : ""}`
          : city
            ? `📍 ${city}`
            : `📍 Zimbabwe`;

        const typeLine =
          profileType === "service"
            ? "\n🔧 Buyer is searching for a service"
            : profileType === "product"
              ? "\n📦 Buyer is searching for a product"
              : "";

        await sendButtons(supplier.phone, {
          text:
            `🔥 *New Buyer Search*\n\n` +
            `🔎 ${product}\n` +
            `${locationLine}` +
            `${typeLine}\n\n` +
            `A buyer is actively searching on ZimQuote right now.`,
          buttons: [
            { id: "my_supplier_account", title: "🏪 My Store" },
            { id: "suppliers_home", title: "🛒 Marketplace" }
          ]
        });
      } catch (innerErr) {
        console.error("[LIVE DEMAND ALERT]", innerErr.message);
      }
    }
  } catch (err) {
    console.error("[notifySuppliersOfLiveDemand]", err.message);
  }
}



function isBuyerRequestHeadingLine(line = "") {
  const raw = String(line || "").trim();
  if (!raw) return true;

  const clean = raw
    .replace(/[–-]/g, "-")
    .replace(/\s+/g, " ")
    .trim();

  if (!clean) return true;

  if (/^stage\s*\d+/i.test(clean)) return true;
  if (/^(bonding material|remainder waste fittings|appliances\/setting|water\/tubing|sewer\/drainlaying)$/i.test(clean)) return true;

  // short label-style headings without qty
  if (
    clean.length <= 40 &&
    !/(?:x\s*\d+|\d+\s*(?:length|lengths|pair|pairs|bag|bags|tonne|tonnes|kg|g|mm|ml|mls|job|hr|hours?))/i.test(clean) &&
    !/\d/.test(clean)
  ) {
    return true;
  }

  return false;
}

function normalizeBuyerRequestLine(line = "") {
  let s = String(line || "")
    .replace(/[’′`]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[•▪◦●]/g, "")
    .replace(/\s*x\s*/gi, " x")
    .replace(/\)\s*x/gi, ") x")
    .replace(/,+$/g, "")
    .replace(/\s+/g, " ")
    .trim();

  // Strip problem-statement prefixes so "my geyser is leaking" -> "geyser leaking"
  // This normalises natural Zimbabwean English into product/service names.
  s = s
    .replace(/^(i need someone to |i need |i want |please |kindly |can you |could you |we need |we want )/i, "")
    .replace(/^(my |our |the |a |an )/i, "")
    .replace(/^(there is a |there is |im having |i am having |i have a |i have |i've got a |i've got )/i, "")
    .replace(/\b(is leaking|is broken|is faulty|is not working|is damaged|needs repair|needs fixing|needs replacement|has a leak|has a fault)\b/gi, "repair")
    .replace(/\b(install|installation|fitting|fit|fix|repair|service|replace|replacement)\b/gi, (m) => m)
    .replace(/\s+/g, " ")
    .trim();

  return s;
}

function parseSingleBuyerRequestLine(line = "") {
  const clean = normalizeBuyerRequestLine(line);
  if (!clean || isBuyerRequestHeadingLine(clean)) return null;

  // examples:
  // 110 Access tees x2
  // Vent valves x2
  // 15mm cu elbws x 78
  // Bath tub(standard) x1
  // Cement x2 bags
  // Pitsand x1 tonne
  // ── Measurement suffixes - keep attached to product name, never treat as unit ──
  const _MSUF = new Set([
    "mm","cm","m","km","ml","l","kg","g","mg","lb","lbs","oz","ft","in","inch",
    "psi","bar","kpa","mpa","kw","kva","hp","v","volt","amp","amps","watt","w","a","ah",
    "litre","litres","liter","liters","tonne","tonnes","ton","tons","metre","metres",
    "meter","meters","gallon","gallons","sqm","sqft","kwh","mhz","ghz","mb","gb","tb"
  ]);

  // Case 1: explicit "x N unit?" - always treat as qty
  const _xm = clean.match(/^(.+?)\s+x\s*(\d+(?:\.\d+)?)\s*([a-zA-Z]*)$/i);
  if (_xm) {
    const _prod = String(_xm[1] || "").trim().replace(/[,:;.\-]+$/g, "").trim();
    const _qty  = Number(_xm[2] || 1);
    const _unit = String(_xm[3] || "units").trim().toLowerCase() || "units";
    if (_prod) return { product: _prod, quantity: Number.isFinite(_qty) && _qty > 0 ? _qty : 1, unitLabel: _unit, notes: "", valid: true };
  }

  // Case 2: "N unit" at end - only qty if unit is not a measurement suffix
  const _bm = clean.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z]+)$/i);
  if (_bm) {
    const _prod = String(_bm[1] || "").trim().replace(/[,:;.\-]+$/g, "").trim();
    const _qty  = Number(_bm[2] || 1);
    const _unit = String(_bm[3] || "").trim().toLowerCase();
    const _isMeas = _MSUF.has(_unit);
    const _prodEndsMeas = /\d+(mm|cm|kg|ml|m|ft|in|psi|bar|v|w|a|kw|kva|hp|ah|litre|liter)$/i.test(_prod);
    if (!_isMeas && !_prodEndsMeas && _prod) {
      return { product: _prod, quantity: Number.isFinite(_qty) && _qty > 0 ? _qty : 1, unitLabel: _unit, notes: "", valid: true };
    }
  }

  // Case 3: No quantity found - default qty=1, whole clean string is product
  return {
    product: clean.replace(/[,:;.\-]+$/g, "").trim(),
    quantity: 1,
    unitLabel: "units",
    notes: "",
    valid: false
  };
}

function parseBuyerRequestItems(text = "") {
  const raw = String(text || "").trim();
  if (!raw) return [];

  // ── NATURAL LANGUAGE SENTENCE DETECTION ──────────────────────────────────
  // If the input is a full sentence (starts with conversational phrasing OR is
  // > 80 chars with no newlines and no quantity pattern), use the NLP extractor.
  // This handles professional requests like:
  //   "I need a Bill of Quantities for a 4-bed house in Ruwa, 280m²"
  //   "Please quote for architectural drawings, 3-bedroom residential"
  //   "Need an electrician for DB board fault, Borrowdale Harare"
  const _isLongSentence = raw.length > 60 && !raw.includes("\n") && !/\bx\s*\d+/i.test(raw);
  const _startsNaturally = /^(i need|i want|we need|we want|please|can you|could you|kindly|need |looking for|good morning|good afternoon|good evening|hi |hello )/i.test(raw.trim());

  if (_isLongSentence || _startsNaturally) {
    const nlResult = extractNaturalLanguageRequest(raw);
    if (nlResult) {
      return [{
        product:   nlResult.product,
        quantity:  1,
        unitLabel: "job",
        notes:     nlResult.notes  // full original text kept as notes for seller
      }];
    }
  }

  // ── STRUCTURED ITEM LIST (existing parser) ────────────────────────────────
  const rawLines = raw
    .split(/\n+/)
    .map(line => normalizeBuyerRequestLine(line))
    .filter(Boolean);

  const mergedLines = [];
  for (let i = 0; i < rawLines.length; i++) {
    let current = rawLines[i];
    if (isBuyerRequestHeadingLine(current)) continue;

    const currentHasQty = /\bx\s*\d+/i.test(current);

    // join wrapped lines like:
    // "22mm cu to cu"
    // "couplings x6"
    if (!currentHasQty && i + 1 < rawLines.length) {
      const next = rawLines[i + 1];
      if (next && !isBuyerRequestHeadingLine(next) && /\bx\s*\d+/i.test(next)) {
        current = `${current} ${next}`.replace(/\s+/g, " ").trim();
        i += 1;
      }
    }

    mergedLines.push(current);
  }

  const parsed = mergedLines
    .map(parseSingleBuyerRequestLine)
    .filter(Boolean)
    .filter(item => normalizeProductName(item.product || ""));

  // fallback for very small comma-style input
  if (!parsed.length) {
    const loose = parseBulkOrderInput(raw)
      .filter(i => i && normalizeProductName(i.product || ""))
      .map(i => ({
        product: String(i.product || "").trim(),
        quantity: Number(i.quantity || 1),
        unitLabel: i.unitLabel || "units",
        notes: ""
      }));

    return loose;
  }

  return parsed.map(item => ({
    product: item.product,
    quantity: Number(item.quantity || 1),
    unitLabel: item.unitLabel || "units",
    notes: item.notes || ""
  }));
}

function formatBuyerRequestItems(items = [], limit = 15) {
  const visible = items.slice(0, limit);
  const lines = visible.map((item, idx) => {
    const qty = Number(item.quantity || 1);
    const unitLabel = item.unitLabel || "units";
    return `${idx + 1}. ${item.product} x${qty}${unitLabel && unitLabel !== "units" ? ` ${unitLabel}` : ""}`;
  });

  if (items.length > limit) {
    lines.push(`… and ${items.length - limit} more item${items.length - limit === 1 ? "" : "s"}`);
  }

  return lines.join("\n");
}

function parseBuyerRequestLocationInput(text = "") {
  const raw = String(text || "").trim();
  if (!raw) return { city: null, area: null };

  const lower = raw.toLowerCase();
  const matchedCity = SUPPLIER_CITIES.find(c => lower.includes(String(c).toLowerCase())) || null;

  let area = null;
  if (matchedCity) {
    area = raw
      .replace(new RegExp(matchedCity, "i"), "")
      .replace(/^[,\-\s]+|[,\-\s]+$/g, "")
      .trim() || null;
  }

  if (!matchedCity && raw.includes(",")) {
    const parts = raw.split(",").map(p => p.trim()).filter(Boolean);
    if (parts.length >= 2) {
      const cityCandidate = parts[parts.length - 1];
      const exactCity = SUPPLIER_CITIES.find(c => c.toLowerCase() === cityCandidate.toLowerCase()) || null;
      if (exactCity) {
        return {
          city: exactCity,
          area: parts.slice(0, -1).join(", ").trim() || null
        };
      }
    }
  }

  return {
    city: matchedCity,
    area
  };
}

function parseInlineSimpleBuyerRequest(text = "") {
  const raw = String(text || "").trim();
  if (!raw) {
    return {
      items: [],
      city: null,
      area: null,
      itemText: ""
    };
  }

  // Reuse the same shortcode parser used by Browse & Shop
  const parsed =
    parseShortcodeSearch(raw) ||
    parseShortcodeSearch(raw.startsWith("find ") ? raw : `find ${raw}`);

  if (!parsed || !parsed.product) {
    return {
      items: [],
      city: null,
      area: null,
      itemText: raw
    };
  }

  let productText = String(parsed.product || "").trim();

  // ── Quantity extraction ───────────────────────────────────────────────────────
  // Rules:
  //  1. "x 5" or "x5" anywhere at end → explicit qty, always accepted
  //  2. Bare trailing number with NO unit → qty, e.g. "cement 10"
  //  3. Bare trailing number WITH a measurement unit suffix → PART OF PRODUCT NAME
  //     e.g. "ball valve 20mm" → product="ball valve 20mm", qty=1 (NOT qty=20)
  //
  // Measurement suffixes that must stay attached to the product (not treated as units):
  const MEASUREMENT_SUFFIXES = new Set([
    "mm","cm","m","km","ml","l","kg","g","mg","lb","lbs","oz","ft","in","inch",
    "psi","bar","kpa","mpa","kw","kva","hp","v","volt","amp","amps","watt","w","a","ah",
    "litre","litres","liter","liters","tonne","tonnes","ton","tons","metre","metres",
    "meter","meters","gallon","gallons","inch","inches","sqm","sqft","kwh","mhz","ghz",
    "mb","gb","tb","rpm","nm","khz","mw","gw"
  ]);

  let quantity = 1;
  let unitLabel = "units";

  // Case 1: explicit "x N unit?" at end - always treat as qty
  const explicitQtyMatch = productText.match(/^(.+?)\s+x\s*(\d+(?:\.\d+)?)\s*([a-zA-Z]*)$/i);
  if (explicitQtyMatch) {
    const maybeProduct = String(explicitQtyMatch[1] || "").trim();
    const maybeQty     = Number(explicitQtyMatch[2] || 1);
    const maybeUnit    = String(explicitQtyMatch[3] || "").trim().toLowerCase();
    if (maybeProduct && Number.isFinite(maybeQty) && maybeQty > 0) {
      return {
        items: [{ product: maybeProduct, quantity: maybeQty, unitLabel: maybeUnit || "units", notes: "" }],
        city: parsed.city || null, area: parsed.area || null, itemText: maybeProduct
      };
    }
  }

  // Case 2: bare trailing "N unit?" - only treat as qty if unit is NOT a measurement suffix
  const bareQtyMatch = productText.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z]*)$/i);
  if (bareQtyMatch) {
    const maybeProduct = String(bareQtyMatch[1] || "").trim();
    const maybeQty     = Number(bareQtyMatch[2] || 1);
    const maybeUnit    = String(bareQtyMatch[3] || "").trim().toLowerCase();

    // If the unit part is a measurement suffix → keep whole string as product name, qty=1
    const isMeasurement = maybeUnit && MEASUREMENT_SUFFIXES.has(maybeUnit);
    // Also guard: if the "product" part itself ends with a measurement-looking pattern
    // e.g. "20mm" → don't split
    const productEndsMeasurement = /\d+\s*(mm|cm|kg|ml|l|m|ft|in|psi|bar|v|w|a|hp|kw|kva|ah|litre|litr)$/i.test(maybeProduct);

    if (!isMeasurement && !productEndsMeasurement && maybeProduct && Number.isFinite(maybeQty) && maybeQty > 0 && maybeQty < 10000) {
      return {
        items: [{ product: maybeProduct, quantity: maybeQty, unitLabel: maybeUnit || "units", notes: "" }],
        city: parsed.city || null, area: parsed.area || null, itemText: maybeProduct
      };
    }
  }

  // Case 3: No quantity - default qty=1, full productText is the product name
  return {
    items: [{ product: productText, quantity: 1, unitLabel: "units", notes: "" }],
    city: parsed.city || null, area: parsed.area || null, itemText: productText
  };
}


function tokenizeProductText(value = "") {
  return normalizeProductName(value)
    .split(" ")
    .map(t => t.trim())
    .filter(Boolean)
    .filter(t => t.length > 1);
}

function scoreVariantCandidate(requestedProduct = "", candidateName = "") {
  const req = normalizeProductName(requestedProduct);
  const cand = normalizeProductName(candidateName);

  if (!req || !cand) return 0;
  if (req === cand) return 100;

  let score = 0;

  if (cand.startsWith(req)) score += 40;
  if (cand.includes(req)) score += 25;
  if (req.includes(cand)) score += 10;

  const reqTokens = tokenizeProductText(req);
  const candTokens = tokenizeProductText(cand);

  for (const token of reqTokens) {
    if (candTokens.includes(token)) score += 8;
    else if (cand.includes(token)) score += 4;
  }

  if (reqTokens.length === 1 && candTokens.length > 1 && cand.includes(reqTokens[0])) {
    score += 12;
  }

  return score;
}

function getSupplierVariantMatches(supplier, requestedProduct = "", opts = {}) {
  const limit = Number(opts.limit || 5);

  const catalogueItems = getSupplierCatalogueSourceItems(supplier) || [];
  const scored = catalogueItems
    .map(item => ({
      ...item,
      score: scoreVariantCandidate(requestedProduct, item.name)
    }))
    .filter(item => item.score > 0)
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;

      const aPriced = typeof a.rawPrice === "number" ? 1 : 0;
      const bPriced = typeof b.rawPrice === "number" ? 1 : 0;
      if (bPriced !== aPriced) return bPriced - aPriced;

      return String(a.name).localeCompare(String(b.name));
    });

  return scored.slice(0, limit);
}

function isStrongSingleVariantMatch(matches = []) {
  if (!matches.length) return false;
  if (matches.length === 1) return true;

  const first = matches[0];
  const second = matches[1];

  if (!first) return false;
  if (!second) return true;

  // clear winner if score gap is good enough
  return (first.score - second.score) >= 12;
}

async function findSuppliersForBuyerRequest({ items = [], city = null, area = null }) {
  // ── Detect whether this is a service request or product request ────────────
  // This drives which supplier type we prioritise and how we filter results.
  const requestIsService = _buyerRequestIsService(items);

  const scoreMap = new Map();
  const topItems = items.slice(0, 5);

  for (const item of topItems) {
    const term = item.product || "";

    // ── Search strategy based on request type ─────────────────────────────────
    // Service request  → search service suppliers first, product suppliers only
    //                    if they have the exact product name (e.g. a plumbing
    //                    supplies shop that also stocks "geyser installation kits")
    // Product request  → search product suppliers first, service suppliers only
    //                    if they appear with a very strong match score
    const primaryType   = requestIsService ? "service"  : "product";
    const secondaryType = requestIsService ? "product"  : "service";

    const primaryResults = await runSupplierSearch({
      city: city || null, product: term, area: area || null, profileType: primaryType
    });
    const secondaryResults = await runSupplierSearch({
      city: city || null, product: term, area: area || null, profileType: secondaryType
    });

    // Score and accumulate - primary type results use their quality score,
    // secondary type results require a high match score (≥25) to avoid
    // e.g. plumbing supplies stores receiving service requests
    const MIN_SECONDARY_SCORE = 25;  // must have rated match in products/rates, not just category

    for (const supplier of primaryResults) {
      const key      = String(supplier._id);
      const matchScore = scoreSupplierMatch(supplier, term);
      const entry    = scoreMap.get(key) || { supplier, score: 0, bestMatch: 0 };
      entry.score   += Math.max(matchScore, 10);  // floor of 10 for appearing in results
      entry.bestMatch = Math.max(entry.bestMatch, matchScore);
      scoreMap.set(key, entry);
    }

    for (const supplier of secondaryResults) {
      const key        = String(supplier._id);
      const matchScore = scoreSupplierMatch(supplier, term);
      // Only include secondary-type suppliers if they have a strong direct match
      // (avoids product suppliers getting service requests and vice versa)
      if (matchScore < MIN_SECONDARY_SCORE) continue;
      const entry = scoreMap.get(key) || { supplier, score: 0, bestMatch: 0 };
      entry.score   += matchScore;
      entry.bestMatch = Math.max(entry.bestMatch, matchScore);
      scoreMap.set(key, entry);
    }
  }

  // ── Filter: if ANY supplier has a strong match (score ≥ 25),
  //   remove weak category-only matches (score < 10) so they don't get spammed
  const allEntries = [...scoreMap.values()].filter(e => e.supplier?.active);
  const bestScore  = allEntries.reduce((m, e) => Math.max(m, e.bestMatch), 0);
  const threshold  = bestScore >= 25 ? 8 : 0;  // raise bar when good matches exist

  return allEntries
    .filter(e => e.bestMatch >= threshold || e.score >= threshold)
    .sort((a, b) => b.score - a.score)
    .map(e => e.supplier)
    .slice(0, 10);
}

function buildBuyerRequestRef(request) {
  return (
    request?.ref ||
    request?.reference ||
    request?.requestRef ||
    `REQ-${String(request?._id || "").slice(-6).toUpperCase()}`
  );
}

function getBuyerRequestKey(request) {
  return String(request?._id || "").trim();
}


async function sendBuyerQuotePdf({ request, supplier, response }) {
  try {
    if (!response || !Array.isArray(response.items) || !response.items.length) {
      return null;
    }

    const ref          = buildBuyerRequestRef(request);
    const supplierName = supplier?.businessName || response?.supplierName || "Supplier";
    const site         = (process.env.SITE_URL || "").replace(/\/$/, "");

    // ── Supplier contact details for the PDF ──────────────────────────────────
    const supplierPhone   = supplier?.contactDetails || response?.supplierPhone || supplier?.phone || "";
    const supplierAddress = [
      supplier?.address,
      supplier?.location?.area,
      supplier?.location?.city
    ].filter(Boolean).join(", ") || "";
    const supplierWebsite = supplier?.website || "";

    // ── Delivery / collection note ────────────────────────────────────────────
   const deliveryNote = request.serviceAddress
  ? `Service address: ${request.serviceAddress}`
  : request.deliveryRequired
    ? `Delivery to buyer required${request.deliveryAddress ? `\nDelivery address: ${request.deliveryAddress}` : ""}`
      : response.deliveryAvailable === true
        ? "Delivery available"
        : "Collection only";

    // ── Buyer info shown on the quote ─────────────────────────────────────────
    const buyerRef  = request.buyerPhone
      ? `WhatsApp: ${request.buyerPhone}`
      : "";
    const buyerArea = request.area
      ? `${request.area}, ${request.city || "Zimbabwe"}`
      : (request.city || "Zimbabwe");

    // ── Build billingTo block - buyer details ─────────────────────────────────
  const billingTo = [
  `Request Ref: ${ref}`,
  `Location: ${buyerArea}`,
  request.deliveryAddress ? `Delivery address: ${request.deliveryAddress}` : "",
  request.serviceAddress ? `Service address: ${request.serviceAddress}` : "",
  buyerRef,
  deliveryNote
].filter(Boolean).join("\n");

    // ── Build supplier address block for bizMeta ──────────────────────────────
    const supplierAddressBlock = [
      supplierAddress,
      supplierPhone  ? `Tel: ${supplierPhone}` : "",
      supplierWebsite ? `Web: ${supplierWebsite}` : ""
    ].filter(Boolean).join("\n");

    // ── Notes / message from supplier ─────────────────────────────────────────
    const supplierNote = response.message
      ? `Note from seller: ${response.message}`
      : "";

    // Build PDF line items - show "Rate on request" for unpriced service items
    const _pdfItems = (response.items || []).map(i => {
      if (i.rateOnRequest) {
        return {
          item:  i.product + " (Rate on request)",
          qty:   Number(i.quantity || 1),
          unit:  0,
          total: 0
        };
      }
      return {
        item:  i.product,
        qty:   Number(i.quantity || 1),
        unit:  Number(i.pricePerUnit || 0),
        total: Number(i.total || 0)
      };
    });

    const { filename } = await generatePDF({
      type:      "quote",
      number:    ref,
      date:      new Date(),
      billingTo,
      notes:     supplierNote || undefined,
      items:     _pdfItems,
      bizMeta: {
        name:     supplierName,
        logoUrl:  supplier?.logoUrl || "",
        address:  supplierAddressBlock,
        _id:      String(supplier?._id || request._id),
        status:   "quotation"
      }
    });

    // Use /quotes/ path - same folder used by working invoice/quote sendDocument calls
    const link = `${site}/docs/generated/quotes/${filename}`;

    // ── Normalize buyer phone ─────────────────────────────────────────────────
    const _normBuyerPdf  = String(request.buyerPhone || "").replace(/\D+/g, "");
    const _fullBuyerPdf  = _normBuyerPdf.startsWith("0") && _normBuyerPdf.length === 10
      ? "263" + _normBuyerPdf.slice(1) : _normBuyerPdf;

    // ── Send the PDF document - same call signature as working invoice/receipt sends ─
    if (!site) {
  console.error("[BUYER QUOTE PDF] SITE_URL is missing. Cannot send public PDF link.");
  return null;
}

await sendDocument(_fullBuyerPdf, {
  link,
  filename,
  caption: `📄 Quotation ${ref} from ${supplierName}`
});
    console.log(`[BUYER QUOTE PDF] PDF dispatched to ${_fullBuyerPdf}: ${filename}`);

    // ── Follow-up text so buyer knows to scroll up for the PDF ───────────────────
    const _followUpText =
      `📄 *Quotation PDF sent above ↑*\n` +
      `📞 To order, contact: ${response.supplierPhone || supplierPhone}\n` +
      `_Reference: ${ref}_`;
    try {
      await sendText(_fullBuyerPdf, _followUpText);
    } catch (_) {}

    return link;
  } catch (err) {
    console.error("[BUYER QUOTE PDF]", err.message);
    return null;
  }
}
async function buildAutoQuoteForSupplier({ supplier, items = [] }) {
  const responseItems = [];
  let matchedCount = 0;
  let totalAmount = 0;

  const ambiguousItems = [];
  const unmatchedItems = [];

  for (const item of items) {
    const requestedName = item.product;

    // 1) try current exact/partial priced match logic first
    const directMatch = findMatchingSupplierPrice(supplier, requestedName);

    if (directMatch && typeof directMatch.amount === "number" && !Number.isNaN(directMatch.amount)) {
      const qty = Number(item.quantity || 1);
      const total = Number((qty * Number(directMatch.amount)).toFixed(2));

      responseItems.push({
        product: directMatch.product || requestedName,
        quantity: qty,
        unit: directMatch.unit || item.unitLabel || "each",
        pricePerUnit: Number(directMatch.amount),
        total,
        available: true
      });

      matchedCount += 1;
      totalAmount += total;
      continue;
    }

    // 2) try broader catalogue variant matching
    const variantMatches = getSupplierVariantMatches(supplier, requestedName, { limit: 5 });

    // only auto-use if there is one strong clear winner AND it has a price
    if (isStrongSingleVariantMatch(variantMatches)) {
      const best = variantMatches[0];

      if (typeof best.rawPrice === "number" && !Number.isNaN(best.rawPrice)) {
        const qty = Number(item.quantity || 1);
        const total = Number((qty * Number(best.rawPrice)).toFixed(2));

        responseItems.push({
          product: best.name || requestedName,
          quantity: qty,
          unit: best.unit || item.unitLabel || "each",
          pricePerUnit: Number(best.rawPrice),
          total,
          available: true
        });

        matchedCount += 1;
        totalAmount += total;
        continue;
      }
    }

    // 3) multiple possible matches = ambiguous, do not fail silently
    if (variantMatches.length) {
      ambiguousItems.push({
        requested: requestedName,
        suggestions: variantMatches.slice(0, 3).map(v => ({
          name: v.name,
          priced: typeof v.rawPrice === "number" && !Number.isNaN(v.rawPrice),
          priceLabel: v.priceLabel || ""
        }))
      });
      continue;
    }

    // 4) nothing similar found
    unmatchedItems.push(requestedName);
  }

  return {
    matchedCount,
    responseItems,
    totalAmount: responseItems.length ? Number(totalAmount.toFixed(2)) : null,
    fullyPriced: responseItems.length === items.length && items.length > 0,
    ambiguousItems,
    unmatchedItems
  };
}

async function sendBuyerRequestResponseToBuyer({ request, supplier, response }) {
  const supplierName = supplier?.businessName || response?.supplierName || "Supplier";
  const ref = buildBuyerRequestRef(request);

  if (response.mode === "unavailable") {
    return sendButtons(request.buyerPhone, {
      text:
        `📭 *Response for ${ref}*\n\n` +
        `🏪 ${supplierName}\n` +
        `This provider is not available for your request right now.`,
      buttons: [
        { id: "find_supplier", title: "🔍 Browse & Shop" },
        { id: "sup_request_sellers", title: "⚡ Request Again" }
      ]
    });
  }

  const pricedItems = (response.items || []).filter(i =>
    i && i.available !== false && Number(i.pricePerUnit) > 0
  );

  const itemLines = pricedItems.length
    ? pricedItems.map(i => {
        const qty = Number(i.quantity || 1);
        const unit = i.unit || "each";
        const unitLabel = ["person", "hour", "hr", "day", "night", "trip", "group", "vehicle"].includes(unit)
          ? `per ${unit}`
          : `/${unit}`;

        return `• ${i.product} x${qty} @ $${Number(i.pricePerUnit).toFixed(2)} ${unitLabel} = $${Number(i.total || 0).toFixed(2)}`;
      }).join("\n")
    : `• Provider sent a message but no priced items were attached.`;

  const totalLine = typeof response.totalAmount === "number"
    ? `\n\n💵 *Total: $${Number(response.totalAmount).toFixed(2)}*`
    : "";

  const pickupLine = request.serviceAddress
    ? `\n📍 Pickup/service point: ${request.serviceAddress}`
    : "";

  const noteLine = response.message
    ? `\n📝 ${response.message}`
    : "";

  const _buyerMsg = {
    text:
      `📨 *New Seller Quote* (${ref})\n\n` +
      `🏪 *${supplierName}*\n\n` +
      `${itemLines}` +
      `${totalLine}` +
      `${pickupLine}` +
      `${noteLine}\n\n` +
      `📞 Contact: ${response.supplierPhone || supplier?.phone || ""}`,
    buttons: [
      { id: `buyer_view_all_quotes_${request._id}`, title: "📊 Compare Quotes" },
      { id: "find_supplier", title: "🛒 Marketplace" }
    ]
  };

  await sendButtons(request.buyerPhone, _buyerMsg);

  if (pricedItems.length) {
    const pdfLink = await sendBuyerQuotePdf({
      request,
      supplier,
      response: { ...response, items: pricedItems }
    });

    if (!pdfLink) {
      await sendText(
        request.buyerPhone,
        `⚠️ The PDF quotation could not be sent, but your quote details are shown above.`
      );
    }
  }
}
export async function notifySuppliersOfBuyerRequest(request) {
  // ── Route to the correct supplier finder ─────────────────────────────────
  // findSuppliersForBuyerRequest uses runSupplierSearch which only searches
  // profileType "product" or "service" - it will NEVER return hospitality suppliers.
  // For hospitality/tourism requests, we must use findSuppliersForRequest from
  // requestMatchEngine which has the full hospitality intent classification.
  const _isTourismNotif = _buyerRequestIsTourism(request.items || []);

  let suppliers;
  if (_isTourismNotif) {
    // Use the requestMatchEngine which correctly finds profileType="hospitality" suppliers
    suppliers = await findSuppliersForRequest({
      items: (request.items || []).map(i => ({ product: i.product || i.service || i.raw || "", ...i })),
      city:  request.city  || null,
      area:  request.area  || null
    });
    console.log(`[BUYER REQ] Tourism/hospitality request → findSuppliersForRequest → ${suppliers.length} suppliers`);
  } else {
    suppliers = await findSuppliersForBuyerRequest({
      items: request.items || [],
      city:  request.city  || null,
      area:  request.area  || null
    });
  }

  const notifiedIds = [];

  for (const supplier of suppliers) {
    // Skip sellers who have paused request notifications
    if (supplier.pauseRequests === true) {
      console.log(`[BUYER REQ] Skipping paused supplier ${supplier.phone}`);
      continue;
    }
    try {
     const ref = buildBuyerRequestRef(request);
const requestKey = getBuyerRequestKey(request);

if (!requestKey) {
  console.error("[BUYER REQ] Cannot notify suppliers: missing request._id", request);
  return 0;
}
      const itemLines = formatBuyerRequestItems(request.items || [], 12);
      const locationLine = request.area
        ? `📍 ${request.area}${request.city ? `, ${request.city}` : ""}`
        : request.city
          ? `📍 ${request.city}`
          : `📍 Zimbabwe`;

        // Build numbered item list with quick-reply guidance
      const _notifItemLines = (request.items || []).map((item, i) => {
        const qty  = Number(item.quantity || 1);
        const unit = item.unitLabel && item.unitLabel !== "units" ? ` ${item.unitLabel}` : "";
        return `${i + 1}. ${item.product} (${qty}${unit})`;
      }).join("\n");
 
      const _notifItemCount  = (request.items || []).length;
      const _notifExamples   = _notifItemCount === 1
        ? `1=12.50`
        : Array.from({ length: Math.min(_notifItemCount, 3) }, (_, i) => `${i + 1}=${(i * 5 + 10).toFixed(2)}`).join(", ");
 
      // Build compact item summary for the template (single line, max 1024 chars)
 // Template variable must be single-line - no newlines allowed
     // Template ping only - full item list shown when supplier taps into chatbot
      const _templateItemCount = (request.items || []).length;

      const _templateLocation = request.area
        ? `${request.area}${request.city ? `, ${request.city}` : ""}`
        : request.city || "Zimbabwe";

      const _isServiceNotif = request.isServiceRequest || _buyerRequestIsService(request.items || []);
      const _deliveryLine = _isServiceNotif
        ? (request.serviceAddress
            ? `📍 Service at: ${request.serviceAddress}`
            : "📍 Client will share their address")
        : request.deliveryRequired
          ? "🚚 Delivery to buyer needed"
          : "🏠 Collection / flexible";

   // Step 1: Send template ping - reaches supplier even outside 24-hour window
     await notifySupplierNewRequestTemplate({
  supplierPhone:        supplier.phone,
  supplier,
  notificationContacts: supplier.notificationContacts || [],
  requestId:            requestKey,
        ref,
        locationText:  _templateLocation,
        itemCount:     _templateItemCount,
        itemSummary:   _notifItemLines,
        deliveryLine:  _deliveryLine,
        fullItemLines: _notifItemLines,
        replyExamples: _notifExamples,
        buyerPhone:    request.buyerPhone || null       // shown only to VIP sellers
      });

      // Step 2: Try to send interactive buttons after the template ping.
      // REALITY: a business-initiated template does NOT open the 24-hour window -
      // only a message FROM the seller does. So this sendButtons DELIVERS only to a
      // seller who has messaged in the last 24h (warm session). For a COLD seller it
      // is rejected by WhatsApp (logged below, non-fatal) and they instead act by
      // REPLYING to the template, which opens the window and triggers the same
      // interactive card via the awaiting_offer_intro handler.
      const _supplierPhone = String(supplier.phone).replace(/\D+/g, "");
      const _normalizedSupplierPhone = _supplierPhone.startsWith("0") && _supplierPhone.length === 10
        ? "263" + _supplierPhone.slice(1) : _supplierPhone;

      // ── Step 2: Set state to "awaiting_offer_intro" ─────────────────────────────
      // FIX: store requestIds in a map (sellerPendingRequests) so a notification
      // contact on multiple sellers' lists never has one request overwrite another.
      const _reqId = requestKey;

      async function _setSellerRequestSession(targetPhone) {
        const _existing = await UserSession.findOne({ phone: targetPhone }).lean();
        let _map = {};
        try {
          const _raw = _existing?.tempData?.sellerPendingRequests;
          _map = _raw ? (typeof _raw === "object" && !Array.isArray(_raw) ? _raw : JSON.parse(_raw)) : {};
        } catch (_) { _map = {}; }

        // Prune entries older than 48 hours
        const _cutoff = Date.now() - 48 * 60 * 60 * 1000;
        for (const key of Object.keys(_map)) {
          if ((_map[key]?.storedAt || 0) < _cutoff) delete _map[key];
        }
        _map[_reqId] = { state: "awaiting_offer_intro", storedAt: Date.now(), requestId: _reqId, role: "primary" };

        await UserSession.findOneAndUpdate(
          { phone: targetPhone },
          {
            $set: {
              // New map - safely accumulates multiple concurrent request pointers
              "tempData.sellerPendingRequests":    _map,
              // Legacy scalar - kept for backward compat with in-flight sessions
              "tempData.sellerRequestReplyState":  "awaiting_offer_intro",
              "tempData.sellerRequestId":           _reqId
            }
          },
          { upsert: true }
        );
      }

      await _setSellerRequestSession(_normalizedSupplierPhone);
      console.log(`[BUYER REQ] Session set to awaiting_offer_intro for ${_normalizedSupplierPhone} (req ${_reqId})`);

      // ── Step 2b: Try interactive buttons (delivers to WARM sessions only) ───────
      // Warm seller (messaged in last 24h): buttons arrive instantly. Cold seller:
      // WhatsApp rejects this (caught below) and the seller replies to the template
      // instead, which opens the window and shows the same card. VIP sellers also
      // get the buyer phone in the card and (now) in the v1 template itself.
      try {
        const _step2IsService = request.isServiceRequest || _buyerRequestIsService(request.items || []);
        const _step2ItemLines = (request.items || []).map((item, i) => {
          const qty  = Number(item.quantity || 1);
          const unit = item.unitLabel && item.unitLabel !== "units" ? ` ${item.unitLabel}` : "";
          return `${i + 1}. *${item.product}* (${qty}${unit})`;
        }).join("\n");

        const _step2Delivery = _step2IsService
          ? (request.serviceAddress ? `📍 Service at: ${request.serviceAddress}` : "📍 Client will share address")
          : request.deliveryRequired ? "🚚 Delivery needed" : "🏠 Collection / flexible";

        const _step2Location = request.area
          ? `📍 ${request.area}${request.city ? `, ${request.city}` : ""}`
          : request.city ? `📍 ${request.city}` : "📍 Zimbabwe";

        // ── VIP buyer phone reveal ─────────────────────────────────────────────
        // Sellers granted the phone-reveal permission (revealBuyerPhone OR the
        // profile-viewer permission revealVisitorPhone) see the buyer's number right
        // on this in-session card, so it works even when the v1 template is used.
        const _step2RevealPhone =
          (supplier?.revealBuyerPhone === true || supplier?.revealVisitorPhone === true) && !!request.buyerPhone;
        const _step2BuyerLine = _step2RevealPhone
          ? `📞 Buyer contact: ${_zqFmtPhone(request.buyerPhone)}\n`
          : "";

        await sendButtons(_normalizedSupplierPhone, {
          text:
            `🔔 *New ${_step2IsService ? "Service" : "Product"} Request - ${ref}*\n\n` +
            `${_step2Location}\n` +
            `${_step2Delivery}\n` +
            `${_step2BuyerLine}\n` +
            `📦 *${(request.items || []).length} item${(request.items || []).length === 1 ? "" : "s"} needed:*\n` +
            `${_step2ItemLines}\n\n` +
            `─────────────────\n` +
            `Tap *View & Quote* to enter your price${(request.items || []).length === 1 ? "" : "s"}.\n` +
            `The buyer receives your quote instantly.`,
          buttons: [
            { id: `req_offer_${requestKey}`,   title: "⚡ View & Quote"  },
            { id: `req_unavail_${requestKey}`,  title: "❌ Not Available" }
          ]
        });
        console.log(`[BUYER REQ] Interactive buttons sent to ${_normalizedSupplierPhone} (req ${_reqId})`);
      } catch (_step2Err) {
        // Non-fatal - seller still has the template + session state; they can type "hi" to proceed
        console.warn(`[BUYER REQ] Step 2 sendButtons failed for ${_normalizedSupplierPhone}:`, _step2Err.message);
      }

      // ── Also set awaiting_offer_intro for all notification contacts ────────────
      // They receive the template too (fan-out in notifySupplierNewRequestTemplate)
      // so they must also have a session so View & Quote works for them.
      const _notifContacts = supplier.notificationContacts || [];
      if (_notifContacts.length > 0) {
        await Promise.allSettled(_notifContacts.map(async (nc) => {
          const _ncNorm = String(nc).replace(/\D+/g, "");
          const _ncPhone = _ncNorm.startsWith("0") && _ncNorm.length === 10
            ? "263" + _ncNorm.slice(1) : _ncNorm;
          // Tag this session entry as notification_only so the engine knows this phone
          // is a watcher, not the quoting supplier. The Map entry role is checked in
          // the awaiting_offer_intro block to suppress auto-open for notification contacts.
          await _setSellerRequestSession(_ncPhone);
          // Override the role to notification_only AFTER the session is set
          const _ncExisting = await UserSession.findOne({ phone: _ncPhone }).lean();
          const _ncMap = { ...(_ncExisting?.tempData?.sellerPendingRequests || {}) };
          if (_ncMap[_reqId]) {
            _ncMap[_reqId].role = "notification_only";
            await UserSession.findOneAndUpdate(
              { phone: _ncPhone },
              { $set: { "tempData.sellerPendingRequests": _ncMap } },
              { upsert: true }
            );
          }
          console.log(`[BUYER REQ] Session set to awaiting_offer_intro for notif contact ${_ncPhone} (req ${_reqId}) [notification_only]`);
        }));
      }
      notifiedIds.push(supplier._id);
    } catch (err) {
      console.error("[BUYER REQUEST NOTIFY]", err.message);
    }
  }

  request.notifiedSuppliers = notifiedIds;
  if (notifiedIds.length > 0) {
    // Stamp the time suppliers were last notified so auto-close can give them a grace period.
    // Uses findByIdAndUpdate to safely add the field even if not in the schema (strict: false).
    try {
      await BuyerRequest.findByIdAndUpdate(
        request._id,
        { $set: { notifiedSuppliers: notifiedIds, lastNotifiedAt: new Date() } }
      );
    } catch (_) {
      await request.save();
    }
  } else {
    await request.save();
  }

  return notifiedIds.length;
}


// ── Detect whether a buyer request is for services (vs. physical products) ──
// Checks item names against known service keywords so we can use correct
// language ("service address" instead of "delivery") in the buyer flow.
function _buyerRequestIsService(items = []) {
  const SERVICE_KEYWORDS = [
    "install","repair","fix","service","replace","fitting","fit","plumb","drain",
    "electric","wire","wiring","paint","build","construct","renovate","plaster",
    "weld","clean","garden","lawn","trim","tutor","teach","lesson","photograph",
    "video","cater","chef","design","print","security","guard","account",
    "tax","audit","legal","transport","courier","mechanic","beat",
    "geyser","borehole","fumigat","pest","massage","barber","haircut","hair",
    "nail","makeup","booking","hire","maintenance","thermostat","element",
    // ── Tourism & hospitality ─────────────────────────────────────────────────
    "safari","game drive","game park","lodge","cruise","fishing trip","boat trip",
    "boat hire","houseboat","tour","tours","tourism","guided","bird watching",
    "bush walk","nature walk","cultural tour","village tour","city tour",
    "accommodation","chalet","camp","resort","guesthouse","airbnb","sunset cruise",
    "adventure","excursion","sightseeing","day trip","weekend","getaway","package",
    "transfer","pickup","sundowner","rafting","zip line","bungee","horse riding",
    "canoe","kayak","mokoro","island transfer","fishing guide","birding"
  ];
  if (!items || !items.length) return false;
  return items.some(item => {
    const name = (item.product || item.service || item.raw || "").toLowerCase();
    return SERVICE_KEYWORDS.some(kw => name.includes(kw));
  });
}

// ── Detect if a request is tourism/hospitality-related (for context-aware prompts) ─
// Uses classifyRequestItems from requestMatchEngine for accuracy.
// Falls back to keyword list for lightweight checks.
function _buyerRequestIsTourism(items = []) {
  const TOURISM_KEYWORDS = [
    "safari","game drive","game park","lodge","cruise","fishing trip","boat trip",
    "boat hire","houseboat","tour","tours","tourism","guided","bird watching",
    "bush walk","nature walk","cultural tour","village tour","city tour",
    "accommodation","chalet","camp","resort","guesthouse","airbnb","sunset cruise",
    "adventure","excursion","sightseeing","day trip","getaway","package","rafting",
    "canoe","kayak","island transfer","fishing guide","birding","game lodge"
  ];
  if (!items || !items.length) return false;
  return items.some(item => {
    const name = (item.product || item.service || item.raw || "").toLowerCase();
    return TOURISM_KEYWORDS.some(kw => name.includes(kw));
  });
}

async function finalizeBuyerRequestSubmission({
  from,
  phone,
  pendingRequest,
  deliveryRequired = false,
  serviceAddress = null,
  deliveryAddress = null,
  attachedImageUrl     = null,
  attachedImageCaption = ""
}) {
  if (!pendingRequest?.items?.length) {
    return sendButtons(from, {
      text: "❌ Request session expired. Please start again.",
      buttons: [{ id: "sup_request_sellers", title: "⚡ Request Sellers" }]
    });
  }

  const _isServiceReq    = pendingRequest.isServiceRequest || _buyerRequestIsService(pendingRequest.items || []);
  const _isTourismReq2   = _buyerRequestIsTourism(pendingRequest.items || []);
  // BuyerRequest.profileType enum only accepts "product" or "service" - hospitality is not a valid value.
  // We use "service" for hospitality/tourism requests (they behave like services: no delivery, service address).
  // The hospitality flag is re-derived at notify time from the item names via _buyerRequestIsTourism().
  const _storedProfileType = (_isTourismReq2 || _isServiceReq) ? "service" : (pendingRequest.profileType || "product");

  const request = await BuyerRequest.create({
    buyerPhone: from,
    requestType: pendingRequest.requestType || "simple",
    profileType: _storedProfileType,
    rawText: pendingRequest.rawText || "",
    items: pendingRequest.items || [],
    city: pendingRequest.city || null,
    area: pendingRequest.area || null,

    deliveryRequired: (_isServiceReq || _isTourismReq2) ? false : Boolean(deliveryRequired),
    deliveryAddress: !(_isServiceReq || _isTourismReq2) ? (deliveryAddress || pendingRequest.deliveryAddress || "") : "",

    serviceAddress: (_isServiceReq || _isTourismReq2) ? (serviceAddress || pendingRequest.serviceAddress || "") : "",
    status: "open",

    // Image fields (null for text-only requests - no change to existing flow)
    imageUrl:     attachedImageUrl     || null,
    imageCaption: attachedImageCaption || "",
    imageStatus:  attachedImageUrl ? "pending_review" : "none"
  });

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.buyerRequestState":   "",
        "tempData.pendingBuyerRequest": "",
        "tempData.buyerRequestMode":    "",
        "tempData.photoPromptShown":    ""
      }
    },
    { upsert: true }
  );

  const ref = buildBuyerRequestRef(request);

  // ── IMAGE PATH: hold supplier notification, notify admin for review ────────
  if (attachedImageUrl) {
    const _imgSummary  = (request.items || []).slice(0, 3).map((it, i) => `${i + 1}. ${it.product} x${Number(it.quantity || 1)}`).join(", ");
    const _imgLocation = request.area ? `${request.area}, ${request.city || ""}`.trim() : request.city || "Zimbabwe";
    try {
      const { notifyAdminPhotoReview } = await import("./buyerRequestNotifications.js");
      await notifyAdminPhotoReview({ ref, itemSummary: _imgSummary, locationText: _imgLocation, requestId: String(request._id) });
    } catch (err) {
      console.warn("[FINALIZE] notifyAdminPhotoReview failed:", err.message);
    }
    return sendButtons(from, {
      text:
        `✅ *Request submitted - photo under review.*\n\n` +
        `Ref: *${ref}*\n\n` +
        `${(request.items || []).map((it, i) => `${i + 1}. ${it.product} x${Number(it.quantity || 1)}`).join("\n")}\n\n` +
        `📸 Your photo is being reviewed before we send it to sellers.\n` +
        `This usually takes a few hours. You will receive a WhatsApp notification here once it is approved.`,
      buttons: [
        { id: "buyer_my_requests",   title: "📋 My Requests" },
        { id: "sup_request_sellers", title: "⚡ New Request"  }
      ]
    });
  }

  // ── TEXT-ONLY PATH: existing behaviour, completely unchanged ──────────────
  const notifiedCount = await notifySuppliersOfBuyerRequest(request);

  const itemLines = (request.items || [])
    .map((item, i) => {
      const qty = Number(item.quantity || 1);
      const unit = item.unitLabel && item.unitLabel !== "units" ? ` ${item.unitLabel}` : "";
      return `${i + 1}. ${item.product} x${qty}${unit}`;
    })
    .join("\n");

  const locationLine = request.area
    ? `📍 ${request.area}, ${request.city || ""}`.trim()
    : request.city
      ? `📍 ${request.city}`
      : "📍 Zimbabwe";

  const deliveryLine = _isServiceReq
    ? request.serviceAddress
      ? `📍 Service / pickup point: ${request.serviceAddress}`
      : "📍 Service address: buyer will share later"
    : request.deliveryRequired
      ? `🚚 Delivery required${request.deliveryAddress ? `\n📍 Delivery address: ${request.deliveryAddress}` : ""}`
      : "🏠 Collection / no delivery needed";

  return sendButtons(from, {
    text:
      `✅ *Request sent to sellers.*\n\n` +
      `Ref: *${ref}*\n\n` +
      `${itemLines}\n\n` +
      `${locationLine}\n` +
      `${deliveryLine}\n\n` +
      `Suppliers notified: *${notifiedCount}*\n\n` +
      `When sellers reply with prices, you’ll receive the quotation here.`,
    buttons: [
      { id: "buyer_my_requests", title: "📋 My Requests" },
      { id: "sup_request_sellers", title: "⚡ New Request" }
    ]
  });
}

async function _sendSupplierCatalogueBrowser(from, supplier, cart = [], opts = {}) {
  const searchTerm = opts.searchTerm || "";
  const pageSize = opts.pageSize || 6;
  const selectionMode = opts.selectionMode || "catalogue";

  const allItems = getFilteredSupplierCatalogueItems(supplier, searchTerm);
  const totalItems = allItems.length;

  if (!totalItems) {
    return sendButtons(from, {
      text:
        `😕 No ${supplier.profileType === "service" ? "services" : "products"} found` +
        (searchTerm ? ` for *${searchTerm}*.` : "."),
      buttons: [
     { id: `sup_catalogue_search_${supplier._id}`, title: "🔎 Search Again" },
        { id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Full Catalogue" },
        { id: `sup_cart_view_${supplier._id}`, title: "🛒 View Cart" }
      ]
    });
  }

  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const page = Math.max(0, Math.min(Number(opts.page || 0), totalPages - 1));
  const start = page * pageSize;
  const visible = allItems.slice(start, start + pageSize);

  const rows = visible.map(item => ({
    id: `sup_cart_add_${supplier._id}_${encodeURIComponent(item.name)}`,
    title: item.name.slice(0, 72),
    description:
      item.priceLabel ||
      (supplier.profileType === "service" ? "Tap to select this service" : "Tap to select this item")
  }));
  if (page > 0) {
    rows.push({
      id: `sup_catalog_page_prev_${supplier._id}`,
      title: opts.selectionMode === "search_pick" ? "⬅ Previous Matches" : "⬅ Previous Products"
    });
  }

  if (page < totalPages - 1) {
    rows.push({
      id: `sup_catalog_page_next_${supplier._id}`,
      title: opts.selectionMode === "search_pick" ? "➡ More Matches" : "➡ More Products"
    });
  }

  if (page === 0 && opts.selectionMode === "search_pick") {
    rows.push({ id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Full Catalogue" });
  }

  if (page === 0) {
    rows.push({ id: `sup_number_page_open_${supplier._id}`, title: "⚡ Quick Order" });
  }

  rows.push({ id: `sup_cart_view_${supplier._id}`, title: "🛒 View Cart" });

  if (rows.length > 10) rows.splice(10);

   const header = formatCatalogueHeader({
    supplier,
    page,
    totalPages,
    totalItems,
    searchTerm,
    cartCount: cart.length,
    selectionMode: opts.selectionMode || "catalogue"
  });

  return sendList(from, header, rows);
}


async function _sendSupplierNumberedCatalogueText(from, supplier, cart = [], opts = {}) {
  const searchTerm = opts.searchTerm || "";
  const pageSize = opts.pageSize || 25;

  const allItems = getFilteredSupplierCatalogueItems(supplier, searchTerm);
  const totalItems = allItems.length;

  if (!totalItems) {
    return sendButtons(from, {
      text:
        `😕 No ${supplier.profileType === "service" ? "services" : "products"} found` +
        (searchTerm ? ` for *${searchTerm}*.` : "."),
      buttons: [
        { id: `sup_catalogue_search_${supplier._id}`, title: "🔎 Search Again" },
        { id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Full Catalogue" },
        { id: `sup_cart_view_${supplier._id}`, title: "🛒 View Cart" }
      ]
    });
  }

  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const page = Math.max(0, Math.min(Number(opts.page || 0), totalPages - 1));
  const start = page * pageSize;
  const visible = allItems.slice(start, start + pageSize);

  const numbered = visible
    .map((item, i) => {
      const absoluteIndex = start + i + 1;
      return `${absoluteIndex}. ${item.name}${item.priceLabel ? ` - ${item.priceLabel}` : ""}`;
    })
    .join("\n");

  const cartLine = cart.length ? `\n🛒 Cart: ${cart.length} item${cart.length === 1 ? "" : "s"}` : "";
  const searchLine = searchTerm ? `\n🔎 Filtered: *${searchTerm}*` : "";
  const modeLine = searchTerm
    ? `\nShowing matching items first. You can open the full catalogue below.`
    : "";

  await sendText(
    from,
`⚡ *Quick Order by Number*
${supplier.businessName}${searchLine}${cartLine}${modeLine}

Page ${page + 1} of ${totalPages} • ${totalItems} item${totalItems === 1 ? "" : "s"}

${numbered}

*Send item number + quantity*
Examples:
_2x3_
_7x1, 10x4_
_12x2, 15x1, 18x6_`
  );

  const navButtons = [];
  if (page > 0) {
    navButtons.push({ id: `sup_number_page_prev_${supplier._id}`, title: "⬅ Prev Numbers" });
  }
  if (page < totalPages - 1) {
    navButtons.push({ id: `sup_number_page_next_${supplier._id}`, title: "➡ Next Numbers" });
  }

  if (navButtons.length) {
    await sendButtons(from, {
      text: "Choose next page:",
      buttons: navButtons
    });
  }

  const utilityButtons = [];

  if (searchTerm) {
    utilityButtons.push({ id: `sup_number_full_${supplier._id}`, title: "📚 Full Catalogue" });
  } else {
    utilityButtons.push({ id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Browse Catalogue" });
  }

  utilityButtons.push({ id: `sup_cart_view_${supplier._id}`, title: "🛒 View Cart" });
  utilityButtons.push({ id: "sup_back_to_search_results", title: "⬅ Back" });

  return sendButtons(from, {
    text: "Other options:",
    buttons: utilityButtons
  });
}



async function _sendSupplierCartMenu(from, supplier, cart = []) {
  const sess = await UserSession.findOne({ phone: from.replace(/\D+/g, "") });
  const focusedItem = sess?.tempData?.selectedSupplierItem || null;

  if (!cart.length) {
    return sendButtons(from, {
      text: "🛒 Your cart is empty.",
      buttons: [
        { id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Browse Catalogue" },
        { id: `sup_catalogue_search_${supplier._id}`, title: "🔎 Search Supplier" },
        { id: "suppliers_home", title: "⬅ Suppliers" }
      ]
    });
  }

  const rows = cart.slice(0, 5).map(item => ({
    id: `sup_cart_remove_${supplier._id}_${encodeURIComponent(item.product)}`,
    title: `➖ Remove ${item.product}`.slice(0, 72),
    description:
      `Qty ${item.quantity}` +
      (typeof item.pricePerUnit === "number"
        ? ` • $${Number(item.pricePerUnit).toFixed(2)}/${item.unit || "each"}`
        : "")
  }));

  rows.push({
    id: `sup_cart_confirm_${supplier._id}`,
    title: supplier.profileType === "service" ? "✅ Confirm Booking" : "✅ Confirm & Send Order"
  });

  rows.push({ id: `sup_cart_clear_${supplier._id}`, title: "🗑 Clear Cart" });
  rows.push({ id: `sup_catalog_page_open_${supplier._id}`, title: "📚 Add More Items" });
  rows.push({ id: `sup_catalogue_search_${supplier._id}`, title: "🔎 Search Supplier" });
  rows.push({ id: `sup_cart_custom_${supplier._id}`, title: "✍ Type Custom Item" });

  const summary = cart
    .map(i => {
      const price = typeof i.pricePerUnit === "number" ? ` @ $${Number(i.pricePerUnit).toFixed(2)}` : "";
      return `• ${i.product} x${i.quantity}${price}`;
    })
    .join("\n");

  const focusedLine = focusedItem?.product
    ? `🎯 *Selected now:* ${focusedItem.product}\n\n`
    : "";

  if (rows.length > 10) rows.splice(10);

  return sendList(
    from,
    `${focusedLine}🛒 *Your Cart* (${cart.length} item${cart.length === 1 ? "" : "s"})\n\n${summary}`,
    rows
  );
}
/**
 * Helper: get caller's effective branchId.
 * - Clerks/managers → their assigned branchId
 * - Owner → targetBranchId stored in sessionData (set by branch picker)
 */
function getEffectiveBranchId(caller, sessionData) {
  if (caller?.role === "owner") {
    return sessionData?.targetBranchId || null;
  }
  return caller?.branchId || null;
}

async function startOnboarding(from, phone) {
  const existingOwner = await UserRole.findOne({ phone, role: "owner", pending: false }).lean();

  if (existingOwner?.businessId) {
    const b = await Business.findById(existingOwner.businessId);
    if (b) {
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: b._id }, { upsert: true });
      // Always reset to onboarding state (handles ghost biz and stale states)
      b.sessionState = "awaiting_business_name";
      b.sessionData = {};
      await saveBizSafe(b);
      await sendText(from, "👋 Welcome! Let's set up your business.\n\nSend your business name:");
      return;
    }
  }

  const newBiz = await Business.create({
    name: "", currency: "USD", package: "trial",
    subscriptionStatus: "inactive",
    sessionState: "awaiting_business_name",
    sessionData: {}, ownerPhone: phone
  });

  await UserRole.create({ phone, role: "owner", pending: false, businessId: newBiz._id });
  await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: newBiz._id }, { upsert: true });
  await sendText(from, "👋 Welcome! Let's set up your business.\n\nSend your business name:");
}

async function showSalesDocs(from, type, ownerBranchId = undefined, page = 0, search = null, dateFilter = null) {
  const biz = await getBizForPhone(from);
  if (!biz) return sendMainMenu(from);

  const phone  = from.replace(/\D+/g, "");
  const caller = await UserRole.findOne({ businessId: biz._id, phone, pending: false });
  const query  = { businessId: biz._id, type };

  if (caller?.role === "owner" && ownerBranchId !== undefined) {
    if (ownerBranchId !== null) query.branchId = ownerBranchId;
  } else if (caller && ["clerk", "manager"].includes(caller.role) && caller.branchId) {
    query.branchId = caller.branchId;
  }

  // ── Date filter ───────────────────────────────────────────────────────────
  if (dateFilter) {
    const now   = new Date();
    const year  = now.getFullYear();
    const month = now.getMonth();
    if (dateFilter === "this_month") {
      query.createdAt = { $gte: new Date(year, month, 1), $lt: new Date(year, month + 1, 1) };
    } else if (dateFilter === "last_month") {
      query.createdAt = { $gte: new Date(year, month - 1, 1), $lt: new Date(year, month, 1) };
    } else if (dateFilter === "this_year") {
      query.createdAt = { $gte: new Date(year, 0, 1), $lt: new Date(year + 1, 0, 1) };
    } else if (dateFilter === "last_7") {
      const d = new Date(); d.setDate(d.getDate() - 7);
      query.createdAt = { $gte: d };
    }
  }

  // ── Text search - invoice number or client name ───────────────────────────
  if (search) {
    const Client       = (await import("../models/client.js")).default;
    const matchClients = await Client.find({
      businessId: biz._id,
      name: { $regex: search, $options: "i" }
    }).distinct("_id");

    query.$or = [
      { number: { $regex: search, $options: "i" } },
      ...(matchClients.length ? [{ clientId: { $in: matchClients } }] : [])
    ];
  }

  const PAGE_SIZE  = 8;
  const total      = await Invoice.countDocuments(query);

  if (!total) {
    const label = dateFilter === "this_month" ? "this month"
                : dateFilter === "last_month" ? "last month"
                : dateFilter === "this_year"  ? "this year"
                : dateFilter === "last_7"     ? "last 7 days"
                : search ? `"${search}"` : "";
    await sendText(from, `📄 No ${type}s found${label ? ` for ${label}` : ""}.`);
    return sendSalesMenu(from);
  }

  const totalPages = Math.ceil(total / PAGE_SIZE);
  const safePage   = Math.min(page, totalPages - 1);
  const docs       = await Invoice.find(query)
    .sort({ createdAt: -1 })
    .skip(safePage * PAGE_SIZE)
    .limit(PAGE_SIZE)
    .lean();

  // Load client names
  const Client    = (await import("../models/client.js")).default;
  const clientIds = [...new Set(docs.map(d => d.clientId?.toString()).filter(Boolean))];
  const clients   = await Client.find({ _id: { $in: clientIds } }).lean();
  const clientMap = Object.fromEntries(clients.map(c => [c._id.toString(), c.name || c.phone || "-"]));

  // Build header
  let header = `📄 ${type[0].toUpperCase() + type.slice(1)}s`;
  if (ownerBranchId && caller?.role === "owner") {
    const branch = await Branch.findById(ownerBranchId);
    if (branch) header += ` - ${branch.name}`;
  } else if (caller?.role === "owner" && ownerBranchId === null) {
    header += ` - All`;
  }
  if (dateFilter === "this_month") header += " · This Month";
  else if (dateFilter === "last_month") header += " · Last Month";
  else if (dateFilter === "this_year")  header += " · This Year";
  else if (dateFilter === "last_7")     header += " · Last 7 Days";
  if (search) header += ` 🔍 "${search}"`;

  // Store in session so user can type number to open
  const typeCode    = type === "invoice" ? "inv" : type === "quote" ? "qt" : "rct";
  const branchCode  = ownerBranchId || "all";
  const filterCode  = dateFilter  || "none";
  const searchCode  = search ? encodeURIComponent(search).slice(0, 30) : "0";

  biz.sessionState = "sales_doc_list";
  biz.sessionData  = {
    docListType:    type,
    docListPage:    safePage,
    docListBranch:  ownerBranchId,
    docListSearch:  search,
    docListFilter:  dateFilter,
    docListIds:     docs.map(d => d._id.toString()),
    docListOffset:  safePage * PAGE_SIZE
  };
  await saveBizSafe(biz);

  // Numbered text list - no WhatsApp row limits
  let msg = `${header}\nPage ${safePage + 1}/${totalPages} · ${total} total\n\n`;
  docs.forEach((d, i) => {
    const statusIcon = d.status === "paid" ? "✅" : d.status === "partial" ? "⏳" : "🔴";
    const clientName = clientMap[d.clientId?.toString()] || "";
    const dateStr    = d.createdAt ? new Date(d.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short" }) : "";
    msg += `${safePage * PAGE_SIZE + i + 1}. *${d.number}* ${statusIcon}\n`;
    msg += `   $${Number(d.total || 0).toFixed(2)} ${d.currency || ""}`;
    if (clientName) msg += ` · ${clientName}`;
    if (dateStr)    msg += ` · ${dateStr}`;
    msg += "\n";
  });
  msg += `\nType a number (1–${docs.length}) to open it.`;

  await sendText(from, msg);

  // Build 3 navigation/filter buttons
  const navBtns = [];
  if (safePage > 0)
    navBtns.push({ id: `vdoc_prev_${typeCode}_${branchCode}_${safePage}_${filterCode}_${searchCode}`, title: "⬅ Prev" });
  if (safePage < totalPages - 1)
    navBtns.push({ id: `vdoc_next_${typeCode}_${branchCode}_${safePage}_${filterCode}_${searchCode}`, title: "➡ Next" });

  // Filter button - show most useful one based on current state
  if (!dateFilter && !search)
    navBtns.push({ id: `vdoc_filter_${typeCode}_${branchCode}`, title: "📅 Filter by Date" });
  else
    navBtns.push({ id: `vdoc_filter_${typeCode}_${branchCode}`, title: "🔄 Change Filter" });

  return sendButtons(from, {
    text: "Open by number, filter, or search:",
    buttons: navBtns.slice(0, 3)
  });
}

// ─── Client list helper ───────────────────────────────────────────────────────

async function sendClientSelectList(from, biz) {
  const clients = await (await import("../models/client.js")).default
    .find({ businessId: biz._id })
    .sort({ updatedAt: -1 }).limit(9).lean();

  const rows = clients.map(c => ({ id: `client_${c._id}`, title: c.name || c.phone }));
  rows.push({ id: "inv_new_client", title: "➕ Add new client" });
  return sendList(from, "👤 Select client", rows);
}

// ─────────────────────────────────────────────────────────────────────────────

export async function handleIncomingMessage({ from, action, hasImage = false, imageUrl = null, imageCaption = "" }) {

  const phone = from.replace(/\D+/g, "");

 if (!phone || phone.length < 9 || phone.length > 15) {
    console.error("❌ Invalid phone for session key:", { from, phone, action });
    return;
  }

  // ── NEW CONTACT TRACKING ─────────────────────────────────────────────────
  // Fire-and-forget: only writes on first contact, never overwrites.
  PhoneContact.findOneAndUpdate(
    { phone },
    { $setOnInsert: { phone, firstMessage: String(action || "").slice(0, 200), channel: "whatsapp" } },
    { upsert: true, new: false }
  ).catch(err => console.error("[PHONE CONTACT TRACK]", err.message));
  // ─────────────────────────────────────────────────────────────────────────

  const text = typeof action === "string" ? action.trim() : "";
  const al = text.toLowerCase();
  const a = typeof action === "string" ? action.trim().toLowerCase() : "";

const isMetaAction =
    typeof action === "string" &&
    (
 Object.values(ACTIONS).some(v => (v || "").toLowerCase() === a) ||
      a === "__document_uploaded__" ||
       a === "expense_generate_receipt" ||
      a.startsWith("report_branch_") ||
      a.startsWith("sup_") ||
      a.startsWith("rate_order_") ||
      a.startsWith("sup_plan_") ||
a.startsWith("sup_accept_") ||
      a.startsWith("sup_decline_") ||
      a.startsWith("sup_view_order_") ||
      a.startsWith("sup_contact_buyer_") ||
      a.startsWith("dec_out_of_stock") ||
      a.startsWith("dec_min_not_met") ||
      a.startsWith("dec_no_delivery") ||
      a.startsWith("dec_price_changed") ||
      a.startsWith("dec_other") ||
      a.startsWith("sup_order_") ||
      a.startsWith("sup_view_") ||
      a.startsWith("sup_save_") ||
      a.startsWith("sup_search_cat_") ||
      a.startsWith("sup_search_city_") ||
      a.startsWith("sup_eta_") ||
a === "find_supplier" ||
      a === "register_supplier" ||
      a === "list_my_business" ||   // broadcast template button payload alias
      a === "my_supplier_account" ||
a === "my_orders" ||
      a.startsWith("my_orders_page_") ||
      a.startsWith("order_detail_") ||
      a.startsWith("sup_book_") ||
      a.startsWith("sup_book_confirm_") ||
      a === "exp_show_categories" ||
      a.startsWith("exp_quick_save_") ||
  a === "reg_type_product" ||
      a === "reg_type_service" ||
      a === "reg_type_hospitality" ||
      a === "reg_type_school" ||
      a === "reg_type_product" ||
      a === "reg_type_service" ||
      a.startsWith("sup_hosp_type_") ||
      a === "sup_hosp_facilities_done" ||
      a === "sup_skip_rest_rates" ||
      a === "sup_skip_extra_services" ||
      a.startsWith("sup_hosp_fac_toggle_") ||
      a.startsWith("sup_collar_") ||
      a === "sup_travel_yes" ||
      a === "sup_travel_no" ||
      a === "sup_preset_confirm" ||
a === "sup_preset_prices_yes" ||
a.startsWith("sup_load_preset_") ||
      a === "sup_skip_products" ||
a === "sup_enter_own_products" ||
a === "sup_request_upload" ||
a === "sup_addr_skip" ||
a === "sup_contact_skip" ||
a === "sup_website_skip" ||
a === "sup_prices_confirm_yes" ||
a === "sup_price_update_confirm" ||
a === "sup_price_confirm_yes" ||
      a === "sup_price_confirm_no" ||
a === "sup_prices_edit" ||
a === "sup_preset_confirm" ||
a === "sup_preset_prices_yes" ||
a.startsWith("sup_load_preset_") ||

    a === "sup_skip_prices" ||
      a === "sup_done_prices" ||
      a === "sup_update_prices" ||
      a === "sup_edit_products" ||
      a === "sup_quick_edit_products" ||
      a === "sup_toggle_delivery" ||
      a === "sup_toggle_active" ||
      a === "sup_edit_area" ||
      a === "sup_my_orders" ||
      a === "sup_my_earnings" ||
      a === "sup_my_reviews" ||
      a === "sup_upgrade_plan" ||
      a === "sup_renew_plan" ||
      a === "onboard_business" ||
        a === "main_menu_back" ||
      a.startsWith("payinv_full_") ||
      a === "biz_tools_menu" ||
      a === "marketplace_menu" ||
       a.startsWith("inv_cat_page_") ||


             a === "sup_request_quote_search" ||
      a === "sup_save_search_current" ||
      a.startsWith("sup_request_quote_supplier_") ||
      a.startsWith("sup_ask_availability_") ||



      a === "sup_request_sellers" ||
      a === "sup_use_saved_location" ||
      a === "sup_change_location" ||
      a === "sup_pause_requests" ||
      a === "sup_resume_requests" ||
      a === "sup_request_mode_simple" ||
      a === "sup_request_mode_bulk" ||
      a === "sup_request_delivery_yes" ||
      a === "sup_request_delivery_no" ||
      a.startsWith("req_offer_") ||
      a.startsWith("req_unavail_") ||
      a === "view_and_quote" ||
      a === "not_available" ||
      a.startsWith("buyer_view_all_quotes_") ||
      a === "buyer_my_requests" ||


        a.startsWith("view_invoices_page_") ||
      a.startsWith("view_quotes_page_") ||
        a.startsWith("view_receipts_page_") ||
      a.startsWith("view_all_products_page_") ||
      a === "view_all_products" ||
      a === "prod_update_prices" ||
      a === "prod_update_rates" ||
      a === "prod_add_products" ||
      a === "prod_add_services" ||
      a === "prod_preview_save" ||
      a === "prod_preview_edit" ||
      a === "prod_preview_cancel" ||
      a === "prod_prices_confirm_save" ||
      a === "prod_prices_confirm_edit" ||
      a === "svc_rates_confirm_save" ||
      a === "svc_rates_confirm_edit" ||
      a === "svc_rate_per_job" ||
      a === "svc_rate_per_hour" ||
      a === "svc_rate_per_day" ||
      a === "svc_rate_per_meter" ||
      a === "svc_rate_per_room" ||
      a === "svc_rate_per_visit" ||
      a === "suppliers_home" ||
      a === "back" ||
      a === "suppliers_home" ||
      a.startsWith("branch_") ||
      a.startsWith("new_doc_branch_") ||
      a.startsWith("add_product_branch_") ||
      a.startsWith("add_client_branch_") ||
      a.startsWith("payment_in_branch_") ||
      a.startsWith("expense_branch_") ||
      a.startsWith("bulk_expense_branch_") ||
      a.startsWith("view_expense_receipts_branch_") ||
      a.startsWith("view_payment_history_branch_") ||
      a.startsWith("view_clients_branch_") ||
     a.startsWith("cashbal_branch_") ||
  a === "sup_search_next_page" ||
      a === "sup_search_prev_page" ||
 a.startsWith("vdoc_prev_") ||
      a.startsWith("vdoc_next_") ||
      a.startsWith("vdoc_search_") ||
      a.startsWith("vdoc_filter_") ||
      a.startsWith("vdoc_date_") ||
    a === "exp_show_categories" ||
      a === "exp_bulk_confirm_yes" ||
      a === "exp_bulk_confirm_no" ||
      a === "exp_bulk_keep_adding" ||
      a.startsWith("paylist_prev_") ||
      a.startsWith("paylist_next_") ||
      a.startsWith("paylist_search_") ||
      // ── Schools ────────────────────────────────────────────────────────────
      a === "find_school" ||
      a === "school_register" ||
      a === "school_account" ||
      a === "school_pay_plan" ||
      a === "school_search_refine" ||
      a === "school_toggle_admissions" ||
      a === "school_update_fees" ||
      a === "school_reg_confirm_yes" ||
      a === "school_reg_confirm_no" ||
      a === "school_reg_address_skip" ||
      a === "school_reg_principal_skip" ||
      a === "school_reg_email_skip" ||
      a === "school_reg_cur_done" ||
      a === "school_reg_fac_done" ||
      a === "school_reg_ext_done" ||
      a === "school_reg_city_other" ||
      a.startsWith("school_reg_type_") ||
      a.startsWith("school_reg_city_") ||
      a.startsWith("school_reg_cur_") ||
      a.startsWith("school_reg_gender_") ||
      a.startsWith("school_reg_boarding_") ||
    a.startsWith("school_reg_fac_") ||
      a.startsWith("school_reg_ext_") ||
      a === "school_reg_city_more" ||
      a === "school_search_city_more" ||
      a.startsWith("school_plan_") ||
      a.startsWith("school_search_city_") ||
      a.startsWith("school_search_type_") ||
      a.startsWith("school_search_fees_") ||
      a.startsWith("school_search_fac_") ||
      a.startsWith("school_search_page_") ||
      a.startsWith("school_view_") ||
    a.startsWith("school_dl_profile_") ||
      (a.startsWith("school_apply_") && !a.startsWith("school_apply_start_")) ||
      a.startsWith("school_apply_start_") ||
      a.startsWith("sa_grade_") ||
      a.startsWith("school_enquiry_") ||
      a === "school_my_profile" ||
      a === "school_my_facilities" ||
      a === "school_my_fees" ||
      a === "school_my_reviews" ||
      a === "school_my_inquiries" ||
      a === "school_more_options" ||
      a === "school_applications" ||
      a === "school_enquiries" ||
      a === "school_contacts" ||
      a === "school_marketplace" ||
      a === "school_share_link" ||
 a === "school_update_reg_link" ||
      a === "school_update_email" ||
      a === "school_update_website" ||
      a === "school_upload_brochure" ||
      // ── school admin facility/extramural toggles ──
      a === "school_admin_manage_facilities" ||
      a === "school_admin_manage_extramural" ||
      a === "school_admin_edit_fees" ||
      a === "school_admin_edit_reg_link" ||
      a === "school_admin_edit_email" ||
      a === "school_admin_edit_website" ||
      a === "school_admin_upload_brochure" ||
      a.startsWith("school_fac_toggle_") ||
      a.startsWith("school_fac_page_") ||
      a.startsWith("school_ext_toggle_") ||
      a.startsWith("school_ext_page_") ||
      a === "school_get_zq_link" ||
      a === "school_share_link_wa" ||
      a === "school_smart_card_menu" ||
      a === "school_my_leads" ||
      a.startsWith("school_sc_src_") ||
      a.startsWith("school_followup_") ||
      a.startsWith("school_leads_page_") ||
      a.startsWith("sfaq_") ||
      a.startsWith("sc_") ||
      // ── Group smart link list-reply taps ─────────────────────────────────
      // zqg_sel_<id>        = buyer tapped a seller row in a group list
      // zqg_register_<slug> = buyer tapped "List Your Business Here" row
      // Without these isMetaAction=false and both fall into shortcode search.
      a.startsWith("zqg_sel_") ||
      a.startsWith("zqg_register_") ||
      // ── School group smart link list-reply taps ─────────────────────────
      // zqsg_sch_<schoolId>      = visitor tapped a school in a school group list
      // zqsg_register_<slug>     = visitor tapped "Add My School Here" CTA
      a.startsWith("zqsg_sch_") ||
      a.startsWith("zqsg_register_") ||
      // ── Business tools dynamic actions ───────────────────────────────────
      a.startsWith("inv_") ||
      a.startsWith("payinv_") ||
      a.startsWith("prod_") ||
      a.startsWith("doc_") ||
      a.startsWith("subpay_") ||
      a.startsWith("stmt_client_") ||
      a.startsWith("invite_branch_") ||
      a.startsWith("assign_user_") ||
      a.startsWith("assign_branch_") ||
      a.startsWith("onb_") ||
      a.startsWith("rate_") ||
      a.startsWith("req_offer_confirm_") ||
      a.startsWith("req_auto_") ||
      a.startsWith("view_invoices_branch_") ||
      a.startsWith("view_quotes_branch_") ||
      a.startsWith("view_receipts_branch_") ||
      a.startsWith("view_products_branch_") ||
      a.startsWith("view_all_products_page_") ||
      a.startsWith("view_all_invoices_page_") ||
      a.startsWith("view_all_quotes_page_") ||
      a.startsWith("view_all_receipts_page_") ||
      a.startsWith("cashbal_branch_") ||
      a.startsWith("new_doc_branch_") ||
      a.startsWith("add_product_branch_") ||
      a.startsWith("add_client_branch_") ||
      a.startsWith("payment_in_branch_") ||
      a.startsWith("expense_branch_") ||
      a.startsWith("bulk_expense_branch_") ||
      a.startsWith("view_expense_receipts_branch_") ||
      a.startsWith("view_payment_history_branch_") ||
      a.startsWith("view_clients_branch_") ||
      a.startsWith("vdoc_") ||
      a.startsWith("svc_rate_") ||
      a === "add_another_expense" ||
      a.startsWith("exp_cat_") ||
      a === "exp_show_categories" ||
      a === "view_all_products" ||
      a === "view_all_invoices" ||
      a === "view_all_quotes" ||
      a === "view_all_receipts" ||
      a === "cashbal_branch_all" ||
      a === "sup_search_type_product" ||
      a === "__document_uploaded__" ||
      // ── Recurring Billing ─────────────────────────────────────────────────
      a === "recurring_billing_menu" ||
      a === "rb_accounts" ||
      a === "rb_record_payment" ||
      a === "rb_pay_tenant" ||
      a === "rb_pay_income" ||
      a === "rb_generate_invoices" ||
      a === "rb_account_stmt" ||
      a === "rb_tenant_stmt" ||
      a === "rb_billing_stmt" ||
      a === "rb_reminders" ||
      a === "rb_add_expense" ||
      a === "rb_vacate" ||
      a === "rb_vacate_yes" ||
      a.startsWith("rb_acct_") ||
      a.startsWith("rb_tenant_") ||
      a.startsWith("rb_period_") ||
      a.startsWith("rb_pay_method_") ||
      a === "rb_period_all" ||
      a === "rb_period_custom" ||
      // ── Stock Control ─────────────────────────────────────────────────────
      a === "stock_menu" ||
      a === "products_menu" ||
      a === "stock_enable" ||
      a === "stock_add_item" ||
      a === "stock_in" ||
      a === "stock_adjust" ||
      a === "stock_view" ||
      a === "stock_report" ||
      a === "stock_settings" ||
      a === "stock_disable" ||
      a === "stock_automatch_toggle" ||
      a === "branches_users_menu" ||
      a.startsWith("stock_item_") ||
      a.startsWith("stock_period_")
    
    );
  // ── Parse skip / edit commands ────────────────────────────────────────────
  // Supports: "skip 3,7,15"  "edit 1x5, 3x15"  "skip 3 edit 1x5"
  function _parseEditSkip(inputText, draftItems) {
    const raw = String(inputText || "").trim();
    let editUpdates = {};   // { itemIndex(1-based): newPrice }
    let skipIndices = new Set();
    let hasEditCmd = false;
    let hasSkipCmd = false;

    // ── "have 3,7,15" - I ONLY have these items, skip all others ────────────
    let haveMode = false;
    const haveMatch = raw.match(/\bhave\s+([\d,\s]+)/i);
    if (haveMatch) {
      hasSkipCmd = true;
      haveMode = true;
      const haveSet = new Set();
      haveMatch[1].split(/[,\s]+/).forEach(n => {
        const idx = parseInt(n);
        if (!isNaN(idx)) haveSet.add(idx);
      });
      // Skip everything NOT in the have list
      for (let i = 1; i <= draftItems.length; i++) {
        if (!haveSet.has(i)) skipIndices.add(i);
      }
    }

    // ── "skip 3,7,15" - skip specific items ──────────────────────────────────
    if (!haveMode) {
      const skipMatch = raw.match(/\bskip\s+([\d,\s]+)/i);
      if (skipMatch) {
        hasSkipCmd = true;
        skipMatch[1].split(/[,\s]+/).forEach(n => {
          const idx = parseInt(n);
          if (!isNaN(idx) && idx >= 1 && idx <= draftItems.length) skipIndices.add(idx);
        });
      }
    }

    // ── "edit 1x5 3x15" or "1x5, 3x15" or "1 5, 3 15" or "1:5" - edit specific prices ──
    // Accepts: 1x12.50  1=12.50  1:12.50  1 12.50  - all map to item 1 @ $12.50
    const editSection = raw
      .replace(/\bhave\s+[\d,\s]+/i, "")
      .replace(/\bskip\s+[\d,\s]+/i, "")
      .replace(/^\bedit\b\s*/i, "").trim();
    // Match: number followed by x/=/:/space then price
    const pairPattern = /(\d+)\s*[x=:\s]\s*(\d+(?:\.\d+)?)/gi;
    let m;
    while ((m = pairPattern.exec(editSection)) !== null) {
      // Skip if the separator is a space and both sides are just standalone numbers
      // (could be "skip 3 7" which is skip, not edit)
      const sep = editSection.slice(m.index + m[1].length, m.index + m[0].length - m[2].length).trim();
      // Only skip if pure space separator AND no decimal in price (ambiguous)
      if (sep === "" && !m[2].includes(".") && !hasSkipCmd) {
        // Accept it anyway - context is price entry mode
      }
      hasEditCmd = true;
      editUpdates[parseInt(m[1])] = parseFloat(m[2]);
    }

    return { editUpdates, skipIndices, hasEditCmd, hasSkipCmd, haveMode };
  }

  // =========================
  // 🔑 JOIN INVITATION (ABSOLUTE PRIORITY)
  // =========================
  if (al === "join") {
    const invite = await UserRole.findOne({ phone, pending: true }).populate("businessId branchId");

    if (!invite) {
      await sendText(from, "❌ No pending invitation found for this number.");
      return;
    }

    invite.pending = false;
    await invite.save();

    await UserSession.findOneAndUpdate(
      { phone }, { activeBusinessId: invite.businessId._id }, { upsert: true }
    );

    await sendText(from,
`✅ Invitation accepted!

🏢 Business: ${invite.businessId.name}
📍 Branch: ${invite.branchId?.name || "Main"}
🔑 Role: ${invite.role}

Reply *menu* to start.`);

    await sendMainMenu(from);
    return;
  }

  console.log("META INCOMING:", { from, action });

let biz = await getBizForPhone(from);
const isGhostSupplierBiz = !!(biz && biz.name?.startsWith("pending_supplier_"));

  // ── Tenant self-service: if no biz and phone matches a RecurringTenant with canSelfServe ──
  // Allows tenants to check their balance by WhatsApping the chatbot number.
  if (!biz && !isMetaAction) {
    try {
      const { getTenantBalanceSummary } = await import("./recurringBilling.js");
      const RecurringTenant = (await import("../models/recurringTenant.js")).default;
      // Search across all businesses for this phone
      let tp = phone;
      if (tp.startsWith("0")) tp = "263" + tp.slice(1);
      const tRecord = await RecurringTenant.findOne({ phone: tp, isActive: true, canSelfServe: true }).lean();
      if (tRecord) {
        const Business = (await import("../models/business.js")).default;
        const tbiz = await Business.findById(tRecord.businessId).lean();
        if (tbiz) {
          const tData = await getTenantBalanceSummary(phone, tRecord.businessId);
          if (tData) {
            const cur = tData.cur;
            let msg = `👤 *Welcome, ${tData.tenant.name}*\n`;
            if (tData.account) msg += `🏠 ${tData.account.name}\n`;
            msg += `📍 ${tbiz.name}\n━━━━━━━━━━━━━━━━━━━━\n`;
            if (tData.balance > 0) {
              msg += `💰 *Balance Due: ${tData.balance.toFixed(2)} ${cur}*\n`;
              if (tData.outstanding.length > 0) {
                const oldest = tData.outstanding[0];
                msg += `📄 Invoice: ${oldest.number} - ${oldest.period}\n`;
                msg += `📆 Due: ${new Date(oldest.dueDate).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}\n`;
              }
            } else {
              msg += `✅ *Account is clear - no balance due*\n`;
            }
            msg += `\nContact ${tbiz.name} for your full statement.`;
            await sendText(from, msg);
            return;
          }
        }
      }
    } catch (_tse) {
      // Non-blocking - if this fails, continue normal flow
    }
  }

// ── Ownership check for registration flows ───────────────────────────────────
// getBizForPhone may return a biz where this phone is only a notification contact.
// ownerPhone is unreliable on old records. UserRole is the ground truth.
// _bizIsOwnedByUser = false means biz = null for all registration entry points.
let _bizIsOwnedByUser = true;
if (biz) {
  const _ownerRoleCheck = await UserRole.findOne({ phone, businessId: biz._id, pending: false }).lean();
  if (!_ownerRoleCheck) {
    // Not on this biz - check if they have a role on ANY biz (e.g. clerk assigned via admin)
    // Prefer a role on a real (non-pending_supplier_) biz over a pending registration biz
    const _allRoleChecks = await UserRole.find({ phone, pending: false }).sort({ updatedAt: -1 }).lean();
    let _anyRoleCheck = null;
    for (const _rc of _allRoleChecks) {
      const _rcBiz = await Business.findById(_rc.businessId).lean();
      if (_rcBiz && !_rcBiz.name?.startsWith("pending_supplier_")) {
        _anyRoleCheck = _rc;
        break;
      }
    }
    // Fall back to any role if no real-biz role found
    if (!_anyRoleCheck && _allRoleChecks.length > 0) _anyRoleCheck = _allRoleChecks[0];

    if (_anyRoleCheck?.businessId) {
      // Switch biz to the one they actually belong to
      const _assignedBiz = await Business.findById(_anyRoleCheck.businessId);
      if (_assignedBiz) {
        biz = _assignedBiz;
        _bizIsOwnedByUser = true;
        // Update session so next request is fast
        await UserSession.findOneAndUpdate(
          { phone },
          { $set: { activeBusinessId: _assignedBiz._id } },
          { upsert: true }
        );
        console.log("[OWNERSHIP] phone", phone, "role-switched to biz", _assignedBiz._id, "as", _anyRoleCheck.role);
      } else {
        _bizIsOwnedByUser = false;
        console.log("[OWNERSHIP] phone", phone, "has no role on biz", biz._id, "- notification contact only");
      }
    } else {
      // No UserRole for this phone on any biz - notification contact or new user.
      _bizIsOwnedByUser = false;
      console.log("[OWNERSHIP] phone", phone, "has no role on any biz - notification contact or new user");
    }
  } else {
    console.log("[OWNERSHIP] phone", phone, "owns biz", biz._id, "as", _ownerRoleCheck.role, "state:", biz.sessionState);
  }
} else {
  // No biz from session - try to find via UserRole
  const _roleForNoBiz = await UserRole.findOne({ phone, pending: false }).sort({ updatedAt: -1 }).lean();
  if (_roleForNoBiz?.businessId) {
    const _roleBiz = await Business.findById(_roleForNoBiz.businessId);
    if (_roleBiz) {
      biz = _roleBiz;
      _bizIsOwnedByUser = true;
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { activeBusinessId: _roleBiz._id } },
        { upsert: true }
      );
      console.log("[OWNERSHIP] phone", phone, "found via role →", _roleBiz._id, "as", _roleForNoBiz.role);
    }
  }
  if (!biz) console.log("[OWNERSHIP] phone", phone, "has NO biz");
}

// ── ZQ TEXT DEEP LINK HANDLER (TOP LEVEL - runs for ALL users, any session state) ─
// ZQ:GROUP:<slug> and ZQ:S:<slug> arrive as plain TEXT messages (not interactive).
// They MUST be handled at depth-1 top level - before ALL state machines, the
// if(!biz) block, the big !isMetaAction mega-block, and any session-state logic.
// Without this: biz users with any sessionState, or no-biz users with leftover
// searchMode/supplierRegState session data, all fall into product search flows
// and get the "Which city?" prompt. This is the definitive fix.
if (!isMetaAction && /^ZQ:GROUP:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  console.log(`[ZQ:GROUP TOP LEVEL] from=${from} text=${text.trim()}`);
  const _zqgTopSlug = text.trim().split(":")[2]?.toLowerCase().trim();
  if (_zqgTopSlug) {
    const _zqgTopHandled = await handleGroupSmartLink({
      from, slug: _zqgTopSlug, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_zqgTopHandled) return;
    // Group not found - send a helpful message rather than falling through
    try { await sendText(from, "❌ This group link is no longer active. Type *menu* to browse ZimQuote."); } catch(_) {}
    return;
  }
}

// ── ZQ:REGISTER - "Add Your Business" broadcast deep link (TOP LEVEL) ────────
// Sent via broadcast campaigns (zqm_add_your_business template button payload
// is "list_my_business" which is handled below, but the link in the message
// body uses ZQ:REGISTER so users who manually tap/copy the URL also land here).
if (!isMetaAction && /^ZQ:REGISTER$/i.test(text.trim())) {
  console.log(`[ZQ:REGISTER] from=${from} → startSupplierRegistration`);
  return startSupplierRegistration(from, biz);
}

// ── ZQ:SGROUP:<slug> - school group smart link (TOP LEVEL) ──────────────────
// School group links arrive as plain text, same as ZQ:GROUP:.
// Must be at depth-1 top level so no session state can intercept them.
if (!isMetaAction && /^ZQ:SGROUP:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  console.log(`[ZQ:SGROUP TOP LEVEL] from=${from} text=${text.trim()}`);
  const _zqsgTopSlug = text.trim().split(":")[2]?.toLowerCase().trim();
  if (_zqsgTopSlug) {
    const { handleSchoolGroupSmartLink } = await import("./groupSmartLink.js");
    const _zqsgTopHandled = await handleSchoolGroupSmartLink({
      from, slug: _zqsgTopSlug, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_zqsgTopHandled) return;
    try { await sendText(from, "❌ This school group link is no longer active. Type *menu* to browse ZimQuote."); } catch(_) {}
    return;
  }
}
if (!isMetaAction && /^ZQ:S:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  console.log(`[ZQ:S TOP LEVEL] from=${from} text=${text.trim()}`);
  // ── Staff slugs use the same ZQ:S: prefix as supplier slugs ─────────────────
  // Check if this slug belongs to a staff card FIRST, before the supplier resolver.
  // Staff cards store their slug in zqSlug; we route them to handleStaffDeepLink
  // by rewriting the text to ZQ:STAFF:SLUG:<slug> which parseStaffSlugLink() handles.
  try {
    const _slug = text.trim().slice(5).toLowerCase(); // strip "ZQ:S:" (5 chars)
    const _StaffCardModel = (await import("../models/staffCard.js")).default;
    const _staffBySlug = await _StaffCardModel.findOne({ zqSlug: _slug }).lean();
    if (_staffBySlug) {
      console.log(`[ZQ:S TOP LEVEL] slug=${_slug} → staff card ${_staffBySlug._id}`);
      const _staffHandled = await handleStaffDeepLink({
        from, text: "ZQ:STAFF:SLUG:" + _slug, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (_staffHandled) return;
    }
  } catch (_slErr) {
    console.warn("[ZQ:S STAFF SLUG CHECK]", _slErr.message);
  }
  // Not a staff slug - try as supplier slug
  const _zqsTopHandled = await handleZqDeepLink({
    from, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (_zqsTopHandled) return;
  try { await sendText(from, "❌ This supplier link is no longer active. Type *menu* to browse ZimQuote."); } catch(_) {}
  return;
}

// ── Numbered seller pick (TOP LEVEL) ─────────────────────────────────────────
// After a Browse & Shop search, results are sent as a numbered seller list.
// A buyer replying with "2" (or "more") opens that seller's smart-link store
// (showSellerMenu → profile card + Get Quote/Order/Enquiry + seller notified).
// tryHandleSellerPickText is heavily guarded internally: it only fires when a
// fresh seller list exists in the session AND the user is not inside any other
// text-entry flow (invoices, registration, sc_ quote flows, school forms, etc),
// so typed numbers in every other flow are untouched. "0"/"00" never match.
if (!isMetaAction && /^(?:[1-9][0-9]{0,2}|more|list|results)$/i.test(text.trim())) {
  try {
    const { tryHandleSellerPickText } = await import("./sellerSearchList.js");
    const _spkHandled = await tryHandleSellerPickText({
      from, phone, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_spkHandled) return;
  } catch (_spkErr) {
    console.warn("[SELLER PICK INTERCEPT]", _spkErr.message);
  }
}

// ── APPLY:SCHOOL:<id> - application form QR deep link (TOP LEVEL) ────────────
// MUST be top-level: without this, APPLY:SCHOOL: falls through to the product
// search flow and returns "Which city?" to the parent.
// Case-insensitive: wa.me pre-fills may lowercase the token.
if (!isMetaAction && /^APPLY:SCHOOL:[a-f0-9]{24}$/i.test(text.trim())) {
  console.log(`[APPLY:SCHOOL TOP LEVEL] from=${from} text=${text.trim()}`);
  const _applyIdTop = text.trim().split(":")[2];
  try {
    const _SPTop = (await import("../models/schoolProfile.js")).default;
    const _applySchoolTop = await _SPTop.findById(_applyIdTop).lean();
    if (_applySchoolTop) {
      const { captureSchoolContact, startSchoolApplicationForm } = await import("./schoolApplicationForm.js");
      const { notifyAllSchoolApplicationInterest } = await import("./schoolNotifications.js");
      captureSchoolContact({ schoolId: _applyIdTop, phone, source: "apply" }).catch(() => {});
      // Notify ALL registered notification numbers (school.phone + notificationContacts[])
      notifyAllSchoolApplicationInterest(_applySchoolTop, from.startsWith("263") ? "0"+from.slice(3) : from).catch(() => {});
      await startSchoolApplicationForm({ from, school: _applySchoolTop, UserSession });
    } else {
      await sendText(from, "❌ This application link is no longer active. Please contact the school directly.");
    }
  } catch (_applyTopErr) {
    console.warn("[APPLY:SCHOOL TOP LEVEL]", _applyTopErr.message);
  }
  return;
}

// ── school_apply_start_<id> - TOP LEVEL early intercept ─────────────────────
// MUST be top-level: a parent who also owns a supplier biz (sessionState =
// "supplier_search_city" etc.) would have this action swallowed by
// handleSupplierRegistrationStates() before reaching the handler at line ~12476.
// This mirrors the APPLY:SCHOOL: deep-link pattern above.
if (isMetaAction && a.startsWith("school_apply_start_")) {
  const _sasIdEarly = a.replace("school_apply_start_", "").trim();
  if (mongoose.Types.ObjectId.isValid(_sasIdEarly)) {
    try {
      const _sasSchoolEarly = await SchoolProfile.findById(_sasIdEarly).lean();
      if (_sasSchoolEarly) {
        const { captureSchoolContact } = await import("./schoolApplicationForm.js");
        const { notifyAllSchoolApplicationInterest } = await import("./schoolNotifications.js");
        captureSchoolContact({ schoolId: _sasIdEarly, phone, source: "apply" }).catch(() => {});
        notifyAllSchoolApplicationInterest(_sasSchoolEarly, from.startsWith("263") ? "0"+from.slice(3) : from).catch(() => {});

        // Check for an active in-progress application session
        const _sasFlowEarly = await UserSession.findOne({ phone }).lean();
        const _sasStateEarly = _sasFlowEarly?.tempData?.schoolApplyState;
        if (_sasStateEarly && _sasStateEarly !== "awaiting_start") {
          await sendText(from,
            "📝 You already started an application for *" + _sasSchoolEarly.schoolName + "*.\n" +
            "Please reply to the last question to continue, or type *restart* to start again."
          );
          return;
        }

        let _sasGradesEarly = [];
        try {
          const _sasParsedEarly = JSON.parse(_sasFlowEarly?.tempData?.schoolApplyData || "{}");
          _sasGradesEarly = _sasParsedEarly.gradeOptions || _sasSchoolEarly.applicationForm?.gradeOptions || [];
        } catch (_) {
          _sasGradesEarly = _sasSchoolEarly.applicationForm?.gradeOptions || [];
        }
        const _sasIntakeEarly = _sasSchoolEarly.applicationForm?.intakeYear || "";

        await UserSession.findOneAndUpdate(
          { phone },
          { $set: {
              "tempData.schoolApplyId":    _sasIdEarly,
              "tempData.schoolApplyState": "awaiting_student_name",
              "tempData.schoolApplyData":  JSON.stringify({
                schoolId:     _sasIdEarly,
                schoolName:   _sasSchoolEarly.schoolName,
                intakeYear:   _sasIntakeEarly,
                gradeOptions: _sasGradesEarly
              })
            }
          },
          { upsert: true }
        );

        await sendText(from,
          "📝 *Application - " + _sasSchoolEarly.schoolName + "*\n" +
          (_sasIntakeEarly ? "_" + _sasIntakeEarly + "_\n" : "") +
          "\nAnswer 5 quick questions and your application goes directly to the school.\n\n" +
          "*Step 1 of 5*\n" +
          "What is the *student's full name?*\n" +
          "_e.g. Tatenda Moyo_"
        );
      } else {
        await sendText(from, "❌ This application link has expired. Please contact the school directly.");
      }
    } catch (_sasEarlyErr) {
      console.warn("[SCHOOL APPLY START TOP LEVEL]", _sasEarlyErr.message);
    }
    return;
  }
}

// ── ZQG EARLY HANDLER (TOP LEVEL - runs for ALL users, any session state) ──────
// zqg_sel_<supplierId>  = buyer tapped a seller row in a group WhatsApp list
// zqg_register_<slug>   = buyer tapped "List Your Business Here" CTA row
//
// MUST be at depth-1 top level - before ALL state machines, session gates,
// and the no-biz welcome-screen gate. Without this placement:
//   • Biz users with sessionState "supplier_search_city" get swallowed by
//     handleSupplierRegistrationStates() which doesn't handle zqg_ actions.
//   • No-biz users hit the welcome-screen gate before the handler below.
// This mirrors the REG TYPE EARLY HANDLER pattern directly below.
if (a.startsWith('zqg_sel_') || a.startsWith('zqg_register_')) {
  console.log(`[ZQG EARLY HANDLER] from=${from} action=${a}`);
  const _zqgEarlyHandled = await handleGroupSellerTap({
    from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (_zqgEarlyHandled) return;
}
// ── ZQSG EARLY HANDLER - school group list-reply taps ───────────────────────
// zqsg_sch_<schoolId>   = visitor tapped a school row in a school group list
// zqsg_register_<slug>  = visitor tapped "Add My School Here" CTA
if (a.startsWith('zqsg_sch_') || a.startsWith('zqsg_register_')) {
  console.log(`[ZQSG EARLY HANDLER] from=${from} action=${a}`);
  const { handleSchoolGroupTap } = await import("./groupSmartLink.js");
  const _zqsgEarlyHandled = await handleSchoolGroupTap({
    from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (_zqsgEarlyHandled) return;
}

// ── REG TYPE EARLY HANDLER ──────────────────────────────────────────────────
// Inserted at the TOP LEVEL, before the if(!isMetaAction || isBuyerRequestMetaReply)
// mega-block (line ~3818) which wraps almost the entire engine.
// reg_type_* arrive as isMetaAction=true list_reply buttons, so ANY handler
// inside that mega-block is dead code for these actions.
// This block must stay here - at depth 1 inside handleIncomingMessage only.
if (
  a === "reg_type_product" ||
  a === "reg_type_service" ||
  a === "reg_type_hospitality" ||
  a === "reg_type_school"
) {
  console.log("[REG_TYPE_FIXED] phone:", phone, "action:", a, "biz:", biz?._id, "state:", biz?.sessionState);

  if (!_bizIsOwnedByUser) biz = null;

  if (!biz) {
    const _ep = await Business.findOne({
      ownerPhone: phone,
      name: "pending_supplier_" + phone
    }).lean();

    if (_ep) {
      biz = await Business.findById(_ep._id);
      await UserSession.findOneAndUpdate(
        { phone },
        { activeBusinessId: biz._id },
        { upsert: true }
      );
    } else {
      biz = await Business.create({
        name: "pending_supplier_" + phone,
        currency: "USD",
        package: "trial",
        subscriptionStatus: "inactive",
        isSupplier: false,
        sessionState: "supplier_reg_name",
        sessionData: { supplierReg: {} },
        ownerPhone: phone
      });
      await UserRole.create({ phone, role: "owner", pending: false, businessId: biz._id });
      await UserSession.findOneAndUpdate(
        { phone },
        { activeBusinessId: biz._id },
        { upsert: true }
      );
    }
  }

  // ── School: set state to school_reg_name and ask for school name ────────
  if (a === "reg_type_school") {
    biz.sessionData  = { supplierReg: { profileType: "school" } };
    biz.sessionState = "school_reg_name";
    await saveBizSafe(biz);
    console.log("[REG_TYPE_FIXED] profileType: school bizId:", biz._id, "-> school_reg_name");
    return sendText(from, `🏫 *School Registration*\n\nWhat is your *school's full name*?\n\n_Type *cancel* at any time to stop._`);
  }

  const profileType =
    a === "reg_type_service"     ? "service"     :
    a === "reg_type_hospitality" ? "hospitality" :
    "product";

  biz.sessionData  = { supplierReg: { profileType } };
  biz.sessionState = "supplier_reg_name";
  await saveBizSafe(biz);

  console.log("[REG_TYPE_FIXED] profileType:", profileType, "bizId:", biz._id, "-> supplier_reg_name");

  return sendText(
    from,
    profileType === "hospitality"
      ? "🏨 *Lodge / Hotel / Tourism Registration*\n\nWhat is your business name?\n\n_Examples:_\n_Wilderness Lodge Kariba_\n_Safari Dreams Hwange_\n_Victoria Falls Guesthouse_"
      : "🏪 *What is your business name?*\n\nExample: *Mudziyashe Hardware*"
  );
}
// ── END REG TYPE EARLY HANDLER ───────────────────────────────────────────────

// ── SCHOOL FAQ EARLY HANDLER ────────────────────────────────────────────────
// MUST be at top level - sfaq_* arrive as isMetaAction=true interactive replies.
// The handler inside the !isMetaAction block at ~line 10875 is dead for these.
if (typeof a === "string" && a.startsWith("sfaq_")) {
  console.log("[SFAQ] phone:", phone, "action:", a);
  const _sfaqHandled = await handleSchoolFAQAction({
    from,
    action: a,
    biz,
    saveBiz: biz ? saveBizSafe.bind(null, biz) : null
  });
  if (_sfaqHandled) return;

  // FAQ handler returned false/undefined - school has no FAQ set up yet.
  // For sfaq_enquiry_, show school contact info instead of error message.
  if (a.startsWith("sfaq_enquiry_")) {
    const _sfaqId = a.replace("sfaq_enquiry_", "").trim();
    try {
      const _sfaqSP = (await import("../models/schoolProfile.js")).default;
      const _sfaqSch = await _sfaqSP.findById(_sfaqId).lean();
      if (_sfaqSch) {
        const _sfaqPh = _sfaqSch.contactPhone || _sfaqSch.phone || "";
        const _dispPh = _sfaqPh.startsWith("263") ? "0"+_sfaqPh.slice(3) : _sfaqPh;
        await sendButtons(from, {
          text:
            `❓ *Enquiries - ${_sfaqSch.schoolName}*\n\n` +
            `To ask a question, contact the school directly:\n\n` +
            `📞 Call or WhatsApp: *${_dispPh}*\n` +
            (_sfaqSch.email   ? `📧 ${_sfaqSch.email}\n`   : "") +
            (_sfaqSch.website ? `🌐 ${_sfaqSch.website}\n` : "") +
            `\n_The school team will get back to you._`,
          buttons: [
            { id: `school_apply_start_${_sfaqId}`, title: "📝 Apply on WhatsApp" },
            { id: "school_search_refine", title: "🏫 More Schools" }
          ]
        });
        return;
      }
    } catch (_sfaqErr) { console.warn("[SFAQ FALLBACK]", _sfaqErr.message); }
  }

  console.warn("[SFAQ] unhandled sfaq action:", a);
  return sendText(from, "Sorry, that option expired. Please open the school link again to start fresh.");
}
// ── END SCHOOL FAQ EARLY HANDLER ─────────────────────────────────────────────
// ── SCHOOL REG EARLY HANDLER ────────────────────────────────────────────────
// MUST be at top level - school_reg_* and school_admin_* arrive as
// isMetaAction=true interactive replies. The handler inside the
// !isMetaAction block (~line 12278) is dead code for these actions.
// This mirrors the REG TYPE EARLY HANDLER pattern above.
if (
  a.startsWith("school_reg_type_") ||
  a.startsWith("school_reg_city_") ||
  a.startsWith("school_reg_cur_") ||
  a.startsWith("school_reg_gender_") ||
  a.startsWith("school_reg_boarding_") ||
  a.startsWith("school_reg_fac_") ||
  a.startsWith("school_reg_ext_") ||
  a === "school_reg_city_more" ||
  a.startsWith("school_plan_") ||
  a === "school_reg_address_skip" ||
  a === "school_reg_principal_skip" ||
  a === "school_reg_email_skip" ||
  a === "school_reg_cur_done" ||
  a === "school_reg_fac_done" ||
  a === "school_reg_ext_done" ||
  a === "school_reg_city_other" ||
  a === "school_reg_confirm_yes" ||
  a === "school_reg_confirm_no" ||
  // FIX: parents tapping "Apply on WhatsApp" button must not hit welcome-screen gate
  a.startsWith("school_apply_start_") ||
  // FIX: grade list-reply taps during application must pass through
  a.startsWith("sa_grade_") ||
  a === "school_admin_manage_facilities" ||
  a === "school_admin_manage_extramural" ||
  a === "school_admin_edit_fees" ||
  a === "school_admin_edit_reg_link" ||
  a === "school_admin_edit_email" ||
  a === "school_admin_edit_website" ||
  a === "school_admin_upload_brochure" ||
  a.startsWith("school_fac_page_") ||
  a.startsWith("school_fac_toggle_") ||
  a.startsWith("school_ext_page_") ||
  a.startsWith("school_ext_toggle_")
) {
  console.log("[SCHOOL_REG_FIXED] phone:", phone, "action:", a, "state:", biz?.sessionState);

  if (!biz) {
    await sendText(from, "❌ Session expired. Type *menu* to start again.");
    return;
  }

  // ── school registration + plan actions ──────────────────────────────────
  if (a.startsWith("school_reg_") || a.startsWith("school_plan_")) {
    const handled = await handleSchoolRegistrationActions({
      action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (handled) return;
  }

  // ── school admin: facilities ─────────────────────────────────────────────
  if (
    a === "school_admin_manage_facilities" ||
    a.startsWith("school_fac_page_") ||
    a.startsWith("school_fac_toggle_")
  ) {
    const handled = await handleSchoolSearchActions({
      action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (handled) return;
  }

  // ── school admin: extramural + other admin ───────────────────────────────
  if (
    a === "school_admin_manage_extramural" ||
    a === "school_admin_edit_fees" ||
    a === "school_admin_edit_reg_link" ||
    a === "school_admin_edit_email" ||
    a === "school_admin_edit_website" ||
    a === "school_admin_upload_brochure" ||
    a.startsWith("school_ext_page_") ||
    a.startsWith("school_ext_toggle_")
  ) {
    const handled = await handleSchoolAdminStates({
      state: biz.sessionState, from, text: "", action: a,
      biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (handled) return;
  }
}
// ── END SCHOOL REG EARLY HANDLER ─────────────────────────────────────────────




// ─────────────────────────────────────────────────────────────
// GLOBAL COMMAND/TEXT LOGGER
// Captures EVERY incoming text/button/list/smart-link before flows return
// ─────────────────────────────────────────────────────────────
try {
  const __logSess = await UserSession.findOne({ phone }).lean();

  const __rawCommand = String(action || text || "").trim();

  if (__rawCommand) {
    const __source =
      /^ZQ:/i.test(__rawCommand) ? "smart_link" :
      typeof isMetaAction !== "undefined" && isMetaAction ? "button" :
      "text";

    const __flow =
      /^find\s+school/i.test(__rawCommand) || /^ZQ:SCHOOL:/i.test(__rawCommand) ? "school_search" :
      /^find\s+/i.test(__rawCommand) || __rawCommand.startsWith("sup_") || /^ZQ:SUPPLIER:/i.test(__rawCommand) ? "supplier_search" :
      __rawCommand.startsWith("seller_") ? "seller_chat" :
      "main";

    await logSearchCommand({
      phone,
      rawText: __rawCommand,
      source: __source,
      flow: __flow,
      sessionState:
        biz?.sessionState ||
        __logSess?.tempData?.buyerRequestState ||
        __logSess?.tempData?.orderState ||
        __logSess?.tempData?.supplierSearchState ||
        "",
      parsed: {},
      resultMode: "unknown",
      results: [],
      botReplySummary: "Incoming user command/text captured globally",
      meta: {
        text,
        action,
        isMetaAction: typeof isMetaAction !== "undefined" ? isMetaAction : null,
        buyerRequestState: __logSess?.tempData?.buyerRequestState || "",
        orderState: __logSess?.tempData?.orderState || "",
        supplierSearchType: __logSess?.tempData?.supplierSearchType || "",
        supplierSearchProduct: __logSess?.tempData?.supplierSearchProduct || "",
        activeBusinessId: __logSess?.activeBusinessId || null
      }
    });
  }
} catch (err) {
  console.warn("[GLOBAL COMMAND LOG FAILED]", err.message);
}

  // ── ZQ CHATBOT LINK INTERCEPT ─────────────────────────────────────────────
  // Must be placed HERE - after biz is declared, but before the supplier
  // search text handler (which was treating ZQ:SCHOOL:... as a product search).
  // ZQ:SCHOOL:<id> and ZQ:SUPPLIER:<id> arrive as plain text from wa.me links.
  //
  // FIX: wa.me pre-fill text sometimes gets doubled by WhatsApp
  //   e.g. "ZQ:SUPPLIER:<id>ZQ:SUPPLIER:<id>"
  // Extract only the FIRST valid 24-char hex ObjectId so the doubled/malformed
  // string never reaches the ObjectId parser.
  if (/ZQ:(SCHOOL|SUPPLIER):[a-f0-9]{24}/i.test(text)) {
    const _zqMatch = text.match(/ZQ:(SCHOOL|SUPPLIER):([a-f0-9]{24})/i);
    const _zqCleanText = _zqMatch ? ("ZQ:" + _zqMatch[1].toUpperCase() + ":" + _zqMatch[2]) : text;
    const _zqHandled = await handleZqDeepLink({
      from, text: _zqCleanText, biz,
      saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_zqHandled) return;
  }

  // ── HARD-RESET: "menu" / "0" / "cancel" / main_menu_back always escape ───────
  // Runs BEFORE all state interceptors (buyer request flow, seller pending request,
  // smart-link quote state, booking flow) so no active state can trap a user.
  // This fixes: seller stuck viewing the same pending request; buyer unable to
  // reach the main menu while in a quote/booking/request flow.
  const _isHardReset =
    al === "menu"      || al === "main menu" || al === "main_menu" ||
    al === "0"         || al === "00"        || al === "000"       ||
    al === "cancel"    ||
    a  === "main_menu_back";

  if (_isHardReset) {
    // Reset buyer biz session if stuck in any flow state
    if (biz && biz.sessionState && biz.sessionState !== "ready") {
      biz.sessionState = "ready";
      biz.sessionData  = {};
      await saveBizSafe(biz);
    }
    // Clear ALL active flow state from UserSession so nothing re-triggers
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: {
          // Buyer request flow
          "tempData.buyerRequestState":      "",
          "tempData.pendingBuyerRequest":    "",
          "tempData.buyerRequestMode":       "",
          // Seller BuyerRequest flow
          "tempData.sellerRequestReplyState": "",
          "tempData.sellerRequestId":         "",
          "tempData.pendingDraftQuote":       "",
          "tempData.pendingOfferResponse":    "",
          // Seller smart-link quote flow
          "tempData.scSellerQuoteState":      "",
          // Browse-and-shop quote reply
          "tempData.pendingQuoteReply":       "",
          // Clear activeBusinessId if current biz is a pending_supplier_ registration
          // so sendMainMenu re-resolves to the user's real biz via UserRole scan
          ...(biz?.name?.startsWith("pending_supplier_") ? { activeBusinessId: "" } : {})
      }},
      { upsert: true }
    );
    // If biz is a pending registration, force sendMainMenu to resolve fresh
    if (biz?.name?.startsWith("pending_supplier_")) {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { activeBusinessId: "" } },
        { upsert: true }
      );
    }
    return sendMainMenu(from);
  }

  // ZQ:REQUEST deep link
  // Share: https://wa.me/263771143904?text=ZQ%3AREQUEST
  // Drops any user straight into Request Sellers flow.
  if (/^ZQ:REQUEST$/i.test(text)) {
    if (biz && biz.sessionState !== "ready") {
      biz.sessionState = "ready";
      biz.sessionData  = {};
      await saveBizSafe(biz);
    }
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.buyerRequestState":  "awaiting_items",
          "tempData.buyerRequestMode":   "simple",
          "tempData.pendingBuyerRequest": { requestType: "simple", profileType: "product", items: [] }
        }
      },
      { upsert: true }
    );
    return sendButtons(from, {
      text:
        "\u26a1 *Request Sellers*\n\n"
        + "Get quotes from sellers in your area. Type what you need and your city.\n\n"
        + "*Examples:*\n"
        + "_cement 10 bags harare_\n"
        + "_geyser repair avondale harare_\n"
        + "_school uniform size 8 bulawayo_\n"
        + "_lodge night harare 2 adults_\n\n"
        + "Type your request below \u2193",
      buttons: [
        { id: "sup_request_mode_bulk", title: "Bulk / List"  },
        { id: "main_menu_back",        title: "Main Menu"    }
      ]
    });
  }

    // ── GLOBAL school shortcode trigger ──────────────────────────────────────
  // Must run before supplier shortcode search and before no-biz early returns,
  // but only after isMetaAction and biz are available.
  const SCHOOL_TRIGGER_PHRASES = [
  "find school", "find schools",
  "find primary", "find secondary", "find combined", "find preschool",
  "find ecd", "find kindergarten", "find boarding school", "find day school",
  "find girls school", "find boys school", "find mixed school",
  "find budget school", "find affordable school", "find cheap school",
  "find premium school",
  "find cambridge school", "find cambridge",
  "find zimsec school", "find zimsec",
  "find ib school", "find ib",
  "find a school", "look for school", "search school",
  "find private", "find government", "find mission", "find independent",
  "private school", "private schools",
  "government school", "government schools",
  "mission school", "independent school",
  "school in ", "schools in ", "primary school in ", "secondary school in "
];

  const isSchoolShortcodeQuery =
    typeof action === "string" &&
    SCHOOL_TRIGGER_PHRASES.some(phrase => al.startsWith(phrase) || al.includes(phrase));

  if (!isMetaAction && text.trim().length > 2 && isSchoolShortcodeQuery) {
    const handled = await runSchoolShortcodeSearch({
      from,
      text,
      biz,
      saveBiz: biz ? saveBizSafe : async () => {}
    });
    if (handled !== false) return handled;
  }

  // ── School search FREE-TEXT (typed school name / city inside the funnel) ─────
  // If the user is in the parent school-search funnel and types free text instead
  // of tapping a city button, route it to SCHOOL search - not the Request Sellers
  // flow. Covers biz-owners (sessionState) AND non-biz parents (one-shot marker).
  // Runs AFTER the "find ..." shortcode block and BEFORE the Request Sellers
  // catch-all further down, so a typed school name is never hijacked. A bare name
  // like "hellenic academy" is handled as a NAME search inside the handler.
  if (!isMetaAction && !isSchoolShortcodeQuery && text.trim().length > 1) {
    const _navTok = /^(0|00|menu|main menu|back|cancel|exit|home|hi|hie|hey|hello|start)$/i.test(text.trim());
    if (!_navTok) {
      let _inSchoolSearch =
        !!biz && (biz.sessionState === "school_search_city" || biz.sessionState === "school_search_results");

      if (!_inSchoolSearch && !biz) {
        try {
          const _ssCheck = await UserSession.findOne({ phone }).lean();
          _inSchoolSearch =
            !!_ssCheck?.tempData?.schoolSearchActive &&
            !_ssCheck?.tempData?.buyerRequestState &&
            !_ssCheck?.tempData?.orderState;
        } catch (_) {}
      }

      if (_inSchoolSearch) {
        const handled = await handleSchoolFreeTextSearch({
          from, text, biz, saveBiz: biz ? saveBizSafe : async () => {}
        });
        if (handled !== false) return handled;
      }
    }
  }

  // AUTO-RESET: If a real (non-ghost) supplier's biz is stuck in a registration
  // payment state but their subscription is already active, clear the stale state.
  // This happens when payment completes asynchronously and sessionState is never
  // cleared, leaving the seller's searches routed to the EcoCash handler.
  if (
    biz &&
    !isGhostSupplierBiz &&
    biz.isSupplier &&
    biz.subscriptionStatus === "active" &&
    (biz.sessionState === "supplier_reg_enter_ecocash" ||
     biz.sessionState === "supplier_reg_payment_pending")
  ) {
    biz.sessionState = "ready";
    await saveBizSafe(biz);
  }

  // =========================
  // 📨 BUYER REQUEST / SELLER RESPONSE TEXT STATES
  // =========================
const BUYER_REQUEST_META_ACTIONS = new Set([
  "view_and_quote",
  "not_available",
  "sup_skip_service_address",
  "sup_request_delivery_yes",
  "sup_request_delivery_no",
  "sup_request_delivery_flexible",
  "sup_request_mode_simple",
  "sup_request_mode_bulk"
]);

const isBuyerRequestMetaReply =
  // ── Any recognised button/list tap always enters the mega-block ─────────
  isMetaAction ||
  // ── Plain-text buyer replies that are NOT isMetaAction ───────────────────
  BUYER_REQUEST_META_ACTIONS.has(a) ||
  al === "view & quote" ||
  al === "view and quote" ||
  al === "not available" ||
  al === "confirm" ||
  al === "send" ||
  al === "skip";

if (!isMetaAction || isBuyerRequestMetaReply) {
    const flowSess = await UserSession.findOne({ phone });
    const buyerRequestState = flowSess?.tempData?.buyerRequestState || null;
    const pendingBuyerRequest = flowSess?.tempData?.pendingBuyerRequest || null;

    // Handle plain text "accept ORD-XXXXXX" or "decline ORD-XXXXXX" replies
    // from suppliers who received the template outside the 24hr window
    const _orderReplyMatch = al.match(/^(accept|decline)\s+(ord-[a-f0-9]+)$/i);
    if (_orderReplyMatch) {
      const _action = _orderReplyMatch[1].toLowerCase();
      const _orderRefSuffix = _orderReplyMatch[2].replace("ord-", "").toLowerCase();
      const _matchedOrder = await SupplierOrder.findOne({
        supplierPhone: { $in: [from, phone] },
        status: "pending"
      }).sort({ createdAt: -1 }).lean();

      if (_matchedOrder && String(_matchedOrder._id).slice(-6).toLowerCase() === _orderRefSuffix) {
        if (_action === "accept") {
          return handleOrderAccepted(from, String(_matchedOrder._id), biz, saveBiz);
        } else {
          return handleOrderDeclined(from, String(_matchedOrder._id), biz, saveBiz);
        }
      }
      return sendText(from, `❌ Order not found. Please open the chatbot menu to view your orders.`);
    }

    
    const sellerRequestReplyState = flowSess?.tempData?.sellerRequestReplyState || null;
    const sellerRequestId = flowSess?.tempData?.sellerRequestId || null;
    let pendingDraftQuote = null;
    try {
      const _rawDraft = flowSess?.tempData?.pendingDraftQuote;
      pendingDraftQuote = _rawDraft
        ? (typeof _rawDraft === "string" ? JSON.parse(_rawDraft) : _rawDraft)
        : null;
    } catch (_) { pendingDraftQuote = null; }



      // ── Smart link quote: seller tapped "View & Quote" or "Enter Prices" ────────
    // Fires when the seller has a pending draft quote from the sc_ smart link flow
    // (stored as scPendingSellerQuote in their UserSession by sellerChat.js _scQuoteDone).
    // This has nothing to do with BuyerRequest - it's a direct smart-link quote.
    //
    // FIX: use the scPendingDrafts MAP keyed by refNum so the correct draft is
    // returned when the seller has multiple concurrent smart-link quote notifications.
    {
      // Extract refNum from the action button ID if it's a specific quote action
      let _scTargetRef = null;
      if (a?.startsWith("sc_quote_confirm_")) _scTargetRef = a.replace("sc_quote_confirm_", "").toUpperCase();
      else if (a?.startsWith("sc_quote_edit_")) _scTargetRef = a.replace("sc_quote_edit_", "").toUpperCase();
      else if (a?.startsWith("sc_rfq_price_"))  _scTargetRef = a.replace("sc_rfq_price_", "").toUpperCase();

      let _scDraft = null;
      const _draftsMapRaw = flowSess?.tempData?.scPendingDrafts;

      // Try the map with the specific refNum from the button (most reliable)
      if (_draftsMapRaw && _scTargetRef) {
        try {
          const _map = typeof _draftsMapRaw === "string" ? JSON.parse(_draftsMapRaw) : _draftsMapRaw;
          const _candidate = _map[_scTargetRef];
          if (_candidate) _scDraft = typeof _candidate === "string" ? JSON.parse(_candidate) : _candidate;
        } catch (_) {}
      }

      // For "view_and_quote" (no specific refNum), use scLastNotifiedRef to pick the right draft
      if (!_scDraft && _draftsMapRaw) {
        const _lastRef = flowSess?.tempData?.scLastNotifiedRef;
        if (_lastRef) {
          try {
            const _map = typeof _draftsMapRaw === "string" ? JSON.parse(_draftsMapRaw) : _draftsMapRaw;
            const _candidate = _map[_lastRef];
            if (_candidate) _scDraft = typeof _candidate === "string" ? JSON.parse(_candidate) : _candidate;
          } catch (_) {}
        }
      }

      // Final fallback: legacy scPendingSellerQuote scalar (backward compat)
      if (!_scDraft) {
        const _legacyRaw = flowSess?.tempData?.scPendingSellerQuote;
        if (_legacyRaw) {
          try { _scDraft = typeof _legacyRaw === "string" ? JSON.parse(_legacyRaw) : _legacyRaw; } catch (_) {}
        }
      }

      // FIX: Also check biz.sessionData.scLastRFQ - RFQ smart-link quotes store
      // their data there (not in UserSession scPendingDrafts). When the seller/buyer
      // taps view_and_quote from the template, scLastRFQ has the items and refNum.
      if (!_scDraft && biz?.sessionData?.scLastRFQ) {
        const _lastRfq = biz.sessionData.scLastRFQ;
        // Only use if reasonably recent (within 48 hours)
        if (_lastRfq && (_lastRfq.timestamp || 0) > Date.now() - 48 * 60 * 60 * 1000) {
          _scDraft = {
            refNum:      _lastRfq.refNum,
            supplierId:  _lastRfq.supplierId,
            buyerPhone:  _lastRfq.buyerPhone,
            buyerName:   _lastRfq.buyerName,
            lineItems:   [],
            items:       _lastRfq.items || [],
            total:       0,
            isRFQ:       true,
            isService:   _lastRfq.isService || false
          };
        }
      }
 
      // Determine whether the sc_ draft handler or the BuyerRequest handler should win.
      // Key insight: req_offer_<ObjectId> = marketplace BuyerRequest button
      //              req_offer_<RFQ-/QT-> = smart-link quote button (no BuyerRequest doc)
      //              view_and_quote        = could be either; check _scDraft first
      //
      // BuyerRequest handler wins ONLY when:
      //   1. There is an active sellerRequestReplyState OR sellerRequestId in session, AND
      //   2. The extracted button ID is a valid MongoDB ObjectId (marketplace request)
      // In all other cases, sc_ draft handler wins (if _scDraft exists).

      // Extract the button payload ID for classification
      let _btnExtracted = "";
      if (a?.startsWith("req_offer_") && !a.startsWith("req_offer_confirm_")) {
        _btnExtracted = a.replace("req_offer_", "").trim();
      } else if (a?.startsWith("req_unavail_")) {
        _btnExtracted = a.replace("req_unavail_", "").trim();
      }
      // Is this button carrying a real MongoDB ObjectId (marketplace) or a ref string (smart-link)?
      const _btnIsObjectId = _btnExtracted ? mongoose.Types.ObjectId.isValid(_btnExtracted.toUpperCase()) || 
        mongoose.Types.ObjectId.isValid(_btnExtracted) : false;
      const _btnIsSmartLinkRef = _btnExtracted && !_btnIsObjectId; // RFQ-xxxx, QT-xxxx etc

      // BuyerRequest wins only when we have an active BuyerRequest session state
      // AND the button carries a real ObjectId (not a smart-link ref)
      const _hasBuyerReqPending = !!(
        (sellerRequestReplyState === "awaiting_offer_intro" || sellerRequestReplyState === "awaiting_offer" || sellerRequestId) &&
        !_btnIsSmartLinkRef
      );

      // FIX: If a smart-link draft exists AND this is a view_and_quote tap, the sc_ draft
      // ALWAYS wins - even if sellerRequestReplyState is set from a stale/previous marketplace
      // request. The scLastNotifiedRef on the session proves this notification was for this
      // smart-link draft, not for any BuyerRequest. Without this fix, a stale
      // sellerRequestReplyState makes _hasBuyerReqPending=true which suppresses _scDraftHandles
      // and routes the seller into the BuyerRequest flow → "That request has closed."
      const _scDraftIsForThisNotification = _scDraft &&
        (a === "view_and_quote" || al === "view & quote" || al === "view and quote") &&
        flowSess?.tempData?.scLastNotifiedRef;

      const _scDraftHandles = _scDraft && !(
        _hasBuyerReqPending &&
        !_scDraftIsForThisNotification && // smart-link draft always overrides stale BuyerReq state
        (
          a === "view_and_quote" || al === "view & quote" || al === "view and quote" ||
          a === "not_available" || al === "not available" ||
          (a?.startsWith("req_offer_") && _btnIsObjectId) ||
          (a?.startsWith("req_unavail_") && _btnIsObjectId)
        )
      );

      if (_scDraftHandles && (
        a === "view_and_quote" ||
        al === "view & quote" ||
        al === "view and quote" ||
        a?.startsWith("sc_quote_confirm_") ||
        a?.startsWith("sc_quote_edit_") ||
        a?.startsWith("sc_rfq_price_") ||
        flowSess?.tempData?.scSellerQuoteState === "awaiting_seller_price_edit"
      )) {
        const { handleSellerChatAction, handleSellerChatState } = await import("./sellerChat.js");
 
        if (a === "view_and_quote" || al === "view & quote" || al === "view and quote") {
          // Seller tapped template button - show them the draft quote for confirmation.
          // Clear any stale sellerRequestReplyState so it can't interfere with future actions.
          if (sellerRequestReplyState) {
            await UserSession.findOneAndUpdate(
              { phone },
              { $unset: {
                  "tempData.sellerRequestReplyState": "",
                  "tempData.sellerRequestId":          "",
                  "tempData.pendingDraftQuote":        "",
                  "tempData.pendingOfferResponse":     ""
              }},
              { upsert: true }
            );
          }
          const _scSeller  = await SupplierProfile.findById(_scDraft.supplierId).lean();
          const _scRefNum  = (_scDraft.refNum || "").toUpperCase();
          const _scItems   = (_scDraft.lineItems || []);
          const _scTotal   = _scDraft.total || 0;
          const _scExpiry  = _scDraft.expiry || "";
          const _scIsRFQ   = _scDraft.isRFQ || false;
 
          if (_scIsRFQ) {
            // RFQ - seller needs to enter prices
            // FIX: write the RFQ draft into scPendingDrafts so _scProcessSellerPriceEdit
            // can find it when the seller types their prices (it looks up from session storage).
            const _rfqRawItems = _scDraft.items || _scItems || [];
            const _rfqLineItems = _rfqRawItems.map(it => ({
              name:      it.name || it.product || "Item",
              qty:       Number(it.qty || it.quantity || 1),
              unitPrice: 0,
              lineTotal: 0,
              unit:      it.unit || "job"
            }));
            const _rfqDraftToStore = {
              refNum:    _scRefNum,
              supplierId: _scDraft.supplierId,
              buyerPhone: _scDraft.buyerPhone,
              buyerName:  _scDraft.buyerName,
              lineItems:  _rfqLineItems,
              items:      _rfqRawItems,
              total:      0,
              isRFQ:      true,
              storedAt:   Date.now()
            };

            // Read existing drafts map, add this entry, write back
            const _rfqSessNow = await UserSession.findOne({ phone }).lean();
            let _rfqDraftsMap = {};
            try {
              const _rfqRaw = _rfqSessNow?.tempData?.scPendingDrafts;
              _rfqDraftsMap = _rfqRaw ? (typeof _rfqRaw === "string" ? JSON.parse(_rfqRaw) : _rfqRaw) : {};
            } catch (_) {}
            _rfqDraftsMap[_scRefNum] = _rfqDraftToStore;

            await UserSession.findOneAndUpdate(
              { phone },
              { $set: {
                  "tempData.scSellerQuoteState":   "awaiting_seller_price_edit",
                  "tempData.scLastNotifiedRef":    _scRefNum,
                  "tempData.scPendingDrafts":      JSON.stringify(_rfqDraftsMap),
                  "tempData.scPendingSellerQuote": JSON.stringify(_rfqDraftToStore)
              }},
              { upsert: true }
            );

            // Build the item list with qty shown so seller knows what they're pricing
            // Flag items with long names (likely buyer's full paragraph) so seller knows to rename
            const _rfqItemList = _rfqLineItems.map((it, i) => {
              const _longFlag = (it.name || "").length > 60 ? " ⚠️ _rename this_" : "";
              return `${i + 1}. *${it.name}* × ${it.qty}${_longFlag}`;
            }).join("\n");

            // Show buyer's full notes (scope of work) if present
            const _rfqBuyerNotes = (_scDraft.items || [])
              .map(it => it.notes || "").filter(n => n && n.length > 10)
              .slice(0, 1)[0] || "";
            const _buyerNotesSection = _rfqBuyerNotes
              ? `\n📝 *Buyer's full request:*\n_"${_rfqBuyerNotes.slice(0, 400)}"_\n`
              : "";

            // Build examples using × separator (clearer than = for prices)
            const _rfqEx = _rfqLineItems.slice(0, 3).map((it, i) => {
              const exPrice = [350, 120, 25][i] || 50;
              return `${i + 1}×${exPrice}`;
            }).join("  ");

            // Check if any item name is very long (buyer sent a paragraph)
            const _hasLongItems = _rfqLineItems.some(it => (it.name || "").length > 60);

            const _howToSection =
              `─────────────────\n` +
              `*How to quote:*\n\n` +
              `*1️⃣ Set price:*\n` +
              `_1×350_ or _1=350_ → item 1 = $350\n` +
              `_1×350, 2×120_ → price two items\n\n` +
              (_hasLongItems
                ? `*2️⃣ Rename the item* (buyer sent a long description - clean it up):\n` +
                  `_rename 1: Bill of Quantities (4-bed house, 280m², Ruwa)_\n` +
                  `_Or in one line: 1×350 Bill of Quantities (4-bed, Ruwa)_\n\n`
                : `*2️⃣ Rename (optional):*\n` +
                  `_rename 1: Short professional name_\n\n`) +
              `*3️⃣ Add extra line items* (outside your catalogue):\n` +
              `_add: Disbursements - $50_\n` +
              `_add: Turnaround time: 5 working days_\n` +
              `_add: Travel to site - $30_\n\n` +
              `Type *confirm* to send · *cancel* to discard`;

            // Short, clear guide - avoid wall-of-text
            const _rfqGuide =
              `*How to price:*\n` +
              `_1×350_ → set item 1 to $350\n` +
              `_1×350, 2×120_ → price multiple\n` +
              `_pick 3_ → add your catalogue item 3\n` +
              `_add: Site visit - $80_ → add custom item\n` +
              `_rename 1: BOQ 4-bed house_ → shorten long name\n` +
              `_note: 50% deposit required_ → add PDF note\n\n` +
              `Type *confirm* to send  ·  *cancel* to discard`;

            return sendButtons(from,
              {
                text:
                  `📋 *Quote ${_scRefNum}* - price and send to buyer\n\n` +
                  `Buyer: *${_scDraft.buyerName || _scDraft.buyerPhone || "Buyer"}*\n` +
                  _buyerNotesSection +
                  `*Requested:*\n${_rfqItemList}\n\n` +
                  _rfqGuide,
                buttons: [
                  { id: `sc_quote_edit_${_scRefNum}`,    title: "✏️ Edit & Price" },
                  { id: `sc_quote_preview_${_scRefNum}`, title: "👁 Preview PDF" }
                ]
              }
            );
          }
 
          // Priced quote - show draft for confirm/edit
          const _itemRows = _scItems.map((l, i) =>
            `${i + 1}. ${l.name} × ${l.qty} - $${Number(l.unitPrice).toFixed(2)} = $${Number(l.lineTotal).toFixed(2)}`
          ).join("\n");

          // Show buyer description as reference (stripped from items, stored separately)
          const _buyerRef = _scDraft.buyerDescription
            ? `\n📝 *Buyer's request:* _"${String(_scDraft.buyerDescription).slice(0, 150)}${String(_scDraft.buyerDescription).length > 150 ? "..." : ""}"_\n`
            : "";

          // No items yet (natural text was auto-stripped) OR all items are $0
          const _allZero = _scItems.length === 0 || _scItems.every(l => !l.unitPrice || l.unitPrice === 0);
          const _itemSection = _scItems.length > 0
            ? `${_itemRows}\n${"─".repeat(28)}\n*Total: $${_scTotal.toFixed(2)} USD*`
            : `_No items yet - tap Edit & Price to add your items._`;

          return sendButtons(from, {
            text:
              `📋 *Quote ${_scRefNum}*${_buyerRef}\n` +
              `Buyer: ${_scDraft.buyerName || _scDraft.buyerPhone || "Buyer"}\n\n` +
              `${_itemSection}\n\n` +
              (_allZero
                ? `⚠️ *Tap Edit & Price to build your quote.*\n` +
                  `Add items from your catalogue, type custom ones, or both.`
                : `Confirm to send the quote and PDF to the buyer, or edit first.`),
            buttons: [
              ...(_allZero ? [] : [{ id: `sc_quote_confirm_${_scRefNum}`, title: "✅ Confirm & Send" }]),
              { id: `sc_quote_edit_${_scRefNum}`, title: _allZero ? "✏️ Edit & Price" : "✏️ Edit Prices" }
            ]
          });
        }
 
        // Route all other sc_ actions (confirm, edit, rfq_price) to sellerChat action handler
        if (a?.startsWith("sc_quote_confirm_") || a?.startsWith("sc_quote_edit_") || a?.startsWith("sc_rfq_price_")) {
          const _handled = await handleSellerChatAction({ from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz) });
          if (_handled) return;
        }
 
        // Seller typed a price edit while scSellerQuoteState === "awaiting_seller_price_edit"
        if (flowSess?.tempData?.scSellerQuoteState === "awaiting_seller_price_edit" && text && !isMetaAction) {
          const _handled = await handleSellerChatState({
            state: "sc_awaiting_items", // triggers the UserSession check inside handleSellerChatState
            from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
          });
          if (_handled) return;
        }
      }
    }


    // ── awaiting_offer_intro: supplier's FIRST reply after template ──────────────
    // Fires regardless of what they typed ("hi", "hello", a price, anything).
    // Shows them the full item list + View & Quote button properly.
    // This is the reliable entry point for outside-24hr-session suppliers.
    //
    // FIX: if the seller is currently in an active sc_ smart-link buyer session
    // (e.g. a buyer is browsing their hospitality catalogue and typing item numbers),
    // the sc_ flow must take priority. We skip the BuyerRequest interceptor so the
    // seller's biz.sessionState sc_awaiting_items is handled correctly downstream.
    // EXCEPTION: "view_and_quote", "not_available", and req_offer_/req_unavail_ actions
    // are definitive BuyerRequest seller actions (from the WhatsApp template button).
    // They ALWAYS bypass the sc_ guard - they must work even when biz is in sc_ state.
    // This handles the race condition where sc_quote saves sc_awaiting_items before failing,
    // leaving the biz stuck in sc_ state when the seller later taps "View & Quote".
    // FIX: req_offer_confirm_ is handled by its OWN handler (line ~17230) which 
    // returns before awaiting_offer_intro. Exclude it here so awaiting_offer_intro
    // does not also fire and show the request again after the quote is sent.
    const _isBuyerReqAction = a === "view_and_quote" || al === "view & quote" ||
      al === "view and quote" || a === "not_available" || al === "not available" ||
      (a?.startsWith("req_offer_") && !a.startsWith("req_offer_confirm_")) ||
      a?.startsWith("req_unavail_");

    // ── Resolve the requestId BEFORE deciding whether to enter the block ────────
    // Priority order:
    //  1. req_offer_<id> / req_unavail_<id> button - most reliable, use directly
    //  2. sellerRequestId from session - set when notification was sent
    //  3. view_and_quote with no session id - look up from sellerPendingRequests map
    // We do NOT fall back to "newest request in DB" - that always opens the wrong one.
    let _resolvedRequestId = sellerRequestId;

    // Step 1: extract ID from specific button press (overrides everything)
    // FIX: uppercase the extracted value - WhatsApp lowercases button payloads
    // so "req_offer_RFQ-M5Q5TN" arrives as "req_offer_rfq-m5q5tn".
    // We uppercase so findBuyerRequestByIdOrRef gets "RFQ-M5Q5TN" not "rfq-m5q5tn".
    if (a?.startsWith("req_offer_") && !a.startsWith("req_offer_confirm_")) {
      const _btnId = a.replace("req_offer_", "").trim().toUpperCase();
      if (_btnId && _btnId.length > 5) _resolvedRequestId = _btnId;
    } else if (a?.startsWith("req_unavail_")) {
      const _btnId = a.replace("req_unavail_", "").trim().toUpperCase();
      if (_btnId && _btnId.length > 5) _resolvedRequestId = _btnId;
    }

    // Step 2: for view_and_quote with no id, check the sellerPendingRequests map
    // (stored when the notification was sent). Never use a generic DB newest query.
    if (!_resolvedRequestId && (a === "view_and_quote" || al === "view & quote" || al === "view and quote")) {
      try {
        const _vpSess = await UserSession.findOne({ phone }).lean();
        const _vpMap  = _vpSess?.tempData?.sellerPendingRequests || {};
        const _vpIds  = Object.keys(_vpMap).filter(Boolean);
        if (_vpIds.length === 1) {
          _resolvedRequestId = _vpIds[0];
        } else if (_vpIds.length > 1) {
          // Multiple - use the most recently stored one (storedAt)
          _resolvedRequestId = _vpIds.sort((a, b) =>
            ((_vpMap[b]?.storedAt || 0) - (_vpMap[a]?.storedAt || 0))
          )[0];
        }
      } catch (_) {}
    }

    // Only enter the BuyerRequest flow if:
    // - There's an active sellerRequestReplyState (from a previous notification), OR
    // - The resolved ID is a valid MongoDB ObjectId (marketplace BuyerRequest)
    // Smart-link refs (RFQ-xxxx, QT-xxxx) are NOT BuyerRequest IDs - they have no DB doc.
    const _resolvedIsObjectId = _resolvedRequestId && 
      (mongoose.Types.ObjectId.isValid(_resolvedRequestId) || mongoose.Types.ObjectId.isValid((_resolvedRequestId || "").toLowerCase()));
    const _hasBuyerReqContext = !!(sellerRequestReplyState || _resolvedIsObjectId);

    // FIX: req_offer_confirm_ must NOT enter this block - it has its own handler
    // at line ~17239. It arrives here first because flowSess is read once at the
    // top and sellerRequestReplyState may still be "awaiting_offer" in that snapshot.
    // Without this exclusion, req_offer_confirm_ shows the request again instead of
    // sending the quote.
    // ── awaiting_offer_intro block entry rules ────────────────────────────────
    // This block handles the INTRO state (first message after template notification)
    // and specific button actions (view_and_quote, req_offer_, req_unavail_).
    //
    // It must NOT fire for:
    //   - req_offer_confirm_  → has own handler at line ~17239, returns quote sent
    //   - awaiting_offer + plain text → seller is typing prices, handled below
    //
    // awaiting_offer with plain text must fall through to the awaiting_offer text
    // handler so typed prices like "80/hour" or "1x250 2x80" are processed correctly.
    const _isPlainTextPriceEntry = !isMetaAction && sellerRequestReplyState === "awaiting_offer";

    if (
      _hasBuyerReqContext &&
      !a.startsWith("req_offer_confirm_") &&
      !_isPlainTextPriceEntry &&
      (
        sellerRequestReplyState === "awaiting_offer_intro" ||
        _isBuyerReqAction ||
        (a?.startsWith("req_offer_") && !a.startsWith("req_offer_confirm_")) ||
        a?.startsWith("req_unavail_")
      ) &&
      (!biz?.sessionState?.startsWith("sc_") || _isBuyerReqAction)) {

      // ── If biz is stuck in sc_ state but seller tapped a BuyerRequest button, ──
      // reset the stale sc_ state so the BuyerRequest flow proceeds cleanly.
      if (_isBuyerReqAction && biz?.sessionState?.startsWith("sc_")) {
        biz.sessionState = "ready";
        biz.sessionData  = {};
        await saveBizSafe(biz);
      }

    const _introRequest = await findBuyerRequestByIdOrRef(_resolvedRequestId);

      // ── Multi-format phone lookup (primary phone OR notification contact) ──────
      // FIX: Do this BEFORE the helper functions so _introSupplier is available.
      const _introPhone2   = phone.startsWith("263") ? "0" + phone.slice(3) : "263" + phone.slice(1);
      let _introSupplier = await SupplierProfile.findOne({
        phone: { $in: [phone, _introPhone2, "+" + phone] }
      }).lean();
      if (!_introSupplier) {
        _introSupplier = await SupplierProfile.findOne({
          notificationContacts: { $in: [phone, _introPhone2, "+" + phone] }
        }).lean();
        if (_introSupplier) {
          console.log(`[OFFER INTRO] ${phone} is a notification contact for ${_introSupplier.businessName} (${_introSupplier.phone})`);
        }
      }

      // ── Helper: has this supplier already responded or declined this request? ───
      const _myNormPhone = String(phone).replace(/\D+/g, "");
      const _introSuppId = String(_introSupplier?._id || "");
      function _supplierAlreadyResponded(req) {
        if (!req) return true;
        if (req.status === "closed") return true;
        // Check declinedBy array (set when "Not Available" is tapped)
        if ((req.declinedBy || []).some(p => String(p).replace(/\D+/g,"") === _myNormPhone)) return true;
        // Check responses array - match by phone OR supplierId (whichever is available)
        if ((req.responses || []).some(r =>
          String(r.supplierPhone || "").replace(/\D+/g,"") === _myNormPhone ||
          (_introSuppId && String(r.supplierId || "") === _introSuppId)
        )) return true;
        return false;
      }

      // ── Helper: advance to next valid pending request or clear all state ────────
      async function _advanceOrClearPendingRequests(skipId, reason = "closed") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: {
              "tempData.sellerRequestReplyState": "",
              "tempData.sellerRequestId":          "",
              [`tempData.sellerPendingRequests.${skipId}`]: ""
          }},
          { upsert: true }
        );
        const _nxtSess = await UserSession.findOne({ phone }).lean();
        const _nxtMap  = _nxtSess?.tempData?.sellerPendingRequests || {};
        const _nxtIds  = Object.keys(_nxtMap).filter(id => id !== skipId);
        const _validNxt = [];
        for (const id of _nxtIds) {
  const _nxtReq = await findBuyerRequestByIdOrRef(id)
    .then(r => r?.lean ? r.lean() : r)
    .catch(() => null);
          if (_nxtReq && !_supplierAlreadyResponded(_nxtReq)) {
            _validNxt.push(id);
          } else {
            await UserSession.findOneAndUpdate(
              { phone },
              { $unset: { [`tempData.sellerPendingRequests.${id}`]: "" } },
              { upsert: true }
            );
          }
        }
        if (_validNxt.length > 0) {
          await UserSession.findOneAndUpdate(
            { phone },
            { $set: {
                "tempData.sellerRequestReplyState": "awaiting_offer_intro",
                "tempData.sellerRequestId":          _validNxt[0]
            }},
            { upsert: true }
          );
          const _msgReason = reason === "already_responded"
            ? `You already responded to that request.`
            : `That request has closed.`;
          return sendText(from,
            `⏰ ${_msgReason} You have ${_validNxt.length} other pending request(s).\n\n` +
            `Reply with anything to see the next one.`
          );
        }
        return sendText(from,
          `⏰ *That request has closed.*\n\n` +
          `The buyer's request has expired or been filled.\n\n` +
          `New requests will be sent to you automatically when buyers need your products or services.`
        );
      }

      // ── Skip this request if supplier already responded or it's closed ───────
     if (!_introRequest) {
  console.warn(`[OFFER INTRO] Request not found for payload=${_resolvedRequestId}`);
  return sendText(
    from,
    `⚠️ I could not open that request.\n\nPlease tap the latest *View & Quote* button again, or type *menu*.`
  );
}

// Do NOT block View & Quote just because a response exists.
// Sellers may reopen the request to review, correct, or resend a quote.
// Duplicate prevention must happen only when sending/confirming the final quote.
if (_introRequest.status === "closed") {
  // Grace period: if the request was notified recently (within 30 min) and then
  // closed by the cron BEFORE the seller could respond, let them still quote it.
  // This happens when createdAt is old but lastNotifiedAt is recent - the cron
  // closes on createdAt but the seller just received the notification.
  const _closedGraceMs  = 30 * 60 * 1000; // 30 minutes
  const _lastNotifiedAt = _introRequest.lastNotifiedAt
    ? new Date(_introRequest.lastNotifiedAt).getTime() : 0;
  const _withinGrace    = _lastNotifiedAt && (Date.now() - _lastNotifiedAt) < _closedGraceMs;
  if (!_withinGrace) {
  return sendText(
    from,
    `⏰ *That request has closed.*\n\nThe buyer's request has expired or been filled.`
  );
  }
  // Within grace: fall through and let seller quote it
  console.log(`[OFFER INTRO] Closed request ${_introRequest._id} within grace period - allowing seller to quote (notified ${Math.round((Date.now() - _lastNotifiedAt) / 60000)}m ago)`);
}

      const _introRef       = buildBuyerRequestRef(_introRequest);
      const _introItems     = (_introRequest.items || []);
      const _introIsService = _introSupplier?.profileType === "service";

      // ── NOTIFICATION CONTACT: allowed to quote on behalf of the business ──────
      // A notification contact is an extra number on the SAME supplier profile
      // (supplier.notificationContacts). Previously we hard-blocked these numbers
      // from the quote flow, so they received the request + photo but could never
      // act on it ("can't quote or view request"). We now let them view & quote:
      // the response is attributed to the business (_introSupplier, resolved above
      // via the notificationContacts lookup), and confirm-time de-duplication by
      // supplierId prevents the same business quoting twice. No state is cleared here.
      try {
        const _ncCheckSess = await UserSession.findOne({ phone }).lean();
        const _ncCheckMap  = _ncCheckSess?.tempData?.sellerPendingRequests || {};
        const _ncCheckIds  = Object.keys(_ncCheckMap).filter(Boolean);
        const _allNotifOnly = _ncCheckIds.length > 0 &&
          _ncCheckIds.every(id => _ncCheckMap[id]?.role === "notification_only");
        if (_allNotifOnly) {
          console.log(`[OFFER INTRO] ${phone} is a notification contact for ${_introSupplier?.businessName || "the business"} - allowing view & quote`);
        }
      } catch (_ncErr) { /* non-fatal */ }

      // ── FIX: when seller types something generic (not a specific button tap),
      // check if they have multiple pending requests and show a picker so they
      // can choose which one to open - preventing the wrong request from auto-opening.
      const _isSpecificAction = a?.startsWith("req_offer_") || a?.startsWith("req_unavail_")
        || a === "view_and_quote" || al === "view & quote" || al === "view and quote"
        || a === "not_available"  || al === "not available";

      if (!_isSpecificAction) {
        let _pendingMap = {};
        try {
          const _pendingSess = await UserSession.findOne({ phone }).lean();
          _pendingMap = _pendingSess?.tempData?.sellerPendingRequests || {};
          const _cutoff48 = Date.now() - 48 * 60 * 60 * 1000;
          for (const key of Object.keys(_pendingMap)) {
            if ((_pendingMap[key]?.storedAt || 0) < _cutoff48) delete _pendingMap[key];
          }
        } catch (_) { _pendingMap = {}; }

        const _pendingIds = Object.keys(_pendingMap).filter(Boolean);
        if (_pendingIds.length >= 1) {
          const _reqDocs = await Promise.all(
            _pendingIds.map(id =>
              findBuyerRequestByIdOrRef(id)
                .then(r => r?.lean ? r.lean() : r)
                .catch(() => null)
            )
          );
          // Filter out requests where this supplier already responded, declined, or closed
          const _myPhone = String(phone).replace(/\D+/g, "");
          const _validDocs = _reqDocs.filter(req => {
            if (!req) return false;
            if (req.status === "closed") return false;
            if ((req.declinedBy || []).some(p => String(p).replace(/\D+/g,"") === _myPhone)) return false;
            if ((req.responses || []).some(r =>
              String(r.supplierPhone || "").replace(/\D+/g,"") === _myPhone ||
              String(r.supplierId || "") === String(_introSupplier?._id || "")
            )) return false;
            return true;
          });

          if (_validDocs.length > 1) {
            // Multiple pending requests → show picker
            const _reqLines = _validDocs.map((req, i) => {
              const _ref   = buildBuyerRequestRef(req);
              const _items = (req.items || []).map(it => it.product || it.service).slice(0, 2).join(", ");
              const _loc   = req.area ? `${req.area}, ${req.city || ""}` : (req.city || "");
              return `${i + 1}. *${_ref}* - ${_items}${_loc ? ` (${_loc})` : ""}`;
            }).join("\n");
            return sendButtons(from, {
              text:
                `📋 *You have ${_validDocs.length} pending quote requests:*\n\n` +
                `${_reqLines}\n\n` +
                `Tap one to open and quote it.`,
              buttons: _validDocs.slice(0, 3).map(req => ({
                id:    `req_offer_${String(req._id)}`,
                title: buildBuyerRequestRef(req)
              }))
            });
          } else if (_validDocs.length === 1) {
            // Exactly 1 pending request - do NOT auto-open it.
            // Show a nudge with explicit buttons so the supplier chooses to open it.
            // This prevents "hi" or any unrelated command from hijacking into the quote flow.
            const _nudgeReq   = _validDocs[0];
            const _nudgeRef   = buildBuyerRequestRef(_nudgeReq);
            const _nudgeItems = (_nudgeReq.items || []).map(it => it.product || it.service).slice(0, 2).join(", ");
            const _nudgeLoc   = _nudgeReq.area
              ? `${_nudgeReq.area}, ${_nudgeReq.city || ""}`
              : (_nudgeReq.city || "Harare");
            return sendButtons(from, {
              text:
                `📬 *You have a pending quote request:*\n\n` +
                `📦 ${_nudgeItems}\n` +
                `📍 ${_nudgeLoc}\n` +
                `Ref: *${_nudgeRef}*\n\n` +
                `Tap *View & Quote* to open it and send your price, or *Not Available* to decline.`,
              buttons: [
                { id: `req_offer_${String(_nudgeReq._id)}`,   title: "⚡ View & Quote" },
                { id: `req_unavail_${String(_nudgeReq._id)}`, title: "❌ Not Available" }
              ]
            });
          }
          // _validDocs.length === 0 → all stale/closed, fall through to clear state
        }
      }

      // ── Send image to seller if this request has an approved photo ──────────
      // Sent BEFORE the pricing form so the seller sees context first.
      // Uses a separate sendImage call - template messages cannot carry images.
      if (_introRequest.imageUrl && _introRequest.imageStatus === "approved") {
        try {
          const _capNames = _introItems
            .map(it => it.product || it.service)
            .filter(Boolean).slice(0, 3).join(", ");
          await sendImage(from, {
            imageUrl: _introRequest.imageUrl,
            caption:  _introRequest.imageCaption
              ? `📸 ${_introRef} · ${_capNames || "buyer photo"}\n${_introRequest.imageCaption}`
              : `📸 ${_introRef} · Buyer photo for: ${_capNames || "the requested item"}`
          });
        } catch (imgErr) {
          console.warn(`[OFFER INTRO] Failed to send buyer image to ${from}:`, imgErr.message);
        }
      }

      // ── If supplier tapped "View & Quote" from the v2 template ───────────────
      // Also fires when they tap a specific req_offer_<id> button from the picker.
      // Go DIRECTLY to the pricing form - skip the intermediate buttons message.
      if (a === "view_and_quote" || al === "view & quote" || al === "view and quote"
          || (a?.startsWith("req_offer_") && !a.startsWith("req_offer_confirm_"))) {
        // ── Build auto-priced draft from supplier's own prices + preset prices ──
        const _draft = buildDraftQuoteFromRequest(_introSupplier, _introRequest);

        // Build the full response object now so req_offer_confirm_ can send it directly
        const _draftResponse = {
          supplierId:        _introSupplier?._id || null,
          supplierPhone:     _introSupplier?.phone || from,
          supplierName:      _introSupplier?.businessName || "Supplier",
          mode:              "manual_offer",
          message:           (_draft.missingItems?.length || _draft.rorItems?.length)
            ? [
                _draft.rorItems?.length  ? `Rate on request: ${_draft.rorItems.join(", ")}` : "",
                _draft.missingItems?.length ? `Not available: ${_draft.missingItems.join(", ")}` : ""
              ].filter(Boolean).join(" | ")
            : "",
          items:             _draft.responseItems || [],
          totalAmount:       _draft.totalAmount   || null,
          deliveryAvailable: _introSupplier?.delivery?.available ?? null,
          etaText:           ""
        };

        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.sellerRequestReplyState": "awaiting_offer",
              "tempData.sellerRequestId":         _resolvedRequestId,
              "tempData.pendingDraftQuote":        _draft,
              "tempData.pendingOfferResponse":     JSON.stringify(_draftResponse)
            }
          },
          { upsert: true }
        );

        const _directLocation = _introRequest.area
          ? `📍 ${_introRequest.area}, ${_introRequest.city || ""}`
          : _introRequest.city ? `📍 ${_introRequest.city}` : "";
        const _introIsServiceA = _introRequest.isServiceRequest || _buyerRequestIsService(_introRequest.items || []);
        // Reveal the buyer's phone on the quote card for permitted sellers (either
        // revealBuyerPhone or the profile-viewer permission revealVisitorPhone).
        const _directBuyerReveal =
          (_introSupplier?.revealBuyerPhone === true || _introSupplier?.revealVisitorPhone === true) && !!_introRequest.buyerPhone;
        const _directDelivery = (_introIsServiceA
          ? (_introRequest.serviceAddress ? `📍 Service at: ${_introRequest.serviceAddress}` : "📍 Client will share address")
          : _introRequest.deliveryRequired ? "🚚 Delivery needed" : "🏠 Collection / flexible")
          + (_directBuyerReveal ? `\n📞 Buyer contact: ${_zqFmtPhone(_introRequest.buyerPhone)}` : "");

        // ── Case 1: All items auto-priced ────────────────────────────────────
        if (_draft.responseItems.length === _introItems.length && _introItems.length > 0 && !_draft.missingItems.length) {
          const _allLines = _draft.responseItems.map((item, i) =>
            item.rateOnRequest
              ? `${i + 1}. *${item.product}* × ${item.quantity} - _Rate on request_`
              : `${i + 1}. *${item.product}* × ${item.quantity} - $${Number(item.pricePerUnit).toFixed(2)} = $${Number(item.total).toFixed(2)}`
          ).join("\n");

          // Always send two messages: list then buttons (no length limit issues)
          await sendText(from,
            `📋 *Quote Preview - ${_introRef}*\n` +
            `${_directLocation}  ${_directDelivery}\n` +
            `─────────────────\n` +
            `${_allLines}\n\n` +
            `💵 *Total: $${Number(_draft.totalAmount || 0).toFixed(2)}*\n\n` +
            `_Prices from your catalogue. All ${_draft.responseItems.length} items matched._`
          );
          return sendButtons(from, {
            text:
              `*What would you like to do?*\n\n` +
              `✏️ *Edit a price:* _edit 1x12.50_ or _edit 1x5 3x8_\n` +
              `❌ *Skip items you don't have:* _skip 3_ or _skip 3,7,15_\n` +
              `⚡ *Only have a few items:* _have 3,7_ (skips everything else)\n` +
              `🗑️ *Discard:* _cancel_`,
            buttons: [
              { id: `req_offer_confirm_${_resolvedRequestId}`, title: "Confirm & Send" },
              { id: `req_offer_${_resolvedRequestId}`,         title: "Edit Prices"    }
            ]
          });
        }

        // ── Case 2: Some items priced, some missing ───────────────────────────
        if (_draft.responseItems.length > 0) {
          const _pricedLines = _draft.responseItems.map((item, i) =>
            `${i + 1}. *${item.product}* × ${item.quantity} - $${Number(item.pricePerUnit).toFixed(2)} = $${Number(item.total).toFixed(2)} ✅`
          ).join("\n");
          const _missingLines = _draft.missingItems.map((m, i) => `${_draft.responseItems.length + i + 1}. ${m} - ❓ add price`).join("\n");

          await sendText(from,
            `📋 *Quote Preview - ${_introRef}*\n` +
            `${_directLocation}  ${_directDelivery}\n` +
            `─────────────────\n` +
            `*✅ Auto-priced (${_draft.responseItems.length} items):*\n${_pricedLines}\n\n` +
            `💵 *Priced total: $${Number(_draft.totalAmount || 0).toFixed(2)}*\n\n` +
            `*❓ Still needs your price (${_draft.missingItems.length} items):*\n${_missingLines}`
          );
          return sendButtons(from, {
            text:
              `*What would you like to do?*\n\n` +
              `• Type *send* to quote only the ✅ priced items\n` +
              `• Add missing prices: _edit 30x12.50 31x8_\n` +
              `• Skip items you don't have: _skip 30,31_\n` +
              `• Only have a few: _have 1,2,3_ (skips rest)\n` +
              `• Discard: _cancel_`,
            buttons: [
              { id: `req_offer_confirm_${_resolvedRequestId}`, title: "Send Priced Items" },
              { id: `req_offer_${_resolvedRequestId}`,         title: "Edit Prices"       }
            ]
          });
        }

        // ── Case 3: No prices found - show blank form with item list ──────────
        const _blankItemLines = _introItems.map((item, i) =>
          `${i + 1}. *${item.product}* × ${Number(item.quantity || 1)}`
        ).join("\n");
        const _blankEx     = _introItems.slice(0, 3).map((_, i) => `${i+1}x${(i*5+8).toFixed(2)}`).join("  ");
        const _blankSingle = _introItems.length === 1;

        // Hospitality check: ONLY show per-night/person/room examples if the supplier
        // has profileType="hospitality". Plumbers/electricians/product sellers
        // NEVER see tourism or hospitality prompts regardless of categories.
        const _supplierIsHospitality = _introSupplier?.profileType === "hospitality";
        const _requestIsTourism  = _buyerRequestIsTourism(_introItems);
        const _isTourismOffer    = _supplierIsHospitality && _requestIsTourism;

        // Determine if request is specifically an accommodation (nights/room) request
        const _isAccommodation = _isTourismOffer &&
          ["hospitality_stay"].includes(
            (() => { try { const {classifyRequestItems} = require("./requestMatchEngine.js"); return classifyRequestItems(_introItems).dominant; } catch(_){return "other";} })()
          );

        const _unitExamples = _isTourismOffer
          ? (_isAccommodation
            ? `*1x80/night*  or  *1x80/night  2x120/night  3x40/rest*\n_Accepted units: /night  /rest  /day  /room  /person  /person/night_`
            : `*1x80/person*  or  *1x80/person  2x50/hour*\n_Accepted units: /person  /hour  /hr  /day  /night  /trip  /group_`)
          : (_introIsService
            ? `*${_blankEx || "1x80/job"}*  or  *1x80/job  2x50/hr*`
            : `*${_blankEx || "1x12.50"}*`);

        // Show seller's own catalogue items so they can "pick" from them
        const _sellerCatItems = [
          ...(_introSupplier?.prices    || []).map(p => ({ name: p.product,  price: p.amount,      unit: p.unit || "each" })),
          ...(_introSupplier?.rates     || []).map(r => ({ name: r.service,  price: r.rate,        unit: "" })),
          ...(_introSupplier?.roomTypes || []).map(t => ({ name: t.roomType, price: t.pricePerNight, unit: "/night" }))
        ].filter(i => i.name).slice(0, 10);

        const _catalogueLines = _sellerCatItems.length
          ? "\n\n📋 *Your catalogue (pick by number):*\n" +
            _sellerCatItems.map((it, i) =>
              `${i+1}. ${it.name}${it.price ? ` - $${Number(it.price).toFixed ? Number(it.price).toFixed(2) : it.price}${it.unit ? "/"+it.unit : ""}` : ""}`
            ).join("\n") +
            "\n_Type *pick 1* or *pick 2 qty 3* to add from catalogue_"
          : "";

        return sendText(from,
          `📋 *${_introRef} - Enter your prices*\n` +
          `${_directLocation}  ${_directDelivery}\n` +
          `─────────────────\n` +
          `*${_introIsService ? "Services" : "Items"} requested:*\n${_blankItemLines}\n` +
          `─────────────────\n\n` +
          `💰 *How to price this request:*\n` +
          (_blankSingle
            ? (_isTourismOffer
                ? `Type: *80/person*  or  *80/hour*  or  *80/day*`
                : `Type: *12.00*  or  *12.00/${_introIsService ? "job" : "each"}*`)
            : `Type each price:\n${_unitExamples}\n\n_(item number x price/unit)_`) +
          (_blankSingle ? "" : `\nCan't supply an item? Type *0* for it.`) +
          `\n\n➕ *Add a line:* _add labour 150_ or _add call-out fee 50/job_\n` +
          `❓ *Ask buyer a detail:* _ask: what size PVC elbow?_ or _ask: interior or exterior?_\n` +
          `📝 *Add a note:* _note available Monday, deposit 50% required_\n` +
          `❌ *Cancel:* _cancel_` +
          _catalogueLines
        );
      }

      // ── If supplier tapped "Not Available" from the v2 template ─────────────
      if (a === "not_available" || al === "not available") {
        // FIX: fully clear ALL BuyerRequest session state, not just the one entry.
        // Also remove from sellerPendingRequests map so it can't reappear.
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: {
              "tempData.sellerRequestReplyState":  "",
              "tempData.sellerRequestId":           "",
              "tempData.pendingDraftQuote":         "",
              "tempData.pendingOfferResponse":      "",
              [`tempData.sellerPendingRequests.${_resolvedRequestId}`]: ""
          }},
          { upsert: true }
        );
        if (_introSupplier) {
          const _naResponse = {
            supplierId:       _introSupplier._id,
            supplierPhone:    _introSupplier.phone,
            supplierName:     _introSupplier.businessName,
            mode:             "unavailable",
            message:          "",
            items:            [],
            totalAmount:      null,
            deliveryAvailable: _introSupplier.delivery?.available ?? null,
            etaText:          "",
            respondedAt:      new Date()
          };
          _introRequest.responses.push(_naResponse);
          // FIX: mark the request as declined by this supplier so it never
          // re-opens for them. We store the supplier's phone in a declinedBy array.
          if (!_introRequest.declinedBy) _introRequest.declinedBy = [];
          const _naPhone = String(_introSupplier.phone || phone).replace(/\D+/g, "");
          if (!_introRequest.declinedBy.includes(_naPhone)) {
            _introRequest.declinedBy.push(_naPhone);
          }
          await _introRequest.save();
          await sendBuyerRequestResponseToBuyer({ request: _introRequest, supplier: _introSupplier, response: _naResponse });
        }
        return sendButtons(from, {
          text: "✅ *Response sent.* The buyer has been notified you are not available.",
          buttons: [
            { id: "my_supplier_account", title: "🏪 My Store"   },
            { id: "suppliers_home",      title: "🛒 Marketplace" }
          ]
        });
      }

      // ── Any other message (e.g. "hi") → show item list + buttons ─────────────
      const _introItemLines = _introItems.map((item, i) =>
        `${i + 1}. *${item.product}* × ${Number(item.quantity || 1)}`
      ).join("\n");
      const _introLocation  = _introRequest.area
        ? `${_introRequest.area}, ${_introRequest.city || ""}`
        : (_introRequest.city || "Zimbabwe");
      const _introIsServiceB = _introRequest.isServiceRequest || _buyerRequestIsService(_introRequest.items || []);
      const _introDelivery = _introIsServiceB
        ? (_introRequest.serviceAddress ? `📍 Service at: ${_introRequest.serviceAddress}` : "📍 Client will share address")
        : _introRequest.deliveryRequired ? "🚚 Delivery needed" : "🏠 Collection / flexible";

      await UserSession.findOneAndUpdate(
        { phone },
        { $set: {
            "tempData.sellerRequestReplyState": "awaiting_offer",
            "tempData.sellerRequestId":          _resolvedRequestId
        }},
        { upsert: true }
      );

      return sendButtons(from, {
        text:
          `🔔 *New ${_introIsService ? "Service" : "Product"} Request - ${_introRef}*\n\n` +
          `📍 *Location:* ${_introLocation}\n` +
          `${_introDelivery}\n\n` +
          `📦 *${_introItems.length} item${_introItems.length === 1 ? "" : "s"} needed:*\n` +
          `${_introItemLines}\n\n` +
          `─────────────────\n` +
          `Tap *View & Quote* to enter your price${_introItems.length === 1 ? "" : "s"}.\n` +
          `The buyer receives your quote instantly.`,
      buttons: [
  { id: `req_offer_${String(_introRequest._id)}`,   title: "View & Quote"  },
  { id: `req_unavail_${String(_introRequest._id)}`, title: "Not Available" }
]
      });
    }

    // ── pendingQuoteReply: seller received a browse-and-shop quote request ────────
    // They reply with a price/message and we forward it directly to the buyer.
    const _pendingQuote = flowSess?.tempData?.pendingQuoteReply;
    if (_pendingQuote === "true" && text && !a) {
      const _pqItem      = flowSess?.tempData?.pendingQuoteItem       || "your item";
      const _pqBuyer     = flowSess?.tempData?.pendingQuoteBuyerPhone || "";
      const _pqCity      = flowSess?.tempData?.pendingQuoteCity       || "";
      const _pqArea      = flowSess?.tempData?.pendingQuoteArea       || "";
      const _pqSupplier  = await findSupplierByPhone(phone);

      // Handle cancel
      if (text.trim().toLowerCase() === "cancel") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: {
            "tempData.pendingQuoteReply":      "",
            "tempData.pendingQuoteItem":       "",
            "tempData.pendingQuoteBuyerPhone": "",
            "tempData.pendingQuoteCity":       "",
            "tempData.pendingQuoteArea":       ""
          }},
          { upsert: true }
        );
        return sendText(from, "✅ Quote request ignored.");
      }

      // Clear session
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: {
          "tempData.pendingQuoteReply":      "",
          "tempData.pendingQuoteItem":       "",
          "tempData.pendingQuoteBuyerPhone": "",
          "tempData.pendingQuoteCity":       "",
          "tempData.pendingQuoteArea":       ""
        }},
        { upsert: true }
      );

      const _pqSupplierName = _pqSupplier?.businessName || "A seller";
      const _pqSupplierPhone = _pqSupplier?.phone || from;
      const _pqLocation = _pqArea ? `${_pqArea}, ${_pqCity}` : _pqCity;

      // Forward quote to buyer
      if (_pqBuyer) {
        const _pqNormBuyer = String(_pqBuyer).replace(/\D+/g, "");
        const _pqFullBuyer = _pqNormBuyer.startsWith("0") && _pqNormBuyer.length === 10
          ? "263" + _pqNormBuyer.slice(1) : _pqNormBuyer;
        try {
          await sendButtons(_pqFullBuyer, {
            text:
              `💬 *Quote received for: ${_pqItem}*\n\n` +
              `🏪 *${_pqSupplierName}*\n` +
              (_pqLocation ? `📍 ${_pqLocation}\n` : "") +
              `📞 ${_pqSupplierPhone}\n\n` +
              `💵 *Quote:* ${text.trim()}\n\n` +
              `Contact the seller directly to confirm your order.`,
            buttons: [
              { id: "find_supplier",       title: "🔍 Browse & Shop" },
              { id: "sup_request_sellers", title: "⚡ Request Sellers" }
            ]
          });
          console.log(`[PENDING QUOTE] Forwarded quote from ${from} to buyer ${_pqFullBuyer}`);
        } catch (fwdErr) {
          console.error(`[PENDING QUOTE] Failed to forward to buyer: ${fwdErr.message}`);
        }
      }

      // Confirm to seller
      return sendButtons(from, {
        text:
          `✅ *Quote sent to buyer!*\n\n` +
          `You quoted: _${text.trim()}_\n` +
          `For: *${_pqItem}*\n\n` +
          `The buyer will see your price and contact details. Good luck! 🎯`,
        buttons: [
          { id: "my_supplier_account", title: "🏪 My Store"   },
          { id: "suppliers_home",      title: "🛒 Marketplace" }
        ]
      });
    }

    // If supplier types while in confirm state, treat as wanting to edit → re-enter pricing
    // FIX: skip if sc_ smart-link buyer session is active (not a BuyerRequest confirm action)
    if (sellerRequestReplyState === "awaiting_offer_confirm" && sellerRequestId && text && !a &&
        !biz?.sessionState?.startsWith("sc_")) {
      await UserSession.findOneAndUpdate(
        { phone },
        {
          $set: {
            "tempData.sellerRequestReplyState": "awaiting_offer",
            "tempData.sellerRequestId": sellerRequestId
          },
          $unset: { "tempData.pendingOfferResponse": "" }
        },
        { upsert: true }
      );
      // Re-show the item list so they can re-enter
      const _editRequest = await BuyerRequest.findById(sellerRequestId);
      if (_editRequest) {
        const _editItems = (_editRequest.items || []);
        const _editLines = _editItems.map((item, i) => `${i+1}. *${item.product}* × ${Number(item.quantity||1)}`).join("\n");
        const _editEx    = _editItems.slice(0,3).map((_,i) => `${i+1}x${(i*5+8).toFixed(2)}`).join("  ");
        return sendText(from,
          `✏️ *Edit your prices - ${buildBuyerRequestRef(_editRequest)}*\n\n` +
          `*Items:*\n${_editLines}\n\n` +
          `*Re-enter prices:*\n` +
          `*${_editEx || "12.50"}*  or  *1x12.50  2x8.00*\n\n` +
          `Type *cancel* to go back.`
        );
      }
    }

   // FIX: skip BuyerRequest awaiting_offer handler if an sc_ smart-link buyer
   // session is active on this phone. The sc_ flow (biz.sessionState) handles
   // typed input like "1x3,5" - if we let awaiting_offer run first it hijacks
   // the input and shows the wrong (old BuyerRequest) quote preview.
   if (sellerRequestReplyState === "awaiting_offer" && sellerRequestId && !isMetaAction &&
       !biz?.sessionState?.startsWith("sc_") &&
       !/^ZQ:STAFF:/i.test(text.trim()) &&
       !a.startsWith("sc_quote_")) {

  // ── cancel ───────────────────────────────────────────────────────────────
  if (al === "cancel") {
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.sellerRequestReplyState": "", "tempData.sellerRequestId": "", "tempData.pendingDraftQuote": "", "tempData.pendingOfferResponse": "",
         [`tempData.sellerPendingRequests.${sellerRequestId}`]: "" } },
      { upsert: true }
    );
    return sendSupplierAccountMenu(from, await findSupplierByPhone(phone));
  }

  const request = await BuyerRequest.findById(sellerRequestId);
  if (!request) {
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.sellerRequestReplyState": "", "tempData.sellerRequestId": "", "tempData.pendingDraftQuote": "", "tempData.pendingOfferResponse": "",
         [`tempData.sellerPendingRequests.${sellerRequestId}`]: "" } },
      { upsert: true }
    );
    return sendText(from, "❌ Request not found or expired.");
  }

  const supplier = await findSupplierByPhone(phone);
  if (!supplier) {
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.sellerRequestReplyState": "", "tempData.sellerRequestId": "", "tempData.pendingDraftQuote": "", "tempData.pendingOfferResponse": "",
         [`tempData.sellerPendingRequests.${sellerRequestId}`]: "" } },
      { upsert: true }
    );
    console.warn(`[OFFER] Supplier not found for phone ${phone} - checked primary + notificationContacts`);
    return sendText(from,
      "❌ Profile not found.\n\n" +
      "If you received a quote request, please ask your primary account holder to respond, " +
      "or contact ZimQuote support to link your number."
    );
  }

  // ── Helper: build a preview text of current draft items ───────────────────
  // Returns {text, short} - short=true means fits in sendButtons (≤900 chars)
  // ── _sendDraftPreview: ALWAYS sends two messages ──────────────────────────
  // 1. Full item list as sendText (no length limit)
  // 2. Action buttons as sendButtons (always shows tap buttons)
  async function _sendDraftPreview(items, skippedNames, ref, totalAmt, reqId) {
    const editedCount = items.filter(i => i._edited).length;

    const cleanItems = (items || []).map(item => ({
  product: item.product,
  quantity: Number(item.quantity || 1),
  unit: item.unit || "each",
  pricePerUnit: Number(item.pricePerUnit || 0),
  total: Number(item.total || 0),
  available: true
}));

const cleanTotal = Number(
  cleanItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2)
);

const pendingResponse = {
  supplierId: supplier._id,
  supplierPhone: supplier.phone,
  supplierName: supplier.businessName,
  mode: "manual_offer",
  message: skippedNames?.length ? `Not in stock: ${skippedNames.join(", ")}` : "",
  items: cleanItems,
  totalAmount: cleanTotal,
  deliveryAvailable: supplier.delivery?.available ?? null,
  etaText: ""
};

await UserSession.findOneAndUpdate(
  { phone },
  {
    $set: {
      "tempData.pendingOfferResponse": JSON.stringify(pendingResponse),
      "tempData.pendingDraftQuote": {
        responseItems: cleanItems,
        skippedItems: skippedNames || [],
        totalAmount: cleanTotal
      }
    }
  },
  { upsert: true }
);
    const lines = items.map((item, i) =>
      `${i + 1}. *${item.product}* × ${item.quantity} - $${Number(item.pricePerUnit).toFixed(2)} = $${Number(item.total).toFixed(2)}${item._edited ? " ✏️" : ""}`
    ).join("\n");
    const skippedLine = skippedNames?.length
      ? `\n\n❌ *Skipped - not in stock (${skippedNames.length}):*\n${skippedNames.map(s => `• ${s}`).join("\n")}`
      : "";
    const editNote = editedCount > 0 ? `\n_✏️ = price you edited_` : "";

    // Message 1: the full item list
    await sendText(from,
      `📋 *Quote Preview - ${ref}*\n` +
      `─────────────────\n` +
      `${lines}\n\n` +
      `💵 *Total: $${Number(totalAmt).toFixed(2)}*${skippedLine}${editNote}`
    );

    // Message 2: action buttons + short command guide
    return sendButtons(from, {
      text:
        `*What would you like to do?*\n\n` +
        `✏️ *Edit a price:* _edit 1x12.50_  or  _1 12.50_  or  _1=12.50_\n` +
        `➕ *Add a line:* _add labour 150_ or _add call-out fee 50/job_\n` +
        `❓ *Ask buyer a detail:* _ask: what size do you need?_\n` +
        `📋 *Pick from catalogue:* _pick 1_ or _pick 2 qty 3_\n` +
        `📝 *Add a note:* _note deposit required, available Mon-Fri_\n` +
        `❌ *Skip items:* _skip 3_ or _skip 3,7,15_\n` +
        `⚡ *Only have some items:* _have 3,7_ (skips all others)\n` +
        `🗑️ *Discard:* _cancel_`,
      buttons: [
        { id: `req_offer_confirm_${reqId}`, title: "Confirm & Send" },
        { id: `req_offer_${reqId}`,         title: "Edit Prices"    }
      ]
    });
  }

  // ── Parse "add [item description] [price]" command ────────────────────────
  // e.g. "add labour 150" or "add call-out fee 50/job"
  function _parseAddCommand(inputText) {
    const raw = String(inputText || "").trim();
    const m = raw.match(/^add\s+(.+?)\s+([\d]+(?:\.\d+)?)(?:\s*\/(\S+))?$/i);
    if (!m) return null;
    return {
      product:      m[1].trim(),
      pricePerUnit: parseFloat(m[2]),
      unit:         m[3] || "each"
    };
  }

  // ── Parse "note [text]" command ───────────────────────────────────────────
  function _parseNoteCommand(inputText) {
    const raw = String(inputText || "").trim();
    const m = raw.match(/^note\s+(.+)$/i);
    return m ? m[1].trim() : null;
  }

  const _isService = supplier.profileType === "service";
  const _ref = buildBuyerRequestRef(request);

  // ── "add [item] [price]" - seller adds a line not in original request ─────
  const _addCmd = _parseAddCommand(text);
  if (_addCmd) {
    const _addDraft = pendingDraftQuote?.responseItems?.length
      ? pendingDraftQuote
      : { responseItems: buildDraftQuoteFromRequest(supplier, request).items || [], skippedItems: [], totalAmount: 0 };

    const qty = 1;
    const newItem = {
      product:      _addCmd.product,
      quantity:     qty,
      unit:         _addCmd.unit,
      pricePerUnit: _addCmd.pricePerUnit,
      total:        Number((_addCmd.pricePerUnit * qty).toFixed(2)),
      _edited:      true
    };
    const updatedItems = [...(_addDraft.responseItems || []), newItem];
    const newTotal = Number(updatedItems.reduce((s, i) => s + Number(i.total || 0), 0).toFixed(2));
    const updatedDraft = { ..._addDraft, responseItems: updatedItems, totalAmount: newTotal };

    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.pendingDraftQuote": updatedDraft } },
      { upsert: true }
    );
    return _sendDraftPreview(updatedItems, updatedDraft.skippedItems || [], _ref, newTotal, sellerRequestId);
  }

  // ── "ask [question]" - seller asks buyer for more detail before quoting ──────
  // Real-world need: plumber receives "I need a PVC elbow" - doesn't know size.
  // Builder receives "plastering" - doesn't know interior/exterior/sqm.
  // This sends the seller's question to the buyer via the bot and waits for reply.
  // The seller stays in awaiting_offer state so they can quote once buyer responds.
  // Formats: "ask what size PVC elbow?" / "ask: is this interior or exterior?"
  const _askMatch = text.match(/^ask[:\s]+(.+)$/i);
  if (_askMatch) {
    const _askQuestion = _askMatch[1].trim().slice(0, 300);
    if (_askQuestion.length < 3) {
      return sendText(from, `❌ Type your question after *ask:*\n_e.g. ask: what size PVC elbow do you need?_`);
    }

    // Get the buyer's phone from the request
    const _askRequest = await BuyerRequest.findById(sellerRequestId).lean();
    const _askBuyerPhone = _askRequest?.buyerPhone || _askRequest?.phone;

    if (!_askBuyerPhone) {
      return sendText(from, `❌ Could not find buyer's contact. The request may have expired.`);
    }

    // Save the pending question in session so we know to relay buyer's reply back
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: {
          "tempData.sellerPendingQuestion": {
            question:     _askQuestion,
            buyerPhone:   _askBuyerPhone,
            sellerPhone:  phone,
            requestId:    sellerRequestId,
            askedAt:      Date.now()
          }
      }},
      { upsert: true }
    );

    // Send question to the buyer on behalf of the seller
    const _askSupplierName = supplier.businessName || "The seller";
    try {
      const { sendButtons: _sendBuyerBtn } = await import("./metaSender.js");
      await _sendBuyerBtn(_askBuyerPhone, {
        text:
          `❓ *${_askSupplierName} has a question before quoting:*\n\n` +
          `_"${_askQuestion}"_\n\n` +
          `Please reply to help them give you an accurate quote.`,
        buttons: [{ id: `buyer_clarif_done_${sellerRequestId}`, title: "✅ I replied below" }]
      });
    } catch (_askErr) {
      console.warn(`[ASK CMD] Could not send question to buyer ${_askBuyerPhone}: ${_askErr.message}`);
    }

    return sendText(from,
      `✅ *Question sent to buyer!*\n\n` +
      `_"${_askQuestion}"_\n\n` +
      `The buyer will reply and you will be notified. You can still enter prices while waiting.\n\n` +
      `When they reply, their answer will appear here.\n` +
      `Type *confirm* when ready to send your quote, or keep editing.`
    );
  }

  // ── "note [text]" - seller adds a note to the quote (visible on PDF) ─────
  // e.g. "note deposit required, available Monday"
  const _noteText = _parseNoteCommand(text);
  if (_noteText) {
    const _noteDraft = pendingDraftQuote || { responseItems: [], skippedItems: [], totalAmount: 0 };
    const updatedDraft = { ..._noteDraft, sellerNote: _noteText };
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.pendingDraftQuote": updatedDraft } },
      { upsert: true }
    );
    return sendText(from,
      `📝 Note added: _"${_noteText}"_\n\n` +
      `Type *confirm* to send, or keep editing.\n` +
      `Type *note [new text]* to replace the note.`
    );
  }

  // pick 1 qty 2 or pick P1 2 -- seller picks from their own catalogue by number
  // Accepts: "pick 1", "pick 1 qty 2", "pick P1 2", "pick 1 2"
  const _pickMatch = text.match(/^pick\s+(?:p)?(\d+)(?:\s+(?:qty\s*)?(\d+(?:\.\d+)?))?/i);
  if (_pickMatch) {
    const _pickIdx  = parseInt(_pickMatch[1], 10) - 1;
    const _pickQty  = parseFloat(_pickMatch[2] || "1") || 1;
    const _catItems = [
      ...(supplier?.prices    || []).map(p => ({ name: p.product,  price: Number(p.amount||0), unit: p.unit||"each" })),
      ...(supplier?.rates     || []).map(r => ({ name: r.service,  price: parseFloat(String(r.rate||"").replace(/[^\d.]/g,"")||"0"), unit: "job" })),
      ...(supplier?.roomTypes || []).map(t => ({ name: t.roomType, price: Number(t.pricePerNight||0), unit: "night" }))
    ].filter(i => i.name).slice(0, 10);
    const _picked = _catItems[_pickIdx];
    if (!_picked) return sendText(from, `Item ${_pickIdx+1} not found in your catalogue. You have ${_catItems.length} items (1–${_catItems.length}).`);
    const _pDraft  = pendingDraftQuote?.responseItems?.length ? pendingDraftQuote : { responseItems: [], skippedItems: [], totalAmount: 0 };
    const _pTotal  = Number((_picked.price * _pickQty).toFixed(2));
    const _pItem   = { product: _picked.name, quantity: _pickQty, unit: _picked.unit, pricePerUnit: _picked.price, total: _pTotal, _edited: true };
    const _pItems  = [...(_pDraft.responseItems||[]), _pItem];
    const _pGrand  = Number(_pItems.reduce((s,i)=>s+Number(i.total||0),0).toFixed(2));
    const _pUpdate = { ..._pDraft, responseItems: _pItems, totalAmount: _pGrand };
    await UserSession.findOneAndUpdate({ phone }, { $set: { "tempData.pendingDraftQuote": _pUpdate } }, { upsert: true });
    return _sendDraftPreview(_pItems, _pDraft.skippedItems||[], _ref, _pGrand, sellerRequestId);
  }
  if (al === "confirm" || al === "send") {
    const _confirmDraft = pendingDraftQuote;
    if (!_confirmDraft?.responseItems?.length) {
      return sendText(from,
        `⚠️ No draft found. Please tap *View & Quote* again from the request message.`
      );
    }

    const responseItems = _confirmDraft.responseItems.map(item => ({
      product:      item.product,
      quantity:     Number(item.quantity || 1),
      unit:         item.unit || "each",
      pricePerUnit: Number(item.pricePerUnit || 0),
      total:        Number(item.total || 0),
      available:    true
    }));

    const totalAmount = Number(responseItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2));
    const skippedNote = (_confirmDraft.skippedItems?.length)
      ? `Not in stock: ${_confirmDraft.skippedItems.join(", ")}`
      : [
        _confirmDraft.rorItems?.length     ? `Rate on request: ${_confirmDraft.rorItems.join(", ")}` : "",
        _confirmDraft.missingItems?.length ? `Not available: ${_confirmDraft.missingItems.join(", ")}` : ""
      ].filter(Boolean).join(" | ");

    const _draftNote = _confirmDraft.sellerNote || "";

    const response = {
      supplierId:        supplier._id,
      supplierPhone:     supplier.phone,
      supplierName:      supplier.businessName,
      mode:              "manual_offer",
      message:           [skippedNote, _draftNote].filter(Boolean).join(" | "),
      items:             responseItems,
      totalAmount,
      deliveryAvailable: supplier.delivery?.available ?? null,
      etaText:           ""
    };

    request.responses.push(response);
    await request.save();

    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.sellerRequestReplyState": "", "tempData.sellerRequestId": "", "tempData.pendingDraftQuote": "", "tempData.pendingOfferResponse": "",
         [`tempData.sellerPendingRequests.${sellerRequestId}`]: "" } },
      { upsert: true }
    );

    trackSupplierResponseSpeed(supplier.phone, request.createdAt).catch(console.error);
    await sendBuyerRequestResponseToBuyer({ request, supplier, response });

    return sendButtons(from, {
      text:
        `✅ *Quote sent!*\n\n` +
        `🏪 ${supplier.businessName}\n` +
        `📦 ${responseItems.length} item${responseItems.length === 1 ? "" : "s"} quoted\n` +
        `💵 Total: $${totalAmount.toFixed(2)}\n\n` +
        `The buyer will see your prices and can contact you directly.`,
      buttons: [
        { id: "my_supplier_account", title: "🏪 My Store" },
        { id: "suppliers_home",      title: "🛒 Marketplace" }
      ]
    });
  }

  // ── EDIT / SKIP commands - update draft and show preview ──────────────────
  const { editUpdates, skipIndices, hasEditCmd, hasSkipCmd } = _parseEditSkip(text, pendingDraftQuote?.responseItems || []);

  if ((hasEditCmd || hasSkipCmd) && pendingDraftQuote?.responseItems?.length) {
    // Apply edits to the draft
    const updatedItems = (pendingDraftQuote.responseItems || [])
      .filter((_, idx) => !skipIndices.has(idx + 1))  // remove skipped items
      .map((item, _newIdx) => {
        // find original 1-based index before filtering for skip
        const origIdx = (pendingDraftQuote.responseItems || []).indexOf(item) + 1;
        if (editUpdates[origIdx] !== undefined) {
          const newPrice = Number(editUpdates[origIdx]);
          const qty = Number(item.quantity || 1);
          return {
            ...item,
            pricePerUnit: newPrice,
            total:        Number((qty * newPrice).toFixed(2)),
            _edited:      true
          };
        }
        return item;
      });

    const skippedNames = (pendingDraftQuote.responseItems || [])
      .filter((_, idx) => skipIndices.has(idx + 1))
      .map(i => i.product);

    const newTotal = Number(updatedItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2));

    // Persist the updated draft
    const updatedDraft = {
      ...pendingDraftQuote,
      responseItems: updatedItems,
      skippedItems:  [...(pendingDraftQuote.skippedItems || []), ...skippedNames],
      totalAmount:   newTotal
    };

    // Also update pendingOfferResponse so "Confirm & Send" button works
    const _editedResponse = {
      supplierId: supplier._id, supplierPhone: supplier.phone, supplierName: supplier.businessName,
      mode: "manual_offer",
      message: updatedDraft.skippedItems?.length ? `Not in stock: ${updatedDraft.skippedItems.join(", ")}` : "",
      items: updatedItems.map(item => ({
        product: item.product, quantity: Number(item.quantity || 1), unit: item.unit || "each",
        pricePerUnit: Number(item.pricePerUnit || 0), total: Number(item.total || 0), available: true
      })),
      totalAmount: newTotal, deliveryAvailable: supplier.delivery?.available ?? null, etaText: ""
    };
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.pendingDraftQuote": updatedDraft, "tempData.pendingOfferResponse": JSON.stringify(_editedResponse) } },
      { upsert: true }
    );

    return _sendDraftPreview(updatedItems, updatedDraft.skippedItems, _ref, newTotal, sellerRequestId);
  }

  // ── GREETING / confusion while in awaiting_offer - re-show the draft ─────
  const _looksLikeGreeting = !hasEditCmd && !hasSkipCmd &&
    !/\d/.test(text) && text.trim().length < 30 &&
    /^(hi|hello|hey|yes|ok|okay|sure|what|how|hie|help|good|fine|yeah|send|go|start|ready|quote|pricing|price|available|avail|\?+|\!+)$/i
      .test(text.trim().replace(/[.,!?]+$/, "").trim());

  if (_looksLikeGreeting && pendingDraftQuote?.responseItems?.length) {
    return _sendDraftPreview(pendingDraftQuote.responseItems, pendingDraftQuote.skippedItems || [], _ref, pendingDraftQuote.totalAmount || 0, sellerRequestId);
  }

  // ── TYPED PRICES (no draft, or seller typed raw prices directly) ──────────
  {
    const requestedProducts = (request.items || []).map(i => i.product);
    const parsed = parseSupplierPriceInput(text, requestedProducts, _isService);

    let responseItems = [];
    let totalAmount = null;
    let message = "";

    if (parsed.updated.length) {
      // If we have a draft, MERGE typed prices into it (don't discard auto-priced items)
      if (pendingDraftQuote?.responseItems?.length) {
        const updatedMap = new Map(parsed.updated.map(u => [normalizeProductName(u.product), u]));
        const mergedItems = (pendingDraftQuote.responseItems || []).map(item => {
          const match = updatedMap.get(normalizeProductName(item.product));
          if (match) {
            const qty = Number(item.quantity || 1);
            const unitPrice = Number(match.amount || 0);
            return { ...item, pricePerUnit: unitPrice, total: Number((qty * unitPrice).toFixed(2)), _edited: true };
          }
          return item;
        });

        const newTotal = Number(mergedItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2));
        const updatedDraft = { ...pendingDraftQuote, responseItems: mergedItems, totalAmount: newTotal };

        await UserSession.findOneAndUpdate(
          { phone },
          { $set: { "tempData.pendingDraftQuote": updatedDraft } },
          { upsert: true }
        );

        return _sendDraftPreview(mergedItems, updatedDraft.skippedItems || [], _ref, newTotal, sellerRequestId);
      }

      // No draft - build response from parsed prices only
      const updatedMap = new Map(parsed.updated.map(u => [normalizeProductName(u.product), u]));
      responseItems = (request.items || []).map(item => {
        const match = updatedMap.get(normalizeProductName(item.product));
        if (!match) return null;
        const qty = Number(item.quantity || 1);
        const unitPrice = Number(match.amount || 0);
        return { product: item.product, quantity: qty, unit: match.unit || item.unitLabel || "each", pricePerUnit: unitPrice, total: Number((qty * unitPrice).toFixed(2)), available: true };
      }).filter(Boolean);

      if (responseItems.length) {
        totalAmount = Number(responseItems.reduce((sum, i) => sum + Number(i.total || 0), 0).toFixed(2));
      }
      if (parsed.failed.length) message = `Some parts skipped: ${parsed.failed.slice(0, 3).join(", ")}`;

      // Show preview and ask for confirm
      const _newDraft = { responseItems, missingItems: [], totalAmount };
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { "tempData.pendingDraftQuote": _newDraft } },
        { upsert: true }
      );
      return _sendDraftPreview(responseItems, [], _ref, totalAmount, sellerRequestId);

    } else {
      // No prices parsed - message-only or greeting
      message = String(text || "").trim();
      if (!message || _looksLikeGreeting) {
        return sendText(from,
          `⚠️ I couldn't read prices from that.\n\n` +
          `• Type *confirm* to send the draft as-is\n` +
          `• *edit 1x12.50* - change a price\n` +
          `• *skip 3,7* - remove items you don't have\n` +
          `• *cancel* to go back`
        );
      }

      // Do NOT allow empty service/hospitality quotations.
      // Show correct examples based on profileType - never show /person /trip to plumbers.
      if (_isService) {
        const _isHospSupplier = supplier?.profileType === "hospitality";
        return sendText(
          from,
          `⚠️ Please include at least one price before sending the quote.\n\n` +
          `Examples:\n` +
          (_isHospSupplier
            ? `_1=80/night_\n_1=120/night_\n_1=80/person_\n_1=150/trip_\n`
            : `_1=80/job_\n_1=150/hr_\n_1=500/day_\n`) +
          `\nYou can also add a note:\n` +
          (_isHospSupplier
            ? `_1=80/night msg includes breakfast, WiFi and braai area_\n`
            : `_1=80/job msg available from Monday_\n`) +
          `\nType *cancel* to discard.`
        );
      }

      // For products, also avoid sending empty quotations unless there is a clear note.
      const _msgResp = {
        supplierId: supplier._id, supplierPhone: supplier.phone, supplierName: supplier.businessName,
        mode: "manual_offer", message, items: [], totalAmount: null,
        deliveryAvailable: supplier.delivery?.available ?? null, etaText: ""
      };
      request.responses.push(_msgResp);
      await request.save();
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.sellerRequestReplyState": "", "tempData.sellerRequestId": "", "tempData.pendingDraftQuote": "", "tempData.pendingOfferResponse": "",
         [`tempData.sellerPendingRequests.${sellerRequestId}`]: "" } },
        { upsert: true }
      );
      await sendBuyerRequestResponseToBuyer({ request, supplier, response: _msgResp });
      return sendButtons(from, {
        text: `✅ *Message sent to buyer.*\n\n_"${message.slice(0, 80)}"_`,
        buttons: [{ id: "my_supplier_account", title: "🏪 My Store" }, { id: "suppliers_home", title: "🛒 Marketplace" }]
      });
    }
  }
  }



 if (buyerRequestState === "awaiting_items") {
  // ── FIX: sc_ smart-link button taps must NEVER be treated as buyer request
  // item text. When a buyer has a stale buyerRequestState="awaiting_items" in
  // session and then taps a smart card button (e.g. "Get instant quote" or
  // "View All Services"), the action id (sc_quote_<id> / sc_catalogue_<id>)
  // was being fed through parseItemListWithQty, flagged as a vague product
  // name, and returning the "Please use the full product name" error -
  // blocking the sc_ handler at the bottom of the file from ever running.
  // The fix: skip the entire buyerRequestState block for ANY isMetaAction sc_ tap.
  // This mirrors the REG TYPE EARLY HANDLER pattern used elsewhere in this file.
  if (isMetaAction && a.startsWith("sc_")) {
    // fall through to the sc_ handler block below
  } else {

  // ── GUARD: if the user's biz is actively in an invoice/quote/receipt flow,
  // skip the buyer request handler entirely so business tools state machine
  // (continueTwilioFlow) can process the typed input correctly.
  // Without this guard, typing catalogue numbers like "3,4" in the invoice
  // catalogue picker gets swallowed by the buyer request parser.
  const _bizFlowStates = new Set([
    "creating_invoice_add_items", "creating_invoice_pick_product",
    "creating_invoice_enter_prices", "creating_invoice_enter_catalogue_prices",
    "creating_invoice_confirm", "creating_invoice_qty",
    "creating_invoice_add_item_text", "creating_invoice_custom_names",
    "creating_invoice_custom_preview", "creating_invoice_custom_edit",
    "creating_invoice_set_discount", "creating_invoice_set_vat",
    "creating_invoice_add_note", "creating_invoice_new_client",
    "creating_invoice_new_client_phone",
    "creating_quote_add_items", "creating_quote_pick_product",
    "creating_quote_enter_prices", "creating_quote_enter_catalogue_prices",
    "creating_quote_confirm", "creating_quote_qty",
    "creating_quote_add_item_text", "creating_quote_custom_names",
    "creating_quote_custom_preview", "creating_quote_custom_edit",
    "creating_quote_set_discount", "creating_quote_set_vat",
    "creating_quote_add_note", "creating_quote_new_client",
    "creating_quote_new_client_phone",
    "creating_receipt_add_items", "creating_receipt_pick_product",
    "creating_receipt_enter_prices", "creating_receipt_enter_catalogue_prices",
    "creating_receipt_confirm", "creating_receipt_qty",
    "creating_receipt_add_item_text", "creating_receipt_custom_names",
    "creating_receipt_custom_preview", "creating_receipt_custom_edit",
    "creating_receipt_set_discount", "creating_receipt_set_vat",
    "creating_receipt_add_note", "creating_receipt_new_client",
    "creating_receipt_new_client_phone",
    "sales_doc_list", "creating_invoice_choose_client"
  ]);
  const _skipBuyerReqForBizFlow = biz && _bizFlowStates.has(biz.sessionState);
  if (!_skipBuyerReqForBizFlow) {
  // ── Universal escape words always work in any state ────────────────────
  if (al === "cancel" || al === "00" || al === "000") {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $unset: {
          "tempData.buyerRequestState": "",
          "tempData.pendingBuyerRequest": "",
          "tempData.buyerRequestMode": ""
        }
      },
      { upsert: true }
    );
    return sendButtons(from, {
      text: "✅ Request cancelled.",
      buttons: [
        { id: "sup_request_sellers", title: "⚡ Request Sellers" },
        { id: "find_supplier",       title: "🔍 Browse & Shop" }
      ]
    });
  }

  if (al === "0" || al === "menu" || al === "main menu") {
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "" } },
      { upsert: true }
    );
    return sendMainMenu(from);
  }

  if (al === "help") {
    return sendText(from,
      `📋 *Shortcuts:*\n\n` +
      `*0* = Main menu (always)\n` +
      `*00* = Cancel current flow\n` +
      `*menu* = Main menu (always)\n` +
      `*back* = Previous step\n` +
      `*quotes* = View your current quotes\n` +
      `*my requests* = View request history\n` +
      `*help* = Show this list\n\n` +
      `Type *0* to go to main menu now.`
    );
  }

if (al === "my requests" || al === "buyer_my_requests") {
    return handleIncomingMessage({ from, action: "buyer_my_requests" });
  }

  const requestMode = flowSess?.tempData?.buyerRequestMode || pendingBuyerRequest?.requestType || "simple";

  // SIMPLE MODE = one-line item + suburb/city
  if (requestMode === "simple") {
    // ── Try to parse using the improved quantity-aware parser ──────────────
    // First, try shortcode parser (handles "find X city" syntax)
    const parsedInline = parseInlineSimpleBuyerRequest(text);

    // Also try the new parseItemListWithQty for plain descriptions
    // e.g. "copper pipe 15mm, 5 lengths, Msasa" or "need plumber, Avondale"
    let parsedItems = parsedInline.items;
    let parsedCity  = parsedInline.city;
    let parsedArea  = parsedInline.area;

    // If shortcode parser didn't find items, try the new qty-aware parser
    if (!parsedItems.length && text.trim().length > 3) {
      // Strip trailing city/suburb from the text before parsing items
      const locParsed = parseBuyerRequestLocationInput(text);
      if (locParsed.city) {
        parsedCity = locParsed.city;
        parsedArea = locParsed.area;
        // Remove the city/area portion from the item text
        const textWithoutLoc = text
          .replace(new RegExp(`,?\\s*${locParsed.city}\\b`, "i"), "")
          .replace(new RegExp(`,?\\s*${locParsed.area || ""}\\b`, "i"), "")
          .trim();
        const rawItems = parseItemListWithQty(textWithoutLoc || text);
        if (rawItems.length) {
          parsedItems = rawItems.map(item => ({
            product:   item.product,
            quantity:  item.quantity,
            unitLabel: item.unitLabel,
            notes:     ""
          }));
        }
      } else {
        // No city found - try to parse the whole text as items
        const rawItems = parseItemListWithQty(text);
        if (rawItems.length) {
          parsedItems = rawItems.map(item => ({
            product:   item.product,
            quantity:  item.quantity,
            unitLabel: item.unitLabel,
            notes:     ""
          }));
        }
      }
    }

    if (!parsedItems.length) {
      return sendText(
        from,
        `❌ Please type what you need.\n\n` +
        `*Examples:*\n` +
        `_copper pipe 15mm, 5 lengths_\n` +
        `_cement 50kg x20 bags, Msasa_\n` +
        `_need plumber, burst pipe, Avondale_\n` +
        `_ball valve brass 20mm harare x5_\n\n` +
        `_Tip: quantity goes at the end, after the spec numbers._\n` +
        `Type *0* for main menu or *help* for shortcuts.`
      );
    }

    const vagueItems = getVagueBuyerRequestItems(parsedItems || []);
    if (vagueItems.length) {
      return sendText(from, buildBuyerSpecificityPrompt(vagueItems));
    }

    // ── Natural language: show what was understood + ask scope if very short ──
    // If the item was extracted from a natural-language sentence, show the buyer
    // a confirmation of what was understood before proceeding. This builds trust.
    const _hasNLItem = parsedItems.some(it => it.notes && it.notes.length > 60);
    if (_hasNLItem && parsedItems.length === 1) {
      const _nlItem = parsedItems[0];
      const _notesPreview = (_nlItem.notes || "").slice(0, 200);
      // Store items in session, move to location step with a confirmation message
      await UserSession.findOneAndUpdate(
        { phone },
        {
          $set: {
            "tempData.pendingBuyerRequest": {
              ...(pendingBuyerRequest || {}),
              requestType: "simple",
              items: parsedItems,
              isServiceRequest: _buyerRequestIsService(parsedItems)
            },
            "tempData.buyerRequestState": "awaiting_location"
          }
        },
        { upsert: true }
      );
      return sendButtons(from, {
        text:
          `✅ *Got it!*\n\n` +
          `📋 *Request:* ${_nlItem.product}\n` +
          `📝 *Details sent to seller:*\n_"${_notesPreview}"_\n\n` +
          `📍 *Where are you?* (suburb or city)\n\n` +
          `_e.g. Borrowdale, Msasa Harare, Mbare, Chitungwiza_\n\n` +
          `💡 _The full description above will be shown to matching sellers._\n` +
          `Type *0* for main menu`,
        buttons: [
          { id: "sup_change_location", title: "📍 Change location" }
        ]
      });
    }

    // ── Auto-detect service request ────────────────────────────────────────
    const _simpleIsService = _buyerRequestIsService(parsedItems);

    // ── If location was already typed, skip the location step ──────────────
    if (parsedCity) {
      await UserSession.findOneAndUpdate(
        { phone },
        {
          $set: {
            "tempData.buyerRequestState": _simpleIsService ? "awaiting_service_address" : "awaiting_delivery",
            "tempData.pendingBuyerRequest": {
              ...(pendingBuyerRequest || {}),
              requestType: "simple",
              items: parsedItems,
              rawText: text,
              profileType: "product",
              city: parsedCity,
              area: parsedArea,
              isServiceRequest: _simpleIsService
            }
          }
        },
        { upsert: true }
      );

      // Build confirmation lines with quantity clearly shown
      const _confirmItemLines = (parsedItems || []).map((item, i) => {
        const qty  = Number(item.quantity || 1);
        const unit = item.unitLabel && item.unitLabel !== "units" ? ` ${item.unitLabel}` : "";
        const qtyStr = qty === 1 ? "_(qty: 1)_" : `qty: ${qty}${unit}`;
        return `${i + 1}. *${item.product}*\n   ${qtyStr}`;
      }).join("\n");

      const locationLine = parsedArea
        ? `📍 ${parsedArea}, ${parsedCity}`
        : `📍 ${parsedCity}`;

      if (_simpleIsService) {
        const _isTourismAddr = _buyerRequestIsTourism(parsedItems);
        return sendButtons(
          from,
          {
            text:
              `✅ *Request captured:*\n\n` +
              `${_confirmItemLines}\n\n` +
              `${locationLine}\n\n` +
              (_isTourismAddr
                ? `📍 *Where will you be when the service starts?*\n\n` +
                  `_e.g. Kariba marina, Binga Harbour, Hwange main gate_\n\n` +
                  `Or tap Skip - you can share your exact location with the operator later.`
                : `📍 *Where should the service provider come?*\n\n` +
                  `_e.g. 24 Mabelreign Drive, Harare_\n\n` +
                  `Or tap Skip - share your address directly with the provider.`),
            buttons: [
              { id: "sup_skip_service_address", title: "⏭ Skip (share later)" }
            ]
          }
        );
      }

      // ── Context-aware delivery question ────────────────────────────────────
      const _isTourismReq = _buyerRequestIsTourism(parsedItems);
      if (_isTourismReq) {
        return sendButtons(from, {
          text:
            `✅ *Request captured:*\n\n` +
            `${_confirmItemLines}\n\n` +
            `${locationLine}\n\n` +
            `📍 *Where will you be? / Where should the operator meet you?*`,
          buttons: [
            { id: "sup_request_delivery_yes", title: "📍 My location" },
            { id: "sup_request_delivery_no",  title: "🏕 I'll go to the operator" }
          ]
        });
      }

      return sendButtons(from, {
        text:
          `✅ *Request captured - please check quantities:*\n\n` +
          `${_confirmItemLines}\n\n` +
          `${locationLine}\n\n` +
          `_To correct a quantity, type your request again with the right amount._\n\n` +
          `🚚 Do you need delivery?`,
        buttons: [
          { id: "sup_request_delivery_yes", title: "✅ Yes, delivery" },
          { id: "sup_request_delivery_no",  title: "🏠 No, collection" }
        ]
      });
    }

    // ── No location yet - ask for it ───────────────────────────────────────
    // Use saved location if available
    const _savedCity = flowSess?.tempData?.savedCity || null;
    const _savedArea = flowSess?.tempData?.savedArea || null;

    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.buyerRequestState": "awaiting_location",
          "tempData.pendingBuyerRequest": {
            ...(pendingBuyerRequest || {}),
            requestType: "simple",
            items: parsedItems,
            rawText: text,
            profileType: "product",
            isServiceRequest: _simpleIsService
          }
        }
      },
      { upsert: true }
    );

    if (_savedCity) {
      return sendButtons(from, {
        text:
          `✅ *Got it:*\n\n` +
          `${(parsedItems || []).map((item, i) => {
            const qty  = Number(item.quantity || 1);
            const unit = item.unitLabel && item.unitLabel !== "units" ? ` ${item.unitLabel}` : "";
            return `${i + 1}. *${item.product}* - qty ${qty}${unit}`;
          }).join("\n")}\n\n` +
          `📍 Use saved location *${_savedArea ? `${_savedArea}, ` : ""}${_savedCity}*?`,
        buttons: [
          { id: "sup_use_saved_location", title: `📍 Yes, ${_savedCity}` },
          { id: "sup_change_location",    title: "📍 Change Location" }
        ]
      });
    }

    return sendText(
      from,
      `✅ *Got it. Which area are you in?*\n\n` +
      `Reply with suburb or suburb + city:\n` +
      `_Msasa_, _Borrowdale Harare_, _Luveve Bulawayo_\n\n` +
      `Type *0* for main menu · *00* to cancel`
    );
  }

  // BULK MODE = item list first, location second
  const items = parseBuyerRequestItems(text);
  if (!items.length) {
    return sendText(
      from,
      `❌ Please send the items you need.\n\nExamples:\n_ball valve brass 20mm 5_\n_hp laptop core i7 3_\n_school uniform size 8 10_\n_geyser installation 2_\n\nFor long lists, send one item per line.\n\nType *0* for main menu · *00* to cancel`
    );
  }

  const vagueItems = getVagueBuyerRequestItems(items || []);
  if (vagueItems.length) {
    return sendText(
      from,
      buildBuyerSpecificityPrompt(vagueItems) +
        `\n\nFor bulk requests, fix the vague lines first, then send the full list again.`
    );
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.buyerRequestState": "awaiting_location",
        "tempData.pendingBuyerRequest": {
          ...(pendingBuyerRequest || {}),
          requestType: "bulk",
          items,
          rawText: text,
          profileType: "product",
        }
      }
    },
    { upsert: true }
  );

  return sendText(
    from,
    `📍 *Where do you need these items?*\n\nReply with city or suburb + city.\n\nExamples:\n_Harare_\n_Mbare, Harare_\n_Borrowdale, Harare_\n\nType *0* for main menu`
  );
  } // end _skipBuyerReqForBizFlow guard
  } // end else (not sc_ smart-link action)
}

    if (buyerRequestState === "awaiting_location" &&
        a !== "sup_use_saved_location" &&
        a !== "sup_request_delivery_yes" &&
        a !== "sup_request_delivery_no" &&
        a !== "sup_request_delivery_flexible" &&
        a !== "change_location" &&
        a !== "sup_skip_service_address") {
      if (al === "cancel" || al === "00" || al === "000") {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $unset: {
              "tempData.buyerRequestState": "",
              "tempData.pendingBuyerRequest": "",
              "tempData.buyerRequestMode": ""
            }
          },
          { upsert: true }
        );
        return sendButtons(from, {
          text: "✅ Request cancelled.",
          buttons: [
            { id: "sup_request_sellers", title: "⚡ Request Sellers" },
            { id: "find_supplier",       title: "🔍 Browse & Shop" }
          ]
        });
      }

      if (al === "0" || al === "menu") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "" } },
          { upsert: true }
        );
        return sendMainMenu(from);
      }

      const parsedLocation = parseBuyerRequestLocationInput(text);
      if (!parsedLocation.city) {
        return sendText(
          from,
          `❌ Please include at least the *city*.\n\nExamples:\n_Harare_\n_Mbare, Harare_\n_Avondale, Harare_\n\nType *0* for main menu`
        );
      }

      // Save location for future use
      await UserSession.findOneAndUpdate(
        { phone },
        {
          $set: {
            "tempData.buyerRequestState": "awaiting_delivery",
            "tempData.pendingBuyerRequest": {
              ...(pendingBuyerRequest || {}),
              city: parsedLocation.city,
              area: parsedLocation.area
            },
            "tempData.savedCity": parsedLocation.city,
            "tempData.savedArea": parsedLocation.area || ""
          }
        },
        { upsert: true }
      );

      const _bulkIsService = _buyerRequestIsService(pendingBuyerRequest?.items || []);
      if (_bulkIsService) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.buyerRequestState": "awaiting_service_address",
              "tempData.pendingBuyerRequest": {
                ...(pendingBuyerRequest || {}),
                city: parsedLocation.city,
                area: parsedLocation.area,
                isServiceRequest: true
              }
            }
          },
          { upsert: true }
        );
        return sendText(
          from,
          `📍 *Where should the service provider come?*\n\n` +
          `${parsedLocation.area ? `📍 ${parsedLocation.area}, ${parsedLocation.city}` : `📍 ${parsedLocation.city}`}\n\n` +
          `Type your full address:\n` +
          `_24 Mabelreign Drive, Harare_\n` +
          `_House 7, Borrowdale, Harare_\n\n` +
          `Type *skip* to share your address directly with the provider.\n` +
          `Type *0* for main menu`
        );
      }

      return sendButtons(from, {
        text:
          `🚚 *Do you need delivery?*\n\n` +
          `${parsedLocation.area ? `📍 ${parsedLocation.area}, ${parsedLocation.city}` : `📍 ${parsedLocation.city}`}`,
        buttons: [
          { id: "sup_request_delivery_yes", title: "✅ Yes, delivery" },
          { id: "sup_request_delivery_no", title: "🏠 No, collection" }
        ]
      });
    }

if (buyerRequestState === "awaiting_delivery_address") {
  const _isExit =
    al === "cancel" || al === "0" || al === "00" || al === "000" ||
    al === "menu" || al === "main menu" || al === "main_menu";

  if (_isExit) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $unset: {
          "tempData.buyerRequestState": "",
          "tempData.pendingBuyerRequest": "",
          "tempData.buyerRequestMode": ""
        }
      },
      { upsert: true }
    );

    return sendSuppliersMenu(from);
  }

  const deliveryAddress = String(text || "").trim();

  if (!deliveryAddress || deliveryAddress.length < 5) {
    return sendText(
      from,
      `❌ Please enter a proper delivery / pickup address.\n\n` +
      `Example:\n_24 Mabelreign Drive, Harare_\n__\n\n` +
      `Type *cancel* to stop.`
    );
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.buyerRequestState": "",
        "tempData.pendingBuyerRequest": "",
        "tempData.buyerRequestMode": ""
      }
    },
    { upsert: true }
  );

  return finalizeBuyerRequestSubmission({
    from,
    phone,
    pendingRequest: {
      ...(pendingBuyerRequest || {}),
      deliveryRequired: true,
      deliveryAddress
    },
    deliveryRequired: true,
    deliveryAddress
  });
}


    if (buyerRequestState === "awaiting_service_address") {
      const _isExitSA = al === "cancel" || al === "0" || al === "00" || al === "000" || al === "menu" || al === "main menu" || al === "main_menu";
      if (_isExitSA) {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "" } },
          { upsert: true }
        );
        return sendSuppliersMenu(from);
      }
      if (al === "back") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $set: { "tempData.buyerRequestState": "awaiting_items" } },
          { upsert: true }
        );
        return sendText(from, `↩️ Back to your request.\n\nType your item + city again.\n\nType *cancel* to stop.`);
      }
      // Accept both typed "skip" and tapping the skip button
      const _saAddress = (al === "skip" || a === "sup_skip_service_address") ? null : text.trim();
      if (_saAddress && _saAddress.length < 3) {
        return sendText(from, `❌ Please enter a valid address or type *skip*.\n\nType *cancel* to stop.`);
      }
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "" } },
        { upsert: true }
      );

      // ── Photo prompt: before finalizing, offer the buyer a chance to attach a photo ──
      // Only show once per request (guard: photoPromptShown)
      const _saReqWithAddress = { ...(pendingBuyerRequest || {}), serviceAddress: _saAddress || null, isServiceRequest: true };
      if (!flowSess?.tempData?.photoPromptShown) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.buyerRequestState":  "awaiting_photo_choice",
              "tempData.pendingBuyerRequest": _saReqWithAddress,
              "tempData.photoPromptShown":   true
            }
          },
          { upsert: true }
        );
        return sendButtons(from, {
          text:
            `📷 *Add a photo? (optional)*\n\n` +
            `A photo helps sellers understand exactly what you need and give a more accurate quote.\n\n` +
            `Useful for: repairs, damage, custom items, matching colours or parts.\n\n` +
            `Tap *Add Photo* then send your image, or tap *Skip* to submit now.`,
          buttons: [
            { id: "sup_req_photo_yes",  title: "📷 Add Photo"      },
            { id: "sup_req_photo_skip", title: "⏭ Skip - submit now" }
          ]
        });
      }

      return finalizeBuyerRequestSubmission({
        from, phone,
        pendingRequest: _saReqWithAddress,
        deliveryRequired: false,
        serviceAddress: _saAddress || null
      });
    }

    // ── awaiting_photo_choice: buyer chose to add photo or skip ───────────────
    if (buyerRequestState === "awaiting_photo_choice") {
      if (a === "sup_req_photo_skip" || al === "skip" || al === "00" || al === "cancel") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "", "tempData.photoPromptShown": "" } },
          { upsert: true }
        );
        return finalizeBuyerRequestSubmission({
          from, phone,
          pendingRequest:  pendingBuyerRequest || {},
          deliveryRequired: pendingBuyerRequest?.deliveryRequired || false,
          serviceAddress:   pendingBuyerRequest?.serviceAddress   || null,
          deliveryAddress:  pendingBuyerRequest?.deliveryAddress  || null
        });
      }
      if (a === "sup_req_photo_yes" || al === "add photo" || al === "photo") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $set: { "tempData.buyerRequestState": "awaiting_photo_upload" } },
          { upsert: true }
        );
        return sendText(from,
          `📷 *Send your photo now.*\n\n` +
          `You can add a caption to describe what you need.\n\n` +
          `_Type *skip* if you changed your mind and want to submit without a photo._`
        );
      }
      // Any other text while in photo_choice - re-show prompt
      return sendButtons(from, {
        text: `📷 Would you like to attach a photo to your request?`,
        buttons: [
          { id: "sup_req_photo_yes",  title: "📷 Add Photo"       },
          { id: "sup_req_photo_skip", title: "⏭ Skip - submit now" }
        ]
      });
    }

  // ── __buyer_photo_uploaded__: fired from meta_webhook after image download ──
  // hasImage, imageUrl, imageCaption are passed in from the webhook handler.
  if (a === "__buyer_photo_uploaded__") {
    const _photoSess = await UserSession.findOne({ phone });
    const _photoPending = _photoSess?.tempData?.pendingBuyerRequest || null;

    if (!_photoPending?.items?.length) {
      return sendText(from, "❌ Request session expired. Please start again with your request.");
    }

    if (!imageUrl) {
      return sendText(from, "❌ Could not save your photo. Please try again or type *skip* to submit without a photo.");
    }

    // Clear photo state
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "", "tempData.photoPromptShown": "" } },
      { upsert: true }
    );

    return finalizeBuyerRequestSubmission({
      from, phone,
      pendingRequest:  _photoPending,
      deliveryRequired: _photoPending.deliveryRequired || false,
      serviceAddress:   _photoPending.serviceAddress   || null,
      deliveryAddress:  _photoPending.deliveryAddress  || null,
      attachedImageUrl:     imageUrl,
      attachedImageCaption: imageCaption || ""
    });
  }


    // ── awaiting_photo_upload: waiting for buyer to send the image ────────────
    if (buyerRequestState === "awaiting_photo_upload") {
      // Buyer typed "skip" or cancel instead of sending image
      if (al === "skip" || al === "cancel" || al === "00" || al === "0") {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: { "tempData.buyerRequestState": "", "tempData.pendingBuyerRequest": "", "tempData.buyerRequestMode": "", "tempData.photoPromptShown": "" } },
          { upsert: true }
        );
        return finalizeBuyerRequestSubmission({
          from, phone,
          pendingRequest:  pendingBuyerRequest || {},
          deliveryRequired: pendingBuyerRequest?.deliveryRequired || false,
          serviceAddress:   pendingBuyerRequest?.serviceAddress   || null,
          deliveryAddress:  pendingBuyerRequest?.deliveryAddress  || null
        });
      }
      // Buyer sent text instead of image - keep waiting
      return sendText(from,
        `📷 Please *send a photo* (image message).\n\nOr type *skip* to submit your request without a photo.`
      );
    }



  const ownerRole = await UserRole.findOne({ phone, role: "owner", pending: false }).lean();

if (!biz && ownerRole?.businessId) {
    const existingBiz = await Business.findById(ownerRole.businessId);
    if (existingBiz && !existingBiz.name.startsWith("pending_supplier_")) {
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: existingBiz._id }, { upsert: true });
      await sendText(from, "✅ Welcome back. Opening your menu...");
      await sendMainMenu(from);
      return;
    }
  }

  // =========================
  // 🆕 NEW USER - WELCOME SCREEN (not auto-onboard)
  // =========================

const GREETING_WORDS = new Set([
  "hi", "hello", "hey", "hie", "howzit", "helo", "sup", "yo",
  "yes", "no", "ok", "okay", "k", "sure", "thanks", "thank you",
  "help", "start", "menu", "home", "back", "cancel",
  // Universal shortcuts
  "0", "00", "000", "quotes", "my quotes", "my requests",
  "pause", "resume",
  // Zimbabwean / common first-message greetings
  "good morning", "good afternoon", "good evening", "good day", "good night",
  "morning", "afternoon", "evening",
  "how are you", "how r u", "how are u", "hows it", "howzit guys",
  "i need help", "need help", "what can you do", "what do you do",
  "greetings", "sawubona", "mangwanani", "maswera sei", "makadii",
  "hello there", "hi there", "hey there",
  "request", "request sellers", "request quote", "get quotes", "get a quote"
]);

  // ── Global greeting/menu guard ─────────────────────────────────────────────
if (
  GREETING_WORDS.has(al) &&
  !isMetaAction &&
  (!biz || biz.sessionState === "ready" || biz.sessionState === "supplier_search_city")
) {
  // ── Don't intercept greetings if user has an active offer/quote flow ──────
  // Notification contacts have no "biz" of their own but DO have session state
  // (awaiting_offer_intro, awaiting_offer, etc). Without this check, "hi" from
  // a notification contact hits sendMainMenu() and the offer flow is never reached.
  const _greetSess = await UserSession.findOne({ phone }).lean();
  const _greetOfferState = _greetSess?.tempData?.sellerRequestReplyState;
  const _greetBuyerState = _greetSess?.tempData?.buyerRequestState;
  const _offerFlowActive =
    _greetOfferState === "awaiting_offer_intro" ||
    _greetOfferState === "awaiting_offer" ||
    _greetOfferState === "awaiting_offer_confirm";
  const _buyerFlowActive = !!_greetBuyerState;

  if (!_offerFlowActive && !_buyerFlowActive) {
    if (biz && biz.sessionState !== "ready") {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
    }

    // Route universal shortcuts regardless of state
    if (al === "quotes" || al === "my quotes") {
      return handleIncomingMessage({ from, action: "buyer_my_requests" });
    }
    if (al === "my requests") {
      return handleIncomingMessage({ from, action: "buyer_my_requests" });
    }
    if (al === "pause") {
      return handleIncomingMessage({ from, action: "sup_pause_requests" });
    }
    if (al === "resume") {
      return handleIncomingMessage({ from, action: "sup_resume_requests" });
    }
    // "request", "request sellers", "get quotes" → direct to Request Sellers flow
    if (al === "request" || al === "request sellers" || al === "request quote" || al === "get quotes" || al === "get a quote") {
      return handleIncomingMessage({ from, action: "sup_request_sellers" });
    }

    if (al === "help") {
      await sendText(from,
        `📋 *Shortcuts (work anywhere):*\n\n` +
        `*0* = Main menu\n` +
        `*00* = Cancel current flow\n` +
        `*menu* = Main menu\n` +
        `*quotes* = View your current quotes\n` +
        `*my requests* = Request history\n` +
        `*request* = Request Sellers (get quotes)\n` +
        `*pause* = Pause request notifications (sellers)\n` +
        `*resume* = Resume notifications (sellers)\n` +
        `*help* = Show this list`
      );
    }

    return sendMainMenu(from);
  }
  // else: fall through - let the offer/buyer flow handlers below take over
}

// ── All users: handle typed school enquiry message (biz and non-biz) ───────────
if (!isMetaAction) {
  const _enquirySess = await UserSession.findOne({ phone });
  if (_enquirySess?.tempData?.schoolEnquiryState === "school_parent_enquiry") {
    const message  = (text || "").trim();
    const schoolId = _enquirySess.tempData.enquirySchoolId;

    if (message.toLowerCase() === "cancel") {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
        { upsert: true }
      );
      return sendButtons(from, {
        text: "❌ Enquiry cancelled.",
        buttons: [{ id: "school_search_refine", title: "🔄 Back to Schools" }]
      });
    }

    if (!message || message.length < 3) {
      await sendText(from, "❌ Please type your question or message (at least 3 characters).");
      return;
    }

    if (!schoolId) {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
        { upsert: true }
      );
      return sendButtons(from, {
        text: "❌ Session expired. Please search for the school again.",
        buttons: [{ id: "find_school", title: "🏫 Find a School" }]
      });
    }

    const { default: SchoolProfile } = await import("../models/schoolProfile.js");
    const school = await SchoolProfile.findById(schoolId).lean();

    if (!school) {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
        { upsert: true }
      );
      return sendButtons(from, {
        text: "❌ School not found. Please search again.",
        buttons: [{ id: "find_school", title: "🏫 Find a School" }]
      });
    }

    // Increment enquiry counter
    await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { inquiries: 1 } });

    // Send notification to school with parent's message
    const { notifySchoolEnquiry } = await import("./schoolNotifications.js");
    notifySchoolEnquiry(school.phone, school.schoolName, from, message).catch(() => {});

    // Clear the enquiry session state (UserSession for all users)
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
      { upsert: true }
    );

    // Also reset biz.sessionState if user has a biz account (e.g. a supplier browsing schools)
    if (biz && biz.sessionState === "school_parent_enquiry") {
      biz.sessionState = "ready";
      biz.sessionData  = { ...(biz.sessionData || {}), enquirySchoolId: null };
      await saveBizSafe(biz);
    }

    // Confirm to parent
    return sendButtons(from, {
      text:
`✅ *Enquiry Sent to ${school.schoolName}!*

Your message:
_${message}_

The school has been notified and will contact you on this WhatsApp number.

📞 ${school.contactPhone || school.phone}`,
      buttons: [
        { id: `school_apply_${schoolId}`, title: "📝 Apply Online" },
        { id: "school_search_refine",      title: "🔄 More Schools" }
      ]
    });
  }
}

if (!biz) {
  const supplierExists = await SupplierProfile.findOne({ phone });
  const sess = await UserSession.findOne({ phone });

const searchMode = sess?.tempData?.supplierSearchMode;
const supplierAccountState = sess?.tempData?.supplierAccountState;
const supplierRegState = sess?.supplierRegState;

// ── ZQ deep link intercepts - MUST be first inside if(!biz) ─────────────────
// These MUST run before searchMode/shortcode blocks, the welcome-screen gate,
// and any other session-state logic. A no-biz visitor who has a leftover
// searchMode="product" session state would otherwise have ZQ:GROUP: and ZQ:S:
// treated as product queries, producing the "Which city?" prompt instead of
// the correct group list or supplier profile.
if (!isMetaAction && /^ZQ:S:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  // Check staff slug first before supplier resolver
  try {
    const _slug2 = text.trim().slice(5).toLowerCase(); // strip "ZQ:S:"
    const _StaffCardModel2 = (await import("../models/staffCard.js")).default;
    const _staffBySlug2 = await _StaffCardModel2.findOne({ zqSlug: _slug2 }).lean();
    if (_staffBySlug2) {
      const _sh2 = await handleStaffDeepLink({ from, text: "ZQ:STAFF:SLUG:" + _slug2, biz, saveBiz: saveBizSafe.bind(null, biz) });
      if (_sh2) return;
    }
  } catch (_) {}
  const _handled = await handleZqDeepLink({ from, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}
if (!isMetaAction && /^ZQ:GROUP:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  const _zqgSlug = text.trim().split(":")[2]?.toLowerCase().trim();
  if (_zqgSlug) {
    const _handled = await handleGroupSmartLink({ from, slug: _zqgSlug, biz, saveBiz: saveBizSafe.bind(null, biz) });
    if (_handled) return;
  }
}
// ── ZQ:STAFF:<id> early intercept - must run before searchMode/state logic ───
if (!isMetaAction && /ZQ:STAFF:/i.test(text.trim())) {
  const _handled = await handleStaffDeepLink({ from, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

if (
  searchMode === "product" &&
  !isMetaAction &&
  !GREETING_WORDS.has(text.trim().toLowerCase()) &&
  supplierAccountState !== "supplier_update_prices" &&
  supplierRegState !== "supplier_reg_prices" &&
  // FIX: don't intercept text typed by a no-biz user mid-sc_ quote flow
  !sess?.tempData?.scState?.startsWith("sc_") &&
  // FIX: ZQ: deep links must never be treated as product search queries
  !/^ZQ:/i.test(text.trim())
) {
  const productQuery = text.trim();
  if (!productQuery || productQuery.length < 1) {
    return sendButtons(from, {
      text: "❌ Please type what you're looking for:\n\n_e.g. find cement, find plumber harare_",
      buttons: [{ id: "find_supplier", title: "⬅ Back" }]
    });
  }
function _inlineParseLocation(txt) {
    const _S = {"avondale":"Harare","borrowdale":"Harare","cbd":"Harare","mbare":"Harare","highfield":"Harare","hatfield":"Harare","greendale":"Harare","msasa":"Harare","eastlea":"Harare","waterfalls":"Harare","mufakose":"Harare","chitungwiza":"Harare","ruwa":"Harare","zimre park":"Harare","gazebo":"Harare","damafalls":"Harare","epworth":"Harare","tafara":"Harare","mabvuku":"Harare","highlands":"Harare","greencroft":"Harare","mount pleasant":"Harare","belgravia":"Harare","milton park":"Harare","newlands":"Harare","chisipite":"Harare","gunhill":"Harare","strathaven":"Harare","braeside":"Harare","arcadia":"Harare","southerton":"Harare","workington":"Harare","willowvale":"Harare","graniteside":"Harare","seke":"Harare","norton":"Harare","kambuzuma":"Harare","warren park":"Harare","glen view":"Harare","glenview":"Harare","budiriro":"Harare","kuwadzana":"Harare","dzivarasekwa":"Harare","mabelreign":"Harare","malborough":"Harare","marlborough":"Harare","malbro":"Harare","glen norah":"Harare","glennorah":"Harare","nkulumane":"Bulawayo","luveve":"Bulawayo","entumbane":"Bulawayo","njube":"Bulawayo","mpopoma":"Bulawayo","lobengula":"Bulawayo","makokoba":"Bulawayo","tshabalala":"Bulawayo","pumula":"Bulawayo","cowdray park":"Bulawayo","mahatshula":"Bulawayo","magwegwe":"Bulawayo","hillside":"Bulawayo","white city":"Bulawayo","sakubva":"Mutare","dangamvura":"Mutare","chikanga":"Mutare","mambo":"Gweru","mkoba":"Gweru","senga":"Gweru","ascot":"Gweru","mucheke":"Masvingo","rujeko":"Masvingo","mbizo":"Kwekwe","amaveni":"Kwekwe","macheke":"Murehwa"};
    const _C = ["harare","bulawayo","mutare","gweru","masvingo","kwekwe","kadoma","chinhoyi","victoria falls","bindura","murehwa"];
    const _tc = v => String(v||"").split(" ").filter(Boolean).map(p=>p[0].toUpperCase()+p.slice(1)).join(" ");
    const raw = txt.toLowerCase().trim().replace(/^find\s+/i,"").replace(/^search\s+/i,"").replace(/\s+/g," ");
    const words = raw.split(" ").filter(Boolean);
    let city=null,area=null,ci=-1,cl=0,ai=-1,al=0;
    outer1: for(let len=Math.min(2,words.length);len>=1;len--){for(let i=0;i<=words.length-len;i++){const c=words.slice(i,i+len).join(" ");if(_C.includes(c)){city=_tc(c);ci=i;cl=len;break outer1;}}}
    outer2: for(let len=Math.min(3,words.length);len>=1;len--){for(let i=0;i<=words.length-len;i++){if(i===ci&&len===cl)continue;const c=words.slice(i,i+len).join(" ");if(_S[c]){area=_tc(c);ai=i;al=len;if(!city)city=_S[c];break outer2;}}}
    const rem=[];if(ci>=0)rem.push([ci,ci+cl]);if(ai>=0)rem.push([ai,ai+al]);rem.sort((a,b)=>a[0]-b[0]);
    const prod=words.filter((_,i)=>!rem.some(([s,e])=>i>=s&&i<e)).join(" ").trim();
    return{product:prod||raw,city,area};
  }

  const _loc = _inlineParseLocation(productQuery);
  const parsed = (_loc.city || _loc.area) ? _loc : (parseShortcodeSearch(productQuery) || parseShortcodeSearch(`find ${productQuery}`) || { product: productQuery, city: null, area: null });

  const cleanProduct = String(parsed.product || "")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ");

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.supplierSearchProduct": cleanProduct,
        ...(parsed.city ? { "tempData.lastSearchCity": parsed.city } : {}),
        ...(parsed.area ? { "tempData.lastSearchArea": parsed.area } : {})
      },
      $unset: { "tempData.supplierSearchMode": "" }
    }
  );

if (parsed.city || parsed.area) {
   const locationLabel = parsed.area
    ? `${parsed.area}, ${parsed.city}`
    : parsed.city;

  // First check supplier/business-name matches in the same city/area context.
  // This prevents business-name searches like "prime dental avondale"
  // from being turned into offer-level service results.
  const supplierResults = await runSupplierSearch({
    city: parsed.city || null,
    product: cleanProduct,
    area: parsed.area || null,
    profileType: sess?.tempData?.supplierSearchType || null
  });

  const normalizedQuery = normalizeProductName(cleanProduct);
  const directBusinessMatches = supplierResults.filter(s => {
    const businessName = normalizeProductName(s.businessName || "");
    return businessName === normalizedQuery || businessName.includes(normalizedQuery);
  });

  if (directBusinessMatches.length > 0) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.searchResults": directBusinessMatches,
          "tempData.searchPage": 0,
          "tempData.searchResultMode": "suppliers"
        }
      },
      { upsert: true }
    );

    const pageResults = directBusinessMatches.slice(0, 9);
    const rows = formatSupplierResults(
      pageResults,
      parsed.city || parsed.area || "",
      cleanProduct
    );

    if (directBusinessMatches.length > 9) {
      rows.push({
        id: "sup_search_next_page",
        title: `➡ More results (${directBusinessMatches.length - 9} more)`
      });
    }

        await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.currentSearchContext": {
            product: cleanProduct,
            city: parsed.city || null,
            area: parsed.area || null,
            profileType: sess?.tempData?.supplierSearchType || null,
            resultMode: "suppliers"
          }
        }
      },
      { upsert: true }
    );

    await sendNumberedSellerResults({
      from, phone,
      suppliers: directBusinessMatches,
      searchTerm: cleanProduct,
      locationLabel
    });

    await _sendPostSearchActions(from, {
      product: cleanProduct,
      resultMode: "suppliers"
    });

    notifySuppliersOfLiveDemand({
      product: cleanProduct,
      city: parsed.city || null,
      area: parsed.area || null,
      profileType: sess?.tempData?.supplierSearchType || null,
      results: directBusinessMatches
    }).catch(err => console.error("[LIVE DEMAND DIRECT MATCH]", err.message));

    return;
  }

  // Keep existing offer-first behavior for real item/service searches
  const offerResults = await runSupplierOfferSearch({
    city: parsed.city || null,
    product: cleanProduct,
    area: null,
    profileType: sess?.tempData?.supplierSearchType || null
  });

  if (Array.isArray(offerResults) && offerResults.length > 0) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.searchResults": offerResults,
          "tempData.searchPage": 0,
          "tempData.searchResultMode": "offers"
        }
      },
      { upsert: true }
    );

    const pageOffers = offerResults.slice(0, 9);
    const rows = formatSupplierOfferResults(pageOffers, cleanProduct);

    if (offerResults.length > 9) {
      rows.push({
        id: "sup_search_next_page",
        title: `➡ More results (${offerResults.length - 9} more)`
      });
    }

     await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.currentSearchContext": {
            product: cleanProduct,
            city: parsed.city || null,
            area: parsed.area || null,
            profileType: sess?.tempData?.supplierSearchType || null,
            resultMode: "offers"
          }
        }
      },
      { upsert: true }
    );

    await sendNumberedSellerResults({
      from, phone,
      offers: offerResults,
      searchTerm: cleanProduct,
      locationLabel
    });

    await _sendPostSearchActions(from, {
      product: cleanProduct,
      resultMode: "offers"
    });

    notifySuppliersOfLiveDemand({
      product: cleanProduct,
      city: parsed.city || null,
      area: parsed.area || null,
      profileType: sess?.tempData?.supplierSearchType || null,
      results: offerResults
    }).catch(err => console.error("[LIVE DEMAND OFFER MATCH]", err.message));

    return;
  }

  if (!supplierResults.length) {
    await logSearchCommand({
      phone,
      rawText: text,
      source: "text",
      flow: "supplier_search",
      sessionState: biz?.sessionState || "",
      parsed: {
        product: shortcode.product || "",
        city: shortcode.city || "",
        area: shortcode.area || "",
        profileType: shortcode.profileType || ""
      },
      resultMode: "none",
      results: [],
      botReplySummary: "No matching supplier or offer results found"
    });

    return sendButtons(from, {
      text: `😕 No results for *${shortcode.product}* in *${locationLabel}*.\n\nTry searching all of Zimbabwe?`,
      buttons: [
        { id: "sup_search_city_all", title: "📍 Search All Cities" },
        { id: "find_supplier",       title: "🔍 Search Again" }
      ]
    });
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.searchResults": supplierResults,
        "tempData.searchPage": 0,
        "tempData.searchResultMode": "suppliers"
      }
    },
    { upsert: true }
  );

  const pageResults = supplierResults.slice(0, 9);
  const rows = formatSupplierResults(
    pageResults,
    parsed.city || parsed.area || "",
    cleanProduct
  );

  if (supplierResults.length > 9) {
    rows.push({
      id: "sup_search_next_page",
      title: `➡ More results (${supplierResults.length - 9} more)`
    });
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.currentSearchContext": {
          product: cleanProduct,
          city: parsed.city || null,
          area: parsed.area || null,
          profileType: sess?.tempData?.supplierSearchType || null,
          resultMode: "suppliers"
        }
      }
    },
    { upsert: true }
  );

  await sendNumberedSellerResults({
    from, phone,
    suppliers: supplierResults,
    searchTerm: cleanProduct,
    locationLabel: parsed.city || ""
  });

  await _sendPostSearchActions(from, {
    product: cleanProduct,
    resultMode: "suppliers"
  });

  notifySuppliersOfLiveDemand({
    product: cleanProduct,
    city: parsed.city || null,
    area: parsed.area || null,
    profileType: sess?.tempData?.supplierSearchType || null,
    results: supplierResults
  }).catch(err => console.error("[LIVE DEMAND SUPPLIER MATCH]", err.message));

  return;
}

  return sendList(from, `🔍 Looking for: *${cleanProduct}*\n\nWhich city?`, [
    ...SUPPLIER_CITIES.slice(0, 9).map(c => ({
      id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`,
      title: c
    })),
    { id: "sup_search_city_all", title: "📍 All Cities" }
  ]);
}
  const hasActiveBuyerFlow =
    !!sess?.tempData?.orderState ||
    !!sess?.tempData?.supplierSearchMode ||
    !!sess?.tempData?.supplierSearchCategory ||
    !!sess?.tempData?.supplierSearchProduct ||
    // FIX: no-biz buyers in sc_ quote flow must not be sent to welcome screen
    !!sess?.tempData?.scState ||
    // FIX: parents mid-application must not be sent to product search or welcome screen
    (!!sess?.tempData?.schoolApplyState && sess.tempData.schoolApplyState !== "awaiting_start");

  // Allow supplier search/order actions through for non-registered users
const allowedWithoutBiz =
  a === "onboard_business" ||
  a === "find_supplier" ||
  a === "register_supplier" ||
  a === "suppliers_home" ||
  a === "my_orders" ||
  a === "sup_upgrade_plan" ||
  a === "sup_renew_plan" ||
 a === "sup_search_type_product" ||
      a === "sup_search_type_service" ||
     a === "reg_type_school" ||
      a === "reg_type_hospitality" ||
      a === "reg_type_product" ||
      a === "reg_type_service" ||
      a.startsWith("sup_hosp_type_") ||
      a === "sup_hosp_facilities_done" ||
      a === "sup_skip_rest_rates" ||
      a === "sup_skip_extra_services" ||
      a.startsWith("sup_hosp_fac_toggle_") ||
  a === "sup_search_more_categories" ||
  a === "sup_search_all" ||

  // ── school admin actions must not fall through to marketplace search ──
  a === "school_admin_manage_facilities" ||
  a === "school_admin_manage_extramural" ||
  a === "school_admin_edit_fees" ||
  a === "school_admin_edit_reg_link" ||
  a === "school_admin_edit_email" ||
  a === "school_admin_edit_website" ||
  a === "school_admin_upload_brochure" ||
  a.startsWith("school_fac_page_") ||
  a.startsWith("school_fac_toggle_") ||
  a.startsWith("school_ext_page_") ||
  a.startsWith("school_ext_toggle_") ||
  a.startsWith("sup_shop_") ||
  a === "sup_back_to_search_results" ||
  a.startsWith("sup_number_full_") ||
  a.startsWith("sup_catalog_page_") ||
  a.startsWith("sup_cart_view_") ||
  a.startsWith("sup_catalogue_search_") ||
  a === "sup_catalogue_search_cancel" ||
  a.startsWith("sup_search_cat_") ||
  a.startsWith("sup_search_city_") ||
  a.startsWith("sup_view_") ||
  a.startsWith("sup_order_") ||
  a.startsWith("sup_save_") ||
  a.startsWith("rate_order_") ||
a.startsWith("sup_accept_") ||
  a.startsWith("sup_decline_") ||
  a.startsWith("sup_view_order_") ||
  a.startsWith("sup_contact_buyer_") ||
  a.startsWith("sup_cart_add_") ||
  a.startsWith("sup_cart_confirm_") ||
  a.startsWith("sup_cart_clear_") ||
  a.startsWith("sup_cart_remove_") ||
  a.startsWith("sup_cart_custom_") ||
  a.startsWith("paylist_prev_") ||
      a.startsWith("paylist_next_") ||
      a.startsWith("paylist_search_") ||

  a === "sup_request_sellers" ||
  a === "sup_use_saved_location" ||
  a === "sup_change_location" ||
  a === "sup_pause_requests" ||
  a === "sup_resume_requests" ||
  a === "sup_request_mode_simple" ||
  a === "sup_request_mode_bulk" ||
  a === "sup_request_delivery_yes" ||
  a === "sup_request_delivery_no" ||
  a.startsWith("req_offer_") ||
  a.startsWith("req_unavail_") ||
  a === "view_and_quote" ||
  a === "not_available" ||
  a.startsWith("buyer_view_all_quotes_") ||
  a === "buyer_my_requests" ||


a === "sup_search_next_page" ||
  a === "sup_search_prev_page" ||
  a === "my_supplier_account" ||
  a === "main_menu_back" ||
      a.startsWith("payinv_full_") ||
    a === "biz_tools_menu" ||
    a === "marketplace_menu" ||


      a === "sup_request_quote_search" ||
  a === "sup_save_search_current" ||
  a.startsWith("sup_request_quote_supplier_") ||
  a.startsWith("sup_ask_availability_") ||
  // ── Schools ──────────────────────────────────────────────────────────────
  a === "find_school" ||
  a === "school_register" ||
  a === "school_account" ||
  a === "school_pay_plan" ||
  a === "school_search_refine" ||
  a === "school_toggle_admissions" ||
  a === "school_update_fees" ||
  a === "school_reg_confirm_yes" ||
  a === "school_reg_confirm_no" ||
  a === "school_reg_address_skip" ||
  a === "school_reg_principal_skip" ||
  a === "school_reg_email_skip" ||
  a === "school_reg_cur_done" ||
  a === "school_reg_fac_done" ||
  a === "school_reg_ext_done" ||
  a === "school_reg_city_other" ||
  a.startsWith("school_reg_type_") ||
  a.startsWith("school_reg_city_") ||
  a.startsWith("school_reg_cur_") ||
  a.startsWith("school_reg_gender_") ||
  a.startsWith("school_reg_boarding_") ||
  a.startsWith("school_reg_fac_") ||
  a.startsWith("school_reg_ext_") ||
  a.startsWith("school_plan_") ||
  a.startsWith("school_search_city_") ||
  a.startsWith("school_search_type_") ||
  a.startsWith("school_search_fees_") ||
  a.startsWith("school_search_fac_") ||
  a.startsWith("school_search_page_") ||
  a.startsWith("school_view_") ||
 a.startsWith("school_dl_profile_") ||
  (a.startsWith("school_apply_") && !a.startsWith("school_apply_start_")) ||
  a.startsWith("school_apply_start_") ||
  a.startsWith("school_enquiry_") ||
  a === "school_my_profile" ||
  a === "school_my_facilities" ||
  a === "school_my_fees" ||
  a === "school_my_reviews" ||
  a === "school_my_inquiries" ||
  a === "school_more_options" ||
  a === "school_applications" ||
  a === "school_enquiries" ||
  a === "school_contacts" ||
  a === "school_marketplace" ||
  a === "school_share_link" ||
  a === "school_update_reg_link" ||
  a === "school_update_email" ||
  a === "school_update_website" ||
  // ── Buyer-facing actions: must work without a biz or supplier account ──────
  a === "sup_request_sellers" ||
  a === "sup_request_mode_simple" ||
  a === "sup_request_mode_bulk" ||
  a === "sup_request_delivery_yes" ||
  a === "sup_request_delivery_no" ||
  a === "sup_skip_service_address" ||
  a === "sup_req_photo_yes" ||
  a === "sup_req_photo_skip" ||
  a === "buyer_my_requests" ||
  a.startsWith("buyer_view_all_quotes_") ||
  a.startsWith("req_offer_") ||
  a.startsWith("req_unavail_") ||

  // ── Seller smart-link chat (sc_) - buyers visiting via ZQ:SUPPLIER link ─────
  // These MUST be here or no-biz visitors get sent to welcome screen after
  // tapping any menu option (Quote, Order, Enquiry, Contact, Review etc).
  a.startsWith("sc_") ||

  // ── School FAQ (sfaq_) - parents visiting via ZQ:SCHOOL link ────────────────
  // Same issue: parent taps a school FAQ button → redirected without this.
  a.startsWith("sfaq_") ||
  // ── Group smart link list-reply taps ─────────────────────────────────────
  // zqg_sel_<id>        = buyer tapped a seller row in a group list
  // zqg_register_<slug> = buyer tapped "List Your Business Here"
  // Without these the welcome-screen gate fires and swallows the action.
  a.startsWith("zqg_sel_") ||
  a.startsWith("zqg_register_") ||
  // School group list-reply taps - allow no-biz visitors
  a.startsWith("zqsg_sch_") ||
  a.startsWith("zqsg_register_");

// ── Shortcode search intercept: "find cement", "s plumber harare" etc ─────
// ── Shortcode search intercept: "find cement", "find mushambahuro harare" etc ─────


if (GREETING_WORDS.has(text.trim().toLowerCase())) {
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.supplierSearchMode": "",
        "tempData.supplierSearchProduct": "",
        "tempData.supplierSearchCategory": "",
        "tempData.lastSearchCity": "",
        "tempData.lastSearchArea": ""
      }
    },
    { upsert: true }
  );
}

const _sessForOrderCheck = await UserSession.findOne({ phone });
const _activeOrderState = _sessForOrderCheck?.tempData?.orderState;
const _orderBlockedStates = new Set([
  "supplier_order_address",
  "supplier_order_picking",
  "supplier_order_enter_price"
]);

// AFTER:
const _schoolEnquiryState = _sessForOrderCheck?.tempData?.schoolEnquiryState;

// ── Group list-reply tap early intercept (no-biz path) ─────────────────────
// FIX: zqg_sel_ and zqg_register_ come in as interactive list_reply actions.
// isMetaAction is now true for them (fixed above), so they no longer hit the
// shortcode search. But they also need a handler HERE - before any no-biz
// early-return gates that check !isMetaAction - because those gates would
// otherwise block execution before the handler at the bottom of the file runs.
if (a.startsWith("zqg_sel_") || a.startsWith("zqg_register_")) {
  const _zqgHandled = await handleGroupSellerTap({ from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_zqgHandled) return;
}

// ── ZQ:S:<slug> early intercept (no-biz path) ─────────────────────────────
// FIX: ZQ:S: smart links were falling through to parseShortcodeSearch and
// being treated as product searches, triggering the "Which city?" prompt.
// These must be handled HERE - before the shortcode block - for visitors who
// have no business account (the common case for smart link visitors).
if (!isMetaAction && /^ZQ:S:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  // Check staff slug first before supplier resolver
  try {
    const _slug3 = text.trim().slice(5).toLowerCase(); // strip "ZQ:S:"
    const _StaffCardModel3 = (await import("../models/staffCard.js")).default;
    const _staffBySlug3 = await _StaffCardModel3.findOne({ zqSlug: _slug3 }).lean();
    if (_staffBySlug3) {
      const _sh3 = await handleStaffDeepLink({ from, text: "ZQ:STAFF:SLUG:" + _slug3, biz, saveBiz: saveBizSafe.bind(null, biz) });
      if (_sh3) return;
    }
  } catch (_) {}
  const _handled = await handleZqDeepLink({ from, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}
// FIX: ZQ:GROUP: links were falling through to parseShortcodeSearch and
// triggering the "Which city?" prompt for visitors without a business account.
if (!isMetaAction && /^ZQ:GROUP:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  const _slug = text.trim().split(":")[2]?.toLowerCase().trim();
  if (_slug) {
    const _handled = await handleGroupSmartLink({ from, slug: _slug, biz, saveBiz: saveBizSafe.bind(null, biz) });
    if (_handled) return;
  }
}

if (
  !isMetaAction &&
  text.trim().length > 2 &&
  !GREETING_WORDS.has(text.trim().toLowerCase()) &&
  !_orderBlockedStates.has(_activeOrderState) &&
  _schoolEnquiryState !== "school_parent_enquiry" &&
  !biz?.sessionState?.startsWith("sc_") &&
  // FIX: no-biz buyers in the sc_ quote flow store their state in UserSession.
  // Without this check, typed item selections (e.g. "1x3,6") hit the shortcode
  // search instead of being routed to handleSellerChatState.
  !_sessForOrderCheck?.tempData?.scState?.startsWith("sc_") &&
  // FIX: ZQ: deep links (ZQ:GROUP:, ZQ:S:, ZQ:SUPPLIER:, ZQ:SCHOOL:) must
  // never reach parseShortcodeSearch - they are handled by the intercepts above.
  !/^ZQ:/i.test(text.trim()) &&
  // FIX: zqg_ group list-reply actions must never reach shortcode search.
  // isMetaAction is now true for them, but this guard is belt-and-suspenders.
  !a.startsWith("zqg_")
) {
  console.log(`[HIT-NOBIZ-SHORTCODE] text="${text}"`);
  const { parseShortcodeSearch } = await import("./supplierSearch.js");
  const shortcode = parseShortcodeSearch(text);

  if (shortcode) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.supplierSearchProduct": shortcode.product,
          ...(shortcode.city ? { "tempData.lastSearchCity": shortcode.city } : {}),
          ...(shortcode.area ? { "tempData.lastSearchArea": shortcode.area } : {})
        }
      },
      { upsert: true }
    );

        // INLINE CITY/SUBURB SEARCH MUST BE OFFER-FIRST
    if (shortcode.city || shortcode.area) {
      const locationLabel = shortcode.area
        ? `${shortcode.area}, ${shortcode.city}`
        : shortcode.city || "Zimbabwe";

      console.log(
        `[TRACE-NOBIZ-OFFER-FIRST] city="${shortcode.city}" area="${shortcode.area}" product="${shortcode.product}"`
      );

      // Behave like city-picker flow:
      // city-level offer search first, without forcing area
      let offerResults = await runSupplierOfferSearch({
        city: shortcode.city || null,
        product: shortcode.product,
        area: null
      });

      console.log(`[TRACE-NOBIZ-OFFER-FIRST-RESULT1] offerResults.length=${offerResults.length}`);

      // Retry across all cities, still without forcing area
      if (!offerResults.length) {
        offerResults = await runSupplierOfferSearch({
          city: null,
          product: shortcode.product,
          area: null
        });
        console.log(`[TRACE-NOBIZ-OFFER-FIRST-RESULT2] offerResults.length=${offerResults.length}`);
      }

      if (offerResults.length) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": offerResults,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "offers",
              "tempData.supplierSearchProduct": shortcode.product,
              ...(shortcode.city ? { "tempData.lastSearchCity": shortcode.city } : {}),
              ...(shortcode.area ? { "tempData.lastSearchArea": shortcode.area } : {})
            }
          },
          { upsert: true }
        );

        const pageOffers = offerResults.slice(0, 9);
        const rows = formatSupplierOfferResults(pageOffers, shortcode.product);

        if (offerResults.length > 9) {
          rows.push({
            id: "sup_search_next_page",
            title: `➡ More results (${offerResults.length - 9} more)`
          });
        }

        return sendNumberedSellerResults({
          from, phone,
          offers: offerResults,
          searchTerm: shortcode.product,
          locationLabel
        });
      }

      // Only now fallback to supplier-level results
      const searchArgs = {
        ...(shortcode.city ? { city: shortcode.city } : {}),
        product: shortcode.product,
        area: shortcode.area || null
      };

      console.log(`[TRACE-NOBIZ-SUPPLIER-FALLBACK] searchArgs=${JSON.stringify(searchArgs)}`);
      const results = await runSupplierSearch(searchArgs);
      console.log(`[TRACE-NOBIZ-SUPPLIER-FALLBACK2] runSupplierSearch returned ${results.length} results`);

      if (results.length) {
        const rows = formatSupplierResults(
          results.slice(0, 9),
          shortcode.city || shortcode.area || "",
          shortcode.product
        );

        if (results.length > 9) {
          rows.push({
            id: "sup_search_next_page",
            title: `➡ More results (${results.length - 9} more)`
          });
        }

        return sendNumberedSellerResults({
          from, phone,
          suppliers: results,
          searchTerm: shortcode.product,
          locationLabel
        });
      }

      return sendButtons(from, {
        text: `😕 No results for *${shortcode.product}*${shortcode.city ? ` in *${shortcode.city}*` : ""}.\n\nTry a different city or search term.`,
        buttons: [
          { id: "find_supplier", title: "🔍 Search Again" },
          { id: "sup_search_city_all", title: "📍 Try All Cities" }
        ]
      });
    }

    // NO LOCATION: keep existing supplier-first behavior
    const searchArgs = {
      ...(shortcode.city ? { city: shortcode.city } : {}),
      product: shortcode.product,
      area: shortcode.area || null
    };

    console.log(`[TRACE-NOBIZ] non-biz shortcode path: searchArgs=${JSON.stringify(searchArgs)}`);
    const results = await runSupplierSearch(searchArgs);
    console.log(`[TRACE-NOBIZ2] runSupplierSearch returned ${results.length} results`);

        const normalizedQuery = normalizeProductName(shortcode.product);
    const directBusinessMatches = results.filter(s => {
      const businessName = normalizeProductName(s.businessName || "");
      return businessName === normalizedQuery || businessName.includes(normalizedQuery);
    });

    // BUSINESS-NAME SEARCH:
    // always show a selectable results list first,
    // even if there is only one clear business match.
    if (directBusinessMatches.length > 0) {
      const pageResults = directBusinessMatches.slice(0, 9);
      const rows = formatSupplierResults(
        pageResults,
        shortcode.city || shortcode.area || null,
        shortcode.product
      );

      if (directBusinessMatches.length > 9) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": directBusinessMatches,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "suppliers"
            }
          },
          { upsert: true }
        );
        rows.push({
          id: "sup_search_next_page",
          title: `➡ More results (${directBusinessMatches.length - 9} more)`
        });
      } else {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": directBusinessMatches,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "suppliers"
            }
          },
          { upsert: true }
        );
      }

      const locationLabel = shortcode.area
        ? `${shortcode.area}, ${shortcode.city}`
        : shortcode.city || null;

      return sendNumberedSellerResults({
        from, phone,
        suppliers: directBusinessMatches,
        searchTerm: shortcode.product,
        locationLabel: locationLabel || ""
      });
    }


if (shortcode.city && results.length) {
      const locationLabel = shortcode.area
        ? `${shortcode.area}, ${shortcode.city}`
        : shortcode.city;

      // Try offers with city first
      console.log(`[TRACE-B] calling runSupplierOfferSearch city="${shortcode.city}" product="${shortcode.product}" area="${shortcode.area}"`);
         // IMPORTANT:
      // For inline suburb/city text like "find valve mbare",
      // do NOT force area on offer search.
      // Use city-level offer search first so this matches the city-picker flow.
      let offerResults = await runSupplierOfferSearch({
        city: shortcode.city,
        product: shortcode.product,
        area: null
      });

      // If city-level offer search returns nothing, retry across all cities
      // but still do NOT force area here.
      if (!offerResults.length) {
        offerResults = await runSupplierOfferSearch({
          city: null,
          product: shortcode.product,
          area: null
        });
      }
      if (offerResults.length) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": offerResults,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "offers"
            }
          },
          { upsert: true }
        );
        if (biz) {
          biz.sessionData = {
            ...(biz.sessionData || {}),
            supplierSearch: { product: shortcode.product, city: shortcode.city },
            searchResults: offerResults,
            searchPage: 0,
            searchResultMode: "offers"
          };
          await saveBizSafe(biz);
        }
        const pageOffers = offerResults.slice(0, 9);
        const rows = formatSupplierOfferResults(pageOffers, shortcode.product);
        if (offerResults.length > 9) {
          rows.push({ id: "sup_search_next_page", title: `➡ More results (${offerResults.length - 9} more)` });
        }
        return sendNumberedSellerResults({ from, phone, offers: offerResults, searchTerm: shortcode.product, locationLabel });
      }

      // Only reach here if no offers found anywhere - show businesses as last resort
      const pageResults = results.slice(0, 9);
      const rows = formatSupplierResults(pageResults, shortcode.city, shortcode.product);
      if (results.length > 9) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": results,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "suppliers"
            }
          },
          { upsert: true }
        );
        rows.push({ id: "sup_search_next_page", title: `➡ More results (${results.length - 9} more)` });
      }
      return sendNumberedSellerResults({ from, phone, suppliers: results, searchTerm: shortcode.product, locationLabel });
    }

    if (!shortcode.city && directBusinessMatches.length > 0) {
      const pageResults = directBusinessMatches.slice(0, 9);
      const rows = formatSupplierResults(pageResults, null, shortcode.product);

      if (directBusinessMatches.length > 9) {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": directBusinessMatches,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "suppliers"
            }
          },
          { upsert: true }
        );
        rows.push({ id: "sup_search_next_page", title: `➡ More results (${directBusinessMatches.length - 9} more)` });
      }

      return sendNumberedSellerResults({ from, phone, suppliers: directBusinessMatches, searchTerm: shortcode.product, locationLabel: "" });
    }

 // City was given but no results found - say so, offer to try all cities
    if (shortcode.city) {
      return sendButtons(from, {
        text: `😕 No results for *${shortcode.product}* in *${shortcode.city}*.\n\nTry a different city or search all of Zimbabwe?`,
        buttons: [
          { id: "sup_search_city_all", title: "📍 Search All Cities" },
          { id: "find_supplier",       title: "🔍 Search Again" }
        ]
      });
    }

    // No city given - ask for it
   // No city given - store product in session then ask for city
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.supplierSearchProduct": shortcode.product, "tempData.supplierSearchMode": "product" } },
      { upsert: true }
    );
    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), supplierSearch: { product: shortcode.product } };
      biz.sessionState = "supplier_search_city";
      await saveBizSafe(biz);
    }
    return sendList(from, `🔍 Looking for: *${shortcode.product}*\n\nWhich city?`, [
      ...SUPPLIER_CITIES.slice(0, 9).map(c => ({
        id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`,
        title: c
      })),
      { id: "sup_search_city_all", title: "📍 All Cities" }
    ]);
  }
}

 

// ── Group smart link list-reply tap handler (no-biz path) ──────────────────
// MUST be placed here - BEFORE the welcome-screen gate - so no-biz visitors
// who tap a seller row or the "List Your Business" CTA from a group link
// are handled correctly instead of being sent to the Welcome screen.
// (allowedWithoutBiz includes zqg_ so the gate below is also bypassed,
// but this handler ensures an immediate response and return.)
if (a.startsWith("zqg_sel_") || a.startsWith("zqg_register_")) {
  const _zqgHandled = await handleGroupSellerTap({ from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_zqgHandled) return;
}

 if (!supplierExists && al !== "join" && !allowedWithoutBiz && !hasActiveBuyerFlow) {
  // Delegate to sendMainMenu which handles all cases correctly (new user, staff, supplier, etc.)
  return sendMainMenu(from);
}



}

// ── School Application text-reply early intercept ────────────────────────────
// CRITICAL FIX: parents mid-application (awaiting_student_name, awaiting_grade,
// awaiting_dob, awaiting_parent_name, awaiting_parent_phone) must NEVER reach
// the supplier shortcode search guards. Those guards check biz.sessionState
// only - they are blind to schoolApplyState in UserSession.tempData.
// This block runs AFTER if(!biz) so it covers BIZ users (the failing case).
// No-biz users: they return from inside if(!biz) so they never reach here,
// but their path is safe because they exit above before shortcode search.
if (!isMetaAction) {
  const _saEarlySess = await UserSession.findOne({ phone }).lean();
  const _saEarlyState = _saEarlySess?.tempData?.schoolApplyState;
  if (_saEarlyState && _saEarlyState !== "awaiting_start") {
    const _saEarlyId = _saEarlySess.tempData.schoolApplyId;
    let _saEarlyData = {};
    try { _saEarlyData = JSON.parse(_saEarlySess.tempData.schoolApplyData || "{}"); } catch (_) {}

    const _saEarlyUpd = async (nextState, extra = {}) => {
      _saEarlyData = { ..._saEarlyData, ...extra };
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { "tempData.schoolApplyState": nextState, "tempData.schoolApplyData": JSON.stringify(_saEarlyData) } },
        { upsert: true }
      );
    };

    if (_saEarlyState === "awaiting_student_name") {
      const _saEarlyName = text.trim();
      await _saEarlyUpd("awaiting_grade", { studentName: _saEarlyName });
      const _saEarlyGrades = _saEarlyData.gradeOptions || [];
      if (_saEarlyGrades.length > 0 && _saEarlyGrades.length <= 10) {
        const _saEarlyRows = _saEarlyGrades.map(g => ({ id: `sa_grade_${g.replace(/\s+/g,"_")}`, title: g.slice(0,24) }));
        await sendList(from, `\u2705 *${_saEarlyName}*\n\n*Step 2 of 5*\nSelect the *grade or form* applying for:`, _saEarlyRows);
      } else {
        await sendText(from, `\u2705 *${_saEarlyName}*\n\n*Step 2 of 5*\nWhat *grade or form* are they applying for?\n_e.g. Form 1, Grade 7, ECD A_`);
      }
      return;
    }

    if (_saEarlyState === "awaiting_grade") {
      const _saEarlyGrade = a.startsWith("sa_grade_")
        ? a.replace(/^sa_grade_/,"").replace(/_/g," ").trim()
        : text.trim();
      await _saEarlyUpd("awaiting_dob", { grade: _saEarlyGrade });
      await sendText(from, `\u2705 *${_saEarlyGrade}*\n\n*Step 3 of 5*\nWhat is the *student's date of birth?*\n_e.g. 15 March 2014 or 15/03/2014_`);
      return;
    }

    if (_saEarlyState === "awaiting_dob") {
      await _saEarlyUpd("awaiting_parent_name", { dob: text.trim() });
      await sendText(from, `\u2705 *${text.trim()}*\n\n*Step 4 of 5*\nWhat is the *parent or guardian's full name?*\n_The name the school should use when contacting you_`);
      return;
    }

    if (_saEarlyState === "awaiting_parent_name") {
      await _saEarlyUpd("awaiting_parent_phone", { parentName: text.trim() });
      await sendText(from, `\u2705 *${text.trim()}*\n\n*Step 5 of 5*\nWhat is your *WhatsApp / contact number?*\n_The school will call or message you on this number. You can also just type "same" to use this number._`);
      return;
    }

    if (_saEarlyState === "awaiting_parent_phone") {
      const _rawP = text.trim().toLowerCase();
      _saEarlyData.parentPhone = (_rawP === "same" || _rawP === "this")
        ? (from.startsWith("263") ? "0"+from.slice(3) : from) : _rawP;
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolApplyState": "", "tempData.schoolApplyId": "", "tempData.schoolApplyData": "" } },
        { upsert: true }
      );
      const _parentContact = _saEarlyData.parentPhone || (from.startsWith("263") ? "0"+from.slice(3) : from);
      await sendButtons(from, {
        text:
          `\ud83d\udcdd *Application Submitted \u2014 ${_saEarlyData.schoolName || "School"}*\n\n` +
          `\ud83d\udc64 Student: *${_saEarlyData.studentName || "\u2014"}*\n` +
          `\ud83d\udcda Grade: *${_saEarlyData.grade || "\u2014"}*\n` +
          `\ud83c\udf82 Date of Birth: *${_saEarlyData.dob || "\u2014"}*\n` +
          `\ud83d\udc6a Parent/Guardian: *${_saEarlyData.parentName || "\u2014"}*\n` +
          `\ud83d\udcde Contact: *${_parentContact}*\n\n` +
          `\u2705 *Application received!*\n` +
          `The school will contact you on *${_parentContact}* shortly.\n\n` +
          `_Keep WhatsApp open \u2014 the school may message you here too._`,
        buttons: [
          { id: `sfaq_enquiry_${_saEarlyId}`,      title: "\u2753 Ask a Question" },
          { id: `sfaq_back_${_saEarlyId}`,          title: "\ud83c\udfeb School Profile" }
        ]
      });
      try {
        const { captureSchoolContact, emailApplicationToSchool } = await import("./schoolApplicationForm.js");
        await captureSchoolContact({
          schoolId: _saEarlyId, phone, source: "apply",
          extraData: { studentName: _saEarlyData.studentName, parentName: _saEarlyData.parentName,
            gradeInterest: _saEarlyData.grade, converted: true, appliedAt: new Date(), applicationData: _saEarlyData }
        });
        const _saEarlySchool = _saEarlyId ? await SchoolProfile.findById(_saEarlyId).lean() : null;
        if (_saEarlySchool) {
          await emailApplicationToSchool({ school: _saEarlySchool, data: _saEarlyData, applicantPhone: from });
          if (_saEarlySchool.applicationForm?.notifyPhone) {
            try {
              const { sendButtons: _eSb } = await import("./metaSender.js");
              const _eNP   = String(_saEarlySchool.applicationForm.notifyPhone).replace(/\D/g,"");
              const _eNorm = _eNP.startsWith("0") ? "263"+_eNP.slice(1) : _eNP;
              const _eTime = new Date().toLocaleString("en-GB",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit",timeZone:"Africa/Harare"});
              await _eSb(_eNorm, {
                text:
                  `\u2705 *New WhatsApp Application \u2014 ${_saEarlySchool.schoolName}*\n\n` +
                  `\ud83d\udc64 *${_saEarlyData.studentName || "\u2014"}*  |  \ud83d\udcda ${_saEarlyData.grade || "\u2014"}\n` +
                  `\ud83d\udc6a Parent: *${_saEarlyData.parentName || "\u2014"}*\n` +
                  `\ud83d\udcde *${_parentContact}*\n` +
                  `\u23f0 ${_eTime}\n\n` +
                  `_Full details sent to your email. Call the parent to confirm._`,
                buttons: [{ id: "school_my_profile", title: "\ud83c\udfeb My School" }]
              });
            } catch (_eErr) { console.warn("[SCHOOL WA NOTIFY BIZ]", _eErr.message); }
          }
        }
      } catch (_eFinal) { console.warn("[SCHOOL APPLY BIZ FINAL]", _eFinal.message); }
      return;
    }
  }
}

if (a === "sup_save_search_current") {
  const sess = await UserSession.findOne({ phone });
  const ctx = sess?.tempData?.currentSearchContext || {};

  const saved = await _saveCurrentSearchForBuyer({
    phone,
    biz,
    fallback: ctx
  });

  return sendButtons(from, {
    text:
      `✅ Search saved.\n\n` +
      `🔎 ${saved.product || "Search"}\n` +
      `${saved.area ? `📍 ${saved.area}${saved.city ? `, ${saved.city}` : ""}\n` : saved.city ? `📍 ${saved.city}\n` : ""}` +
      `You can search again anytime.`,
    buttons: [
      { id: "find_supplier", title: "🔍 Search Again" },
      { id: "suppliers_home", title: "🛒 Marketplace" }
    ]
  });
}




if (a === "sup_request_quote_search") {
  const sess = await UserSession.findOne({ phone });
  const ctx = sess?.tempData?.currentSearchContext || {};
  const results = sess?.tempData?.searchResults || [];

  if (!results.length) {
    return sendButtons(from, {
      text: "❌ Search session expired. Please search again.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  const uniqueSupplierIds = [
    ...new Set(
      results
        .map(r => String(r?.supplierId || r?._id || r?.supplier?._id || ""))
        .filter(Boolean)
    )
  ].slice(0, 5);

  const suppliers = await SupplierProfile.find({
    _id: { $in: uniqueSupplierIds }
  }).lean();

  if (!suppliers.length) {
    return sendButtons(from, {
      text: "❌ No suppliers available for quote request right now.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  // ── Shared helper: send quote request notification with template fallback ──
  async function _sendQuoteNotification(supplierPhone, supplierProfile, item, buyerPhone, ctx) {
    const normalizedPhone = String(supplierPhone).replace(/\D+/, "");
    const fullPhone = normalizedPhone.startsWith("0") && normalizedPhone.length === 10
      ? "263" + normalizedPhone.slice(1) : normalizedPhone;

    const isService = supplierProfile?.profileType === "service";
    const label     = item || ctx.product || "your request";
    const cityText  = ctx.city || supplierProfile?.location?.city || "Zimbabwe";
    const areaText  = ctx.area ? `${ctx.area}, ${cityText}` : cityText;

    // ── Set session state so seller's price reply is handled correctly ──────────
    const _normPhoneKey = fullPhone.replace(/\D+/g, "");
    await UserSession.findOneAndUpdate(
      { phone: _normPhoneKey },
      {
        $set: {
          "tempData.pendingQuoteReply":      "true",
          "tempData.pendingQuoteItem":       label,
          "tempData.pendingQuoteBuyerPhone": buyerPhone,
          "tempData.pendingQuoteCity":       ctx.city || "",
          "tempData.pendingQuoteArea":       ctx.area || ""
        }
      },
      { upsert: true }
    );

    const interactiveBody = {
      text:
        `📋 *New Quote Request*\n\n` +
        `${isService ? "🔧 Service" : "🔎 Item"}: *${label}*\n` +
        `${ctx.area ? `📍 Area: ${ctx.area}\n` : ""}` +
        `${ctx.city ? `🏙 City: ${ctx.city}\n` : ""}` +
        `📞 Buyer: ${buyerPhone}\n\n` +
        `─────────────────\n` +
        `💰 *Reply with your price to send the buyer a quote.*\n\n` +
        `*Examples:*\n` +
        `• *25* - flat price\n` +
        `• *25/hour* or *25/job* - rate\n` +
        `• *From 50, depends on scope* - range\n\n` +
        `Or type a full message e.g: _250 includes labour and materials_\n\n` +
        `Type *cancel* to ignore this request.`,
      buttons: [
        { id: "my_supplier_account", title: "🏪 My Store"   },
        { id: "suppliers_home",      title: "🛒 Marketplace" }
      ]
    };

    // ── Try interactive first (works within 24-hour session) ──────────────────
    try {
      await sendButtons(fullPhone, interactiveBody);
      return;
    } catch (btnErr) {
      console.warn(`[QUOTE NOTIFY] sendButtons failed for ${fullPhone}: ${btnErr.message} - trying template`);
    }

    // ── Outside 24-hour window - use approved Meta template ───────────────────
    // Reuses supplier_new_buyer_request template (already approved & active).
    // Template body:
    //   New buyer request on ZimQuote!
    //   Ref: {{1}} | Location: {{2}} | Items: {{3}} | {{4}}
    try {
      const _axios = (await import("axios")).default;
      const _PHONE_ID    = process.env.WHATSAPP_PHONE_NUMBER_ID || process.env.META_PHONE_NUMBER_ID || process.env.PHONE_NUMBER_ID;
      const _TOKEN       = process.env.META_ACCESS_TOKEN || process.env.WHATSAPP_ACCESS_TOKEN;
      const _quoteRef    = `QR-${Date.now().toString(36).toUpperCase().slice(-5)}`;

      await _axios.post(
        `https://graph.facebook.com/v24.0/${_PHONE_ID}/messages`,
        {
          messaging_product: "whatsapp",
          to:   fullPhone,
          type: "template",
          template: {
            name:     "supplier_new_buyer_request",
            language: { code: "en" },
            components: [{
              type: "body",
              parameters: [
                { type: "text", text: _quoteRef },
                { type: "text", text: areaText  },
                { type: "text", text: `Quote requested: ${label}` },
                { type: "text", text: "Buyer wants your price" }
              ]
            }]
          }
        },
        { headers: { Authorization: `Bearer ${_TOKEN}`, "Content-Type": "application/json" } }
      );
      console.log(`[QUOTE NOTIFY] Template sent to ${fullPhone} (${_quoteRef})`);

      // After template opens session, send full interactive details after 2s
      await new Promise(r => setTimeout(r, 2000));
      await sendButtons(fullPhone, interactiveBody);
    } catch (tplErr) {
      console.error(`[QUOTE NOTIFY] Template also failed for ${fullPhone}: ${tplErr.message}`);
    }
  }

  for (const supplier of suppliers) {
    try {
      await _sendQuoteNotification(supplier.phone, supplier, ctx.product, from, ctx);
    } catch (err) {
      console.error("[QUOTE REQUEST SEARCH NOTIFY]", err.message);
    }
  }

  return sendButtons(from, {
    text:
      `✅ Quote request sent to matching suppliers for *${ctx.product || "your search"}*.\n\n` +
      `Suppliers can now respond to you directly.`,
    buttons: [
      { id: "my_orders", title: "📋 My Orders" },
      { id: "find_supplier", title: "🔍 Search Again" }
    ]
  });
}




if (a.startsWith("sup_request_quote_supplier_")) {
  const raw = a.replace("sup_request_quote_supplier_", "");
  const parts = raw.split("_");
  const supplierId = parts.shift();
  const productName = parts.length ? decodeURIComponent(parts.join("_")) : null;

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const ctx = sess?.tempData?.currentSearchContext || {};
  const requestedItem =
    productName ||
    ctx.product ||
    sess?.tempData?.supplierSearchProduct ||
    "item/service";

  // ── Notify supplier with template fallback (reaches outside 24-hour window) ──
  try {
    const _normPhone2  = String(supplier.phone).replace(/\D+/g, "");
    const _fullPhone2  = _normPhone2.startsWith("0") && _normPhone2.length === 10
      ? "263" + _normPhone2.slice(1) : _normPhone2;
    const _isService2  = supplier?.profileType === "service";
    const _cityText2   = ctx.city || supplier?.location?.city || "Zimbabwe";
    const _areaText2   = ctx.area ? `${ctx.area}, ${_cityText2}` : _cityText2;

    // ── Set session state so seller's price reply is handled correctly ──────────
    const _normPhone2Key = _fullPhone2.replace(/\D+/g, "");
    await UserSession.findOneAndUpdate(
      { phone: _normPhone2Key },
      {
        $set: {
          "tempData.pendingQuoteReply":      "true",
          "tempData.pendingQuoteItem":       requestedItem,
          "tempData.pendingQuoteBuyerPhone": from,
          "tempData.pendingQuoteCity":       ctx.city || "",
          "tempData.pendingQuoteArea":       ctx.area || ""
        }
      },
      { upsert: true }
    );

    const _interactiveBody2 = {
      text:
        `📋 *New Quote Request*\n\n` +
        `🏪 A buyer selected your business\n` +
        `${_isService2 ? "🔧 Service" : "🔎 Item"}: *${requestedItem}*\n` +
        `${ctx.area ? `📍 Area: ${ctx.area}\n` : ""}` +
        `${ctx.city ? `🏙 City: ${ctx.city}\n` : ""}` +
        `📞 Buyer: ${from}\n\n` +
        `─────────────────\n` +
        `💰 *Reply with your price to send the buyer a quote.*\n\n` +
        `*Examples:*\n` +
        `• *25* - flat price\n` +
        `• *25/hour* or *25/job* - rate\n` +
        `• *From 50, depends on scope* - range\n\n` +
        `Or type a full message e.g: _250 includes labour and materials_\n\n` +
        `Type *cancel* to ignore this request.`,
      buttons: [
        { id: "my_supplier_account", title: "🏪 My Store"   },
        { id: "suppliers_home",      title: "🛒 Marketplace" }
      ]
    };

    // Try interactive first (within 24hr session)
    let _sentInteractive = false;
    try {
      await sendButtons(_fullPhone2, _interactiveBody2);
      _sentInteractive = true;
    } catch (btnErr) {
      console.warn(`[QUOTE NOTIFY SINGLE] sendButtons failed for ${_fullPhone2}: ${btnErr.message} - trying template`);
    }

    // Outside 24-hour window - send approved Meta template to open session
    if (!_sentInteractive) {
      try {
        const _axios2    = (await import("axios")).default;
        const _PHONE_ID2 = process.env.WHATSAPP_PHONE_NUMBER_ID || process.env.META_PHONE_NUMBER_ID || process.env.PHONE_NUMBER_ID;
        const _TOKEN2    = process.env.META_ACCESS_TOKEN || process.env.WHATSAPP_ACCESS_TOKEN;
        const _qRef2     = `QR-${Date.now().toString(36).toUpperCase().slice(-5)}`;

        await _axios2.post(
          `https://graph.facebook.com/v24.0/${_PHONE_ID2}/messages`,
          {
            messaging_product: "whatsapp",
            to:   _fullPhone2,
            type: "template",
            template: {
              name:     "supplier_new_buyer_request",
              language: { code: "en" },
              components: [{
                type: "body",
                parameters: [
                  { type: "text", text: _qRef2 },
                  { type: "text", text: _areaText2 },
                  { type: "text", text: `Quote requested: ${requestedItem}` },
                  { type: "text", text: "Buyer wants your price" }
                ]
              }]
            }
          },
          { headers: { Authorization: `Bearer ${_TOKEN2}`, "Content-Type": "application/json" } }
        );
        console.log(`[QUOTE NOTIFY SINGLE] Template sent to ${_fullPhone2} (${_qRef2})`);

        // Template opens the session - send full interactive details after 2s
        await new Promise(r => setTimeout(r, 2000));
        await sendButtons(_fullPhone2, _interactiveBody2);
      } catch (tplErr) {
        console.error(`[QUOTE NOTIFY SINGLE] Template also failed for ${_fullPhone2}: ${tplErr.message}`);
      }
    }
  } catch (err) {
    console.error("[QUOTE REQUEST SINGLE SUPPLIER]", err.message);
  }

  return sendButtons(from, {
    text:
      `✅ Quote request sent to *${supplier.businessName}* for *${requestedItem}*.`,
    buttons: [
      { id: `sup_view_${supplier._id}`, title: "🏪 View Supplier" },
      { id: "find_supplier", title: "🔍 Search Again" }
    ]
  });
}




if (a.startsWith("sup_ask_availability_")) {
  const raw = a.replace("sup_ask_availability_", "");
  const parts = raw.split("_");
  const supplierId = parts.shift();
  const productName = parts.length ? decodeURIComponent(parts.join("_")) : null;

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const ctx = sess?.tempData?.currentSearchContext || {};
  const requestedItem =
    productName ||
    ctx.product ||
    sess?.tempData?.supplierSearchProduct ||
    "item/service";

  // ── Notify supplier with template fallback (reaches outside 24-hour window) ──
  try {
    const _normPhoneAv  = String(supplier.phone).replace(/\D+/g, "");
    const _fullPhoneAv  = _normPhoneAv.startsWith("0") && _normPhoneAv.length === 10
      ? "263" + _normPhoneAv.slice(1) : _normPhoneAv;
    const _isServiceAv  = supplier?.profileType === "service";
    const _cityTextAv   = ctx.city || supplier?.location?.city || "Zimbabwe";
    const _areaTextAv   = ctx.area ? `${ctx.area}, ${_cityTextAv}` : _cityTextAv;

    const _avBody = {
      text:
        `❓ *Buyer Availability Check*\n\n` +
        `${_isServiceAv ? "🔧 Service" : "🔎 Item"}: *${requestedItem}*\n` +
        `${ctx.area ? `📍 Area: ${ctx.area}\n` : ""}` +
        `${ctx.city ? `🏙 City: ${ctx.city}\n` : ""}` +
        `📞 Buyer: ${from}\n\n` +
        `${_isServiceAv
          ? "Buyer wants to know if you are available. Reply to confirm."
          : "Buyer wants to know if this is in stock. Reply to confirm."}`,
      buttons: [
        { id: "my_supplier_account", title: "🏪 My Store"   },
        { id: "suppliers_home",      title: "🛒 Marketplace" }
      ]
    };

    let _avSent = false;
    try {
      await sendButtons(_fullPhoneAv, _avBody);
      _avSent = true;
    } catch (btnErr) {
      console.warn(`[AVAIL NOTIFY] sendButtons failed for ${_fullPhoneAv}: ${btnErr.message} - trying template`);
    }

    if (!_avSent) {
      try {
        const _axiosAv   = (await import("axios")).default;
        const _PHONE_IDAv = process.env.WHATSAPP_PHONE_NUMBER_ID || process.env.META_PHONE_NUMBER_ID || process.env.PHONE_NUMBER_ID;
        const _TOKENAv    = process.env.META_ACCESS_TOKEN || process.env.WHATSAPP_ACCESS_TOKEN;
        const _avRef      = `AV-${Date.now().toString(36).toUpperCase().slice(-5)}`;

        await _axiosAv.post(
          `https://graph.facebook.com/v24.0/${_PHONE_IDAv}/messages`,
          {
            messaging_product: "whatsapp",
            to:   _fullPhoneAv,
            type: "template",
            template: {
              name:     "supplier_new_buyer_request",
              language: { code: "en" },
              components: [{
                type: "body",
                parameters: [
                  { type: "text", text: _avRef },
                  { type: "text", text: _areaTextAv },
                  { type: "text", text: `Availability check: ${requestedItem}` },
                  { type: "text", text: _isServiceAv ? "Are you available?" : "Is this in stock?" }
                ]
              }]
            }
          },
          { headers: { Authorization: `Bearer ${_TOKENAv}`, "Content-Type": "application/json" } }
        );
        console.log(`[AVAIL NOTIFY] Template sent to ${_fullPhoneAv} (${_avRef})`);
        await new Promise(r => setTimeout(r, 2000));
        await sendButtons(_fullPhoneAv, _avBody);
      } catch (tplErr) {
        console.error(`[AVAIL NOTIFY] Template also failed for ${_fullPhoneAv}: ${tplErr.message}`);
      }
    }
  } catch (err) {
    console.error("[ASK AVAILABILITY]", err.message);
  }

  return sendButtons(from, {
    text:
      `✅ Your availability request was sent to *${supplier.businessName}*.`,
    buttons: [
      { id: `sup_view_${supplier._id}`, title: "🏪 View Supplier" },
      { id: "find_supplier", title: "🔍 Search Again" }
    ]
  });
}




// =========================
// 📦 NO-BIZ SUPPLIER REGISTRATION PRICE FLOW
// =========================
if ((!biz || isGhostSupplierBiz) && !isMetaAction) {
  const sess = await UserSession.findOne({ phone });
  const regState = sess?.supplierRegState;
  const reg = sess?.supplierRegData || {};

  if (regState === "supplier_reg_prices") {
    const raw = (text || "").trim();
    const isService = reg.profileType === "service";
    const products = (reg.products || []).filter(p => p !== "pending_upload");

    if (!raw) {
      await sendText(from, "❌ Please send your prices or rates, or tap Skip.");
      return true;
    }

    if (!products.length) {
      await sendText(from, "❌ No products/services found in registration. Please go back and add them first.");
      return true;
    }

    const { updated, failed } = parseSupplierPriceInput(raw, products, isService);

    if (!updated.length) {
      const numbered = products.map((p, i) => `${i + 1}. ${p}`).join("\n");

   await sendText(from,
`❌ Couldn't read your ${isService ? "rates" : "prices"}.

*Your items:*
${numbered}

─────────────────
*Fastest way: update by item number*

*Single item:*
_${isService ? "1x20/job" : "1x5.50"}_
_${isService ? "1 x 20/job" : "1 x 5.50"}_

*Same ${isService ? "rate" : "price"} for selected items:*
_${isService ? "1,3,5x20/job" : "1,3,5x5.50"}_
_${isService ? "1,3,5 x 20/job" : "1,3,5 x 5.50"}_

*Same ${isService ? "rate" : "price"} for a range:*
_${isService ? "1-4x15/hr" : "1-4x5.50"}_
_${isService ? "1-4 x 15/hr" : "1-4 x 5.50"}_

*Mixed updates:*
_${isService ? "1x20/job,2x15/trip,3x10/hr" : "1x5.50,2x8.00,3x12.00"}_
_${isService ? "1 x 20/job, 2 x 15/trip, 3 x 10/hr" : "1 x 5.50, 2 x 8.00, 3 x 12.00"}_

*Other options still work:*

*Update ALL in order:*
_${products.slice(0, 3).map((_, i) => (((i + 1) * 4)).toFixed(2)).join(", ")}_

*Update selected items by name:*
_${products.slice(0, 2).map(p => `${p}: ${isService ? "20/job" : "6.00"}`).join(", ")}_

Type *skip* to add them later.`
);
      return true;
    }

    const previewLines = updated
      .map(u => `• ${u.product} - $${Number(u.amount).toFixed(2)}/${u.unit}`)
      .join("\n");

    const failNote = failed.length
      ? `\n\n⚠️ Skipped ${failed.length}: _${failed.slice(0, 2).join(", ")}_`
      : "";

    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "supplierRegData.pendingPriceUpdate": updated
        }
      },
      { upsert: true }
    );

    return sendButtons(from, {
      text:
`💰 *${isService ? "Rate" : "Price"} Preview* (${updated.length} items)

${previewLines}${failNote}

Save these ${isService ? "rates" : "prices"}?`,
      buttons: [
        { id: "sup_price_update_confirm", title: "✅ Save" },
        { id: "sup_skip_prices", title: "⏭ Skip For Now" }
      ]
    });
  }
}


// =========================
// 🏪 NO-BIZ SUPPLIER ACCOUNT PRICE UPDATE FLOW
// =========================
if ((!biz || isGhostSupplierBiz) && !isMetaAction) {
  const sess = await UserSession.findOne({ phone });
  const accountState = sess?.tempData?.supplierAccountState;

  if (accountState === "supplier_update_prices") {
    const supplier = await SupplierProfile.findOne({ phone });
    if (!supplier) {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.supplierAccountState": "", "tempData.pendingPriceUpdate": "" } }
      );
      return sendSuppliersMenu(from);
    }

    const raw = (text || "").trim();
    const isService = supplier.profileType === "service";
    const products = (supplier.products || []).filter(p => p !== "pending_upload");

    if (!raw) {
      await sendText(from, `❌ Please send your ${isService ? "rates" : "prices"}, or type *cancel*.`);
      return true;
    }

    if (al === "cancel") {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.supplierAccountState": "", "tempData.pendingPriceUpdate": "", "tempData.supplierAccountType": "" } }
      );
      return sendSupplierAccountMenu(from, supplier);
    }

    if (!products.length) {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.supplierAccountState": "", "tempData.pendingPriceUpdate": "", "tempData.supplierAccountType": "" } }
      );
      return sendButtons(from, {
        text: `❌ No ${isService ? "services" : "products"} found. Add items first.`,
        buttons: [{ id: "sup_edit_products", title: "✏️ Manage Items" }]
      });
    }

    const { updated, failed } = parseSupplierPriceInput(raw, products, isService);

    if (!updated.length) {
      await sendSupplierItemsInChunks(
        from,
        products,
        `💰 Update ${isService ? "Rates" : "Prices"}`
      );
      await sendSupplierQuickPriceHelp(from, products, isService);

      return sendButtons(from, {
        text: `❌ Couldn't read your ${isService ? "rates" : "prices"}.\n\nTry again or go back to your account.`,
        buttons: [{ id: "my_supplier_account", title: "🏪 My Account" }]
      });
    }

    const previewLines = updated
      .map(u => `• ${u.product} - $${Number(u.amount).toFixed(2)}/${u.unit}`)
      .join("\n");

    const failNote = failed.length
      ? `\n\n⚠️ Skipped ${failed.length}: _${failed.slice(0, 2).join(", ")}_`
      : "";

    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.pendingPriceUpdate": updated
        }
      },
      { upsert: true }
    );

    return sendButtons(from, {
      text:
`💰 *${isService ? "Rate" : "Price"} Preview* (${updated.length} items)

${previewLines}${failNote}

Save these ${isService ? "rates" : "prices"}?`,
      buttons: [
        { id: "sup_price_update_confirm", title: "✅ Save" },
        { id: "my_supplier_account", title: "🏪 My Account" }
      ]
    });
  }
}

if (!isMetaAction) {
  const sess = await UserSession.findOne({ phone });
  const browseMode =
    biz?.sessionData?.orderBrowseMode ??
    sess?.tempData?.orderBrowseMode;

  const supplierId =
    biz?.sessionData?.orderSupplierId ??
    sess?.tempData?.orderSupplierId;

  if (browseMode === "catalogue_search" && supplierId) {
    const supplier = await SupplierProfile.findById(supplierId).lean();
    if (!supplier) return sendSuppliersMenu(from);

    const searchTerm = text.trim();
    const cart = await getCurrentOrderCart({ biz, phone });

    if (!searchTerm) {
      return sendText(from, "❌ Type a product name to search.");
    }

    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderBrowseMode: "catalogue",
        orderCatalogueSearch: searchTerm,
        orderCataloguePage: 0
      }
    });

    return _sendSupplierCatalogueBrowser(from, supplier, cart, {
      page: 0,
      searchTerm
    });
  }
}
  // =========================
  // 🛒 BUYER ORDER FLOW (no-biz users via UserSession)
  // =========================
  if (!biz && !isMetaAction) {
    const sess = await UserSession.findOne({ phone });
    const orderState = sess?.tempData?.orderState;

    if (
  al === "cancel" &&
  (orderState === "supplier_order_product" || orderState === "supplier_order_address")
) {
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.orderState": "",
        "tempData.orderSupplierId": "",
        "tempData.orderItems": "",
        "tempData.orderProduct": "",
        "tempData.orderQuantity": ""
      }
    }
  );

await sendText(from, "❌ Order cancelled.");
return sendButtons(from, {
  text: "What would you like to do next?",
  buttons: [
    { id: "find_supplier", title: "🔍 Browse & Shop" },
    { id: "my_orders", title: "📋 My Orders" },
    
  ]
});
}



if (orderState === "supplier_order_product") {
  const parsedItems = parseBulkOrderInput(text);

  if (!parsedItems.length || parsedItems.every(i => !i.valid)) {
  return sendText(from,
`❌ Please enter your order in this format:

*product qty, product qty*

Examples:
*sugar 2, bread 3, milk 1*
*cement 10, river sand 2*

You can also send one per line.

Type *cancel* to stop this order.`);
  }

  // Fetch supplier to check if delivery is required
  const _sess2 = await UserSession.findOne({ phone });
  const _sid2 = _sess2?.tempData?.orderSupplierId;
  const _sup2 = _sid2 ? await SupplierProfile.findById(_sid2).lean() : null;
  const isServiceSupplier = _sup2?.profileType === "service";
 const _needsAddress2 = (isServiceSupplier && _sup2?.travelAvailable) || (!isServiceSupplier && _sup2?.delivery?.available === true);

  const preview = parsedItems
    .map(i => `• ${i.product} x${i.quantity}${i.unitLabel && i.unitLabel !== "units" ? " " + i.unitLabel : ""}`)
    .join("\n");

  if (!_needsAddress2 && _sup2) {
    // Collection-only: submit the order immediately, no address needed
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: { "tempData.orderItems": parsedItems },
        $unset: { "tempData.orderProduct": "", "tempData.orderQuantity": "" }
      }
    );

    let totalAmount = 0; let pricedCount = 0;
    const finalItems = parsedItems.filter(i => i.valid).map(entry => {
      const quantity = Number(entry.quantity) || 1;
      const matchedPrice = findMatchingSupplierPrice(_sup2, entry.product);
      let pricePerUnit = null, total = null, finalUnit = entry.unitLabel || "units";
      if (matchedPrice && typeof matchedPrice.amount === "number") {
        pricePerUnit = matchedPrice.amount;
        total = quantity * matchedPrice.amount;
        finalUnit = matchedPrice.unit || finalUnit;
        totalAmount += total; pricedCount++;
      }
      return { product: entry.product, quantity, unit: finalUnit, pricePerUnit, currency: "USD", total };
    });

    const order = await SupplierOrder.create({
      supplierId: _sup2._id, supplierPhone: _sup2.phone,
      buyerPhone: phone, items: finalItems, totalAmount, currency: "USD",
      delivery: { required: false, address: "Collection" }, status: "pending"
    });
    await notifySupplierNewOrder(_sup2.phone, order);

    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderItems": "", "tempData.orderProduct": "", "tempData.orderQuantity": "" } }
    );

    const itemSummary = finalItems.map(i => `• ${i.product} x${i.quantity}`).join("\n");
    await sendText(from,
`✅ *Order sent to ${_sup2.businessName}!*

${itemSummary}
🏠 *Collection only* - contact the supplier to arrange pickup
${pricedCount > 0 ? `💵 Estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Supplier: ${_sup2.phone}

${pricedCount === finalItems.length ? "All items were auto-priced. Supplier can confirm immediately. 🎉" : "Supplier will confirm pricing shortly. 🎉"}`);
    return sendButtons(from, {
      text: "What would you like to do next?",
      buttons: [
        { id: "find_supplier", title: "🔍 Browse & Shop" },
        { id: "my_orders", title: "📋 My Orders" },
        
      ]
    });
  }

  // Delivery/service supplier: ask for address
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.orderItems": parsedItems,
        "tempData.orderState": "supplier_order_address"
      },
      $unset: {
        "tempData.orderProduct": "",
        "tempData.orderQuantity": ""
      }
    }
  );

return sendText(from,
`${isServiceSupplier ? "📅" : "🛒"} *${isServiceSupplier ? "Booking Summary" : "Order Summary"}*

${preview}

*Now enter your ${isServiceSupplier ? "location or contact note" : "delivery address"}:*

${isServiceSupplier
  ? "Examples:\n• *House number 24, Mabelreign*\n• *Come tomorrow 10am*\n• *Call me when you arrive*"
  : "Examples:\n• *123 Samora Machel Ave, Harare*\n• *Deliver to Avondale after 4pm*\n• *Call me when you get here*"
}

Type *cancel* to stop this ${isServiceSupplier ? "booking" : "order"}.`);
}

   

if (orderState === "supplier_order_address") {
  const address = text.trim();
if (!address || address.length < 2) {
  return sendText(from,
`❌ Please enter your delivery address or contact note:

Type *cancel* to stop this order.`);
}

  const sess3 = await UserSession.findOne({ phone });
  const supplierId = sess3?.tempData?.orderSupplierId;
 const orderItemsInput = sess3?.tempData?.orderCart?.length
  ? sess3.tempData.orderCart
  : (sess3?.tempData?.orderItems || []);

if (!supplierId) {
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $unset: {
        "tempData.orderState": "",
        "tempData.orderSupplierId": "",
        "tempData.orderItems": "",
        "tempData.orderProduct": "",
        "tempData.orderQuantity": ""
      }
    }
  );
  await sendText(from, "❌ Order session expired. Please search for the supplier again.");
  //return sendSuppliersMenu(from);

return sendButtons(from, {
  text: "What would you like to do next?",
  buttons: [
    { id: "find_supplier", title: "🔍 Browse & Shop" },
    { id: "register_supplier", title: "📦 Become a Supplier" },
    
  ]
});

}



  const supplier = await SupplierProfile.findById(supplierId).lean();

  if (!supplier) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $unset: {
          "tempData.orderState": "",
          "tempData.orderSupplierId": "",
          "tempData.orderItems": "",
          "tempData.orderProduct": "",
          "tempData.orderQuantity": ""
        }
      }
    );
    await sendText(from, "❌ Supplier not found. Please search again.");
    return sendSuppliersMenu(from);
  }
 
 const normalizedItems = Array.isArray(orderItemsInput) ? orderItemsInput : [];
if (!normalizedItems.length) {
  await UserSession.findOneAndUpdate(
    { phone },
    { $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderItems": "" } }
  );
  await sendText(from, "❌ Order session expired. Please start again.");
  return sendSuppliersMenu(from);
}

let totalAmount = 0;
let pricedCount = 0;

const finalItems = normalizedItems.map(entry => {
  const quantity = Number(entry.quantity) || 1;
  const requestedUnit = entry.unitLabel || "units";
  const matchedPrice = findMatchingSupplierPrice(supplier, entry.product);

  let pricePerUnit = null;
  let total = null;
  let finalUnit = requestedUnit;

  if (matchedPrice && typeof matchedPrice.amount === "number") {
    pricePerUnit = matchedPrice.amount;
    total = quantity * matchedPrice.amount;
    finalUnit = matchedPrice.unit || requestedUnit;
    totalAmount += total;
    pricedCount++;
  }

  return {
    product: entry.product,
    quantity,
    unit: finalUnit,
    pricePerUnit,
    currency: "USD",
    total
  };
});

const order = await SupplierOrder.create({
  supplierId: supplier._id,
  supplierPhone: supplier.phone,
  buyerPhone: phone,
  items: finalItems,
  totalAmount,
  currency: "USD",
  delivery: {
    required: supplier.delivery?.available || false,
    address
  },
  status: "pending"
});

      await notifySupplierNewOrder(supplier.phone, order);

      // Clear order state from UserSession
    await UserSession.findOneAndUpdate(
  { phone },
  {
    $unset: {
      "tempData.orderState": "",
      "tempData.orderSupplierId": "",
      "tempData.orderItems": "",
      "tempData.orderProduct": "",
      "tempData.orderQuantity": ""
    }
  }
);

 const itemSummary = finalItems
  .map(i => `• ${i.product} x${i.quantity}${i.unit && i.unit !== "units" ? " " + i.unit : ""}`)
  .join("\n");

const isServiceSupplier = supplier.profileType === "service";

await sendText(from,
`✅ *${isServiceSupplier ? "Booking sent to" : "Order sent to"} ${supplier.businessName}!*

${itemSummary}
${supplier.delivery?.available
  ? `📍 ${address}`
  : isServiceSupplier
    ? `📍 Location/Note: ${address}`
    : `📝 Note: ${address}`}
${pricedCount > 0 ? `💵 Current estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Supplier: ${supplier.phone}

${pricedCount === finalItems.length
  ? `${isServiceSupplier ? "All services were auto-priced. Supplier can confirm immediately. 🎉" : "All items were auto-priced. Supplier can confirm immediately. 🎉"}`
  : pricedCount > 0
    ? `${isServiceSupplier ? "Some services were auto-priced. Supplier will confirm the rest. 🎉" : "Some items were auto-priced. Supplier will confirm the rest. 🎉"}`
    : `${isServiceSupplier ? "Supplier will confirm pricing for the booking shortly. 🎉" : "Supplier will confirm pricing shortly. 🎉"}`}`);
return sendButtons(from, {
  text: "What would you like to do next?",
  buttons: [
    { id: "find_supplier", title: "🔍 Browse & Shop" },
    { id: "register_supplier", title: "📦 Become a Supplier" },
    
  ]
});

    }
  }
  // =========================
  // 🔑 ROLE CHECK
  // =========================
  let callerRole = null;
  let caller = null;
  if (biz) {
    caller = await UserRole.findOne({ businessId: biz._id, phone, pending: false });
    callerRole = caller?.role || null;
  }

  // ── Block suspended or locked users ──────────────────────────────────────
  if (caller?.locked || caller?.suspended) {
    await sendText(from, "🔒 Your account has been suspended by an administrator. Please contact your business owner.");
    return;
  }

  // ─── META BUTTON / LIST ACTIONS ──────────────────────────────────────────

  if (al === "inv_use_client") {
    if (!biz) return sendMainMenu(from);
    return sendClientSelectList(from, biz);
  }

  if (al === "inv_skip_client") {
    await handleSkipClient(from);
    return;
  }

 if (a.startsWith("payinv_")) {
    if (!biz) return sendMainMenu(from);
    // Handle "Pay Full Balance" shortcut button: payinv_full_{id}
    const isFullPay = a.startsWith("payinv_full_");
    const invoiceId = isFullPay
      ? a.replace("payinv_full_", "")
      : a.replace("payinv_", "");

    const invoice = await Invoice.findById(invoiceId);
    if (!invoice) return sendText(from, "Invoice not found.");

    if (isFullPay) {
      // Skip amount entry - go straight to method
      biz.sessionState = "payment_method";
      biz.sessionData = { invoiceId: invoice._id, amount: invoice.balance };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text:
`💳 *${invoice.number}*
Paying full balance: *${formatMoney(invoice.balance, invoice.currency)}*

How was it paid?`,
        buttons: [
          { id: "pay_method_cash",    title: "💵 Cash" },
          { id: "pay_method_ecocash", title: "📱 EcoCash" },
          { id: "pay_method_bank",    title: "🏦 Bank" }
        ]
      });
    }

    // Normal flow - show balance and ask for amount with "Pay Full" shortcut
    biz.sessionState = "payment_amount";
    biz.sessionData = { invoiceId: invoice._id };
    await saveBizSafe(biz);

    return sendButtons(from, {
      text:
`💳 *${invoice.number}*
Total:   ${formatMoney(invoice.total, invoice.currency)}
Paid:    ${formatMoney(invoice.amountPaid, invoice.currency)}
Balance: *${formatMoney(invoice.balance, invoice.currency)}*

Type amount or tap Full:`,
      buttons: [
        { id: `payinv_full_${invoice._id}`, title: "✅ Pay Full Balance" },
        { id: ACTIONS.MAIN_MENU,            title: "❌ Cancel" }
      ]
    });
  }

  // ── Invoice confirm actions ────────────────────────────────────────────────

// ── Payment invoice list: prev / next / search ────────────────────────────
  if (a.startsWith("paylist_prev_") || a.startsWith("paylist_next_")) {
    if (!biz) return sendMainMenu(from);
    const raw       = a.replace("paylist_prev_", "").replace("paylist_next_", "");
    const parts     = raw.split("_");
    const branchRaw = parts[0] === "br0" ? null : parts[0];
    const curPage   = parseInt(parts[1]) || 0;
    const newPage   = a.startsWith("paylist_prev_") ? curPage - 1 : curPage + 1;
    await showUnpaidInvoices(from, branchRaw, Math.max(0, newPage));
    return;
  }

  if (a.startsWith("paylist_search_")) {
    if (!biz) return sendMainMenu(from);
    const branchRaw = a.replace("paylist_search_", "");
    biz.sessionState = "payment_invoice_search";
    biz.sessionData  = { invoiceSearchBranch: branchRaw === "br0" ? null : branchRaw };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "🔍 *Search Invoices*\n\nType invoice number:\n_e.g. INV-000005_",
      buttons: [{ id: ACTIONS.PAYMENTS_MENU, title: "❌ Cancel" }]
    });
  }

  // ── Doc search result - triggered after user types search term ────────────
  if (biz?.sessionState === "sales_doc_search_ready") {
    const docType    = biz.sessionData?.docSearchType   || "invoice";
    const branchRaw  = biz.sessionData?.docSearchBranch;
    const search     = biz.sessionData?.docSearchTerm   || null;
    const branch     = branchRaw === undefined ? undefined : (branchRaw || null);
    biz.sessionState = "ready"; biz.sessionData = {};
    await saveBizSafe(biz);
    return showSalesDocs(from, docType, branch, 0, search);
  }

  // ── Invoice confirm actions ────────────────────────────────────────────────




 if (a === "inv_generate_pdf") {
    if (!biz) return sendMainMenu(from);
    // Guard: any item still priced at 0 cannot produce a valid PDF total
    const zeroItems = (biz.sessionData.items || []).filter(i => Number(i.unit) === 0);
    if (zeroItems.length) {
      const names = zeroItems.map(i => `• ${i.item}`).join("\n");
      return sendButtons(from, {
        text:
          `⚠️ *${zeroItems.length} item${zeroItems.length === 1 ? "" : "s"} still need a price:*\n\n` +
          `${names}\n\nPlease set prices before generating the PDF.`,
        buttons: [
          { id: "inv_set_item_prices", title: "💰 Set prices" },
          { id: "inv_cancel",          title: "❌ Cancel"      }
        ]
      });
    }
    await continueTwilioFlow({ from, text: "2" });
    return;
  }
 

   if (a === "inv_set_item_prices") {
    if (!biz) return sendMainMenu(from);
    const unpricedIndexes = findUnpricedIndexes(biz.sessionData.items || []);
    if (!unpricedIndexes.length) {
      // All items now have prices - proceed directly to PDF
      await continueTwilioFlow({ from, text: "2" });
      return;
    }
    biz.sessionData.unpricedIndexes = unpricedIndexes;
    biz.sessionState = "creating_invoice_enter_catalogue_prices";
    await saveBizSafe(biz);
    const promptText = buildUnpricedPromptText(biz.sessionData.items, unpricedIndexes, biz.currency || "USD");
    return sendButtons(from, {
      text: promptText,
      buttons: [{ id: "inv_cancel", title: "❌ Cancel" }]
    });
  }
 
  // Skip price button from invoice_quick_add_product_price state
  if (a === "inv_skip_product_price") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_skip_product_price" });
    return;
  }
 
  // Skip price button from creating_invoice_enter_prices state
  if (a === "inv_skip_item_price") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_skip_item_price" });
    return;
  }
 
 

  if (a === "inv_set_discount") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "creating_invoice_set_discount";
    await saveBizSafe(biz);
    await sendButtons(from, { text: "💸 Enter discount percent (0-100):", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    return;
  }

  if (a === "inv_set_vat") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "creating_invoice_set_vat";
    await saveBizSafe(biz);
    await sendButtons(from, { text: "🧾 Enter VAT percent (0-100):", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    return;
  }

if (a === "inv_item_catalogue" || a.startsWith("inv_cat_page_")) {
    if (!biz) return sendMainMenu(from);

    const query = { businessId: biz._id, isActive: true };
    let branchFilter = null;
    if (caller && ["clerk", "manager"].includes(caller.role) && caller.branchId) {
      branchFilter = caller.branchId;
    } else if (caller?.role === "owner" && biz.sessionData?.targetBranchId) {
      branchFilter = biz.sessionData.targetBranchId;
    }
    if (branchFilter) {
      query.$or = [
        { branchId: branchFilter },
        { branchId: null },
        { branchId: { $exists: false } }
      ];
    }

    const dbProducts = await Product.find(query).sort({ name: 1 }).lean();

    // ── Pull supplier profile services/products and merge into catalogue ──────
    // Looks up the SupplierProfile linked to this business phone so that
    // a plumber can pick "geyser installation - $150" directly from their rates.
    let supplierItems = [];
    const _supplierProf = await SupplierProfile.findOne({ phone }).lean();
    if (_supplierProf) {
      const _isServiceProf = _supplierProf.profileType === "service";

      // 1. rates[] (service providers: has price already)
      for (const rate of (_supplierProf.rates || [])) {
        if (!rate.service) continue;
        // Parse price from rate string like "150/job" or "$80/hr" or "80"
        const _priceMatch = String(rate.rate || "").match(/[\d.]+/);
        const _price = _priceMatch ? parseFloat(_priceMatch[0]) : 0;
        // Avoid duplicating a Product already in catalogue
        const _alreadyIn = dbProducts.some(p => p.name.toLowerCase() === rate.service.toLowerCase());
        if (!_alreadyIn) {
          supplierItems.push({ _id: `sp_rate_${rate._id || rate.service}`, name: rate.service, unitPrice: _price, source: "profile" });
        }
      }

      // 2. listedProducts[] (split blob, no price)
      const _listedBlob = (_supplierProf.listedProducts || [])
        .flatMap(p => String(p || "").split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean));
      for (const lp of _listedBlob) {
        const _alreadyInDb = dbProducts.some(p => p.name.toLowerCase() === lp.toLowerCase());
        const _alreadyInRates = supplierItems.some(s => s.name.toLowerCase() === lp.toLowerCase());
        if (!_alreadyInDb && !_alreadyInRates) {
          supplierItems.push({ _id: `sp_listed_${lp}`, name: lp, unitPrice: 0, source: "profile" });
        }
      }
    }

    // Merged list: DB products first (they have prices), then supplier profile items
    const allProducts = [
      ...dbProducts.map(p => ({ _id: p._id.toString(), name: p.name, unitPrice: p.unitPrice, source: "db" })),
      ...supplierItems
    ];

    if (!allProducts.length) {
      biz.sessionState = "creating_invoice_add_items";
      biz.sessionData.itemMode = "choose_catalogue_or_custom";
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: "📦 No items in catalogue yet.\n\nWhat would you like to do?",
        buttons: [
          { id: "inv_add_new_product", title: "➕ Add new product" },
          { id: "inv_item_custom",     title: "✍️ Custom item" }
        ]
      });
    }

    const PAGE_SIZE = 20;
    const page = a.startsWith("inv_cat_page_") ? parseInt(a.replace("inv_cat_page_", ""), 10) || 0 : 0;
    const totalPages = Math.ceil(allProducts.length / PAGE_SIZE);
    const start = page * PAGE_SIZE;
    const visible = allProducts.slice(start, start + PAGE_SIZE);

    // Store full catalogue in session for quick-pick lookup by number
    biz.sessionState = "creating_invoice_pick_product";
    biz.sessionData.catalogueProducts = allProducts.map(p => ({
      _id: p._id,
      name: p.name,
      unitPrice: p.unitPrice,
      source: p.source || "db"
    }));
    biz.sessionData.cataloguePage = page;
    await saveBizSafe(biz);

    const hasSupplierItems = supplierItems.length > 0;
    const catalogueLabel = hasSupplierItems ? "📦 *Your Products & Services*" : "📦 *Product Catalogue*";

    // Build numbered text list
    const numbered = visible.map((p, i) => {
      const priceLabel = p.unitPrice > 0
        ? ` - ${formatMoney(p.unitPrice, biz.currency)}`
        : p.source === "profile" ? " - (enter price)" : "";
      return `${start + i + 1}. *${p.name}*${priceLabel}`;
    }).join("\n");

    await sendText(from,
`${catalogueLabel}
Page ${page + 1} of ${totalPages} · ${allProducts.length} item${allProducts.length === 1 ? "" : "s"}

${numbered}

─────────────────
*Quick-pick: type number × quantity*
_One item:_  3x2
_Multiple:_  3x2, 7x1, 12x5
_Add all prices automatically_`
    );

    // Navigation + action buttons
    const navBtns = [];
    if (page > 0)              navBtns.push({ id: `inv_cat_page_${page - 1}`, title: "⬅ Prev" });
    if (page < totalPages - 1) navBtns.push({ id: `inv_cat_page_${page + 1}`, title: "➡ Next" });
    navBtns.push({ id: "inv_item_custom", title: "✍️ Custom item" });

    return sendButtons(from, {
      text: "Pick items by number or tap an option:",
      buttons: navBtns.slice(0, 3)
    });
  }


if (a === "inv_item_catalogue" || a.startsWith("inv_cat_page_")) {
  if (!biz) return sendMainMenu(from);
 
  const query = { businessId: biz._id, isActive: true };
  let branchFilter = null;
  if (caller && ["clerk", "manager"].includes(caller.role) && caller.branchId) {
    branchFilter = caller.branchId;
  } else if (caller?.role === "owner" && biz.sessionData?.targetBranchId) {
    branchFilter = biz.sessionData.targetBranchId;
  }
  if (branchFilter) {
    query.$or = [
      { branchId: branchFilter },
      { branchId: null },
      { branchId: { $exists: false } }
    ];
  }
 
  const dbProducts = await Product.find(query).sort({ name: 1 }).lean();
 
  // Merge supplier profile rates + listed products (unchanged logic)
  let supplierItems = [];
  const _supplierProf = await SupplierProfile.findOne({ phone }).lean();
  if (_supplierProf) {
    for (const rate of (_supplierProf.rates || [])) {
      if (!rate.service) continue;
      const _priceMatch = String(rate.rate || "").match(/[\d.]+/);
      const _price = _priceMatch ? parseFloat(_priceMatch[0]) : 0;
      const _alreadyIn = dbProducts.some(p => p.name.toLowerCase() === rate.service.toLowerCase());
      if (!_alreadyIn) {
        supplierItems.push({ _id: `sp_rate_${rate._id || rate.service}`, name: rate.service, unitPrice: _price, source: "profile" });
      }
    }
    const _listedBlob = (_supplierProf.listedProducts || [])
      .flatMap(p => String(p || "").split(/[\r\n,]+/).map(s => s.trim()).filter(Boolean));
    for (const lp of _listedBlob) {
      const _alreadyInDb    = dbProducts.some(p => p.name.toLowerCase() === lp.toLowerCase());
      const _alreadyInRates = supplierItems.some(s => s.name.toLowerCase() === lp.toLowerCase());
      if (!_alreadyInDb && !_alreadyInRates) {
        supplierItems.push({ _id: `sp_listed_${lp}`, name: lp, unitPrice: 0, source: "profile" });
      }
    }
  }
 
  const allProducts = [
    ...dbProducts.map(p => ({ _id: p._id.toString(), name: p.name, unitPrice: p.unitPrice || 0, source: "db" })),
    ...supplierItems
  ];
 
  if (!allProducts.length) {
    biz.sessionState = "creating_invoice_add_items";
    biz.sessionData.itemMode = "choose_catalogue_or_custom";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
        "📦 No items in catalogue yet.\n\n" +
        "_Add products once, reuse them forever._\n\nWhat would you like to do?",
      buttons: [
        { id: "inv_add_new_product", title: "➕ Add item(s)" },
        { id: "inv_item_custom",     title: "✍️ Custom item"  }
      ]
    });
  }
 
  const PAGE_SIZE  = 20;
  const page       = a.startsWith("inv_cat_page_") ? parseInt(a.replace("inv_cat_page_", ""), 10) || 0 : 0;
  const totalPages = Math.ceil(allProducts.length / PAGE_SIZE);
  const start      = page * PAGE_SIZE;
  const visible    = allProducts.slice(start, start + PAGE_SIZE);
 
  // Store full catalogue in session for quick-pick lookup
  biz.sessionState = "creating_invoice_pick_product";
  biz.sessionData.catalogueProducts = allProducts.map(p => ({
    _id: p._id, name: p.name, unitPrice: p.unitPrice || 0, source: p.source || "db"
  }));
  biz.sessionData.cataloguePage = page;
  await saveBizSafe(biz);
 
  // Build numbered list - items with no price show _(no price)_ tag
  const numbered = visible.map((p, i) => {
    const num      = start + i + 1;
    const hasPrice = Number(p.unitPrice) > 0;
    const priceTag = hasPrice
      ? ` - ${formatMoney(p.unitPrice, biz.currency)}`
      : " - _(no price)_";
    return `${num}. *${p.name}*${priceTag}`;
  }).join("\n");
 
  const catalogueLabel = supplierItems.length > 0 ? "📦 *Your Products & Services*" : "📦 *Product Catalogue*";
 
  await sendText(from,
`${catalogueLabel}
Page ${page + 1} of ${totalPages} · ${allProducts.length} item${allProducts.length === 1 ? "" : "s"}
 
${numbered}
 
─────────────────
*Quick-pick:* type *number × quantity*
_One item:_   3x2
_Multiple:_   3x2, 7x1, 12x5
_No price?_   you'll be asked after picking`
  );
 
  const navBtns = [];
  if (page > 0)              navBtns.push({ id: `inv_cat_page_${page - 1}`, title: "⬅ Prev" });
  if (page < totalPages - 1) navBtns.push({ id: `inv_cat_page_${page + 1}`, title: "➡ Next" });
  navBtns.push({ id: "inv_item_custom", title: "✍️ Custom item" });
 
  return sendButtons(from, {
    text: "Pick items by number or tap an option:",
    buttons: navBtns.slice(0, 3)
  });
}
 




if (a === "add_another_expense") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "expense_smart_entry";
    biz.sessionData  = { targetBranchId: biz.sessionData?.targetBranchId, bulkExpenses: [] };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
`💸 *Add More Expenses*

_fuel 30, lunch 15, zesa 50_

Or tap to pick a category:`,
      buttons: [
        { id: "exp_show_categories", title: "📂 Pick by Category" },
        { id: ACTIONS.MAIN_MENU,     title: "🏠 Done" }
      ]
    });
  }

// "Pick by Category" button from smart entry → show category list
  if (a === "exp_show_categories") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = ACTIONS.EXPENSE_CATEGORY;
    // preserve branch context
    biz.sessionData = {
      targetBranchId: biz.sessionData?.targetBranchId,
      bulkExpenses:   biz.sessionData?.bulkExpenses || []
    };
    await saveBizSafe(biz);
    return sendList(from, "📂 Select Category", [
      { id: "exp_cat_rent",        title: "🏢 Rent" },
      { id: "exp_cat_utilities",   title: "💡 Utilities" },
      { id: "exp_cat_transport",   title: "🚗 Transport & Fuel" },
      { id: "exp_cat_supplies",    title: "📦 Supplies & Stock" },
      { id: "exp_cat_salaries",    title: "👷 Salaries & Wages" },
      { id: "exp_cat_maintenance", title: "🔧 Maintenance" },
      { id: "exp_cat_other",       title: "📝 Other" }
    ]);
  }

  // ── exp_cat_* → user picked a category, now prompt for description + amount
  if (a.startsWith("exp_cat_")) {
    if (!biz) return sendMainMenu(from);
    const CAT_MAP = {
      exp_cat_rent:        "Rent",
      exp_cat_utilities:   "Utilities",
      exp_cat_transport:   "Transport",
      exp_cat_supplies:    "Supplies",
      exp_cat_salaries:    "Salaries",
      exp_cat_maintenance: "Maintenance",
      exp_cat_other:       "Other"
    };
    const CAT_EXAMPLES = {
      exp_cat_rent:        "_office rent 500_",
      exp_cat_utilities:   "_zesa 50, water 20, wifi 30_",
      exp_cat_transport:   "_fuel 40, kombi fare 5_",
      exp_cat_supplies:    "_printing paper 15, toner 30_",
      exp_cat_salaries:    "_cashier salary 300 bank_",
      exp_cat_maintenance: "_AC service 80, plumber 50_",
      exp_cat_other:       "_miscellaneous 25_"
    };
    const chosenCat = CAT_MAP[a] || "Other";
    const example   = CAT_EXAMPLES[a] || "_description amount_";
    biz.sessionState = "expense_smart_entry";
    biz.sessionData  = {
      targetBranchId:  biz.sessionData?.targetBranchId,
      bulkExpenses:    biz.sessionData?.bulkExpenses || [],
      presetCategory:  chosenCat
    };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
`📂 *${chosenCat} Expense*

Type description and amount:
${example}

Multiple items: _desc1 amount1, desc2 amount2_`,
      buttons: [
        { id: "exp_bulk_confirm_yes", title: "✅ Save What I Have" },
        { id: ACTIONS.PAYMENTS_MENU, title: "❌ Cancel" }
      ]
    });
  }

  // ── Expense bulk: button taps route into continueTwilioFlow ──────────────
  if (
    a === "exp_bulk_confirm_yes" ||
    a === "exp_bulk_confirm_no"  ||
    a === "exp_bulk_keep_adding"
  ) {
    if (!biz) return sendMainMenu(from);
    // Pass the button ID as text so twilioStateBridge state handler picks it up
    const handled = await continueTwilioFlow({ from, text: a });
    if (handled) return;
  }
  // ✅ ADD THIS BLOCK immediately after the add_another_expense block
if (a === "expense_generate_receipt") {
  if (!biz) return sendMainMenu(from);

  const lastExpense = biz.sessionData?.lastExpense;

  if (!lastExpense) {
    biz.sessionState = "ready";
    biz.sessionData = {};
    await saveBizSafe(biz);
    await sendText(from, "❌ No expense found to generate receipt for.");
    return sendMainMenu(from);
  }

  const receiptNumber = `EXP-${lastExpense.id.toString().slice(-6)}`;

  const { filename } = await generatePDF({
    type: "receipt",
    number: receiptNumber,
    date: lastExpense.date || new Date(),
    billingTo: lastExpense.category,
    items: [{
      item: lastExpense.description || lastExpense.category,
      qty: 1,
      unit: lastExpense.amount,
      total: lastExpense.amount
    }],
    bizMeta: {
      name: biz.name,
      logoUrl: biz.logoUrl,
      address: biz.address || "",
      _id: biz._id.toString(),
      status: "paid"
    }
  });

  const site = (process.env.SITE_URL || "").replace(/\/$/, "");
  const url = `${site}/docs/generated/receipts/${filename}`;
  await sendDocument(from, { link: url, filename });

  biz.sessionState = "ready";
  biz.sessionData = {};
  await saveBizSafe(biz);

  await sendText(from, "✅ Expense receipt generated!");
  return sendMainMenu(from);
}

// ✅ NEW: Generate receipt for last expense (SKIP add another)
  if (biz?.sessionState === "expense_add_another_menu" && !isMetaAction) {
    const textLower = text.toLowerCase().trim();
    
    // User types anything (not a button) while in this state
    if (textLower === "receipt" || textLower === "generate" || textLower === "skip") {
      const lastExpense = biz.sessionData?.lastExpense;
      
      if (!lastExpense) {
        biz.sessionState = "ready";
        biz.sessionData = {};
        await saveBizSafe(biz);
        await sendText(from, "❌ No expense found.");
        return sendMainMenu(from);
      }

      const receiptNumber = `EXP-${lastExpense.id.toString().slice(-6)}`;

      const { filename } = await generatePDF({
        type: "receipt", 
        number: receiptNumber, 
        date: lastExpense.date || new Date(),
        billingTo: lastExpense.category,
        items: [{
          item: lastExpense.description || lastExpense.category,
          qty: 1,
          unit: lastExpense.amount,
          total: lastExpense.amount
        }],
        bizMeta: {
          name: biz.name,
          logoUrl: biz.logoUrl,
          address: biz.address || "",
          _id: biz._id.toString(),
          status: "paid"
        }
      });

      const site = (process.env.SITE_URL || "").replace(/\/$/, "");
      const url = `${site}/docs/generated/receipts/${filename}`;
      await sendDocument(from, { link: url, filename });

      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);

      await sendText(from, "✅ Receipt generated!");
      return sendMainMenu(from);
    }
    
    // Otherwise keep waiting for button press
    return true;
  }

  if (a === "prod_add_products") {
    if (!biz) return sendMainMenu(from);
    if (caller?.role === "owner") return sendBranchSelectorAddProduct(from);
    biz.sessionState = "product_add_name";
    biz.sessionData  = { targetBranchId: biz.sessionData?.targetBranchId };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
        "📦 *Add Products*\n\n" +
        "Type one product name, or many separated by commas:\n\n" +
        "_cement_\n" +
        "_cement, river sand, pit sand, bricks, quarry stones_\n\n" +
        "You do not need to add prices now.",
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }
 
  // ── Add Services (from Products & Services menu) ───────────────────────
  if (a === "prod_add_services") {
    if (!biz) return sendMainMenu(from);
    if (caller?.role === "owner") return sendBranchSelectorAddProduct(from);
    biz.sessionState = "service_add_name";
    biz.sessionData  = { targetBranchId: biz.sessionData?.targetBranchId, isService: true };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
        "🔧 *Add Services*\n\n" +
        "Type one service name, or many separated by commas:\n\n" +
        "_house wiring_\n" +
        "_house wiring, solar installation, geyser repair, borehole pump wiring_\n\n" +
        "Services can be priced per job, per hour, per day, per meter, per room or custom.\n" +
        "You do not need to add prices now.",
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }
 
  // ── Preview-confirm buttons routed into twilioStateBridge ──────────────
  if (
    a === "prod_preview_save"   ||
    a === "prod_preview_edit"   ||
    a === "prod_preview_cancel" ||
    a === "prod_prices_confirm_save" ||
    a === "prod_prices_confirm_edit" ||
    a === "svc_rates_confirm_save"   ||
    a === "svc_rates_confirm_edit"   ||
    a === "svc_rate_per_job"         ||
    a === "svc_rate_per_hour"        ||
    a === "svc_rate_per_day"         ||
    a === "svc_rate_per_meter"       ||
    a === "svc_rate_per_room"        ||
    a === "svc_rate_per_visit"
  ) {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: a });
    return;
  }
 
  // ── Update Product Prices ──────────────────────────────────────────────
  if (a === "prod_update_prices") {
    if (!biz) return sendMainMenu(from);
 
    // Build a query scoped to the caller's branch
    const query = { businessId: biz._id, isActive: true, $or: [{ isService: false }, { isService: { $exists: false } }] };
    if (caller?.role !== "owner" && caller?.branchId) {
      query.$and = [
        { $or: [{ branchId: caller.branchId }, { branchId: null }, { branchId: { $exists: false } }] }
      ];
    } else if (biz.sessionData?.targetBranchId) {
      query.$and = [
        { $or: [{ branchId: biz.sessionData.targetBranchId }, { branchId: null }, { branchId: { $exists: false } }] }
      ];
    }
 
    const products = await Product.find(query).sort({ name: 1 }).lean();
    if (!products.length) {
      return sendButtons(from, {
        text: "📦 No products found. Add some products first.",
        buttons: [
          { id: "prod_add_products",  title: "📦 Add Products" },
          { id: ACTIONS.MAIN_MENU,    title: "🏠 Main Menu"    }
        ]
      });
    }
 
    const numbered = products.map((p, i) => {
      const price = p.unitPrice > 0 ? formatMoney(p.unitPrice, biz.currency) : "_(no price)_";
      return `${i + 1}. *${p.name}* - ${price}`;
    }).join("\n");
 
    biz.sessionState = "product_update_prices";
    biz.sessionData  = {
      ...biz.sessionData,
      updateCatalogue: products.map(p => ({ _id: p._id.toString(), name: p.name, unitPrice: p.unitPrice || 0 }))
    };
    await saveBizSafe(biz);
 
    // sendText for the list (no 1024-char limit), then sendButtons for the action
    await sendText(from,
      `💰 *Update Product Prices*\n\n${numbered}\n\n` +
      `─────────────────\n` +
      `Type *item number × price*, separated by commas:\n\n` +
      `_1 x 12_\n` +
      `_1 x 12, 2 x 35, 3 x 28_\n\n` +
      `This means: item number × price`
    );
    return sendButtons(from, {
      text: "Type your price updates above, or cancel:",
      buttons: [{ id: "inv_cancel", title: "❌ Cancel" }]
    });
  }
 
  // ── Update Service Rates ───────────────────────────────────────────────
  if (a === "prod_update_rates") {
    if (!biz) return sendMainMenu(from);
 
    const query = { businessId: biz._id, isActive: true, isService: true };
    if (caller?.role !== "owner" && caller?.branchId) {
      query.$and = [
        { $or: [{ branchId: caller.branchId }, { branchId: null }, { branchId: { $exists: false } }] }
      ];
    } else if (biz.sessionData?.targetBranchId) {
      query.$and = [
        { $or: [{ branchId: biz.sessionData.targetBranchId }, { branchId: null }, { branchId: { $exists: false } }] }
      ];
    }
 
    const services = await Product.find(query).sort({ name: 1 }).lean();
    if (!services.length) {
      return sendButtons(from, {
        text: "🔧 No services found. Add some services first.",
        buttons: [
          { id: "prod_add_services", title: "🔧 Add Services" },
          { id: ACTIONS.MAIN_MENU,   title: "🏠 Main Menu"    }
        ]
      });
    }
 
    const numbered = services.map((p, i) => {
      const rate = p.unitPrice > 0 && p.rateUnit
        ? `${formatMoney(p.unitPrice, biz.currency)}/${p.rateUnit}`
        : p.unitPrice > 0 ? formatMoney(p.unitPrice, biz.currency) : "_(no rate)_";
      return `${i + 1}. *${p.name}* 🔧 - ${rate}`;
    }).join("\n");
 
    biz.sessionState = "service_update_rates";
    biz.sessionData  = {
      ...biz.sessionData,
      updateCatalogue: services.map(p => ({
        _id:      p._id.toString(),
        name:     p.name,
        unitPrice: p.unitPrice || 0,
        rateUnit:  p.rateUnit || null
      }))
    };
    await saveBizSafe(biz);
 
    // sendText for the list (no 1024-char limit), then sendButtons for the action
    await sendText(from,
      `💰 *Update Service Rates*\n\n${numbered}\n\n` +
      `─────────────────\n` +
      `Type *item number × price/rate*, separated by commas:\n\n` +
      `_1 x 20/hour_\n` +
      `_1 x 20/hour, 2 x 50/job, 3 x 10/meter_\n\n` +
      `Rate types: /job /hour /day /meter /room /visit /project\n\n` +
      `_If you leave out the rate type, we'll ask you._`
    );
    return sendButtons(from, {
      text: "Type your rate updates above, or cancel:",
      buttons: [{ id: "inv_cancel", title: "❌ Cancel" }]
    });
  }
 

 if (a === "inv_add_new_product") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "invoice_quick_add_product_name";
    biz.sessionData  = { ...biz.sessionData, itemMode: "catalogue", quickAddProduct: {} };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
        "📦 *Enter product/service name:*\n\n" +
        "_Add multiple at once with commas:_\n" +
        "_house wiring, solar installation, geyser repair_",
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }
 

 if (a === "add_another_product") {
    if (!biz) return sendMainMenu(from);
    const isService = biz.sessionData?.isService || false;
    biz.sessionState = isService ? "service_add_name" : "product_add_name";
    biz.sessionData  = { targetBranchId: biz.sessionData?.targetBranchId, isService };
    await saveBizSafe(biz);
    const label = isService ? "services" : "products";
    const hint  = isService
      ? "_house wiring, solar installation, geyser repair_"
      : "_cement, river sand, pit sand, bricks_";
    return sendButtons(from, {
      text: `📦 *Add more ${label}:*\n\n${hint}\n\nYou do not need to add prices now.`,
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }
 
   if (a === "product_skip_price") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "product_skip_price" });
    return;
  }
 
 

  if (a === "inv_item_custom") {
    if (!biz) return sendMainMenu(from);
    // ── Custom item bulk entry: prompt for comma-separated names ─────────────
    biz.sessionData.itemMode          = "custom_names";
    biz.sessionData.pendingCustomNames = [];
    biz.sessionState = "creating_invoice_custom_names";
    await saveBizSafe(biz);
    const _docLabel = biz.sessionData?.docType === "quote" ? "Quotation"
      : biz.sessionData?.docType === "receipt" ? "Receipt"
      : "Invoice";
    return sendButtons(from, {
      text:
        `✍️ *Add items - ${_docLabel}*\n\n` +
        buildFastAddHelpText(biz),
      buttons: [{ id: "inv_cancel", title: "❌ Cancel" }]
    });
  }

  // ── Inline custom item action buttons ────────────────────────────────────
  // ── inv_add_item: from confirm preview, user wants to add another item ─────
  if (a === "inv_add_item") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "creating_invoice_add_items";
    biz.sessionData.itemMode          = null;
    biz.sessionData.lastItem          = null;
    biz.sessionData.expectingQty      = false;
    biz.sessionData.pendingCustomNames = [];
    await saveBizSafe(biz);
    return sendAddItemPrompt(from);
  }

  if (a === "inv_custom_confirm") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_custom_confirm" });
    return;
  }
  if (a === "inv_custom_edit") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_custom_edit" });
    return;
  }
  if (a === "inv_custom_cancel") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_custom_cancel" });
    return;
  }
  if (a === "inv_custom_skip_price") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "inv_custom_skip_price" });
    return;
  }

  if (a === "inv_client_phone_same" || a === "inv_client_phone_skip") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: a });
    return;
  }

  if (a === "add_client_phone_same") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: a });
    return;
  }

  if (al === "inv_new_client") {
    await handleNewClientFromInvoice(from);
    return;
  }

  if (a === "inv_view_products") {
    if (!biz) return sendMainMenu(from);
    const products = await Product.find({ businessId: biz._id, isActive: true }).lean();
    if (!products.length) return sendText(from, "📦 No products found.");
    let msg = "📦 *Product catalogue:*\n\n";
    products.forEach((p, i) => { msg += `${i + 1}) *${p.name}* - ${formatMoney(p.unitPrice, biz.currency)}\n`; });
    return sendText(from, msg);
  }

  // ── Client statement ───────────────────────────────────────────────────────
  if (a === ACTIONS.CLIENT_STATEMENT) {
    if (!biz) return sendMainMenu(from);
    const Client = (await import("../models/client.js")).default;
    let clients;

    if (caller && ["clerk", "manager"].includes(caller.role) && caller.branchId) {
      const branchInvoices = await Invoice.find({ businessId: biz._id, branchId: caller.branchId }).distinct("clientId");
      clients = await Client.find({ businessId: biz._id, _id: { $in: branchInvoices } }).lean();
    } else {
      clients = await Client.find({ businessId: biz._id }).lean();
    }

    if (!clients.length) { await sendText(from, "No clients found."); return sendMainMenu(from); }

    biz.sessionState = "client_statement_choose_client";
    biz.sessionData = {};
    await saveBizSafe(biz);

    return sendList(from, "📄 Select client for statement",
      clients.map(c => ({ id: `stmt_client_${c._id}`, title: c.name || c.phone }))
    );
  }

 if (a === ACTIONS.ADD_PRODUCT) {
    if (!biz) return sendMainMenu(from);
    // Route to the new cleaner menu
    if (caller?.role === "owner") return sendBranchSelectorAddProduct(from);
    biz.sessionState = "product_add_name";
    biz.sessionData  = { targetBranchId: null };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
        "📦 *Add Products*\n\n" +
        "Type one product name, or many separated by commas:\n\n" +
        "_cement_\n" +
        "_cement, river sand, pit sand, bricks_\n\n" +
        "You do not need to add prices now.",
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }

  // ── Owner picks branch for Add Product ───────────────────────────────────
 if (a.startsWith("add_product_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("add_product_branch_", "");
    const isService = biz.sessionData?.isService || false;
    biz.sessionState = isService ? "service_add_name" : "product_add_name";
    biz.sessionData  = { targetBranchId: branchId, isService };
    await saveBizSafe(biz);
    const branch = await Branch.findById(branchId);
    const label  = isService ? "Services" : "Products";
    const hint   = isService
      ? "_house wiring, solar installation, geyser repair_"
      : "_cement, river sand, pit sand, bricks_";
    return sendButtons(from, {
      text:
        `📦 *Add ${label} - ${branch?.name || "Branch"}*\n\n` +
        `Type one or many names separated by commas:\n\n${hint}\n\n` +
        `You do not need to add prices now.`,
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }
 
 

  // ── Owner picks branch for Add Client ────────────────────────────────────
  if (a.startsWith("add_client_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("add_client_branch_", "");
    biz.sessionData = { targetBranchId: branchId };
    await saveBizSafe(biz);
    // Now start the client flow with the branch set
    biz.sessionState = "adding_client_name";
    await saveBizSafe(biz);
    const branch = await Branch.findById(branchId);
    return sendButtons(from, {
      text: `👥 *Add Client - ${branch?.name || "Branch"}*\n\nEnter client full name:`,
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }

  // ── Owner picks branch for Payment IN ────────────────────────────────────
  if (a.startsWith("payment_in_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("payment_in_branch_", "");
    biz.sessionData = { targetBranchId: branchId };
    await saveBizSafe(biz);
    // Show unpaid invoices for this branch
    await showUnpaidInvoices(from, branchId);
    return;
  }

  // ── Owner picks branch for Expense (OUT) ─────────────────────────────────
if (a.startsWith("expense_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("expense_branch_", "");

    biz.sessionState = "expense_smart_entry";
    biz.sessionData  = {
      targetBranchId: branchId,
      bulkExpenses: []
    };

    // clear any stale marketplace search context
    delete biz.sessionData.supplierSearch;
    delete biz.sessionData.searchResults;
    delete biz.sessionData.searchPage;
    delete biz.sessionData.orderSupplierId;
    delete biz.sessionData.orderCart;
    delete biz.sessionData.orderItems;
    delete biz.sessionData.orderProduct;
    delete biz.sessionData.orderQuantity;
    delete biz.sessionData.orderIsService;
    delete biz.sessionData.orderBrowseMode;
    delete biz.sessionData.orderCataloguePage;
    delete biz.sessionData.orderCatalogueSearch;

    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
`💸 *Record Expenses*

Type one or many - same format either way:

Single:  _fuel 30_
Many:  _fuel 30, lunch 15, zesa 50, rent 500_
With method:  _salary 850 bank, fuel 30 ecocash_

─────────────────
Type *list* to review  ·  *done* to save  ·  *cancel* to quit`,
      buttons: [
        { id: "exp_show_categories", title: "📂 Pick by Category" },
        { id: ACTIONS.MAIN_MENU,     title: "❌ Cancel" }
      ]
    });
  }
  // ── Owner picks branch for Bulk Expenses ─────────────────────────────────

 // ── Owner picks branch for Bulk Expenses ─────────────────────────────────
  if (a.startsWith("bulk_expense_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("bulk_expense_branch_", "");
    biz.sessionState = "bulk_expense_input";
    biz.sessionData = { targetBranchId: branchId, bulkExpenses: [] };
    await saveBizSafe(biz);
    const branch = await Branch.findById(branchId);
    return sendText(from,
`💰 *Bulk Expense - ${branch?.name || "Branch"}*

Type expenses separated by commas:
*lunch 10, cables 5, transport 20*

Categories auto-detected ✨

*Commands:*
- 'list' - Show all
- 'remove 2' - Delete #2
- 'done' - Save all
- 'help' - More info`);
  }

  // ── Owner picks branch for View Expense Receipts ──────────────────────────
  if (a.startsWith("view_expense_receipts_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("view_expense_receipts_branch_", "");
    return showExpenseReceipts(from, biz, branchId === "all" ? null : branchId);
  }

  // ── Owner picks branch for View Payment History ───────────────────────────
  if (a.startsWith("view_payment_history_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("view_payment_history_branch_", "");
    return showPaymentHistory(from, biz, branchId === "all" ? null : branchId);
  }

  // ── Owner picks branch for View Clients ──────────────────────────────────
  if (a.startsWith("view_clients_branch_")) {
    if (!biz) return sendMainMenu(from);
    const branchId = a.replace("view_clients_branch_", "");
    return showClientsList(from, biz, branchId === "all" ? null : branchId);
  }

  // ── Owner picks branch for New Invoice/Quote/Receipt ─────────────────────
  if (a.startsWith("new_doc_branch_")) {
    if (!biz) return sendMainMenu(from);
    // Format: new_doc_branch_{docType}_{branchId}
    const rest = a.replace("new_doc_branch_", "");
    const parts = rest.split("_");
    // branchId is the last ObjectId segment (24 hex chars), docType is before it
    const branchId = parts[parts.length - 1];
    const docType = parts.slice(0, -1).join("_"); // handles "invoice", "quote", "receipt"

    // Validate branchId
    if (!mongoose.Types.ObjectId.isValid(branchId)) {
      await sendText(from, "⚠️ Invalid branch selected.");
      return sendSalesMenu(from);
    }

    // Store the target branch so the flow uses it
    biz.sessionData = { targetBranchId: branchId };
    await saveBizSafe(biz);

    if (docType === "invoice") return startInvoiceFlow(from);
    if (docType === "quote") {
      if (biz.package === "trial") return promptUpgrade({ biz, from, feature: "Quotes" });
      return startQuoteFlow(from);
    }
    if (docType === "receipt") {
      if (biz.package === "trial") return promptUpgrade({ biz, from, feature: "Receipts" });
      return startReceiptFlow(from);
    }

    return sendSalesMenu(from);
  }


  // ── Doc list: prev/next page navigation ───────────────────────────────────
if (a.startsWith("vdoc_prev_") || a.startsWith("vdoc_next_")) {
    if (!biz) return sendMainMenu(from);
    // format: vdoc_prev_inv_all_2_none_0
    const raw    = a.replace("vdoc_prev_", "").replace("vdoc_next_", "");
    const parts  = raw.split("_");
    const typeMap = { inv: "invoice", qt: "quote", rct: "receipt" };
    const docType    = typeMap[parts[0]] || "invoice";
    const branchRaw  = parts[1] === "all" ? null : parts[1];
    const curPage    = parseInt(parts[2]) || 0;
    const filterCode = parts[3] || "none";
    const searchRaw  = parts.slice(4).join("_");
    const dateFilter = filterCode === "none" ? null : filterCode;
    const search     = searchRaw === "0" ? null : decodeURIComponent(searchRaw);
    const newPage    = a.startsWith("vdoc_prev_") ? curPage - 1 : curPage + 1;
    return showSalesDocs(from, docType, branchRaw ?? undefined, Math.max(0, newPage), search, dateFilter);
  }

  // ── Doc list: search trigger ────────────────────────────────────────────────
// ── Filter by date - show date picker buttons ──────────────────────────────
  if (a.startsWith("vdoc_filter_")) {
    if (!biz) return sendMainMenu(from);
    const parts   = a.replace("vdoc_filter_", "").split("_");
    const typeMap = { inv: "invoice", qt: "quote", rct: "receipt" };
    const docType = typeMap[parts[0]] || "invoice";
    const branchCode = parts[1] || "all";

    // Store context for date selection
    biz.sessionState = "sales_doc_filter";
    biz.sessionData  = { docFilterType: docType, docFilterBranch: branchCode === "all" ? null : branchCode };
    await saveBizSafe(biz);

    const typeLabel = docType[0].toUpperCase() + docType.slice(1);
    return sendList(from, `📅 *Filter ${typeLabel}s*\n\nChoose a time period:`, [
      { id: `vdoc_date_${docType}_${branchCode}_this_month`, title: "📅 This Month" },
      { id: `vdoc_date_${docType}_${branchCode}_last_month`, title: "📅 Last Month" },
      { id: `vdoc_date_${docType}_${branchCode}_last_7`,     title: "📅 Last 7 Days" },
      { id: `vdoc_date_${docType}_${branchCode}_this_year`,  title: "📅 This Year" },
      { id: `vdoc_date_${docType}_${branchCode}_none`,       title: "📋 All Time" },
      { id: `vdoc_search_${docType}_${branchCode}`,         title: "🔍 Search Docs" }
    ]);
  }

  // ── Date filter selected ──────────────────────────────────────────────────
  if (a.startsWith("vdoc_date_")) {
    if (!biz) return sendMainMenu(from);
    const raw    = a.replace("vdoc_date_", "");
    // format: vdoc_date_invoice_all_this_month
    const parts  = raw.split("_");
    const typeMap = { invoice: "invoice", quote: "quote", receipt: "receipt" };
    const docType    = typeMap[parts[0]] || "invoice";
    const branchCode = parts[1] || "all";
    const filterKey  = parts.slice(2).join("_"); // this_month, last_month, etc
    const dateFilter = filterKey === "none" ? null : filterKey;
    const branchId   = branchCode === "all" ? null : branchCode;
    return showSalesDocs(from, docType, branchId ?? undefined, 0, null, dateFilter);
  }

  // ── Search by text ────────────────────────────────────────────────────────
  if (a.startsWith("vdoc_search_")) {
    if (!biz) return sendMainMenu(from);
    const parts   = a.replace("vdoc_search_", "").split("_");
    const typeMap = { inv: "invoice", qt: "quote", rct: "receipt",
                      invoice: "invoice", quote: "quote", receipt: "receipt" };
    const docType    = typeMap[parts[0]] || "invoice";
    const branchCode = parts[1] || "all";
    biz.sessionState = "sales_doc_search";
    biz.sessionData  = {
      docSearchType:   docType,
      docSearchBranch: branchCode === "all" ? null : branchCode
    };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `🔍 *Search ${docType[0].toUpperCase() + docType.slice(1)}s*\n\nType client name or part of invoice number:\n_e.g.  John  or  INV-0003_`,
      buttons: [{ id: ACTIONS.SALES_MENU, title: "❌ Cancel" }]
    });
  }


  // ── Doc list: search result (triggered after user types search term) ───────
  if (biz?.sessionState === "sales_doc_search_ready") {
    const docType   = biz.sessionData?.docSearchType   || "invoice";
    const branchRaw = biz.sessionData?.docSearchBranch;
    const search    = biz.sessionData?.docSearchTerm   || null;
    const branch    = branchRaw === undefined ? undefined : (branchRaw || null);
    biz.sessionState = "ready"; biz.sessionData = {};
    await saveBizSafe(biz);
    return showSalesDocs(from, docType, branch, 0, search);
  }
  // ── Invoice client picker ──────────────────────────────────────────────────
  if (al.startsWith("client_") && al !== ACTIONS.CLIENT_STATEMENT) {
    await handleClientPicked(from, al.replace("client_", ""));
    return;
  }

  // ── Resume an unfinished document after a search interruption ─────────────
  if (a === "inv_resume_flow") {
    if (!biz) return sendMainMenu(from);
    if (biz.sessionData?.pendingSearchText) {
      delete biz.sessionData.pendingSearchText;
      await saveBizSafe(biz);
    }
    return sendText(from, "▶ Continuing where you left off - carry on with your entry, or type *cancel* to discard the draft.");
  }

  // ── Abandon the unfinished document and run the stored search ─────────────
  if (a === "inv_search_instead") {
    if (!biz) return sendMainMenu(from);
    const _pst = biz.sessionData?.pendingSearchText || "";
    biz.sessionState = "ready";
    biz.sessionData  = {};
    await saveBizSafe(biz);

    const shortcode = parseShortcodeSearch(_pst);
    if (!shortcode?.product) return sendMainMenu(from);

    const locationLabel = [shortcode.area, shortcode.city].filter(Boolean).join(", ") || "All Cities";
    try {
      const offerResults = await runSupplierOfferSearch({
        city: shortcode.city, area: shortcode.area, product: shortcode.product
      });
      if (offerResults.length) {
        return sendNumberedSellerResults({
          from, phone, offers: offerResults,
          searchTerm: shortcode.product, locationLabel
        });
      }
      const results = await runSupplierSearch({
        city: shortcode.city, area: shortcode.area, product: shortcode.product
      });
      if (results.length) {
        return sendNumberedSellerResults({
          from, phone, suppliers: results,
          searchTerm: shortcode.product, locationLabel
        });
      }
    } catch (e) {
      console.warn("[SEARCH INSTEAD]", e.message);
    }
    return sendButtons(from, {
      text: `😕 No sellers found for *${shortcode.product}*${shortcode.city ? ` in *${shortcode.city}*` : ""}.`,
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  if (a === ACTIONS.INV_ADD_ANOTHER_ITEM) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "creating_invoice_add_items";
    biz.sessionData.itemMode = null;
    biz.sessionData.lastItem = null;
    biz.sessionData.expectingQty = false;
    biz.sessionData.lastItemSource = null;
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "How would you like to add an item?",
      buttons: [
        { id: "inv_item_catalogue", title: "📦 Catalogue" },
        { id: "inv_item_custom", title: "✍️ Custom item" }
      ]
    });
  }

  if (a === ACTIONS.INV_ENTER_PRICES) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "creating_invoice_enter_prices";
    biz.sessionData.priceIndex = 0;
    await saveBizSafe(biz);
    const item = biz.sessionData.items[0];
    return sendButtons(from, {
      text: `💰 *Enter price for:*\n${item.item} x${item.qty}`,
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }

  if (al === "inv_cancel") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = null;
    biz.sessionData = {};
    biz.markModified("sessionData");
    await biz.save();
    return sendMainMenu(from);
  }

  // ── Payments / Expenses ────────────────────────────────────────────────────

if (a === ACTIONS.RECORD_EXPENSE) {
    if (!biz) return sendMainMenu(from);
    if (caller?.role === "owner") return sendBranchSelectorExpense(from);
    biz.sessionState = "expense_smart_entry";
    biz.sessionData  = { bulkExpenses: [] };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
`💸 *Record Expenses*

Single:  _fuel 30_
Many:  _fuel 30, lunch 15, zesa 50_
With method:  _salary 850 bank_

Type *done* to save`,
      buttons: [
        { id: "exp_show_categories", title: "📂 Pick by Category" },
        { id: ACTIONS.MAIN_MENU,     title: "❌ Cancel" }
      ]
    });
  }

  // ── Stock Control ─────────────────────────────────────────────────────────
  // Entry point from Products & Services → "📊 Stock Control".
  // Optional feature; multi-step flows use twilioStateBridge states.
  // ─────────────────────────────────────────────────────────────────────────
  if (a === "stock_menu") {
    if (!biz) return sendMainMenu(from);
    return sendStockMenu(from, biz);
  }

  if (a === "products_menu") {
    if (!biz) return sendMainMenu(from);
    return sendProductsMenu(from);
  }

  // Combined Branches & Users submenu (used when Business Tools would exceed the
  // 10-row WhatsApp list cap after adding Stock Control).
  if (a === "branches_users_menu") {
    if (!biz) return sendMainMenu(from);
    const { sendBranchesUsersMenu } = await import("./metaMenus.js");
    return sendBranchesUsersMenu(from, biz);
  }

  if (a === "stock_enable") {
    if (!biz) return sendMainMenu(from);
    try {
      const { enableStock } = await import("./stockService.js");
      await enableStock(biz._id, from);
      await sendText(from, "✅ *Stock tracking is now ON.*\n\nNext: tap *Track a Product* to choose the products you want to keep stock for. Only the products you add here are ever counted - everything else is ignored.");
    } catch (e) {
      console.error("[STOCK enable]", e.message);
      await sendText(from, "❌ Couldn't enable stock tracking. Please try again.");
    }
    return sendStockMenu(from, biz);
  }

  if (a === "stock_disable") {
    if (!biz) return sendMainMenu(from);
    try {
      const { disableStock } = await import("./stockService.js");
      await disableStock(biz._id);
      await sendText(from, "Stock tracking is now OFF. Your tracked products and history are kept - turn it back on any time and everything is still here.");
    } catch (_) {}
    return sendProductsMenu(from);
  }

  if (a === "stock_settings") {
    if (!biz) return sendMainMenu(from);
    let autoOn = true;
    try {
      const { getStockSettings } = await import("./stockService.js");
      const st = await getStockSettings(biz._id);
      autoOn = st.autoMatchSales !== false;
    } catch (_) {}
    return sendList(from,
      `⚙ *Stock Settings*\n\n🔗 Sales auto-deduct is currently *${autoOn ? "ON" : "OFF"}*.\n${autoOn
        ? "When you record a sale or receipt, matching products are reduced from stock automatically."
        : "Stock only changes when you record stock in / adjustments yourself - your sales do NOT reduce stock."}`,
      [
        { id: "stock_automatch_toggle", title: autoOn ? "🔗 Turn Sales Auto-Deduct OFF" : "🔗 Turn Sales Auto-Deduct ON" },
        { id: "stock_disable",          title: "🚫 Turn Stock Tracking OFF" },
        { id: "stock_menu",             title: "⬅ Back" }
      ]);
  }

  // Flip the "sales reduce stock automatically" switch on/off.
  if (a === "stock_automatch_toggle") {
    if (!biz) return sendMainMenu(from);
    try {
      const { getStockSettings, setAutoMatchSales } = await import("./stockService.js");
      const st = await getStockSettings(biz._id);
      const next = !(st.autoMatchSales !== false);   // flip current effective value
      await setAutoMatchSales(biz._id, next);
      await sendText(from, next
        ? "✅ *Sales auto-deduct is ON.*\nRecording a sale or receipt now reduces the matching product's stock automatically."
        : "✅ *Sales auto-deduct is OFF.*\nStock will only change when you record stock in or adjustments. Your sales are untouched.");
    } catch (e) {
      console.error("[STOCK automatch]", e.message);
      await sendText(from, "❌ Couldn't change that setting. Please try again.");
    }
    return sendStockMenu(from, biz);
  }

  // Track products → PICK from the catalogue. Multi-select supported: reply
  // several numbers (e.g. 1,3,5) or "all" to track many at once. Picking keeps
  // the tracked name identical to the catalogue/invoice name (reliable matching)
  // and carries the sell price across automatically. "0" types a custom product
  // (full detailed flow in the bridge); "00" cancels.
  if (a === "stock_add_item") {
    if (!biz) return sendMainMenu(from);
    const { getTrackableCatalogue } = await import("./stockService.js");
    const branchId = getEffectiveBranchId(caller, biz.sessionData);
    let catalogue = [];
    try { catalogue = await getTrackableCatalogue({ businessId: biz._id, branchId }); } catch (_) {}

    const MAX = 30;                       // keep the WhatsApp message readable
    const shown = catalogue.slice(0, MAX);   // [{ name, sellPrice }]

    if (!shown.length) {
      // Nothing in the catalogue yet → go straight to typing (existing add-flow).
      biz.sessionState = "stock_add_name";
      biz.sessionData  = {};
      await saveBizSafe(biz);
      await sendButtons(from, {
        text: "➕ *Track a Product*\n\nYou have no catalogue products yet, so type the product *name* exactly as it appears on your sales (e.g. *Coca-Cola 500ml*).",
        buttons: [{ id: "stock_menu", title: "⬅ Cancel" }]
      });
      return true;
    }

    biz.sessionState = "stock_add_pick";
    biz.sessionData  = { ...(biz.sessionData || {}), stockAddPickList: shown, stockAddBranchId: branchId || null };
    await saveBizSafe(biz);

    let msg = "➕ *Track Products*\n" + "─".repeat(22) + "\nPick the products you want to keep stock for:\n";
    shown.forEach((it, i) => {
      const price = it.sellPrice ? ` - sell ${formatMoney(it.sellPrice, biz.currency)}` : "";
      msg += `\n*${i + 1}.* ${it.name}${price}`;
    });
    msg += "\n" + "─".repeat(22);
    msg += "\n\n✏️ Reply *one* number, or *several* to track many at once (e.g. *1,3,5*).";
    msg += "\n🌟 Reply *all* to track everything listed.";
    msg += "\n➕ Reply *0* to type a product that isn't listed.";
    msg += "\n↩️ Reply *00* to cancel.";
    await sendText(from, msg);
    return true;
  }

  // Record stock in / adjust / view / report → numbered pickers over items
  if (a === "stock_in" || a === "stock_adjust") {
    if (!biz) return sendMainMenu(from);
    const { listStockItems } = await import("./stockService.js");
    const branchId = getEffectiveBranchId(caller, biz.sessionData);
    const items = await listStockItems(biz._id, branchId);
    if (!items.length) {
      await sendText(from, "You have no tracked products yet. Tap *Track a Product* first.");
      return sendStockMenu(from, biz);
    }
    biz.sessionState = a === "stock_in" ? "stock_in_pick" : "stock_adjust_pick";
    biz.sessionData  = { stockItemList: items.map(i => ({ id: String(i._id), name: i.name, unit: i.unit, qty: i.currentQty })) };
    await saveBizSafe(biz);
    let msg = (a === "stock_in" ? "📥 *Record Stock In*" : "🔧 *Adjust / Wastage*") + "\nWhich product?\n";
    items.forEach((it, i) => { msg += `\n*${i + 1}.* ${it.name} - ${it.currentQty} ${it.unit} on hand`; });
    msg += "\n\nReply with the number.";
    await sendText(from, msg);
    return true;
  }

  if (a === "stock_view") {
    if (!biz) return sendMainMenu(from);
    const { listStockItems } = await import("./stockService.js");
    const branchId = getEffectiveBranchId(caller, biz.sessionData);
    const items = await listStockItems(biz._id, branchId);
    if (!items.length) {
      await sendText(from, "No tracked products yet. Tap *Track a Product* to start.");
      return sendStockMenu(from, biz);
    }
    // Recompute cached qty so the view is live
    const { recomputeItemQty } = await import("./stockService.js");
    let msg = "📋 *Stock Levels*\n";
    for (const it of items) {
      let q = it.currentQty;
      try { const r = await recomputeItemQty(it._id); q = r ? r.currentQty : q; } catch (_) {}
      const low = it.reorderLevel > 0 && q <= it.reorderLevel ? " ⚠️ LOW" : "";
      msg += `\n• *${it.name}*: ${q} ${it.unit}${low}`;
    }
    msg += "\n\n_Tap Stock & Sales Report for movement and money._";
    await sendText(from, msg);
    return sendStockMenu(from, biz);
  }

  if (a === "stock_report") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "stock_report_period";
    biz.sessionData  = {};
    await saveBizSafe(biz);
    const now = new Date();
    const months = [-1, 0].map(off => {
      const d = new Date(now.getFullYear(), now.getMonth() + off, 1);
      return { label: d.toLocaleDateString("en-GB", { month: "long", year: "numeric" }), month: d.getMonth(), year: d.getFullYear() };
    });
    await sendList(from, "📈 Stock & Sales Report - period:", [
      ...months.map(m => ({ id: `stock_period_${m.year}_${m.month}`, title: m.label })),
      { id: "stock_period_all",    title: "📊 All Time"     },
      { id: "stock_period_custom", title: "📅 Custom Range" },
      { id: "stock_menu",          title: "⬅ Cancel"       }
    ]);
    return true;
  }

  // ── Recurring Billing ────────────────────────────────────────────────────
  // Entry point from Business Tools menu → "🏠 Recurring Billing"
  // All rb_* actions are routed here. Multi-step flows use twilioStateBridge states.
  // ─────────────────────────────────────────────────────────────────────────

  if (a === "recurring_billing_menu") {
    if (!biz) return sendMainMenu(from);
    return sendRecurringBillingMenu(from);
  }

  // ── View all accounts/units ───────────────────────────────────────────────
  if (a === "rb_accounts") {
    if (!biz) return sendMainMenu(from);
    const { listAccountsForChatbot } = await import("./recurringBilling.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const accounts = await listAccountsForChatbot(biz._id, branchId);
    if (!accounts.length) {
      await sendText(from, "🏠 *Accounts & Units*\n\nNo active accounts found.\n\nAdd units via the admin portal first.");
      return sendRecurringBillingMenu(from);
    }
    const cur = biz.currency || "USD";
    let msg = `🏠 *Accounts & Units - ${biz.name}*\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (const acct of accounts) {
      const balSign = (acct.currentBalance || 0) > 0 ? "🔴" : "✅";
      msg += `\n${balSign} *${acct.name}*${acct.ref ? ` (${acct.ref})` : ""}\n`;
      msg += `   💵 Default rate: ${acct.billingAmount} ${cur}/${acct.billingCycle}\n`;
      // Every tenant gets its own line - an account can host more than one
      // (different rooms/rentals sharing a building), and all of them must
      // show here, not just the first.
      if (!acct._tenants.length) {
        msg += `   👤 Vacant\n`;
      } else {
        for (const t of acct._tenants) {
          const rate = t.billingAmount != null ? `${t.billingAmount} ${cur}/${t.billingCycle || acct.billingCycle} (custom)` : `${acct.billingAmount} ${cur}/${acct.billingCycle}`;
          msg += `   👤 ${t.name} - ${rate} - Bal: ${(t.currentBalance || 0).toFixed(2)} ${cur}\n`;
        }
      }
    }
    await sendText(from, msg);
    return sendRecurringBillingMenu(from);
  }

  // ── Record payment - first ask: tenant payment or other (non-tenant) income ─
  // The Other Income option used to be the last row of a long numbered tenant
  // list, so on big portfolios it was buried below the fold (and could be cut
  // off entirely). Presenting an explicit two-way choice keeps it always visible
  // in one tap.
  if (a === "rb_record_payment") {
    if (!biz) return sendMainMenu(from);
    return sendButtons(from, {
      text: "💰 *Record Payment*\n\nWhat are you recording?",
      buttons: [
        { id: "rb_pay_tenant",          title: "👤 Tenant Payment" },
        { id: "rb_pay_income",          title: "💵 Other Income"   },
        { id: "recurring_billing_menu", title: "⬅ Cancel"          }
      ]
    });
  }

  // ── Tenant payment → numbered picker over EVERY tenant + vacant account ─────
  if (a === "rb_pay_tenant") {
    if (!biz) return sendMainMenu(from);
    const { listBillablesForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const billables = await listBillablesForChatbot(biz._id, branchId, { includeVacated: true });
    if (!billables.length) {
      await sendText(from, "❌ No active accounts found. Add units via the admin portal first.");
      return sendRecurringBillingMenu(from);
    }
    biz.sessionState = "rb_payment_pick_account";
    biz.sessionData  = {
      rbBillables: billables.map(b => ({
        accountId: b.accountId.toString(), tenantId: b.tenantId ? b.tenantId.toString() : null,
        accountName: b.accountName, tenantName: b.tenantName, balance: b.balance,
        currency: b.currency, label: b.label
      }))
    };
    await saveBizSafe(biz);
    return sendNumberedPicker(from, "💰 *Tenant Payment* - who is this for?",
      billables.map(b => ({ id: b.label, label: `${b.label} - Bal: ${b.balance.toFixed(2)} ${b.currency}` })),
      { allowBatch: true }
    );
  }

  // ── Other income (not a tenant) → straight into the income entry flow ──────
  if (a === "rb_pay_income") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "rb_income_enter_details";
    biz.sessionData  = { rbIncomeCurrency: biz.currency || "USD" };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `💵 *Other Income* (not a tenant payment)\n\n` +
            `Type each entry as *description amount*.\n` +
            `To add several at once, separate them with commas.\n\n` +
            `*One entry:*\n` +
            `Application fee 20\n\n` +
            `*Several at once:*\n` +
            `Deposit Flat 3A 150, Water recovery 12, Late-rent penalty 15`,
      buttons: [{ id: "recurring_billing_menu", title: "⬅ Cancel" }]
    });
  }

  // ── Account statement - numbered picker over accounts ──────────────────────
  if (a === "rb_account_stmt") {
    if (!biz) return sendMainMenu(from);
    const { listAccountsForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const accounts = await listAccountsForChatbot(biz._id, branchId);
    biz.sessionState = "rb_acct_stmt_pick_account";
    biz.sessionData  = { rbPickList: accounts.map(a2 => a2._id.toString()) };
    await saveBizSafe(biz);
    return sendNumberedPicker(from, "📋 *Account Statement* - select an account",
      accounts.map(a2 => ({ id: a2._id.toString(), label: `${a2.name}${a2.ref ? " (" + a2.ref + ")" : ""} - Bal: ${(a2.currentBalance || 0).toFixed(2)} ${a2.currency || "USD"}` }))
    );
  }

  // ── Tenant statement - numbered picker over EVERY tenant directly ──────────
  // (flat, not account-then-tenant - so it works the same whether an account
  // has one tenant or several, and never truncates at 10 like the old list).
  if (a === "rb_tenant_stmt") {
    if (!biz) return sendMainMenu(from);
    const { listBillablesForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const billables = (await listBillablesForChatbot(biz._id, branchId, { includeVacated: true })).filter(b => b.tenantId);
    if (!billables.length) {
      await sendText(from, "❌ No tenants found. Add tenants via the admin portal first.");
      return sendRecurringBillingMenu(from);
    }
    biz.sessionState = "rb_tenant_stmt_pick_account";
    biz.sessionData  = { rbPickList: billables.map(b => ({ tenantId: b.tenantId.toString(), accountId: b.accountId.toString(), label: b.label })) };
    await saveBizSafe(biz);
    return sendNumberedPicker(from, "👤 *Tenant Statement* - select a tenant",
      billables.map(b => ({ id: b.tenantId.toString(), label: `${b.label} - Bal: ${b.balance.toFixed(2)} ${b.currency}` }))
    );
  }

  // ── Business-wide RECURRING BILLING STATEMENT - period picker ───────────────
  // One cumulative ledger for the WHOLE recurring billing operation: every
  // charge raised, payment collected, and unit expense - chronological, with
  // a running cash balance AND each tenant's/account's own running balance
  // per row, plus who recorded each transaction. Branch-scoped for non-owner
  // callers exactly like every other rb_ flow. Period pick + generation are
  // handled in twilioStateBridge.js (states rb_billing_stmt_pick_period /
  // rb_billing_stmt_custom_date).
  if (a === "rb_billing_stmt") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "rb_billing_stmt_pick_period";
    biz.sessionData  = {};
    await saveBizSafe(biz);

    const now = new Date();
    const months = [-2, -1, 0].map(offset => {
      const d = new Date(now.getFullYear(), now.getMonth() + offset, 1);
      return { label: d.toLocaleDateString("en-GB", { month: "long", year: "numeric" }), month: d.getMonth(), year: d.getFullYear() };
    });
    await sendList(from, "📊 Billing Statement - select period:", [
      ...months.map(m => ({ id: `rb_period_${m.year}_${m.month}`, title: m.label })),
      { id: "rb_period_all",          title: "📊 All Time"       },
      { id: "rb_period_custom",       title: "📅 Custom Range"   },
      { id: "recurring_billing_menu", title: "⬅ Cancel"          }
    ]);
    return true;
  }

  // ── Add unit expense - numbered picker over accounts ────────────────────────
  if (a === "rb_add_expense") {
    if (!biz) return sendMainMenu(from);
    const { listAccountsForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const accounts = await listAccountsForChatbot(biz._id, branchId);
    biz.sessionState = "rb_expense_pick_account";
    biz.sessionData  = { rbPickList: accounts.map(a2 => a2._id.toString()) };
    await saveBizSafe(biz);
    return sendNumberedPicker(from, "🔧 *Add Unit Expense* - select an account",
      accounts.map(a2 => ({ id: a2._id.toString(), label: `${a2.name}${a2.ref ? " (" + a2.ref + ")" : ""}` }))
    );
  }

  // ── Move Out Tenant - pick an ACTIVE tenant to vacate (keeps arrears) ─────────
  if (a === "rb_vacate") {
    if (!biz) return sendMainMenu(from);
    const { listBillablesForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    // Active tenants only - you can only move OUT someone currently in.
    const tenants = (await listBillablesForChatbot(biz._id, branchId)).filter(b => b.tenantId && !b.former);
    if (!tenants.length) {
      await sendText(from, "❌ No active tenants to move out.");
      return sendRecurringBillingMenu(from);
    }
    biz.sessionState = "rb_vacate_pick";
    biz.sessionData  = {
      rbVacateList: tenants.map(t => ({
        tenantId: t.tenantId.toString(), accountId: t.accountId.toString(),
        label: t.label, balance: t.balance, currency: t.currency
      }))
    };
    await saveBizSafe(biz);
    return sendNumberedPicker(from, "🚪 *Move Out Tenant* - who has left?",
      tenants.map(t => ({ id: t.tenantId.toString(), label: `${t.label} - Bal: ${t.balance.toFixed(2)} ${t.currency}` }))
    );
  }

  // ── Account picker pagination (kept for any other callers of the old list) ─
  if (a?.startsWith("rb_more_")) {
    if (!biz) return sendMainMenu(from);
    const offset = parseInt(a.replace("rb_more_", ""), 10) || 0;
    const { listAccountsForChatbot } = await import("./recurringBilling.js");
    const { sendRbAccountPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const accounts = await listAccountsForChatbot(biz._id, branchId);
    return sendRbAccountPicker(from, accounts, offset);
  }

  // ── Invoice ONE account now - numbered picker, NOT a bulk all-at-once run ──
  // This is the recommended, day-to-day way to raise an invoice: pick the
  // one account that needs invoicing right now. The system will refuse if
  // that account/tenant has already been invoiced this period (the lock -
  // see rb_invoice_pick_account below), so it can never be double-billed.
  if (a === "rb_generate_invoices") {
    if (!biz) return sendMainMenu(from);
    const { listBillablesForChatbot } = await import("./recurringBilling.js");
    const { sendNumberedPicker } = await import("./metaMenus.js");
    const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
    const billables = await listBillablesForChatbot(biz._id, branchId);
    if (!billables.length) {
      await sendText(from, "❌ No active accounts found.");
      return sendRecurringBillingMenu(from);
    }
    biz.sessionState = "rb_invoice_pick_account";
    biz.sessionData  = {
      rbBillables: billables.map(b => ({
        accountId: b.accountId.toString(), tenantId: b.tenantId ? b.tenantId.toString() : null,
        label: b.label
      }))
    };
    await saveBizSafe(biz);
    await sendText(from, `ℹ️ Invoicing is *locked to once per billing period* - if an account/tenant was already invoiced this month, it will be skipped automatically.\n\nPick ONE number to invoice now, SEVERAL numbers (e.g. *1,5,12*) to invoice them together, or type *ALL* for the full monthly batch:`);
    return sendNumberedPicker(from, "📄 *Generate Invoice* - who is this for?",
      billables.map(b => ({ id: b.label, label: b.label }))
    );
  }

  // ── Send payment reminders to all tenants with outstanding balances ────────
  if (a === "rb_reminders") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    await sendText(from, "📢 Sending payment reminders to tenants...");
    try {
      const { broadcastPaymentReminders } = await import("./recurringBilling.js");
      const branchId = caller?.role !== "owner" ? caller?.branchId || null : null;
      const result = await broadcastPaymentReminders({ biz, branchId });
      await sendText(from,
        `✅ *Reminders Sent*\n\n📤 Sent: ${result.sent}\n⏭ Skipped (no balance): ${result.skipped}` +
        (result.errors.length ? `\n⚠️ Errors: ${result.errors.length}` : "")
      );
    } catch (e) {
      await sendText(from, `❌ Failed to send reminders: ${e.message}`);
    }
    return sendRecurringBillingMenu(from);
  }

  // ── rb_acct_{id} tapped outside a state flow → show account summary ───────
  if (a?.startsWith("rb_acct_") && biz && !biz.sessionState?.startsWith("rb_")) {
    const acctId = a.replace("rb_acct_", "");
    try {
      const RecurringAccount = (await import("../models/recurringAccount.js")).default;
      const { recomputeAccountBalance } = await import("./recurringBilling.js");
      const acct = await RecurringAccount.findOne({ _id: acctId, businessId: biz._id }).lean();
      if (!acct) { await sendText(from, "❌ Account not found."); return sendRecurringBillingMenu(from); }
      const balance = await recomputeAccountBalance(biz._id, acct._id);
      const cur = acct.currency || biz.currency || "USD";
      await sendText(from,
        `🏠 *${acct.name}*${acct.ref ? ` (${acct.ref})` : ""}\n` +
        `📋 ${acct.description || acct.category}\n` +
        `💵 Charge: ${acct.billingAmount} ${cur}/${acct.billingCycle}\n` +
        `💰 Balance: *${balance.toFixed(2)} ${cur}*\n` +
        `📅 Last invoiced: ${acct.lastInvoicedAt ? new Date(acct.lastInvoicedAt).toLocaleDateString("en-GB") : "Never"}`
      );
    } catch (e) {
      await sendText(from, `❌ Error: ${e.message}`);
    }
    return sendRecurringBillingMenu(from);
  }

  // ── Reports ────────────────────────────────────────────────────────────────
  //
  // Two reports only: Detailed Ledger + Clerk Statement (+ self-serve variant).
  // Date filter is embedded in the menu - user picks report+period in one tap.
  // Custom date: user types range → report runs.
  // Clerk statement: admin picks clerk after period; clerk/manager sees self.
  //
  // Action patterns:
  //   rpt_ledger_{today|week|month|custom}
  //   rpt_clerk_{today|week|month|custom}   ← admin, picks clerk next
  //   rpt_self_{today|week|month|custom}    ← self-serve (clerk/manager)
  //

  // ── Detailed Ledger ───────────────────────────────────────────────────────
  if (a === "rpt_ledger_today") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_detailed"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }
  if (a === "rpt_ledger_week") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_detailed_week"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }
  if (a === "rpt_ledger_month") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_detailed_month"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }
  if (a === "rpt_ledger_alltime") {
    if (!biz) return sendMainMenu(from);
    const { runDetailedLedgerReport } = await import("./dailyReportEnhanced.js");
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    return runDetailedLedgerReport({ biz, from, period: "alltime" });
  }

  if (a === "rpt_ledger_custom") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_date_filter";
    biz.sessionData  = { filterFor: "detailed" };
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: '🗓 *Detailed Ledger - Custom Date Range*\n\nType a date range in any of these formats:\n\n*Same month:*\n  01 Jun - 27 Jun\n  01/06 - 27/06\n\n*Across months:*\n  01 Apr - 01 Jul\n  01/04 - 01/07\n  01/04/2026 - 01/07/2026\n\n*ISO format:*\n  2026-06-01 - 2026-07-01\n\n*Month names (Jan–Dec):*\n  Jan  Feb  Mar  Apr  May  Jun\n  Jul  Aug  Sep  Oct  Nov  Dec\n\nOr type *cancel* to go back.',
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }

  // ── Clerk Statement (admin/owner - picks a clerk) ─────────────────────────
  if (a === "rpt_clerk_alltime") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_clerk_pick";
    biz.sessionData  = { clerkPeriod: "alltime" };
    await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }

  if (a === "rpt_clerk_today" || a === "rpt_clerk_week" || a === "rpt_clerk_month" || a === "rpt_clerk_custom") {
    if (!biz) return sendMainMenu(from);
    const clkPeriodMap = { rpt_clerk_today: "day", rpt_clerk_week: "week", rpt_clerk_month: "month", rpt_clerk_custom: "custom" };
    const clkPeriod    = clkPeriodMap[a] || "day";
    if (a === "rpt_clerk_custom") {
      biz.sessionState = "report_date_filter";
      biz.sessionData  = { filterFor: "clerk" };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: '🗓 *Clerk Statement - Custom Date Range*\n\nType a date range in any of these formats:\n\n*Same month:*\n  01 Jun - 27 Jun\n  01/06 - 27/06\n\n*Across months:*\n  01 Apr - 01 Jul\n  01/04/2026 - 01/07/2026\n\n*ISO format:*\n  2026-06-01 - 2026-07-01\n\n*Month names (Jan–Dec):*\n  Jan  Feb  Mar  Apr  May  Jun\n  Jul  Aug  Sep  Oct  Nov  Dec\n\nOr type *cancel* to go back.',
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }
    biz.sessionState = "report_clerk_pick";
    biz.sessionData  = { clerkPeriod: clkPeriod };
    await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }

  // ── Self Statement (clerk/manager - views own statement) ──────────────────
  if (a === "rpt_self_alltime") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_clerk_statement";
    biz.sessionData  = { clerkPeriod: "alltime", clerkPhone: caller?.phone || null };
    await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }

  if (a === "rpt_self_today" || a === "rpt_self_week" || a === "rpt_self_month" || a === "rpt_self_custom") {
    if (!biz) return sendMainMenu(from);
    const selfPeriodMap = { rpt_self_today: "day", rpt_self_week: "week", rpt_self_month: "month", rpt_self_custom: "custom" };
    const selfPeriod    = selfPeriodMap[a] || "day";
    if (a === "rpt_self_custom") {
      biz.sessionState = "report_date_filter";
      biz.sessionData  = { filterFor: "clerk_self" };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: '🗓 *My Statement - Custom Date Range*\n\nType a date range in any of these formats:\n\n*Same month:*\n  01 Jun - 27 Jun\n  01/06 - 27/06\n\n*Across months:*\n  01 Apr - 01 Jul\n  01/04/2026 - 01/07/2026\n\n*ISO format:*\n  2026-06-01 - 2026-07-01\n\n*Month names (Jan–Dec):*\n  Jan  Feb  Mar  Apr  May  Jun\n  Jul  Aug  Sep  Oct  Nov  Dec\n\nOr type *cancel* to go back.',
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }
    biz.sessionState = "report_clerk_statement";
    biz.sessionData  = { clerkPeriod: selfPeriod, clerkPhone: caller?.phone || null };
    await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }

  // ── Custom date clerk pick: rpt_clk_custom_pick_{phone} ──────────────────
  if (a?.startsWith("rpt_clk_custom_pick_")) {
    if (!biz) return sendMainMenu(from);
    const { runClerkStatementReport } = await import("./dailyReportEnhanced.js");
    const clerkPhone  = a.replace("rpt_clk_custom_pick_", "");
    const customStart = biz.sessionData?.customStart ? new Date(biz.sessionData.customStart) : null;
    const customEnd   = biz.sessionData?.customEnd   ? new Date(biz.sessionData.customEnd)   : null;
    biz.sessionState  = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    return runClerkStatementReport({ biz, from, clerkPhone, period: "custom", customStart, customEnd });
  }

  // ── Legacy/compat: old action IDs bounce to new reports menu ─────────────
  if (
    a === ACTIONS.DAILY_REPORT  ||
    a === ACTIONS.WEEKLY_REPORT ||
    a === ACTIONS.MONTHLY_REPORT ||
    a === ACTIONS.DETAILED_REPORT ||
    a === ACTIONS.CLERK_STATEMENT
  ) {
    if (!biz) return sendMainMenu(from);
    const isGold   = ["gold", "enterprise"].includes(biz.package);
    const isSilver = ["silver", "gold", "enterprise"].includes(biz.package);
    return sendReportsMenu(from, isGold, isSilver);
  }

  if (a === ACTIONS.BRANCH_REPORT) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_choose_branch"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }

  // ── Clerk picker result: clerk_stmt_pick_{phone} ──────────────────────────
  if (a?.startsWith("clerk_stmt_pick_")) {
    if (!biz) return sendMainMenu(from);
    const { runClerkStatementReport } = await import("./dailyReportEnhanced.js");
    const clerkPhone = a.replace("clerk_stmt_pick_", "");
    const period     = biz.sessionData?.clerkPeriod || "day";
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    return runClerkStatementReport({ biz, from, clerkPhone, period });
  }

  // ── Branch sub-report shortcuts (from branch_reports menu) ───────────────
  if (a === "branch_detailed") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_detailed"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }
  if (a === "branch_clerk") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "report_clerk_pick"; biz.sessionData = {}; await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "auto" });
  }
  // Legacy branch_daily / branch_weekly / branch_monthly → new reports menu (scoped to branch)
  if (a === "branch_daily" || a === "branch_weekly" || a === "branch_monthly") {
    if (!biz) return sendMainMenu(from);
    const isGold   = ["gold", "enterprise"].includes(biz.package);
    const isSilver = ["silver", "gold", "enterprise"].includes(biz.package);
    const { sendBranchReportsMenu } = await import("./metaMenus.js");
    return sendBranchReportsMenu(from, isGold, isSilver);
  }

  // ── Product text input states ──────────────────────────────────────────────

 if (biz?.sessionState === "product_add_name") {
    const raw = text?.trim();
    if (!raw || raw.length < 2) {
      await sendButtons(from, {
        text:
          "❌ Enter a valid product name.\n\n" +
          "Add multiple at once with commas:\n" +
          "_cement, river sand, pit sand, bricks_\n\n" +
          "You do not need to add prices now.",
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
      return;
    }
 
    const names = parseCommaNames(raw);
    if (names.length === 0) {
      await sendButtons(from, {
        text: "❌ Enter at least one name (minimum 2 characters):",
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
      return;
    }
 
    // Show preview before saving
    const preview = buildSavePreviewText(names, false);
    const savedBranchId = biz.sessionData?.targetBranchId;
 
    biz.sessionState = "product_add_preview";
    biz.sessionData  = {
      targetBranchId: savedBranchId,
      pendingNames:   names,
      isService:      false
    };
    await saveBizSafe(biz);
 
    return sendButtons(from, {
      text: preview,
      buttons: [
        { id: "prod_preview_save",   title: "✅ Save Products" },
        { id: "prod_preview_edit",   title: "✏️ Edit List"     },
        { id: "prod_preview_cancel", title: "❌ Cancel"        }
      ]
    });
  }
 
 
 

 

  // ── Bulk upload products ───────────────────────────────────────────────────

  if (biz && biz.sessionState === "bulk_upload_products" && !isMetaAction) {
    const msg = (text || "").trim();

    if (msg.toLowerCase() === "cancel") {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Bulk upload cancelled.");
      return sendProductsMenu(from);
    }

    if (msg.toLowerCase() === "done") {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "✅ Bulk upload finished.");
      return sendProductsMenu(from);
    }

    const lines = msg.split("\n").map(l => l.trim()).filter(Boolean);
    const parsed = [], failed = [];

    for (const line of lines) {
      const m = line.match(/^(.+?)\s*[-|:]\s*(\d+(\.\d+)?)\s*$/);
      if (!m) { failed.push(line); continue; }
      const name = m[1].trim();
      const unitPrice = Number(m[2]);
      if (!name || Number.isNaN(unitPrice) || unitPrice < 0) { failed.push(line); continue; }
      parsed.push({ name, unitPrice });
    }

    if (!parsed.length) {
      await sendText(from, `❌ Couldn't read any valid lines.\n\nUse:\nMilk 1L - 1.50\nMath Lesson | 10\n\nInvalid:\n${failed.slice(0, 5).join("\n") || "(none)"}`);
      return;
    }

    const effectiveBranchId = getEffectiveBranchId(caller, biz.sessionData);

    await Product.insertMany(
      parsed.map(p => ({ businessId: biz._id, branchId: effectiveBranchId, name: p.name, unitPrice: p.unitPrice, isActive: true })),
      { ordered: false }
    ).catch(() => {});

    let reply = `✅ Imported: ${parsed.length}`;
    if (failed.length) reply += `\n❌ Skipped: ${failed.length}\n\nExamples skipped:\n${failed.slice(0, 5).join("\n")}`;
    reply += `\n\nSend more lines, or reply *done* to finish.`;
    return sendText(from, reply);
  }

  // ── Bulk expense input ─────────────────────────────────────────────────────

  // ── Bulk expense input (ENHANCED WITH NATURAL LANGUAGE) ───────────────────

// ── Bulk expense input (COMMA-SEPARATED FORMAT) ───────────────────────────

  if (biz && biz.sessionState === "bulk_expense_input" && !isMetaAction) {
    const textRaw = (text || "").trim();
    const textLower = textRaw.toLowerCase();

    // ✅ Handle empty input
    if (!textRaw) {
      await sendText(from, "❌ Type expenses separated by commas.\n\nExample: lunch 10, fuel 20, tea 5");
      return;
    }

    // ✅ Handle 'done' command
    if (textLower === "done" || textLower === "finish" || textLower === "save") {
      const expenseCount = biz.sessionData?.bulkExpenses?.length || 0;
      
      if (expenseCount === 0) {
        biz.sessionState = "ready"; 
        biz.sessionData = {};
        await saveBizSafe(biz);
        await sendText(from, "❌ No expenses to save.");
        return sendPaymentsMenu(from);
      }

      // Move to confirmation
      biz.sessionState = "bulk_expense_confirm";
      await saveBizSafe(biz);

      const { formatBulkSummary } = await import("./expenseParser.js");
      const cur = currencySymbol(biz.currency);
      const summary = formatBulkSummary(biz.sessionData.bulkExpenses, cur);
      
      await sendText(from, `${summary}\n*Confirm?* (yes/no)`);
      return;
    }

    // ✅ Handle 'cancel' command
    if (textLower === "cancel" || textLower === "stop") {
      const count = biz.sessionData?.bulkExpenses?.length || 0;
      biz.sessionState = "ready"; 
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, count > 0 
        ? `❌ Cancelled. Discarded ${count} expense(s).`
        : "❌ Cancelled.");
      return sendPaymentsMenu(from);
    }

    // ✅ Handle 'list' command
   // ✅ Handle 'list' command
    if (textLower === "list" || textLower === "show") {
      const expenses = biz.sessionData?.bulkExpenses || [];
      
      if (expenses.length === 0) {
        await sendText(from, "📝 No expenses yet.\n\nExample: lunch 10, fuel 20");
        return;
      }

      const expenseParser = await import("./expenseParser.js");
      const cur = currencySymbol(biz.currency);
      
      let list = `📝 *Current Expenses (${expenses.length})*\n\n`;
      list += expenseParser.formatExpenseList(expenses, 1, cur);
      const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
      list += `\n*Total: ${cur}${total.toFixed(2)}*\n\nType 'done' to save.`;
      
      await sendText(from, list);
      return;
    }

    // ✅ Handle 'remove N' command
   // ✅ Handle 'remove N' command
    const removeMatch = textLower.match(/^(?:remove|delete|clear)\s+(\d+)$/);
    if (removeMatch) {
      const index = parseInt(removeMatch[1]);
      const expenses = biz.sessionData?.bulkExpenses || [];
      
      if (index < 1 || index > expenses.length) {
        await sendText(from, `❌ Invalid. You have ${expenses.length} expense(s).\n\nType 'list' to see all.`);
        return;
      }
      
      const removed = expenses.splice(index - 1, 1)[0];
      await saveBizSafe(biz);
      
      const expenseParser = await import("./expenseParser.js");
      const cur = currencySymbol(biz.currency);
      const emoji = expenseParser.getCategoryEmoji(removed.category);
      
      await sendText(from, `✅ Removed: ${emoji} ${cur}${removed.amount.toFixed(2)} - ${removed.description}\n\n${expenses.length} expense(s) remaining.`);
      return;
    }
    // ✅ Handle 'clear' or 'clear all' command
    if (textLower === "clear" || textLower === "clear all" || textLower === "reset") {
      const count = biz.sessionData?.bulkExpenses?.length || 0;
      biz.sessionData.bulkExpenses = [];
      await saveBizSafe(biz);
      await sendText(from, `✅ Cleared ${count} expense(s).\n\nStart fresh: lunch 10, fuel 20`);
      return;
    }

    // ✅ Handle 'help' command
    if (textLower === "help" || textLower === "?") {
      await sendText(from,
`💡 *Bulk Expense Help*

*Format:*
description amount, description amount

*Examples:*
- lunch 10, fuel 20, tea 5
- office supplies 50
- transport 15, airtime 10

*Commands:*
- 'list' - Show all expenses
- 'remove 3' - Delete expense #3
- 'clear' - Remove all expenses
- 'done' - Save everything
- 'cancel' - Discard all

Categories auto-detected ✨`);
      return;
    }

    // ✅ PARSE COMMA-SEPARATED EXPENSES
   // ✅ PARSE COMMA-SEPARATED EXPENSES
    const expenseParser = await import("./expenseParser.js");
    const { parseBulkExpenseText, formatExpenseList, getCategoryEmoji: getExpenseCategoryEmoji } = expenseParser;
    
    const result = parseBulkExpenseText(textRaw);
    
    if (result.error || result.expenses.length === 0) {
      let errorMsg = `❌ ${result.error || "Couldn't parse expenses"}\n\n`;
      errorMsg += `*Format:* description amount, description amount\n`;
      errorMsg += `*Example:* lunch 10, fuel 20, tea 5\n\n`;
      if (result.failed && result.failed.length > 0) {
        errorMsg += `Failed to parse:\n${result.failed.slice(0, 3).join('\n')}`;
      }
      await sendText(from, errorMsg);
      return;
    }
    
    // Initialize expenses array if needed
    if (!biz.sessionData.bulkExpenses) {
      biz.sessionData.bulkExpenses = [];
    }
    
    // Add all parsed expenses
    const startIndex = biz.sessionData.bulkExpenses.length + 1;
    biz.sessionData.bulkExpenses.push(...result.expenses);
    await saveBizSafe(biz);
    
    const count = biz.sessionData.bulkExpenses.length;
    const total = biz.sessionData.bulkExpenses.reduce((sum, exp) => sum + exp.amount, 0);
    const cur = currencySymbol(biz.currency);
    
    // Build response
    let response = `✅ Added ${result.expenses.length} expense(s):\n\n`;
    response += formatExpenseList(result.expenses, startIndex, cur);
    response += `\n*Total: ${cur}${total.toFixed(2)}* (${count} items)\n\n`;
    
    if (result.failed && result.failed.length > 0) {
      response += `⚠️ Skipped ${result.failed.length}:\n${result.failed.slice(0, 2).join(', ')}\n\n`;
    }
    
    response += `Continue or type 'done' to save`;
    
    await sendText(from, response);
    return;
  }

  // ✅ Bulk expense confirmation (keep this unchanged)
  if (biz && biz.sessionState === "bulk_expense_confirm" && !isMetaAction) {
    const textLower = text.toLowerCase().trim();
    
    if (textLower === "yes" || textLower === "y" || textLower === "confirm") {
      const expenses = biz.sessionData?.bulkExpenses || [];
      
      if (expenses.length === 0) {
        biz.sessionState = "ready"; 
        biz.sessionData = {};
        await saveBizSafe(biz);
        await sendText(from, "❌ No expenses to save.");
        return sendPaymentsMenu(from);
      }
      
      try {
        const Expense = (await import("../models/expense.js")).default;
        const effectiveBranchId = getEffectiveBranchId(caller, biz.sessionData);
        
        // Save all expenses to database
        const expenseDocs = expenses.map(exp => ({
          businessId: biz._id,
          branchId: effectiveBranchId,
          amount: exp.amount,
          description: exp.description,
          category: exp.category,
          method: "Cash",
          createdBy: phone
        }));
        
        await Expense.insertMany(expenseDocs);
        
        // Clear session
        const count = expenses.length;
        const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
        const cur = currencySymbol(biz.currency);
        
        biz.sessionState = "ready"; 
        biz.sessionData = {};
        await saveBizSafe(biz);
        
        await sendText(from, `✅ *Success!*\n\nSaved ${count} expenses totaling ${cur}${total.toFixed(2)}`);
        return sendPaymentsMenu(from);
        
      } catch (error) {
        console.error('[Bulk Expense Save Error]', error);
        await sendText(from, `❌ Error: ${error.message}\n\nType 'yes' to retry or 'no' to cancel.`);
        return;
      }
    }
    
    if (textLower === "no" || textLower === "n" || textLower === "cancel") {
      const count = biz.sessionData?.bulkExpenses?.length || 0;
      biz.sessionState = "ready"; 
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, `❌ Cancelled. Discarded ${count} expense(s).`);
      return sendPaymentsMenu(from);
    }
    
    await sendText(from, `Reply 'yes' to save or 'no' to cancel.`);
    return;
  }

  // ✅ NEW STATE: Bulk expense confirmation
  if (biz && biz.sessionState === "bulk_expense_confirm" && !isMetaAction) {
    const textLower = text.toLowerCase().trim();
    
    if (textLower === "yes" || textLower === "y" || textLower === "confirm") {
      const expenses = biz.sessionData?.bulkExpenses || [];
      
      if (expenses.length === 0) {
        biz.sessionState = "ready"; 
        biz.sessionData = {};
        await saveBizSafe(biz);
        await sendText(from, "❌ No expenses to save.");
        return sendPaymentsMenu(from);
      }
      
      try {
        const Expense = (await import("../models/expense.js")).default;
        const effectiveBranchId = getEffectiveBranchId(caller, biz.sessionData);
        
        // Save all expenses to database
        const expenseDocs = expenses.map(exp => ({
          businessId: biz._id,
          branchId: effectiveBranchId,
          amount: exp.amount,
          description: exp.description,
          category: exp.category,
          method: exp.method || "Cash",
          createdBy: phone
        }));
        
        await Expense.insertMany(expenseDocs);
        
        // Clear session
        const count = expenses.length;
        const total = expenses.reduce((sum, exp) => sum + exp.amount, 0);
        const cur = currencySymbol(biz.currency);
        
        biz.sessionState = "ready"; 
        biz.sessionData = {};
        await saveBizSafe(biz);
        
        const { formatBulkSummary } = await import("./expenseParser.js");
        const summary = formatBulkSummary(expenses, cur);
        
        await sendText(from, `✅ *Success!*\n\nSaved ${count} expenses totaling ${cur}${total.toFixed(2)} to the system.\n\n${summary}\nType 'bulk expense' to add more.`);
        return sendPaymentsMenu(from);
        
      } catch (error) {
        console.error('[Bulk Expense Save Error]', error);
        await sendText(from, `❌ Error saving expenses: ${error.message}\n\nYour data is still here. Type 'yes' to retry or 'no' to cancel.`);
        return;
      }
    }
    
    if (textLower === "no" || textLower === "n" || textLower === "cancel") {
      const count = biz.sessionData?.bulkExpenses?.length || 0;
      biz.sessionState = "ready"; 
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, `❌ Cancelled. Discarded ${count} expense(s).`);
      return sendPaymentsMenu(from);
    }
    
    await sendText(from, `Please reply 'yes' to save or 'no' to cancel.`);
    return;
  }
  // ── Bulk paste products ────────────────────────────────────────────────────

  if (biz && biz.sessionState === "bulk_paste_input" && !isMetaAction) {
    const textRaw = (text || "").trim();

    if (!textRaw) { await sendText(from, "❌ Paste at least one product or type *done* to finish."); return; }

    if (textRaw.toLowerCase() === "done") {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "✅ Bulk paste complete.");
      return sendProductsMenu(from);
    }

    const items = textRaw.split(/[|\n]/).map(i => i.trim()).filter(Boolean);
    const effectiveBranchId = getEffectiveBranchId(caller, biz.sessionData);
    let created = 0, skipped = 0;

    for (const item of items) {
      const parts = item.split(",").map(p => p.trim());
      if (parts.length < 2) { skipped++; continue; }
      const name = parts[0];
      const unitPrice = Number(parts[1]);
      if (!name || name.length < 2 || Number.isNaN(unitPrice) || unitPrice <= 0) { skipped++; continue; }

      await Product.create({ businessId: biz._id, branchId: effectiveBranchId, name, unitPrice, isActive: true });
      created++;
    }

    let reply = `✅ Imported *${created}* products`;
    if (skipped > 0) reply += `\n⚠️ Skipped *${skipped}* (invalid format)`;
    reply += `\n\nType more or reply *done* to finish.`;
    return sendText(from, reply);
  }

  // =========================
  // 🏢 ONBOARDING
  // =========================
  if (biz && biz.sessionState === "awaiting_business_name") {
    const name = text;
    if (!name || name.length < 2) { await sendText(from, "❌ Please enter a valid business name:"); return; }
    biz.name = name;
    biz.sessionState = "awaiting_address";
    await saveBizSafe(biz);
    await sendButtons(from, {
      text: "📍 Would you like to add your business address?\n(It will appear on invoices & receipts)",
      buttons: [{ id: "onb_address_yes", title: "Add address" }, { id: "onb_address_skip", title: "Skip" }]
    });
    return;
  }

  // ── Settings text states ───────────────────────────────────────────────────

const settingsStates = [
    "settings_currency", "settings_terms", "settings_inv_prefix",
    "settings_qt_prefix", "settings_rcpt_prefix", "settings_address", "bulk_upload_products",
    "awaiting_business_name", "awaiting_address_input", "awaiting_currency",
    "awaiting_logo", "awaiting_logo_upload"
  ];
  // =========================
  // 💳 SUBSCRIPTION: ENTER ECOCASH NUMBER
  // =========================
  if (biz && biz.sessionState === "subscription_enter_ecocash" && !isMetaAction) {
    const waDigits = from.replace(/\D+/g, "");
    const ecocashPhone = normalizeEcocashNumber(text, waDigits);

    if (!ecocashPhone) {
      await sendText(from, "❌ Invalid EcoCash number.\n\nSend like: 0772123456\nOr type *same* to use this WhatsApp number.");
      return;
    }

    biz.sessionState = "subscription_payment_pending";
    biz.sessionData = { ...(biz.sessionData || {}), ecocashPhone };
    await saveBizSafe(biz);

    const selected = biz.sessionData?.targetPackage;
    const plan = selected ? SUBSCRIPTION_PLANS[selected] : null;

    if (!plan) {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Package info missing. Please select a package again.");
      return sendMainMenu(from);
    }

    const reference = `SUB_${biz._id}_${Date.now()}`;
    const payment = paynow.createPayment(reference, biz.ownerEmail || "bmusasa99@gmail.com");
    payment.currency = plan.currency;
    const chargeAmount = biz.sessionData?.amount || plan.price;
    payment.add(`${plan.name} Package`, chargeAmount);

    const response = await paynow.sendMobile(payment, ecocashPhone, "ecocash");

    await SubscriptionPayment.create({
      businessId: biz._id, packageKey: selected, amount: chargeAmount,
      currency: plan.currency, reference, pollUrl: response.pollUrl,
      ecocashPhone, status: "pending"
    });

   if (!response.success || !response.pollUrl) {
  biz.sessionState = "subscription_enter_ecocash";
  biz.sessionData = { ...(biz.sessionData || {}), ecocashPhone };
  await saveBizSafe(biz);
  await sendText(from, "❌ Failed to start EcoCash payment.\n\nPlease enter your EcoCash number again.\nSend like: 0772123456\nOr type *same* to use this WhatsApp number.");
  return;
}

    biz.sessionData.paynow = { reference, pollUrl: response.pollUrl };
    await saveBizSafe(biz);

    const pollUrl = response.pollUrl;
    let attempts = 0;
    const MAX_ATTEMPTS = 15;

    const pollInterval = setInterval(async () => {
      attempts++;
      try {
        const status = await paynow.pollTransaction(pollUrl);

        if (status.status && status.status.toLowerCase() === "paid") {
          clearInterval(pollInterval);
          const freshBiz = await Business.findById(biz._id);

          if (freshBiz?.sessionState === "subscription_payment_pending" && freshBiz.sessionData?.targetPackage) {
            const now = new Date();
            const target = freshBiz.sessionData?.targetPackage;
            const plan = target ? SUBSCRIPTION_PLANS[target] : null;
            if (!plan) return;

            const currentEnds = freshBiz.subscriptionEndsAt ? new Date(freshBiz.subscriptionEndsAt) : null;
            const hasActive = currentEnds && currentEnds.getTime() > now.getTime();

            if (!hasActive) {
              freshBiz.subscriptionStartedAt = now;
              freshBiz.subscriptionEndsAt = new Date(now.getTime() + plan.durationDays * 24 * 60 * 60 * 1000);
            }

            freshBiz.package = target;
            freshBiz.subscriptionStatus = "active";

            const payRec = await SubscriptionPayment.findOne({ businessId: freshBiz._id, reference }).sort({ createdAt: -1 });
            const receiptNumber = `SUB-${reference.slice(-8).toUpperCase()}`;

            const { filename } = await generatePDF({
              type: "receipt", number: receiptNumber, date: now,
              billingTo: `${freshBiz.name} (Subscription)`,
              items: [{ item: `${plan.name} Package`, qty: 1, unit: payRec?.amount || plan.price, total: payRec?.amount || plan.price }],
              bizMeta: { name: "Zimqoute", logoUrl: "", address: "Zimqoute", _id: freshBiz._id.toString(), status: "paid" }
            });

            const site = (process.env.SITE_URL || "").replace(/\/$/, "");
            const receiptUrl = `${site}/docs/generated/receipts/${filename}`;

            if (payRec) {
              payRec.status = "paid"; payRec.paidAt = now;
              payRec.receiptFilename = filename; payRec.receiptUrl = receiptUrl;
              await payRec.save();
            }

            freshBiz.sessionState = "ready"; freshBiz.sessionData = {};
            await freshBiz.save();

            await sendDocument(from, { link: receiptUrl, filename });
            await sendText(from,
`✅ Payment successful!

Package: *${freshBiz.package.toUpperCase()}*
Next due date: *${freshBiz.subscriptionEndsAt ? freshBiz.subscriptionEndsAt.toDateString() : "N/A"}*`);
            await sendMainMenu(from);
          }
        }

        if (attempts >= MAX_ATTEMPTS) clearInterval(pollInterval);
      } catch (err) { console.error("Paynow polling failed:", err); }
    }, 10000);

    await sendText(from, `💳 ${plan.name} Package (${chargeAmount} ${plan.currency})\nEcoCash number: ${ecocashPhone}\n\nPlease confirm the payment on your phone.`);
    return;
  }

  // ── Pass text to Twilio state machine ─────────────────────────────────────

//const escapeWords = ["menu", "hi", "hello", "start", "cancel"];
const escapeWords = ["menu", "hi", "hie", "hey", "hello", "helo", "howzit", "help", "start", "cancel", "yo", "sup"];

  // Pass supplier registration states to the state bridge
const supplierStates = [
 "supplier_reg_name", "supplier_reg_area", "supplier_reg_address", "supplier_reg_products",
  "supplier_reg_contact_details", "supplier_reg_website", "supplier_reg_collar", "supplier_reg_subcat",
  "supplier_reg_prices", "supplier_update_prices",
  "supplier_edit_products", "supplier_edit_area",
  "supplier_reg_confirm", "supplier_reg_enter_ecocash",
  "supplier_reg_payment_pending", "supplier_search_city", "supplier_decline_reason",
  "supplier_reg_type",
  "supplier_reg_travel",
  "supplier_reg_teacher_details",
  "supplier_reg_tourism_details",
  "supplier_reg_hospitality_subtype",
  "supplier_reg_hospitality_rooms",
  "supplier_reg_hospitality_facilities",
  "supplier_reg_hospitality_rest_rates",
  "supplier_reg_hospitality_extra_services",
  "supplier_reg_hospitality_areas",
  "supplier_reg_city",
  "supplier_reg_category",
  "supplier_reg_delivery",
  "supplier_search_product",
  "supplier_order_product",
  "supplier_order_address",
  "supplier_order_enter_price",
  "supplier_order_confirm_price",
  "supplier_order_picking",
  "supplier_reg_biz_currency",
"supplier_select_listed_products",
  "supplier_add_listed_products",
  // ── School registration states (go through same biz session machine) ──────
  "supplier_reg_listing_type",
  "school_reg_name",
  "school_reg_city_text",
  "school_reg_suburb",
  "school_reg_address",
  "school_reg_fees",
  "school_reg_principal",
  "school_reg_email",
  "school_reg_enter_ecocash",
  "school_reg_payment_pending",
  "school_reg_choose_plan",
  "school_reg_confirm",
  "school_reg_type",
  "school_reg_curriculum",
  "school_reg_gender",
  "school_reg_boarding",
  "school_reg_facilities",
  "school_reg_extramural",
  "school_search_city",
  "school_search_results",
"school_admin_update_fees",
  "school_admin_awaiting_brochure",
  "school_parent_enquiry"
];
 
// ── School text-input states (free-text WhatsApp replies during school flow) ─
const schoolTextStates = [
  "school_reg_name",
  "school_reg_city_text",
  "school_reg_suburb",
  "school_reg_address",
  "school_reg_fees",
  "school_reg_principal",
  "school_reg_email",
  "school_reg_enter_ecocash",
  "school_reg_payment_pending"
];
 
// ── School admin text-input states ───────────────────────────────────────────
const schoolAdminStates = [
  "school_admin_update_fees",
  "school_admin_update_reg_link",
  "school_admin_update_email",
  "school_admin_update_website",
  "school_admin_awaiting_brochure",
  "school_parent_enquiry"
];

// ── Shortcode search for any user (runs BEFORE state machine) ─────────────
// supplier_search_city is excluded from the block - typed text in that state
// ── Shortcode search for any user (runs BEFORE state machine) ─────────────
// IMPORTANT:
// Business-tools free-text states must NEVER be intercepted here.
// They belong to continueTwilioFlow(...), not marketplace shortcode search.
const shortcodeBlockedStates = [
  ...supplierStates.filter(s =>
    s !== "supplier_search_city" &&
    s !== "supplier_order_product" &&
    s !== "supplier_order_enter_price"
  ),

 // Business tools text-entry states
  "expense_smart_entry",
  "expense_bulk_confirm",
  "bulk_expense_input",
  "payment_amount",
  "payment_method",
  "expense_amount",
  "expense_category",
  "cash_set_opening_balance",
  "cash_payout_amount",
  "cash_payout_reason",
  "cash_payout_source",
  "cash_payout_recipient",
  "sales_doc_search",
  "sales_doc_list",
  "sales_doc_filter",
  "client_statement_generate",

  // Invoice / quote / receipt - ALL states (text input OR button navigation)
  // Must be exhaustive: any missing state lets typed input trigger city selector
  "creating_invoice_new_client",
  "creating_invoice_new_client_phone",
  "creating_invoice_add_items",
  "creating_invoice_pick_product",
  "creating_invoice_enter_catalogue_prices",
  "creating_invoice_confirm",
  "creating_quote_enter_catalogue_prices",
  "creating_quote_confirm",
  "creating_receipt_enter_catalogue_prices",
  "creating_receipt_confirm",
  "creating_invoice_add_note",
  "creating_quote_add_note",
  "creating_receipt_add_note",
  "creating_invoice_qty",
  "creating_invoice_add_item_text",
  "creating_invoice_custom_names",
  "creating_invoice_custom_preview",
  "creating_invoice_custom_edit",
  "creating_quote_custom_names",
  "creating_quote_custom_preview",
  "creating_quote_custom_edit",
  "creating_receipt_custom_names",
  "creating_receipt_custom_preview",
  "creating_receipt_custom_edit",
  "creating_invoice_set_discount",
  "creating_invoice_set_vat",
  "creating_invoice_enter_prices",
  "invoice_quick_add_product_name",
  "invoice_quick_add_product_price",
  "quote_quick_add_product_name",
  "quote_quick_add_product_price",
  "receipt_quick_add_product_name",
  "receipt_quick_add_product_price",
  "creating_quote_new_client",
  "creating_quote_new_client_phone",
  "creating_quote_add_items",
  "creating_quote_pick_product",
  "creating_quote_qty",
  "creating_quote_add_item_text",
  "creating_quote_set_discount",
  "creating_quote_set_vat",
  "creating_quote_enter_prices",
  "creating_receipt_new_client",
  "creating_receipt_new_client_phone",
  "creating_receipt_add_items",
  "creating_receipt_pick_product",
  "creating_receipt_qty",
  "creating_receipt_add_item_text",
  "creating_receipt_set_discount",
  "creating_receipt_set_vat",
  "creating_receipt_enter_prices",
  "payment_invoice_search",
  "sales_doc_action",

  // Products & services text-entry states
  "product_add_name",
  "product_add_price",
  "product_edit_name",
  "product_edit_price",
  "product_add_name_or_menu",

  // Clients / branches / settings
  "settings_currency",
  "settings_terms",
  "settings_inv_prefix",
  "settings_qt_prefix",
  "settings_rcpt_prefix",
  "branch_add_name",
  "invite_user_phone",
  "add_client_name",
  "add_client_phone",
  "adding_client_name",
  "client_statement_choose_client",
  "client_statement_generate",
  "awaiting_address",
  "awaiting_business_name",
  "subscription_payment_pending",
  "subscription_enter_ecocash",

  // School parent enquiry text input
  "school_parent_enquiry",
  "school_admin_update_fees",
  "school_admin_update_reg_link",
  "school_admin_update_email",
  "school_admin_update_website",
  "school_admin_awaiting_brochure",

  // Service rate update states (text entry: "1x50/job, 2x100/job")
  // Without these, typed rate strings hit the shortcode search and trigger "Which city?"
  "service_update_rates",
  "service_update_rates_confirm_unit",
  "service_update_rates_confirm",

  // Report states - date text "01 Jun - 27 Jun" must never trigger shortcode search
  "report_date_filter",
  "report_clerk_pick_custom",
  "report_detailed",
  "report_detailed_week",
  "report_detailed_month",
  "report_detailed_year",
  "report_clerk_statement",
  "report_clerk_pick",
  "report_clerk_self",
  "report_choose_branch",
  "cash_handover_amount",
  "cash_handover_incoming",
  "cash_handover_note",
  // Recurring billing text-input states
  "rb_payment_pick_account",
  "rb_payment_pick_tenant",
  "rb_payment_review",
  "rb_payment_enter_amount",
  "rb_acct_stmt_pick_account",
  "rb_tenant_stmt_pick_account",
  "rb_expense_pick_account",
  "rb_expense_enter_details",
  // Move-out (vacate) + other-income states: without these, the numbered pick or
  // typed entry hits the shortcode search and triggers the "Which city?" prompt.
  "rb_vacate_pick",
  "rb_vacate_confirm",
  "rb_income_enter_details",
  "rb_income_confirm",
  "rb_expense_confirm",
  "rb_invoice_pick_account",
  "rb_invoice_review",
  "rb_acct_stmt_custom_date",
  "rb_tenant_stmt_pick_period",
  "rb_billing_stmt_pick_period",
  "rb_billing_stmt_custom_date",
  // ── Stock Control text-entry states ──
  "stock_add_name",
  "stock_add_unit",
  "stock_add_opening",
  "stock_add_cost",
  "stock_add_sell",
  "stock_add_reorder",
  "stock_add_aliases",
  "stock_add_pick",
  "stock_add_qty",
  "stock_in_pick",
  "stock_in_qty",
  "stock_adjust_pick",
  "stock_adjust_qty",
  "stock_report_period",
  "stock_report_custom_date"
];

if (
  !isMetaAction &&
  biz &&
  !isGhostSupplierBiz &&
  text.trim().length > 2 &&
  // FIX: ZQ: deep links (ZQ:GROUP:, ZQ:S:, ZQ:SUPPLIER:, ZQ:SCHOOL:) must never
  // be treated as shortcode searches - they have their own handlers further down.
  !/^ZQ:/i.test(text.trim()) &&
  // FIX: zqg_sel_ group seller taps must never be treated as shortcode searches
  !text.trim().toLowerCase().startsWith("zqg_") &&
  !shortcodeBlockedStates.includes(biz.sessionState) &&
  !settingsStates.includes(biz.sessionState) &&
  !schoolAdminStates.includes(biz.sessionState) &&
  !schoolTextStates.includes(biz.sessionState) &&
  !biz.sessionState?.startsWith("sc_")
) {

  console.log(`[HIT-BIZ-SHORTCODE] text="${text}" sessionState="${biz?.sessionState}"`);
  const shortcode = parseShortcodeSearch(text);
  console.log(`[TRACE-A] biz shortcode handler: text="${text}" sessionState="${biz?.sessionState}" shortcode=${JSON.stringify(shortcode)}`);
  if (shortcode) {
    await logSearchCommand({
  phone,
  rawText: text,
  source: "text",
  flow: "supplier_search",
  sessionState: biz?.sessionState || "",
  parsed: shortcode,
  resultMode: "unknown",
  botReplySummary: "Buyer typed supplier shortcode search"
});
if (shortcode.city) {
  const locationLabel = shortcode.area
    ? `${shortcode.area}, ${shortcode.city}`
    : shortcode.city;

  biz.sessionData = {
    ...(biz.sessionData || {}),
    supplierSearch: { product: shortcode.product, city: shortcode.city }
  };

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.supplierSearchProduct": shortcode.product,
        ...(shortcode.city ? { "tempData.lastSearchCity": shortcode.city } : {}),
        ...(shortcode.area ? { "tempData.lastSearchArea": shortcode.area } : {})
      }
    },
    { upsert: true }
  );

  // IMPORTANT:
  // For inline text like "find valve mbare", behave like city-picker flow.
  // Do NOT force suburb/area on offer search.
  console.log(
    `[TRACE-B] calling runSupplierOfferSearch city="${shortcode.city}" product="${shortcode.product}" area=NULL_FIRST_PASS originalArea="${shortcode.area}"`
  );
  let offerResults = [];

  try {
    offerResults = await runSupplierOfferSearch({
      city: shortcode.city,
      product: shortcode.product,
      area: null
    });

    console.log(`[TRACE-B2] offerResults.length=${offerResults.length}`);

    // If city-level offer search returns nothing, retry across all cities,
    // but still do NOT force area here.
    if (!offerResults.length) {
      offerResults = await runSupplierOfferSearch({
        city: null,
        product: shortcode.product,
        area: null
      });

      console.log(`[TRACE-B3] all-cities offerResults.length=${offerResults.length}`);
    }
  } catch (err) {
    await logSearchCommand({
      phone,
      rawText: text,
      source: "text",
      flow: "supplier_search",
      sessionState: biz?.sessionState || "",
      parsed: {
        product: shortcode.product || "",
        city: shortcode.city || "",
        area: shortcode.area || "",
        profileType: shortcode.profileType || ""
      },
      resultMode: "error",
      errorMessage: err.message,
      botReplySummary: "Supplier offer search crashed"
    });

    console.error("[SUPPLIER OFFER SEARCH ERROR]", err);
    return sendText(from, "❌ Search failed. Please try again or type *menu*.");
  }

  if (offerResults.length) {
    await logSearchCommand({
      phone,
      rawText: text,
      source: "text",
      flow: "supplier_search",
      sessionState: biz?.sessionState || "",
      parsed: {
        product: shortcode.product || "",
        city: shortcode.city || "",
        area: shortcode.area || "",
        profileType: shortcode.profileType || ""
      },
      resultMode: "offers",
      results: offerResults,
      botReplySummary: `Returned ${offerResults.length} offer results`
    });
    offerResults = await runSupplierOfferSearch({
      city: null,
      product: shortcode.product,
      area: null
    });
  }

  if (offerResults.length) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.searchResults": offerResults,
          "tempData.searchPage": 0,
          "tempData.searchResultMode": "offers"
        }
      },
      { upsert: true }
    );

    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: {
        product: shortcode.product,
        city: shortcode.city,
        ...(shortcode.area ? { area: shortcode.area } : {})
      },
      searchResults: offerResults,
      searchPage: 0,
      searchResultMode: "offers"
    };
    await saveBizSafe(biz);

    const pageOffers = offerResults.slice(0, 9);
    const rows = formatSupplierOfferResults(pageOffers, shortcode.product);

    if (offerResults.length > 9) {
      rows.push({
        id: "sup_search_next_page",
        title: `➡ More results (${offerResults.length - 9} more)`
      });
    }

    return sendNumberedSellerResults({
      from, phone,
      offers: offerResults,
      searchTerm: shortcode.product,
      locationLabel
    });
  }

  // Offers exhausted - fall back to supplier-level results before giving up,
  // mirroring the no-biz and ghost-biz paths exactly.
  const supplierFallback = await runSupplierSearch({
    city: shortcode.city || null,
    product: shortcode.product,
    area: shortcode.area || null
  });

  if (supplierFallback.length) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { product: shortcode.product, city: shortcode.city },
      searchResults: supplierFallback,
      searchPage: 0,
      searchResultMode: "suppliers"
    };
    await saveBizSafe(biz);
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.searchResults": supplierFallback, "tempData.searchPage": 0, "tempData.searchResultMode": "suppliers" } },
      { upsert: true }
    );
    const supplierRows = formatSupplierResults(supplierFallback.slice(0, 9), shortcode.city || shortcode.area || "", shortcode.product);
    if (supplierFallback.length > 9) {
      supplierRows.push({ id: "sup_search_next_page", title: `➡ More results (${supplierFallback.length - 9} more)` });
    }
    return sendNumberedSellerResults({ from, phone, suppliers: supplierFallback, searchTerm: shortcode.product, locationLabel });
  }
}
 // City was given but 0 results - show no-results message, NOT city picker
    if (shortcode.city) {
      biz.sessionData = { ...(biz.sessionData || {}), supplierSearch: { product: shortcode.product, city: shortcode.city } };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: `😕 No results for *${shortcode.product}* in *${shortcode.city}*.\n\nTry searching all of Zimbabwe?`,
        buttons: [
          { id: "sup_search_city_all", title: "📍 Search All Cities" },
          { id: "find_supplier",       title: "🔍 Search Again" }
        ]
      });
    }

    // No city at all - ask for it
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { product: shortcode.product }
    };
    biz.sessionState = "supplier_search_city";
    await saveBizSafe(biz);
    return sendList(from, `🔍 Looking for: *${shortcode.product}*\n\nWhich city?`, [
      ...SUPPLIER_CITIES.slice(0, 9).map(c => ({
        id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`,
        title: c
      })),
      { id: "sup_search_city_all", title: "📍 All Cities" }
    ]);
  }
}


// ── TOP-LEVEL REGISTRATION STATE DISPATCHER ─────────────────────────────────
// CRITICAL FIX: school text states (school_reg_name, school_reg_city_text, etc.)
// are excluded from the block below by the !schoolTextStates condition. This means
// handleSchoolRegistrationStates was NEVER reached for school text input states,
// leaving school registrants stuck after entering their school name.
// Supplier states (supplier_reg_name etc.) also need consistent saveBiz binding.
// This top-level block fires BEFORE the gated block, catches ALL reg states.
if (
  biz &&
  !isMetaAction &&
  biz.sessionState &&
  text.trim() &&
  !escapeWords.includes(al) &&
  !/^ZQ:/i.test(text.trim()) &&
  !text.trim().toLowerCase().startsWith("zqg_")
) {
  // ── School text-input states (MUST be here - excluded from block below) ──────
  if (schoolTextStates.includes(biz.sessionState)) {
    console.log("[REG-DISPATCH-TOPLVL] school text state:", biz.sessionState, "from:", from);

    // ── school_reg_fees: permissive parser prevents the stuck loop ──────────────
    // schoolRegistration.js expects a clean number or "500/600/700" format.
    // If the school types "$500 per term" or "USD 500", the handler may return
    // false leaving the user with no response and stuck in the same state.
    // We clean the input here, show a clear error with examples if no number
    // found, and force-advance the state if the handler still returns false.
    if (biz.sessionState === "school_reg_fees") {
      const _rawFeeText = (text || "").trim();
      // Skip = no fees / don't know
      const _skipWords = ["skip", "no", "none", "0", "don't know", "not sure", "later"];
      const _isSkip = _skipWords.some(w => _rawFeeText.toLowerCase() === w);

      // Extract all numbers from the input (handles "$500", "USD500", "500/term", "500 600 700")
      const _feeNums = _rawFeeText.replace(/[^0-9./]/g, " ").trim().match(/\d+(\.\d{1,2})?/g);

      if (!_isSkip && (!_feeNums || !_feeNums.length)) {
        // Nothing numeric - show a clear prompt with examples and stop here
        await sendText(from,
`❌ I couldn't read that as a fee amount.

Please enter your school's *term fee in USD* - just the number:

   *500*          → $500 per term (all terms same)
   *500/600/700*  → different per term
   *skip*         → I don't know yet

How much is your school's term fee?`);
        return; // keep state = school_reg_fees
      }

      // Clean the text to the first number (or slash-separated numbers) before passing to handler
      const _cleanedFeeText = _isSkip ? "0" : _feeNums.join("/");

      const _schoolFeesHandled = await handleSchoolRegistrationStates({
        state: biz.sessionState, from, text: _cleanedFeeText, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (_schoolFeesHandled) return;

      // Handler returned false even with clean input - force-advance past fees
      console.warn("[SCHOOL_REG_FEES] handler returned false after cleaning. Force-advancing to school_reg_principal.");
      biz.sessionData = {
        ...(biz.sessionData || {}),
        fees: { term1: Number(_feeNums?.[0]) || 0, term2: Number(_feeNums?.[1]) || Number(_feeNums?.[0]) || 0, term3: Number(_feeNums?.[2]) || Number(_feeNums?.[0]) || 0 }
      };
      biz.sessionState = "school_reg_principal";
      await saveBizSafe(biz);
      await sendText(from, `✅ Fees noted.

👤 What is the *principal's name*? (or type *skip*)`);
      return;
    }

    // All other school text states pass through normally
    const _schoolHandled = await handleSchoolRegistrationStates({
      state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_schoolHandled) return;
  }

  // ── School admin text-input states ──────────────────────────────────────────
  if (schoolAdminStates.includes(biz.sessionState)) {
    console.log("[REG-DISPATCH-TOPLVL] school admin state:", biz.sessionState, "from:", from);
    const _schoolAdminHandled = await handleSchoolAdminStates({
      state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_schoolAdminHandled) return;
  }

  // ── Supplier registration text-input states ──────────────────────────────────
  if (supplierStates.includes(biz.sessionState)) {
    console.log("[REG-DISPATCH-TOPLVL] supplier reg state:", biz.sessionState, "from:", from);
    const _supHandled = await handleSupplierRegistrationStates({
      state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_supHandled) return;
  }

  // ── School FAQ text states ──────────────────────────────────────────────────
  if (biz.sessionState?.startsWith("sfaq_")) {
    console.log("[REG-DISPATCH-TOPLVL] sfaq text state:", biz.sessionState, "from:", from);
    const _sfaqHandled = await handleSchoolFAQState({
      state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_sfaqHandled) return;
  }

  // ── Seller chat text states ──────────────────────────────────────────────────
  if (biz.sessionState?.startsWith("sc_")) {
    const _scHandled = await handleSellerChatState({
      state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (_scHandled) return;
  }
}
// ── END TOP-LEVEL REGISTRATION STATE DISPATCHER ──────────────────────────────

if (!isMetaAction && biz && biz.sessionState && !escapeWords.includes(al) && !settingsStates.includes(biz.sessionState) && !schoolAdminStates.includes(biz.sessionState) && !schoolTextStates.includes(biz.sessionState) && !/^ZQ:/i.test(text.trim())) {
    if (al === "cancel" && supplierStates.includes(biz.sessionState)) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      // Clear stale session so sendMainMenu resolves to real biz via UserRole scan
      if (biz.name?.startsWith("pending_supplier_")) {
        await UserSession.findOneAndUpdate(
          { phone }, { $unset: { activeBusinessId: "" } }, { upsert: true }
        );
      }
      await sendText(from, "❌ Registration cancelled. Sending you back to the main menu.");
      return sendMainMenu(from);
    }

    // ── If in supplier_search_city state and user types a shortcode, treat as new search ──
// FIX: exclude ZQ: deep links - they must fall through to the deep-link handler below.
if (biz.sessionState === "supplier_search_city" && !isMetaAction && !schoolAdminStates.includes(biz.sessionState) && !/^ZQ:/i.test(text.trim()) && !text.trim().toLowerCase().startsWith("zqg_")) {

  console.log(`[HIT-SUPPLIER-SEARCH-CITY] text="${text}" sessionState="${biz.sessionState}"`);

  // ── Greeting while in city-picker → reset and show main menu ─────────────
  if (GREETING_WORDS.has(text.trim().toLowerCase())) {
    biz.sessionState = "ready";
    biz.sessionData  = { ...(biz.sessionData || {}), supplierSearch: {} };
    await saveBizSafe(biz);
    return sendMainMenu(from);
  }

  const shortcode = parseShortcodeSearch(text);
  console.log(`[TRACE-C] supplier_search_city handler: text="${text}" shortcode=${JSON.stringify(shortcode)}`);
  if (shortcode) {
    const cleanProduct = String(shortcode.product || "")
      .toLowerCase()
      .trim()
      .replace(/\s+/g, " ");

  if (shortcode.city || shortcode.area) {
    const locationLabel = shortcode.area
      ? `${shortcode.area}, ${shortcode.city}`
      : shortcode.city || "Zimbabwe";

    // IMPORTANT:
    // In supplier_search_city state, inline text like "find valve mbare"
    // must behave like the working city-picker flow.
    // Do NOT force suburb/area on offer search.
    console.log(
      `[TRACE-D] calling runSupplierOfferSearch city="${shortcode.city}" product="${cleanProduct}" area=NULL_FIRST_PASS originalArea="${shortcode.area}"`
    );

    let offerResults = await runSupplierOfferSearch({
      city: shortcode.city || null,
      product: cleanProduct,
      area: null
    });
    console.log(`[TRACE-D2] first attempt offerResults.length=${offerResults.length}`);

    // Retry across all cities, still without forcing area
    if (!offerResults.length) {
      offerResults = await runSupplierOfferSearch({
        city: null,
        product: cleanProduct,
        area: null
      });
      console.log(`[TRACE-D3] second attempt (no city) offerResults.length=${offerResults.length}`);
    }

    if (offerResults.length) {
      biz.sessionState = "ready";
      biz.sessionData = {
        ...(biz.sessionData || {}),
        supplierSearch: {
          product: cleanProduct,
          ...(shortcode.city ? { city: shortcode.city } : {}),
          ...(shortcode.area ? { area: shortcode.area } : {})
        },
        searchResults: offerResults,
        searchPage: 0,
        searchResultMode: "offers"
      };
      await saveBizSafe(biz);

      const rows = formatSupplierOfferResults(offerResults.slice(0, 9), cleanProduct);
      if (offerResults.length > 9) {
        rows.push({
          id: "sup_search_next_page",
          title: `➡ More results (${offerResults.length - 9} more)`
        });
      }

      return sendNumberedSellerResults({
        from, phone,
        offers: offerResults,
        searchTerm: cleanProduct,
        locationLabel
      });
    }

    // No offers found anywhere - show no-results message
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: {
        product: cleanProduct,
        ...(shortcode.city ? { city: shortcode.city } : {}),
        ...(shortcode.area ? { area: shortcode.area } : {})
      }
    };
    await saveBizSafe(biz);

     await logSearchCommand({
      phone,
      rawText: text,
      source: "text",
      flow: "supplier_search",
      sessionState: biz?.sessionState || "",
      parsed: {
        product: shortcode.product || "",
        city: shortcode.city || "",
        area: shortcode.area || "",
        profileType: shortcode.profileType || ""
      },
      resultMode: "none",
      results: [],
      botReplySummary: "No matching supplier or offer results found"
    });

    return sendButtons(from, {
      text: `😕 No results for *${shortcode.product}* in *${locationLabel}*.\n\nTry searching all of Zimbabwe?`,
      buttons: [
        { id: "sup_search_city_all", title: "📍 Search All Cities" },
        { id: "find_supplier",       title: "🔍 Search Again" }
      ]
    });
  }

    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { product: cleanProduct }
    };
    biz.sessionState = "supplier_search_city";
    await saveBizSafe(biz);

    return sendList(from, `🔍 Looking for: *${cleanProduct}*\n\nWhich city?`, [
      ...SUPPLIER_CITIES.slice(0, 9).map(c => ({ id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`, title: c })),
      { id: "sup_search_city_all", title: "📍 All Cities" }
    ]);
  }

 const productQuery = text.trim().toLowerCase().replace(/\s+/g, " ");

  // Greetings/reset words while in search-city state → drop state, go to main menu
  if (GREETING_WORDS.has(productQuery)) {
    biz.sessionState = "ready";
    biz.sessionData  = { ...(biz.sessionData || {}), supplierSearch: {} };
    await saveBizSafe(biz);
    return sendMainMenu(from);
  }

  if (productQuery.length > 1) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { product: productQuery }
    };
    biz.sessionState = "supplier_search_city";
    await saveBizSafe(biz);

    return sendList(from, `🔍 Looking for: *${productQuery}*\n\nWhich city?`, [
      ...SUPPLIER_CITIES.slice(0, 9).map(c => ({ id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`, title: c })),
      { id: "sup_search_city_all", title: "📍 All Cities" }
    ]);
  }
}

    if (schoolTextStates.includes(biz.sessionState)) {
      const handled = await handleSchoolRegistrationStates({
        state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (handled) return;
    }
 
    // ── School FAQ chatbot text states ──────────────────────────────────────
    if (biz.sessionState?.startsWith("sfaq_")) {
      const handled = await handleSchoolFAQState({
        state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (handled) return;
    }

    // ── School FAQ for non-biz users (first-time visitors via smart link) ────
    // biz exists here but may have null sessionState if user is not registered
    if (!biz.sessionState && flowSess?.tempData?.sfaqState?.startsWith("sfaq_")) {
      const handled = await handleSchoolFAQState({
        state: flowSess.tempData.sfaqState, from, text, biz: null, saveBiz: null
      });
      if (handled) return;
    }

    // ── Seller chatbot text states ────────────────────────────────────────────
    if (biz.sessionState?.startsWith("sc_")) {
      const handled = await handleSellerChatState({
        state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (handled) return;
    }

    // ── School admin text-input states (e.g. fee updates) ────────────────────
    if (schoolAdminStates.includes(biz.sessionState)) {
      const handled = await handleSchoolAdminStates({
        state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (handled) return;
    }
 
    if (supplierStates.includes(biz.sessionState)) {
      const handled = await handleSupplierRegistrationStates({
        state: biz.sessionState, from, text, biz, saveBiz: saveBizSafe.bind(null, biz)
      });
      if (handled) return;
    }
 
    // Only pass to Twilio for real businesses - ghost supplier biz returns "Access denied"
  
    // Business-tool text states are now handled earlier, before marketplace free-text search.
    // Keep only the ghost-supplier-biz bypass here.
    if (biz.name?.startsWith("pending_supplier_")) {
      // ── If ghost biz user is mid-order, mid-listed-selection, or mid-seller-chat, let handlers below process it ──
      if (
        biz.sessionState === "supplier_order_product" ||
        biz.sessionState === "supplier_order_address" ||
        biz.sessionState === "supplier_order_enter_price" ||
        biz.sessionState === "supplier_order_picking" ||
        biz.sessionState === "supplier_select_listed_products" ||
        biz.sessionState?.startsWith("sc_")
      ) {
        // Do nothing here - fall through to the state handlers below
     } else {
        // Ghost biz user typed something unrecognised - try as a search first
        const shortcode = parseShortcodeSearch(text);
 
        if (shortcode) {
          if (shortcode.city || shortcode.area) {
            const locationLabel = shortcode.area
              ? `${shortcode.area}, ${shortcode.city}`
              : shortcode.city || "Zimbabwe";

            // Offer-first: behave like city-picker flow, do NOT force area on first pass
            let offerResults = await runSupplierOfferSearch({
              city: shortcode.city || null,
              product: shortcode.product,
              area: null
            });

            // Retry across all cities if city-level found nothing
            if (!offerResults.length) {
              offerResults = await runSupplierOfferSearch({
                city: null,
                product: shortcode.product,
                area: null
              });
            }

        if (offerResults.length) {
              // Write to BOTH biz.sessionData AND UserSession.tempData so the
              // sup_search_next_page handler (which branches on biz presence) can
              // always find the full result set regardless of which branch it takes.
              biz.sessionData = {
                ...(biz.sessionData || {}),
                searchResults: offerResults,
                searchPage: 0,
                searchResultMode: "offers"
              };
              await saveBizSafe(biz);
              await UserSession.findOneAndUpdate(
                { phone },
                {
                  $set: {
                    "tempData.searchResults": offerResults,
                    "tempData.searchPage": 0,
                    "tempData.searchResultMode": "offers",
                    "tempData.supplierSearchProduct": shortcode.product,
                    ...(shortcode.city ? { "tempData.lastSearchCity": shortcode.city } : {}),
                    ...(shortcode.area ? { "tempData.lastSearchArea": shortcode.area } : {})
                  }
                },
                { upsert: true }
              );
              const pageOffers = offerResults.slice(0, 9);
              const rows = formatSupplierOfferResults(pageOffers, shortcode.product);
              if (offerResults.length > 9) {
                rows.push({ id: "sup_search_next_page", title: `➡ More results (${offerResults.length - 9} more)` });
              }
              return sendNumberedSellerResults({ from, phone, offers: offerResults, searchTerm: shortcode.product, locationLabel });
            }

            // Offers exhausted - fall back to supplier-level results
            const results = await runSupplierSearch({ city: shortcode.city || null, product: shortcode.product, area: shortcode.area || null });
            if (results.length) {
              biz.sessionData = {
                ...(biz.sessionData || {}),
                searchResults: results,
                searchPage: 0,
                searchResultMode: "suppliers"
              };
              await saveBizSafe(biz);
              await UserSession.findOneAndUpdate(
                { phone },
                {
                  $set: {
                    "tempData.searchResults": results,
                    "tempData.searchPage": 0,
                    "tempData.searchResultMode": "suppliers"
                  }
                },
                { upsert: true }
              );
              const rows = formatSupplierResults(results.slice(0, 9), shortcode.city || shortcode.area || "", shortcode.product);
              if (results.length > 9) {
                rows.push({ id: "sup_search_next_page", title: `➡ More results (${results.length - 9} more)` });
              }
              return sendNumberedSellerResults({ from, phone, suppliers: results, searchTerm: shortcode.product, locationLabel });
            }
            return sendButtons(from, {
              text: `😕 No results for *${shortcode.product}*${shortcode.city ? ` in *${shortcode.city}*` : ""}.\n\nTry a different city or search term.`,
              buttons: [
                { id: "find_supplier", title: "🔍 Search Again" },
                { id: "sup_search_city_all", title: "📍 Try All Cities" }
              ]
            });
          }

          // No city or area - store product and ask for city (no-location flow unchanged)
          biz.sessionData = { ...(biz.sessionData || {}), supplierSearch: { product: shortcode.product } };
          biz.sessionState = "supplier_search_city";
          await saveBizSafe(biz);
          return sendList(from, `🔍 Looking for: *${shortcode.product}*\n\nWhich city?`, [
            ...SUPPLIER_CITIES.slice(0, 9).map(c => ({ id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`, title: c })),
            { id: "sup_search_city_all", title: "📍 All Cities" }
          ]);
        }
        // Truly unrecognised - show helpful prompt
        return sendButtons(from, {
          text: `🔍 *Looking for something?*\n\nTry:\n_find cement_\n_find plumber harare_\n_find teacher_\n_find car hire -_\n\nOr type *menu* to see all options.`,
          buttons: [
            { id: "find_supplier", title: "🔍 Browse & Shop" },
            { id: "register_supplier", title: "📦 List My Business" }
          ]
        });
      }
    }
  }

  if (
  biz &&
  !isMetaAction &&
  al === "cancel" &&
  (biz.sessionState === "supplier_order_product" || biz.sessionState === "supplier_order_address")
) {
  biz.sessionState = "ready";
  biz.sessionData = {};
  await saveBizSafe(biz);

  await sendText(from, "❌ Order cancelled.");
return sendButtons(from, {
  text: "What would you like to do next?",
  buttons: [
    { id: "find_supplier", title: "🔍 Browse & Shop" },
    { id: "my_orders", title: "📋 My Orders" },
    
  ]
});
}


// ── Shortcode search for any user ─────────────────────────────────────────


if (escapeWords.includes(al)) {
    if (!biz || biz.name?.startsWith("pending_supplier_")) {
      // Clear supplier reg state if mid-flow
      if (biz?.name?.startsWith("pending_supplier_")) {
        biz.sessionState = "ready";
        biz.sessionData = {};
        await saveBizSafe(biz);
      }
      return sendMainMenu(from);
    }
    biz.sessionState = "ready"; biz.sessionData = {};
    await saveBizSafe(biz);
    return sendMainMenu(from);
  }

  // =========================
  // 📍 ONBOARDING: ADDRESS
  // =========================
  if (biz && biz.sessionState === "awaiting_address") {
    if (a === "onb_address_yes") {
      biz.sessionState = "awaiting_address_input"; await saveBizSafe(biz);
      return sendText(from, "Please enter your business address:");
    }
    if (a === "onb_address_skip") {
      biz.address = ""; biz.sessionState = "awaiting_currency"; await saveBizSafe(biz);
      return sendButtons(from, {
        text: "💱 Select your business currency",
        buttons: [{ id: "onb_currency_USD", title: "USD ($)" }, { id: "onb_currency_ZWL", title: "ZWL (Z$)" }, { id: "onb_currency_ZAR", title: "ZAR (R)" }]
      });
    }
  }

  if (biz && biz.sessionState === "awaiting_address_input" && !isMetaAction) {
    if (!text || text.length < 3) return sendText(from, "Please enter a valid address:");
    biz.address = text; biz.sessionState = "awaiting_currency"; await saveBizSafe(biz);
    return sendButtons(from, {
      text: "💱 Select your business currency",
      buttons: [{ id: "onb_currency_USD", title: "USD ($)" }, { id: "onb_currency_ZWL", title: "ZWL (Z$)" }, { id: "onb_currency_ZAR", title: "ZAR (R)" }]
    });
  }

  if (biz && biz.sessionState === "awaiting_currency" && a.startsWith("onb_currency_")) {
    const currency = a.replace("onb_currency_", "").toUpperCase();
    if (!["USD", "ZWL", "ZAR"].includes(currency)) { await sendText(from, "❌ Invalid currency selection."); return; }
    biz.currency = currency; biz.sessionState = "awaiting_logo"; await saveBizSafe(biz);
    await sendButtons(from, {
      text: "🖼 Would you like to add your business logo now?",
      buttons: [{ id: "onb_logo_yes", title: "📷 Upload Logo" }, { id: "onb_logo_skip", title: "Skip for now" }]
    });
    return;
  }

  if (biz && biz.sessionState === "awaiting_logo") {
    if (a === "onb_logo_yes") { biz.sessionState = "awaiting_logo_upload"; await saveBizSafe(biz); await sendText(from, "📷 Please send your logo image (PNG or JPG).\nYou can also type *skip* to continue without a logo."); return; }
    if (a === "onb_logo_skip") { biz.sessionState = "ready"; await saveBizSafe(biz); await sendText(from, "✅ Setup complete!\n\nYour business is ready to use 🚀"); return sendMainMenu(from); }
  }

  if (biz && biz.sessionState === "awaiting_logo_upload") {
    if (text && text.toLowerCase() === "skip") {
      const mainBranch = await Branch.create({ businessId: biz._id, name: "Main Branch", isDefault: true });
      await UserRole.findOneAndUpdate({ businessId: biz._id, phone, role: "owner" }, { branchId: mainBranch._id });
      biz.sessionState = "ready"; await saveBizSafe(biz);
      await sendText(from, "✅ Setup complete!\n\n🏢 Main Branch created and assigned to you.");
      return sendMainMenu(from);
    }
    if (biz.logoUrl) {
      const mainBranch = await Branch.create({ businessId: biz._id, name: "Main Branch", isDefault: true });
      await UserRole.findOneAndUpdate({ businessId: biz._id, phone, role: "owner" }, { branchId: mainBranch._id });
      biz.sessionState = "ready"; await saveBizSafe(biz);
      await sendText(from, "✅ Setup complete!\n\n🏢 Main Branch created and assigned to you.");
      return sendMainMenu(from);
    }
    return;
  }

  if (a.startsWith("invite_branch_")) {
    const branchId = a.replace("invite_branch_", "");
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "invite_user_phone"; biz.sessionData.branchId = branchId; await saveBizSafe(biz);
    return sendButtons(from, { text: "📱 *Enter WhatsApp number of the user to invite:*\n\nFormat: 0772123456", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }

  if (a.startsWith("assign_user_")) {
    const userId = a.replace("assign_user_", "");
    if (!biz) return sendMainMenu(from);
    const branches = await Branch.find({ businessId: biz._id }).lean();
    if (!branches.length) { await sendText(from, "No branches found."); return sendMainMenu(from); }
    biz.sessionData.userId = userId; biz.sessionState = "assign_branch_pick_branch"; await saveBizSafe(biz);
    return sendList(from, "Select branch", branches.map(b => ({ id: `assign_branch_${b._id}`, title: b.name })));
  }

  if (a.startsWith("assign_branch_")) {
    if (!biz || biz.sessionState !== "assign_branch_pick_branch") return;
    const branchId = a.replace("assign_branch_", "");
    const userId = biz.sessionData.userId;
    if (!userId) { await sendText(from, "⚠️ No user selected."); return sendMainMenu(from); }
    await UserRole.findByIdAndUpdate(userId, { branchId });
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    await sendText(from, "✅ User successfully assigned to branch.");
    return sendMainMenu(from);
  }

  // ── Settings actions ───────────────────────────────────────────────────────

  if (a === ACTIONS.SETTINGS_INV_PREFIX) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_inv_prefix"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current invoice prefix: *${biz.invoicePrefix || "INV"}*\n\nReply with new prefix:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }
  if (a === ACTIONS.SETTINGS_QT_PREFIX) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_qt_prefix"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current quote prefix: *${biz.quotePrefix || "QT"}*\n\nReply with new prefix:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }
  if (a === ACTIONS.SETTINGS_RCPT_PREFIX) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_rcpt_prefix"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current receipt prefix: *${biz.receiptPrefix || "RCPT"}*\n\nReply with new prefix:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }
  if (a === ACTIONS.SETTINGS_CURRENCY) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_currency"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current currency: *${biz.currency}*\n\nReply with new currency (USD, ZWL, ZAR):`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }
  if (a === ACTIONS.SETTINGS_TERMS) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_terms"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current payment terms: *${biz.paymentTermsDays || 0} days*\n\nReply with number of days:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }
  if (a === ACTIONS.SETTINGS_ADDRESS) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "settings_address"; await saveBizSafe(biz);
    return sendButtons(from, { text: `Current address:\n${biz.address || "Not set"}\n\nReply with new address:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
  }

  if (biz?.sessionState === "settings_address" && !isMetaAction) {
    const addr = (text || "").trim();
    if (!addr || addr.length < 3) { await sendText(from, "❌ Please enter a valid address:"); return; }
    biz.address = addr; biz.sessionState = "ready"; biz.sessionData = {};
    await saveBizSafe(biz);
    await sendText(from, "✅ Address updated successfully.");
    return sendSettingsMenu(from);
  }

  if (a === ACTIONS.SETTINGS_LOGO) {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "awaiting_logo_upload"; await saveBizSafe(biz);
    return sendText(from, "📷 Please send your business logo image (PNG or JPG).\nReply 0 to cancel.");
  }

  if (a === ACTIONS.SETTINGS_CLIENTS) {
    if (!biz) return sendMainMenu(from);
    const Client = (await import("../models/client.js")).default;
    const clients = await Client.find({ businessId: biz._id }).lean();
    if (!clients.length) return sendText(from, "No clients found.");
    let msg = "👥 Clients:\n";
    clients.forEach((c, i) => { msg += `${i + 1}) ${c.name || c.phone}\n`; });
    await sendText(from, msg);
    return sendSettingsMenu(from);
  }

  if (a === ACTIONS.SETTINGS_BRANCHES) {
    if (!biz) return sendMainMenu(from);
    return sendBranchesMenu(from);
  }

  // ── Client statement ───────────────────────────────────────────────────────

  if (a.startsWith("stmt_client_")) {
    const clientId = a.replace("stmt_client_", "");
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "client_statement_generate"; biz.sessionData = { clientId };
    await saveBizSafe(biz);
    return continueTwilioFlow({ from, text: "generate" });
  }

  if (a.startsWith("prod_")) {
    const productId = a.replace("prod_", "");
    if (!biz) return sendMainMenu(from);
    const product = await Product.findById(productId);
    if (!product) return sendText(from, "❌ Item not found.");
    biz.sessionData.lastItem = { description: product.name, unit: product.unitPrice, source: "catalogue" };
    biz.sessionData.expectingQty = true;
    biz.sessionState = "creating_invoice_add_items";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `📦 *${product.name}* @ *${formatMoney(product.unitPrice, biz.currency)}*\n\n🔢 *Enter quantity:*`,
      buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
    });
  }

  // ── Package selection ──────────────────────────────────────────────────────

  if (biz?.sessionState === "choose_package" && a.startsWith("pkg_")) {
    const selected = a.replace("pkg_", "");
    if (!["bronze", "silver", "gold"].includes(selected)) return sendText(from, "❌ Invalid package selected.");

    const plan = SUBSCRIPTION_PLANS[selected];
    if (!plan) return sendText(from, "❌ Invalid package selected.");

    const now = new Date();
    const currentKey = biz.package || "trial";
    const currentPlan = SUBSCRIPTION_PLANS[currentKey];
    const currentPrice = currentPlan?.price || 0;
    const endsAt = biz.subscriptionEndsAt ? new Date(biz.subscriptionEndsAt) : null;
    const hasActiveCycle = endsAt && endsAt.getTime() > now.getTime();

    let chargeAmount = plan.price, note = "";

    if (hasActiveCycle && plan.price > currentPrice) {
      const remainingDays = clamp(msDays(endsAt.getTime() - now.getTime()), 0, 30);
      const diff = plan.price - currentPrice;
      chargeAmount = round2(diff * (remainingDays / plan.durationDays));
      if (chargeAmount < 0.01) chargeAmount = 0.01;
      note = `🔁 Upgrade proration:\n• Current: ${currentKey.toUpperCase()}\n• New: ${selected.toUpperCase()}\n• Days remaining: ${Math.ceil(remainingDays)}\n• You pay only the difference for remaining days.`;
    } else if (hasActiveCycle && plan.price <= currentPrice) {
      note = `ℹ️ Downgrades apply on next renewal date.`;
    }

    biz.sessionState = "subscription_enter_ecocash";
    biz.sessionData = { targetPackage: selected, amount: chargeAmount, prorationNote: note || null, previousPackage: currentKey, cycleEndsAt: endsAt ? endsAt.toISOString() : null };
    await saveBizSafe(biz);

    const pkg = PACKAGES[selected];
    const MAP = {
      invoice: "Invoices", quote: "Quotations", receipt: "Receipts",
      clients: "Clients", payments: "Payments",
      reports_daily: "Daily reports", reports_weekly: "Weekly reports", reports_monthly: "Monthly reports",
      branches: "Branches management", users: "User management"
    };
    const featureLines = (pkg?.features || []).map(f => `• ${MAP[f] || f}`);

    return sendText(from,
`✅ Selected: *${plan.name}* (${chargeAmount} ${plan.currency})

📦 Package limits:
• Users: ${pkg?.users}
• Branches: ${pkg?.branches}
• Docs per month: ${pkg?.monthlyDocs}

✨ Features:
${featureLines.join("\n")}

💳 *Payment method: EcoCash only*

Please enter the EcoCash number you want to pay with:
Example: 0772123456

Or type *same* to use this WhatsApp number.`);
  }

  // ── Sales document actions ─────────────────────────────────────────────────

if (a.startsWith("doc_") && a !== ACTIONS.VIEW_DOC && a !== ACTIONS.DELETE_DOC) {
    const docId = a.replace("doc_", "");
    if (!biz) return sendMainMenu(from);
    const doc = await Invoice.findById(docId);
    if (!doc) { await sendText(from, "Document not found."); return sendSalesMenu(from); }

    biz.sessionState = "sales_doc_action"; biz.sessionData = { docId };
    await saveBizSafe(biz);

    const isManager = caller && ["owner", "manager"].includes(caller.role);
    const cur = doc.currency || biz.currency || "USD";

    // Build doc summary text
    const statusEmoji = doc.status === "paid" ? "✅" : doc.status === "partial" ? "⏳" : "🔴";
    const docText =
`📄 *${doc.number}*
Type: ${doc.type} | ${statusEmoji} ${doc.status}
Total: $${Number(doc.total || 0).toFixed(2)} ${cur}
Paid: $${Number(doc.amountPaid || 0).toFixed(2)} | Balance: $${Number(doc.balance || 0).toFixed(2)}`;

    // Max 3 buttons - priority: View PDF, Delete (managers only), Back
    if (isManager) {
      return sendButtons(from, {
        text: docText,
        buttons: [
          { id: ACTIONS.VIEW_DOC,   title: "📄 View PDF" },
          { id: ACTIONS.DELETE_DOC, title: "🗑 Delete" },
          { id: ACTIONS.SALES_MENU, title: "⬅ Back" }
        ]
      });
    }
    return sendButtons(from, {
      text: docText,
      buttons: [
        { id: ACTIONS.VIEW_DOC,   title: "📄 View PDF" },
        { id: ACTIONS.SALES_MENU, title: "⬅ Back" },
        { id: ACTIONS.MAIN_MENU,  title: "🏠 Main Menu" }
      ]
    });
  }

  if (a === ACTIONS.VIEW_DOC) {
    if (!biz?.sessionData?.docId) { await sendText(from, "❌ No document selected."); return sendSalesMenu(from); }
    const doc = await Invoice.findById(biz.sessionData.docId).lean();
    if (!doc) { await sendText(from, "❌ Document not found."); return sendSalesMenu(from); }
    const Client = (await import("../models/client.js")).default;
    const client = await Client.findById(doc.clientId).lean();
    if (!client) { await sendText(from, "❌ Client not found."); return sendSalesMenu(from); }

    const { filename } = await generatePDF({
      type: doc.type, number: doc.number, date: doc.createdAt || new Date(),
      billingTo: client.name || client.phone, items: doc.items,
      bizMeta: { name: biz.name, logoUrl: biz.logoUrl, address: biz.address || "", discountPercent: doc.discountPercent || 0, vatPercent: doc.vatPercent || 0, applyVat: doc.type === "receipt" ? false : true, _id: biz._id.toString(), status: doc.status }
    });

    const site = (process.env.SITE_URL || "").replace(/\/$/, "");
    const folder = doc.type === "invoice" ? "invoices" : doc.type === "quote" ? "quotes" : "receipts";
    const url = `${site}/docs/generated/${folder}/${filename}`;
    await sendDocument(from, { link: url, filename });
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    return;
  }

  if (a === ACTIONS.DELETE_DOC) {
    if (!biz?.sessionData?.docId) { await sendText(from, "❌ No document selected."); return sendSalesMenu(from); }
    if (!caller || !["owner", "manager"].includes(caller.role)) { await sendText(from, "🔒 Only managers and owners can delete documents."); return sendSalesMenu(from); }
    const doc = await Invoice.findById(biz.sessionData.docId);
    if (!doc) { await sendText(from, "❌ Document not found."); return sendSalesMenu(from); }
    if (doc.status === "paid") { await sendText(from, "❌ Paid documents cannot be deleted."); return sendSalesMenu(from); }
    await Invoice.deleteOne({ _id: doc._id });
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    await sendText(from, "🗑 Document deleted successfully.");
    return sendSalesMenu(from);
  }

  if (a.startsWith("subpay_")) {
    if (!biz) return sendMainMenu(from);
    const id = a.replace("subpay_", "");
    const rec = await SubscriptionPayment.findOne({ _id: id, businessId: biz._id }).lean();
    if (!rec) return sendText(from, "Record not found.");
    if (rec.receiptUrl) return sendDocument(from, { link: rec.receiptUrl, filename: rec.receiptFilename || "receipt.pdf" });
    return sendText(from, `Status: ${rec.status}\nAmount: ${rec.amount} ${rec.currency}\nRef: ${rec.reference}`);
  }

  // ── Owner selects branch for cash balance management ───────────────────────

  if (a.startsWith("cashbal_branch_")) {
    if (!biz) return sendMainMenu(from);
    const targetBranchId = a.replace("cashbal_branch_", "");
    const cashAction = biz.sessionData?.cashBalAction;
    if (!cashAction) return sendMainMenu(from);

    biz.sessionData.targetBranchId = targetBranchId;

    if (cashAction === "set_opening") {
      biz.sessionState = "cash_set_opening_balance"; await saveBizSafe(biz);
      return sendButtons(from, { text: "📝 *Set Opening Balance*\n\nEnter the opening cash amount:", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    }
    if (cashAction === "payout") {
      biz.sessionState = "cash_payout_amount"; await saveBizSafe(biz);
      return sendButtons(from, { text: "💸 *Record Payout*\n\nEnter payout amount:", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    }
    if (cashAction === "handover") {
      biz.sessionState = "cash_handover_amount"; await saveBizSafe(biz);
      return sendButtons(from, {
        text: "🔄 *Shift Cash Handover*\n\nCount the cash in the till and enter the total amount:",
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }
    if (cashAction === "view") {
      return showBranchCashBalance(from, biz, targetBranchId);
    }
    return sendMainMenu(from);
  }

  // ─────────────────────────────────────────────────────────────────────────

 // ─────────────────────────────────────────────────────────────────────────
  // 🏪 SUPPLIER PLATFORM ACTION HANDLERS
  // ─────────────────────────────────────────────────────────────────────────

// ── Supplier home - safe back button for supplier flows ───────────────────
  if (a === "suppliers_home") {
    return sendSuppliersMenu(from);
  }


  
  // ── Welcome screen: user chose "Run My Business" ──────────────────────────
  if (a === "onboard_business") {
    return startOnboarding(from, phone);
  }

  // ── HANDLE SUPPLIER LISTED PRODUCT SELECTION ──
if (biz?.sessionState === "supplier_select_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) {
    await sendText(from, "❌ Supplier profile not found.");
    return true;
  }

  const uploaded = (supplier.products || []).filter(p => p && p !== "pending_upload");

  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap =
    Number(biz?.sessionData?.listedSelectionCap) ||
    capMap[supplier.tier] ||
    20;

  const indexes = findSupplierItemIndexes(text, uploaded);

  if (!indexes.length) {
    await sendText(
      from,
      `❌ Invalid selection.\n\nReply with item numbers only.\nExample: *1,2,5*`
    );
    return true;
  }

  const uniqueIndexes = [...new Set(indexes)].slice(0, cap);
  const selected = uniqueIndexes.map(i => uploaded[i]).filter(Boolean);

  supplier.listedProducts = selected;
  await supplier.save();

  biz.sessionState = "ready";
  biz.sessionData = {};
  await saveBizSafe(biz);

  await sendText(
    from,
    `✅ *${selected.length} item${selected.length === 1 ? "" : "s"} listed live now.*`
  );

  return sendSupplierAccountMenu(from, supplier);
}

  // ── Welcome screen: Find Suppliers or register ────────────────────────────
if (a === "find_supplier") {
  // Clear previous search state in BOTH biz and UserSession
  if (biz) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: {}
    };
    biz.sessionState = "supplier_search_product";
    await saveBizSafe(biz);
  }
  // Always clear UserSession - covers ghost-biz users who have biz but also buy
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: { "tempData.supplierSearchMode": "product" },
      $unset: {
        "tempData.supplierSearchCategory": "",
        "tempData.supplierSearchProduct": "",
        "tempData.supplierSearchType": ""
      }
    },
    { upsert: true }
  );
return sendText(from,
`🔍 *Find Suppliers on ZimQuote*

Type what you need. Add a suburb or city to narrow results.

*📦 Products:*
_find cement harare_, _find cooking oil bulawayo_, _find mealie meal borrowdale_, _find tyres avondale_, _find school uniforms glen view_, _find solar panels highlands_

*🧹 Cleaning Services:*
_find deep cleaning harare_, _find house cleaning borrowdale_, _find office cleaning harare_, _find industrial cleaning harare_, _find restaurant cleaning harare_, _find carpet cleaning highlands_, _find end of tenancy cleaning harare_

*🔧 Services:*
_find plumber highlands_, _find electrician borrowdale_, _find teacher harare_, _find tutor glen view_, _find painter avondale_, _find welder harare_, _find catering harare_, _find photographer bulawayo_, _find it support harare_

*🚗 Transport:*
_find car hire harare_, _find delivery bulawayo_, _find moving company harare_

Or pick a category 👇`,
  ).then(() => sendList(from, "📂 Choose how you want to buy:", [
    { id: "sup_search_type_product", title: "📦 Browse Products" },
    { id: "sup_search_type_service", title: "🧰 Browse Services" },
    { id: "sup_request_sellers", title: "⚡ Request Sellers" }
  ]));

}

if (a === "sup_search_type_product" || a === "sup_search_type_service") {
  const searchType = a === "sup_search_type_service" ? "service" : "product";

  // Save search type to session
  if (biz) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { ...(biz.sessionData?.supplierSearch || {}), type: searchType }
    };
    await saveBizSafe(biz);
  } else {
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.supplierSearchType": searchType } },
      { upsert: true }
    );
  }

  // ── Services: show collar groups first (same as seller registration) ──
  // WhatsApp list limit is 10 rows - 21 service categories can't fit in one list.
  if (searchType === "service") {
    return sendList(from, "🔧 What type of service are you looking for?", [
      { id: "sup_search_collar_white_collar", title: "💼 Professional" },
      { id: "sup_search_collar_trade",        title: "🔧 Trade & Artisan" },
      { id: "sup_search_collar_blue_collar",  title: "🧹 General Services" },
      { id: "sup_search_all",                 title: "🔍 Search Services" },
      { id: "find_supplier",                  title: "⬅ Back" }
    ]);
  }

  // ── Products: show first 8 categories + overflow ──
  const filteredCategories = getSupplierCategoriesForType(searchType);
  const categoryRows = [
    ...filteredCategories.slice(0, 8).map(c => ({
      id: `sup_search_cat_${c.id}`,
      title: c.label
    })),
    { id: "sup_search_all", title: "🔍 Search Products" },
    ...(filteredCategories.length > 8
      ? [{ id: "sup_search_more_categories", title: "➕ More Categories" }]
      : [])
  ];

  return sendList(from, "📦 Choose a product category", categoryRows);
}



// ── NEW: Service collar group selected by buyer ───────────────────────────────
// Mirrors the seller registration collar flow - shows only the categories
// ── NEW: Service collar group selected by buyer ───────────────────────────────
// Shows only service categories in the chosen collar group
// WhatsApp list max is 10 rows, so reserve space for More/Back when needed
if (a.startsWith("sup_search_collar_")) {
  const collarKey = a.replace("sup_search_collar_", "");
  const validCollars = ["white_collar", "trade", "blue_collar"];
  if (!validCollars.includes(collarKey)) return startSupplierSearch(from, biz, saveBizSafe);

  const collarLabels = {
    white_collar: "💼 Professional Services",
    trade:        "🔧 Trade & Artisan",
    blue_collar:  "🧹 General Services"
  };

  const collarCategories = SUPPLIER_CATEGORIES.filter(
    c => c.types.includes("service") && c.collar === collarKey
  );

  const hasMore = collarCategories.length > 8;

  // If there is a More button, only show 8 categories here:
  // 8 categories + More + Back = 10 rows max
  // If there is no More button, show up to 9 categories + Back = 10 rows max
  const firstBatch = hasMore
    ? collarCategories.slice(0, 8)
    : collarCategories.slice(0, 9);

  const rows = [
    ...firstBatch.map(c => ({ id: `sup_search_cat_${c.id}`, title: c.label })),
    ...(hasMore ? [{ id: `sup_search_collar_more_${collarKey}`, title: "➕ More" }] : []),
    { id: "sup_search_type_service", title: "⬅ Back" }
  ];

  return sendList(from, collarLabels[collarKey] || "🔧 Choose a category", rows);
}

// ── NEW: Overflow page for a collar group ─────────────────────────────────────
if (a.startsWith("sup_search_collar_more_")) {
  const collarKey = a.replace("sup_search_collar_more_", "");

  const collarCategories = SUPPLIER_CATEGORIES.filter(
    c => c.types.includes("service") && c.collar === collarKey
  );

  const rows = [
    ...collarCategories.slice(8, 17).map(c => ({
      id: `sup_search_cat_${c.id}`,
      title: c.label
    })),
    { id: `sup_search_collar_${collarKey}`, title: "⬅ Back" }
  ];

  return sendList(from, "🔧 More categories", rows);
}




if (a === "sup_search_more_categories") {
  // This handler is only reached from the product category list (services use collar flow)
  let searchType = biz?.sessionData?.supplierSearch?.type || null;
  if (!searchType) {
    const sess = await UserSession.findOne({ phone });
    searchType = sess?.tempData?.supplierSearchType || "product";
  }

  // If somehow service reaches here, redirect to collar picker
  if (searchType === "service") {
    return sendList(from, "🔧 What type of service are you looking for?", [
      { id: "sup_search_collar_white_collar", title: "💼 Professional" },
      { id: "sup_search_collar_trade",        title: "🔧 Trade & Artisan" },
      { id: "sup_search_collar_blue_collar",  title: "🧹 General Services" },
      { id: "sup_search_all",                 title: "🔍 Search Services" },
      { id: "find_supplier",                  title: "⬅ Back" }
    ]);
  }

  const filteredCategories = getSupplierCategoriesForType(searchType);
  // WhatsApp max 10 rows - products overflow: items 9–17, capped at 9 + Back
  const overflowRows = filteredCategories.slice(9, 18).map(c => ({
    id: `sup_search_cat_${c.id}`,
    title: c.label
  }));

  return sendList(from, "📦 More Product Categories", [
    ...overflowRows,
    { id: "sup_search_type_product", title: "⬅ Back" }
  ]);
}

if (a === "register_supplier" || a === "list_my_business") {
  if (!_bizIsOwnedByUser) biz = null;
    const existingSupplier = await SupplierProfile.findOne({ phone });

  if (existingSupplier) {
    if (existingSupplier.active) {
      return sendSupplierAccountMenu(from, existingSupplier);
    }
    const isComplete = Boolean(
      existingSupplier.businessName &&
      existingSupplier.location?.city &&
      existingSupplier.location?.area &&
      Array.isArray(existingSupplier.categories) && existingSupplier.categories.length > 0 &&
      Array.isArray(existingSupplier.products) && existingSupplier.products.length > 0 &&
      existingSupplier.delivery &&
      typeof existingSupplier.delivery.available === "boolean" &&
      typeof existingSupplier.minOrder === "number"
    );
    if (isComplete) {
      return sendSupplierUpgradeMenu(from, existingSupplier.tier);
    }
    return startSupplierRegistration(from, biz);
  }

  // No supplier profile yet - create pending business and start registration
  if (!biz) {
 const newBiz = await Business.create({
  name: "pending_supplier_" + phone,
  currency: "USD",
  package: "trial",
  subscriptionStatus: "inactive",
  isSupplier: false,
  sessionState: "supplier_reg_listing_type",
  sessionData: { supplierReg: {} },
  ownerPhone: phone
});

    await UserRole.create({
      phone,
      role: "owner",
      pending: false,
      businessId: newBiz._id
    });

    await UserSession.findOneAndUpdate(
      { phone },
      { activeBusinessId: newBiz._id },
      { upsert: true }
    );

    return startSupplierRegistration(from, newBiz);
  }

  return startSupplierRegistration(from, biz);
}

// ── SCHOOL SMART LINK / FAQ ACTIONS ─────────────────────────────────────
// MUST run before main-menu fallback, supplier registration, and generic handlers.
// Parents who open school smart links may NOT have a biz record.
if (isMetaAction && typeof a === "string" && a.startsWith("sfaq_")) {
  const handled = await handleSchoolFAQAction({
    from,
    action: a,
    biz,
    saveBiz: biz ? saveBizSafe.bind(null, biz) : null
  });

  if (handled) return;

  // If FAQ handler can't handle it (no FAQs set up), show school contact info
  if (a.startsWith("sfaq_enquiry_")) {
    const _sfaqSchoolId = a.replace("sfaq_enquiry_","").trim();
    try {
      const _sfaqSP = (await import("../models/schoolProfile.js")).default;
      const _sfaqSchool = await _sfaqSP.findById(_sfaqSchoolId).lean();
      if (_sfaqSchool) {
        const _sfaqPhone = _sfaqSchool.contactPhone || _sfaqSchool.phone || "";
        return sendButtons(from, {
          text:
            `❓ *Enquiries - ${_sfaqSchool.schoolName}*\n\n` +
            `📞 Call or WhatsApp: *${_sfaqPhone.startsWith("263") ? "0"+_sfaqPhone.slice(3) : _sfaqPhone}*\n` +
            (_sfaqSchool.email ? `📧 Email: *${_sfaqSchool.email}*\n` : "") +
            (_sfaqSchool.website ? `🌐 Website: ${_sfaqSchool.website}\n` : "") +
            `\n_The school team will respond to your enquiry directly._`,
          buttons: [
            { id: `school_apply_start_${_sfaqSchoolId}`, title: "📝 Apply on WhatsApp" },
            { id: "school_search_refine", title: "🏫 More Schools" }
          ]
        });
      }
    } catch (_sfaqErr) { console.warn("[SFAQ FALLBACK]", _sfaqErr.message); }
  }

  console.warn("[SFAQ ACTION NOT HANDLED]", { from, action: a });
  return sendText(from, "Sorry, that option expired. Please open the school link again to start fresh.");
}

// ── Main Menu back button - always goes to start menu ────────────────────
if (a === "main_menu_back") {
  return sendMainMenu(from);
}
// ═══════════════════════════════════════════════════════════════════════════════
// 🏫 SCHOOLS - Action handlers
// ═══════════════════════════════════════════════════════════════════════════════
 
// ── Parent taps "🏫 Find a School" ───────────────────────────────────────────
if (a === "find_school") {
  return startSchoolSearch(from, biz, saveBizSafe.bind(null, biz));
}
 

// ── School admin: facility toggle & paging (must come BEFORE parent search block)
if (
  a === "school_admin_manage_facilities" ||
  a.startsWith("school_fac_toggle_") ||
  a.startsWith("school_fac_page_")
) {
  const handled = await handleSchoolSearchActions({
    action: a,
    from,
    biz,
    saveBiz: saveBizSafe.bind(null, biz)
  });
  if (handled) return;
}
// ── Parent school search funnel steps (city → type → fees → facility → results)
if (
  a.startsWith("school_search_city_") ||
  a === "school_search_city_more" ||
  a.startsWith("school_search_type_") ||
  a.startsWith("school_search_fees_") ||
  a.startsWith("school_search_fac_") ||
  a.startsWith("school_search_page_") ||
  a === "school_search_refine"
) {
  if (biz) {
    biz.sessionData = biz.sessionData || {};
    biz.sessionData.schoolSearch = biz.sessionData.schoolSearch || {};
  }
  const handled = await handleSchoolSearchActions({
    action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (handled) return;
}
 
// ── Parent taps a school card (view detail / download / apply / contact) ─────
// NOTE: school_apply_start_ is intentionally excluded here - it has its own
// dedicated handler below (line ~12476) and at top-level (line ~3982).
// Routing school_apply_start_ through handleSchoolSearchActions() causes a
// CastError because that function strips "school_apply_" leaving "start_<id>"
// which is not a valid ObjectId.
if (
  a.startsWith("school_view_") ||
  a.startsWith("school_dl_profile_") ||
  (a.startsWith("school_apply_") && !a.startsWith("school_apply_start_")) ||
  a.startsWith("school_enquiry_")
) {
  const handled = await handleSchoolSearchActions({
    action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (handled) return;
}
 
// ── School admin actions (toggle admissions, update fees) ─────────────────────
if (a === "school_toggle_admissions" || a === "school_update_fees") {
  const handled = await handleSchoolSearchActions({
    action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
  });
  if (handled) return;
}
 
// ── School Application Form WhatsApp State Handler ─────────────────────────
// States: awaiting_start → awaiting_student_name → awaiting_grade →
//         awaiting_dob → awaiting_parent_name → awaiting_parent_phone → done
// "school_apply_start_<id>" button also handled here (isMetaAction path)
if (
  (a.startsWith("school_apply_start_") && flowSess?.tempData?.schoolApplyState === "awaiting_start") ||
  (a.startsWith("sa_grade_")           && flowSess?.tempData?.schoolApplyState === "awaiting_grade") ||
  (!isMetaAction && flowSess?.tempData?.schoolApplyState && flowSess.tempData.schoolApplyState !== "awaiting_start")
) {
  const _saState = flowSess.tempData.schoolApplyState;
  const _saId    = flowSess.tempData.schoolApplyId;
  let _saData = {};
  try { _saData = JSON.parse(flowSess.tempData.schoolApplyData || "{}"); } catch (_) {}

  const _saUpdate = async (nextState, extraData = {}) => {
    _saData = { ..._saData, ...extraData };
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.schoolApplyState": nextState, "tempData.schoolApplyData": JSON.stringify(_saData) } },
      { upsert: true }
    );
  };

  // Parent tapped "Apply on WhatsApp" button (awaiting_start or stale)
  if (_saState === "awaiting_start") {
    await _saUpdate("awaiting_student_name");
    await sendText(from,
      `📝 *Application - ${_saData.schoolName || "School"}*\n` +
      (_saData.intakeYear ? `_${_saData.intakeYear}_\n` : "") +
      `\nAnswer 5 quick questions - your application goes directly to the school.\n\n` +
      `*Step 1 of 5*\n` +
      `What is the *student's full name?*\n` +
      `_e.g. Tatenda Moyo_`
    );
    return;
  }

  if (_saState === "awaiting_student_name") {
    const _saName = text.trim();
    await _saUpdate("awaiting_grade", { studentName: _saName });
    const _saGrades = _saData.gradeOptions || [];
    if (_saGrades.length > 0 && _saGrades.length <= 10) {
      // Show grade as a list so parent just taps - no typing
      const _saRows = _saGrades.map(g => ({ id: `sa_grade_${g.replace(/\s+/g,"_")}`, title: g.slice(0,24) }));
      await sendList(from,
        `✅ *${_saName}*\n\n*Step 2 of 5*\nSelect the *grade or form* applying for:`,
        _saRows
      );
    } else {
      await sendText(from, `✅ *${_saName}*\n\n*Step 2 of 5*\nWhat *grade or form* are they applying for?\n_e.g. Form 1, Grade 7, ECD A_`);
    }
    return;
  }

  if (_saState === "awaiting_grade") {
    // Accept both free text and list reply (list reply: a = "sa_grade_Form_1", text = "Form 1")
    const _saGrade = a.startsWith("sa_grade_")
      ? a.replace(/^sa_grade_/,"").replace(/_/g," ").trim()
      : text.trim();
    await _saUpdate("awaiting_dob", { grade: _saGrade });
    await sendText(from, `✅ *${_saGrade}*\n\n*Step 3 of 5*\nWhat is the *student's date of birth?*\n_e.g. 15 March 2014 or 15/03/2014_`);
    return;
  }

  if (_saState === "awaiting_dob") {
    await _saUpdate("awaiting_parent_name", { dob: text.trim() });
    await sendText(from, `✅ *${text.trim()}*\n\n*Step 4 of 5*\nWhat is the *parent or guardian's full name?*\n_The name the school should use when contacting you_`);
    return;
  }

  if (_saState === "awaiting_parent_name") {
    await _saUpdate("awaiting_parent_phone", { parentName: text.trim() });
    await sendText(from, `✅ *${text.trim()}*\n\n*Step 5 of 5*\nWhat is your *WhatsApp / contact number?*\n_The school will call or message you on this number. You can also just type "same" to use this number._`);
    return;
  }

  if (_saState === "awaiting_parent_phone") {
    const _rawPhone = text.trim().toLowerCase();
    _saData.parentPhone = (_rawPhone === "same" || _rawPhone === "this") ? (from.startsWith("263") ? "0"+from.slice(3) : from) : _rawPhone;
    // Clear state
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.schoolApplyState": "", "tempData.schoolApplyId": "", "tempData.schoolApplyData": "" } },
      { upsert: true }
    );
    // Confirmation summary
    const _saSummary =
      `📝 *Application Submitted - ${_saData.schoolName || "School"}*\n\n` +
      `👤 Student: *${_saData.studentName || "-"}*\n` +
      `📚 Grade: *${_saData.grade || "-"}*\n` +
      `🎂 Date of Birth: *${_saData.dob || "-"}*\n` +
      `👪 Parent/Guardian: *${_saData.parentName || "-"}*\n` +
      `📞 Contact: *${_saData.parentPhone || (from.startsWith("263") ? "0"+from.slice(3) : from)}*`;
    await sendButtons(from, {
      text:
        `${_saSummary}\n\n` +
        `✅ *Application received!*\n` +
        `The school will contact you on *${_saData.parentPhone || (from.startsWith("263") ? "0"+from.slice(3) : from)}* shortly.\n\n` +
        `_Keep WhatsApp open - the school may message you here too._`,
      buttons: [
        { id: `sfaq_enquiry_${_saId}`, title: "❓ Ask a Question" },
        { id: `sfaq_back_${_saId}`,    title: "🏫 School Profile" }
      ]
    });
    // Save full contact + email + WhatsApp notify school
    try {
      const { captureSchoolContact, emailApplicationToSchool, notifySchoolApplyLinkOpened } = await import("./schoolApplicationForm.js");
      await captureSchoolContact({
        schoolId: _saId, phone, source: "apply",
        extraData: {
          studentName:   _saData.studentName,
          parentName:    _saData.parentName,
          gradeInterest: _saData.grade,
          converted:     true,
          appliedAt:     new Date(),
          applicationData: _saData
        }
      });
      const _saSchool = _saId ? await SchoolProfile.findById(_saId).lean() : null;
      if (_saSchool) {
        await emailApplicationToSchool({ school: _saSchool, data: _saData, applicantPhone: from });
        // WhatsApp notify school of completed WhatsApp application
        if (_saSchool.applicationForm?.notifyPhone) {
          try {
            const { sendButtons: _sbNotify } = await import("./metaSender.js");
            const _saNP = String(_saSchool.applicationForm.notifyPhone).replace(/\D/g,"");
            const _saNorm = _saNP.startsWith("0") ? "263"+_saNP.slice(1) : _saNP;
            const _saTime = new Date().toLocaleString("en-GB",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit",timeZone:"Africa/Harare"});
            await _sbNotify(_saNorm, {
              text:
                `✅ *New WhatsApp Application - ${_saSchool.schoolName}*\n\n` +
                `👤 *${_saData.studentName || "-"}*  |  📚 ${_saData.grade || "-"}\n` +
                `👪 Parent: *${_saData.parentName || "-"}*\n` +
                `📞 *${_saData.parentPhone || (from.startsWith("263") ? "0"+from.slice(3) : from)}*\n` +
                `⏰ ${_saTime}\n\n` +
                `_Full details sent to your email. Call the parent to confirm._`,
              buttons: [{ id: "school_my_profile", title: "🏫 My School" }]
            });
          } catch (_saNotifyErr) { console.warn("[SCHOOL WA NOTIFY]", _saNotifyErr.message); }
        }
      }
    } catch (_saFinalErr) { console.warn("[SCHOOL APPLY FINAL]", _saFinalErr.message); }
    return;
  }
}

// ── school_apply_start_<id> - parent tapped "Apply on WhatsApp" button ──────
// Fires whether session is awaiting_start (fresh) or any other state (stale tap).
// Always starts Step 1 questions immediately - never re-sends the menu.
if (a.startsWith("school_apply_start_")) {
  const _sasId = a.replace("school_apply_start_","").trim();
  try {
    const _sasSchool = await SchoolProfile.findById(_sasId).lean();
    if (_sasSchool) {
      const { captureSchoolContact } = await import("./schoolApplicationForm.js");
      const { notifyAllSchoolApplicationInterest } = await import("./schoolNotifications.js");
      captureSchoolContact({ schoolId: _sasId, phone, source: "apply" }).catch(() => {});
      notifyAllSchoolApplicationInterest(_sasSchool, from.startsWith("263") ? "0"+from.slice(3) : from).catch(() => {});

      // Read existing grade options from session or school
      let _sasGrades = [];
      let _sasSchoolName = _sasSchool.schoolName;
      let _sasIntakeYear = _sasSchool.applicationForm?.intakeYear || "";
      try {
        const _sasParsed = JSON.parse(flowSess?.tempData?.schoolApplyData || "{}");
        _sasGrades = _sasParsed.gradeOptions || _sasSchool.applicationForm?.gradeOptions || [];
      } catch(_) {
        _sasGrades = _sasSchool.applicationForm?.gradeOptions || [];
      }

      // Set state to awaiting_student_name (skip awaiting_start entirely)
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: {
            "tempData.schoolApplyId":    _sasId,
            "tempData.schoolApplyState": "awaiting_student_name",
            "tempData.schoolApplyData":  JSON.stringify({
              schoolId:     _sasId,
              schoolName:   _sasSchoolName,
              intakeYear:   _sasIntakeYear,
              gradeOptions: _sasGrades
            })
          }
        },
        { upsert: true }
      );

      // Send Step 1 immediately
      await sendText(from,
        `📝 *Application - ${_sasSchoolName}*\n` +
        (_sasIntakeYear ? `_${_sasIntakeYear}_\n` : "") +
        `\nAnswer 5 quick questions and your application goes directly to the school.\n\n` +
        `*Step 1 of 5*\n` +
        `What is the *student's full name?*\n` +
        `_e.g. Tatenda Moyo_`
      );
    } else {
      await sendText(from, "❌ This application link has expired. Please scan the QR code again.");
    }
  } catch (_sasErr) {
    console.warn("[SCHOOL APPLY START]", _sasErr.message);
  }
  return;
}

// ── School FAQ text state for no-biz first-time users ───────────────────────
// A parent who opened a school smart link (ZQ:SCHOOL:...) is NOT a biz user.
// Their sfaq state is in UserSession.tempData.sfaqState (saved by _sess in schoolFAQ.js).
if (!biz && !isMetaAction && flowSess?.tempData?.sfaqState?.startsWith("sfaq_")) {
  const handled = await handleSchoolFAQState({
    state: flowSess.tempData.sfaqState, from, text, biz: null, saveBiz: null
  });
  if (handled) return;
}


// ── Seller chatbot text states for no-biz buyers (sc_ quote/book/enquiry flow) ─
// A buyer who opened a supplier smart link and has NO business account still needs
// to complete the quote flow.  State is in UserSession.tempData.scState.
if (!biz && !isMetaAction && flowSess?.tempData?.scState?.startsWith("sc_")) {
  const { handleSellerChatState: _handleScStateNoBiz } = await import("./sellerChat.js");
  const _scNoBizHandled = await _handleScStateNoBiz({
    state: flowSess.tempData.scState,
    from,
    text,
    biz:     null,
    saveBiz: null
  });
  if (_scNoBizHandled) return;
}

// ── School enquiry text state for no-biz users (sent from smart link enquiry button) ─
// biz?.sessionData?.enquirySchoolId is null for first-time users.
// Read from UserSession.tempData instead and process the enquiry directly here.
if (!biz && !isMetaAction && flowSess?.tempData?.schoolEnquiryState === "school_parent_enquiry") {
  const _seSchoolId = flowSess?.tempData?.enquirySchoolId;
  if (_seSchoolId) {
    const _seRaw = String(text || "").trim();
    if (_seRaw.toLowerCase() === "cancel") {
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
        { upsert: true }
      );
      return sendButtons(from, {
        text: "❌ Enquiry cancelled.",
        buttons: [{ id: "find_school", title: "🏫 Find a School" }]
      });
    }
    if (!_seRaw || _seRaw.length < 3) {
      return sendText(from, "Please type your question or message. Type *cancel* to go back.");
    }
    const SchoolProfile = (await import("../models/schoolProfile.js")).default;
    const _seSchool = await SchoolProfile.findById(_seSchoolId).lean();
    if (_seSchool) {
      await SchoolProfile.findByIdAndUpdate(_seSchoolId, { $inc: { inquiries: 1 } });
      const { notifyAllSchoolEnquiry } = await import("./schoolNotifications.js");
      notifyAllSchoolEnquiry(_seSchool, from, _seRaw).catch(() => {});
      await UserSession.findOneAndUpdate(
        { phone },
        { $unset: { "tempData.schoolEnquiryState": "", "tempData.enquirySchoolId": "" } },
        { upsert: true }
      );
      return sendButtons(from, {
        text:
          `✅ *Enquiry Sent to ${_seSchool.schoolName}!*\n\n` +
          `Your message:\n_${_seRaw}_\n\n` +
          `The school has been notified and will reply on WhatsApp.\n` +
          `📞 ${_seSchool.contactPhone || _seSchool.phone}`,
        buttons: [
          { id: `school_apply_${_seSchoolId}`, title: "📝 Apply Online" },
          { id: "find_school",                  title: "🏫 More Schools" }
        ]
      });
    }
  }
}

// [APPLY:SCHOOL deep link now handled at top level - see top of file]

// ── ZQ deep-link intercept (ZQ:SCHOOL:id and ZQ:SUPPLIER:id) ────────────────
// FIX: tightened regex to require valid 24-char hex ID, and sanitize text to
// extract only the first valid deep-link token (handles wa.me doubled pre-fills).
if (!isMetaAction && /ZQ:(SCHOOL|SUPPLIER):[a-f0-9]{24}/i.test(text)) {
  const _zqMatch2 = text.match(/ZQ:(SCHOOL|SUPPLIER):([a-f0-9]{24})/i);
  const _zqClean2 = _zqMatch2 ? ("ZQ:" + _zqMatch2[1].toUpperCase() + ":" + _zqMatch2[2]) : text;
  // ── School profile view: capture contact + notify ALL school numbers ────────
  if (_zqMatch2 && _zqMatch2[1].toUpperCase() === "SCHOOL") {
    try {
      const _spView = await SchoolProfile.findById(_zqMatch2[2]).lean();
      if (_spView) {
        const { captureSchoolContact } = await import("./schoolApplicationForm.js");
        const { notifyAllSchoolProfileView } = await import("./schoolNotifications.js");
        const _spDisplayFrom = from.startsWith("263") ? "0"+from.slice(3) : from;
        captureSchoolContact({ schoolId: _zqMatch2[2], phone, source: "profile" }).catch(() => {});
        notifyAllSchoolProfileView(_spView, _spDisplayFrom).catch(() => {});
      }
    } catch (_spViewErr) { console.warn("[SCHOOL PROFILE VIEW]", _spViewErr.message); }
  }
  const _handled = await handleZqDeepLink({ from, text: _zqClean2, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

// ── ZQ:STAFF:<id> deep link intercept ────────────────────────────────────────
// Handles ZQ:STAFF:<24-hex>[:SRC:<src>] and ZQ:STAFF:SLUG:<slug>[:SRC:<src>]
// MUST run before ZQ:S: slug check so staff IDs are never misrouted.
if (!isMetaAction && /ZQ:STAFF:/i.test(text)) {
  const _handled = await handleStaffDeepLink({ from, text, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

// ── ZQ:S:<slug> - human-readable named supplier OR staff link ────────────────
if (!isMetaAction && /^ZQ:S:[a-z0-9_-]{1,60}$/i.test(text.trim())) {
  // Check staff slug first - staff cards use the same ZQ:S: prefix
  try {
    const _slug4 = text.trim().slice(5).toLowerCase(); // strip "ZQ:S:"
    const _StaffCardModel4 = (await import("../models/staffCard.js")).default;
    const _staffBySlug4 = await _StaffCardModel4.findOne({ zqSlug: _slug4 }).lean();
    if (_staffBySlug4) {
      const _sh4 = await handleStaffDeepLink({ from, text: "ZQ:STAFF:SLUG:" + _slug4, biz, saveBiz: saveBizSafe.bind(null, biz) });
      if (_sh4) return;
    }
  } catch (_) {}
  const _handled = await handleZqDeepLink({ from, text: text.trim(), biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

// ── ZQ:GROUP:<slug> - group smart link ───────────────────────────────────────
if (!isMetaAction && /^ZQ:GROUP:[a-z0-9-]{2,40}$/i.test(text.trim())) {
  const _slug = text.trim().split(":")[2]?.toLowerCase().trim();
  if (_slug) {
    const _handled = await handleGroupSmartLink({ from, slug: _slug, biz, saveBiz: saveBizSafe.bind(null, biz) });
    if (_handled) return;
  }
}

// ── Admin group / reactivation commands (from ZQ admin WhatsApp numbers) ───────
// Admin phone is set via ZQ_ADMIN_PHONE or ADMIN_WHATSAPP_PHONE env var.
if (!isMetaAction && text.trim().toLowerCase().startsWith("admin group")) {
  const _adminPhone = (process.env.ZQ_ADMIN_PHONE || process.env.ADMIN_WHATSAPP_PHONE || "").replace(/\D/g, "");
  if (_adminPhone && phone === _adminPhone) {
    const _handled = await handleGroupAdminCommand({ from, text: text.trim() });
    if (_handled) return;
  }
}

// ── Admin phone-reveal toggle (from ZQ admin WhatsApp number) ──────────────────
// Grants a seller permission to see buyer / visitor phone numbers, straight from
// WhatsApp - no need to open the /zq-admin panel. Mirrors the web VIP toggle.
//
//   admin revealphone 263773xxxxxx on        → enable BOTH (buyer + visitor)
//   admin revealphone 263773xxxxxx off       → disable both
//   admin revealphone 263773xxxxxx buyer on  → only buyer-on-requests
//   admin revealphone 263773xxxxxx visitor on→ only visitor-on-smartlink
//   admin revealphone 263773xxxxxx           → show current status
//
// Note: revealVisitorPhone (profile-viewer permission) also unlocks the buyer
// phone on requests - the two are treated as one permission tier in notifications.
if (!isMetaAction && /^admin\s+reveal ?phone\b/i.test(text.trim())) {
  const _adminPhone = (process.env.ZQ_ADMIN_PHONE || process.env.ADMIN_WHATSAPP_PHONE || "").replace(/\D/g, "");
  if (_adminPhone && phone === _adminPhone) {
    try {
      // tokens after the command word: [targetPhone] [scope? on|off] [on|off?]
      const _tok = text.trim().replace(/^admin\s+reveal ?phone\b/i, "").trim().split(/\s+/).filter(Boolean);
      const _rawTarget = _tok[0] || "";
      let _tgt = _rawTarget.replace(/\D+/g, "");
      if (_tgt.startsWith("0") && _tgt.length === 10) _tgt = "263" + _tgt.slice(1);

      if (!_tgt || _tgt.length < 9) {
        await sendText(from,
          `📱 *Phone reveal - usage*\n\n` +
          `• \`admin revealphone <number> on\` - enable buyer + visitor\n` +
          `• \`admin revealphone <number> off\` - disable both\n` +
          `• \`admin revealphone <number> buyer on\` - buyer only\n` +
          `• \`admin revealphone <number> visitor on\` - visitor only\n` +
          `• \`admin revealphone <number>\` - show status`
        );
        return;
      }

      // Parse optional scope (buyer|visitor|both) and state (on|off)
      const _rest  = _tok.slice(1).map(t => t.toLowerCase());
      const _scope = _rest.find(t => ["buyer", "visitor", "both"].includes(t)) || "both";
      const _state = _rest.find(t => ["on", "off", "enable", "disable", "true", "false"].includes(t));

      // Match seller by primary phone OR notification contact, any format.
      const _alt = _tgt.startsWith("263") ? "0" + _tgt.slice(3) : _tgt;
      const _sup = await SupplierProfile.findOne({
        $or: [
          { phone:                { $in: [_tgt, _alt, "+" + _tgt] } },
          { notificationContacts: { $in: [_tgt, _alt, "+" + _tgt] } }
        ]
      });

      if (!_sup) {
        await sendText(from, `⚠️ No seller found for *${_tgt}*.\n\nCheck the number and try again.`);
        return;
      }

      // No state word → report current status.
      if (!_state) {
        await sendText(from,
          `🔒 *Phone reveal status*\n\n` +
          `🏪 ${_sup.businessName}\n` +
          `📱 ${_sup.phone}\n\n` +
          `• Buyer phone on requests: ${_sup.revealBuyerPhone ? "🟢 ON" : "⚪ off"}\n` +
          `• Visitor phone on smart link: ${_sup.revealVisitorPhone ? "🟢 ON" : "⚪ off"}\n\n` +
          `_Add \`on\` or \`off\` to change._`
        );
        return;
      }

      const _enable = ["on", "enable", "true"].includes(_state);
      if (_scope === "buyer")   _sup.revealBuyerPhone   = _enable;
      else if (_scope === "visitor") _sup.revealVisitorPhone = _enable;
      else { _sup.revealBuyerPhone = _enable; _sup.revealVisitorPhone = _enable; }
      await _sup.save();

      const _lbl = _scope === "buyer" ? "Buyer phone on requests"
                 : _scope === "visitor" ? "Visitor phone on smart link"
                 : "Buyer + visitor phone reveal";
      console.log(`[ADMIN REVEALPHONE] ${_sup.phone} → ${_scope} ${_enable ? "ON" : "OFF"} by ${phone}`);
      await sendText(from,
        `✅ *${_lbl} ${_enable ? "enabled" : "disabled"}*\n\n` +
        `🏪 ${_sup.businessName} (${_sup.phone})\n\n` +
        `• Buyer phone on requests: ${_sup.revealBuyerPhone ? "🟢 ON" : "⚪ off"}\n` +
        `• Visitor phone on smart link: ${_sup.revealVisitorPhone ? "🟢 ON" : "⚪ off"}`
      );
      return;
    } catch (_rpErr) {
      console.warn("[ADMIN REVEALPHONE] failed:", _rpErr.message);
      await sendText(from, `⚠️ Could not update phone-reveal setting: ${_rpErr.message}`);
      return;
    }
  }
}

// ── ZQ slug shortcode "zq huxton-academy" ────────────────────────────────────
if (!isMetaAction && /^zq /i.test(text) && text.trim().length > 4) {
  const _handled = await handleSchoolSlugSearch({ from, text, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

// ── Staff card self-service: salesperson types "my card" / "staff card" ───────
// Lets any registered salesperson check their own card stats + get share captions
// without needing access to the admin panel.
if (!isMetaAction && /^(my card|staff card|my link|my qr)$/i.test(text.trim())) {
  const _handled = await handleStaffCardSelfMenu({ from });
  if (_handled) return;
}

// ── Staff card self-service: salesperson types "my card" / "staff card" ───────
// Lets any registered salesperson check their own card stats + get share captions
// without needing access to the admin panel.
if (!isMetaAction && /^(my card|staff card|my link|my qr)$/i.test(text.trim())) {
  const _handled = await handleStaffCardSelfMenu({ from });
  if (_handled) return;
}

// ── "my contacts" chatbot command ────────────────────────────────────────────
// Shows the list of phone numbers that have opened this seller's / school's /
// staff card's smart link - but ONLY if the admin has enabled canViewContacts
// on their profile. Default is off; only Typhon can switch it on.
// Supports pagination: "my contacts 2" shows page 2.
if (!isMetaAction && /^my contacts(\s+\d+)?$/i.test(text.trim())) {
  const _mcPage = parseInt((text.trim().match(/\d+/) || ["1"])[0], 10) - 1; // 0-indexed
  const _mcPageSize = 10;
  try {
    const SupplierLinkVisitor = (await import("../models/supplierLinkVisitor.js")).default;
    const SchoolContact       = (await import("../models/schoolContact.js")).default;

    // ── Check: is this a staff card member? ──────────────────────────────────
    const _StaffCard = (await import("../models/staffCard.js")).default;
    const _staffCard = await _StaffCard.findOne({ phone, active: true }).lean();
    if (_staffCard && _staffCard.canViewContacts) {
      const _total = await SupplierLinkVisitor.countDocuments({ staffCardId: _staffCard._id, linkType: "staff" });
      const _visitors = await SupplierLinkVisitor.find({ staffCardId: _staffCard._id, linkType: "staff" })
        .sort({ lastSeen: -1 }).skip(_mcPage * _mcPageSize).limit(_mcPageSize).lean();

      if (!_total) {
        return sendText(from,
          `👥 *My Card Contacts*\n\nNo one has opened your staff card link yet.\n\n` +
          `Share your link to start getting contacts:\n` +
          `_ZQ:STAFF:${String(_staffCard._id)}_`
        );
      }

      const _srcLabel = { fb:"Facebook", wa:"WhatsApp", tt:"TikTok", qr:"QR", sms:"SMS", ig:"Instagram", yt:"YouTube", direct:"Direct" };
      const _lines = _visitors.map((v, i) => {
        const _d  = new Date(v.lastSeen).toLocaleDateString("en-GB", { day:"numeric", month:"short" });
        const _ph = v.phone.startsWith("263") ? "0" + v.phone.slice(3) : v.phone;
        return `${_mcPage * _mcPageSize + i + 1}. ${_ph} · ${_srcLabel[v.source] || v.source} · ${_d}${v.converted ? " ✅" : ""}`;
      }).join("\n");

      const _totalPages = Math.ceil(_total / _mcPageSize);
      const _header = `👥 *Card Contacts (${_total} total)*\n_Page ${_mcPage + 1} of ${_totalPages}_\n\n`;
      const _footer = _totalPages > 1 ? `\n\nType *my contacts ${_mcPage + 2}* for next page.` : "";
      return sendText(from, _header + _lines + _footer);
    }

    // ── Check: is this a school admin? ───────────────────────────────────────
    const _schoolForContacts = await SchoolProfile.findOne({ phone }).lean();
    if (_schoolForContacts) {
      if (!_schoolForContacts.canViewContacts) {
        return sendText(from,
          `🔒 *Contact Database*\n\nThis feature is not enabled on your account.\n\n` +
          `Contact ZimQuote to activate the contact viewer for your school.`
        );
      }
      const _total = await SchoolContact.countDocuments({ schoolId: _schoolForContacts._id });
      const _contacts = await SchoolContact.find({ schoolId: _schoolForContacts._id })
        .sort({ lastSeen: -1 }).skip(_mcPage * _mcPageSize).limit(_mcPageSize).lean();

      if (!_total) {
        return sendText(from,
          `👥 *My School Contacts*\n\nNo contacts recorded yet.\n\n` +
          `Share your school smart link to start capturing contacts.`
        );
      }

      const _srcLabel2 = { profile:"Profile link", apply:"Apply link", enquiry:"Enquiry", brochure:"Brochure" };
      const _lines2 = _contacts.map((c, i) => {
        const _d  = new Date(c.lastSeen).toLocaleDateString("en-GB", { day:"numeric", month:"short" });
        const _ph = c.phone.startsWith("263") ? "0" + c.phone.slice(3) : c.phone;
        const _name = c.parentName || c.name || "";
        return `${_mcPage * _mcPageSize + i + 1}. ${_ph}${_name ? " · " + _name : ""} · ${_srcLabel2[c.source] || c.source} · ${_d}${c.converted ? " ✅" : ""}`;
      }).join("\n");

      const _totalPages2 = Math.ceil(_total / _mcPageSize);
      const _header2 = `👥 *School Contacts (${_total} total)*\n_Page ${_mcPage + 1} of ${_totalPages2}_\n✅ = submitted application\n\n`;
      const _footer2 = _totalPages2 > 1 ? `\n\nType *my contacts ${_mcPage + 2}* for next page.` : "";
      return sendText(from, _header2 + _lines2 + _footer2);
    }

    // ── Check: is this a supplier? ───────────────────────────────────────────
    const _supForContacts = await SupplierProfile.findOne({ phone }).lean();
    if (!_supForContacts) {
      // Not a supplier, school, or staff - silently ignore
    } else if (!_supForContacts.canViewContacts) {
      return sendText(from,
        `🔒 *Contact Database*\n\nThis feature is not enabled on your account.\n\n` +
        `Contact ZimQuote to activate the contact viewer for your listing.`
      );
    } else {
      const _total = await SupplierLinkVisitor.countDocuments({ supplierId: _supForContacts._id, linkType: "supplier" });
      const _visitors = await SupplierLinkVisitor.find({ supplierId: _supForContacts._id, linkType: "supplier" })
        .sort({ lastSeen: -1 }).skip(_mcPage * _mcPageSize).limit(_mcPageSize).lean();

      if (!_total) {
        return sendText(from,
          `👥 *My Link Contacts*\n\nNo contacts yet - share your ZimQuote link to start.\n\n` +
          `Type *my link* or go to *My Smart Link* for your link and QR code.`
        );
      }

      const _srcLabel3 = { fb:"Facebook", wa:"WhatsApp", tt:"TikTok", qr:"QR", sms:"SMS", ig:"Instagram", yt:"YouTube", direct:"Direct" };
      const _lines3 = _visitors.map((v, i) => {
        const _d  = new Date(v.lastSeen).toLocaleDateString("en-GB", { day:"numeric", month:"short" });
        const _ph = v.phone.startsWith("263") ? "0" + v.phone.slice(3) : v.phone;
        return `${_mcPage * _mcPageSize + i + 1}. ${_ph} · ${_srcLabel3[v.source] || v.source} · ${_d}${v.converted ? " ✅" : ""}`;
      }).join("\n");

      const _totalPages3 = Math.ceil(_total / _mcPageSize);
      const _header3 = `👥 *Smart Link Contacts (${_total} total)*\n_Page ${_mcPage + 1} of ${_totalPages3}_\n✅ = sent quote/enquiry/order\n\n`;
      const _footer3 = _totalPages3 > 1 ? `\n\nType *my contacts ${_mcPage + 2}* for next page.` : "";
      return sendText(from, _header3 + _lines3 + _footer3);
    }
  } catch (_mcErr) {
    console.error("[MY CONTACTS]", _mcErr.message);
  }
}

// [REMOVED: old school_apply_ handler - now handled by school_apply_start_ above]

// ── School FAQ chatbot (sfaq_ actions) ───────────────────────────────────────
if (a.startsWith("sfaq_")) {
  const handled = await handleSchoolFAQAction({
    from, action: a, biz,
    saveBiz: biz ? saveBizSafe.bind(null, biz) : null
  });
  if (handled) return;
  // Don't fall through to sendMainMenu - just silently ignore unhandled sfaq
  return;
}

// ── Group smart link seller tap (zqg_sel_<supplierId>) ───────────────────────
if (a.startsWith("zqg_sel_")) {
  const _handled = await handleGroupSellerTap({ from, action: a, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (_handled) return;
}

// ── Seller chatbot (sc_ actions) ─────────────────────────────────────────────
if (a.startsWith("sc_")) {
  // ── Staff card actions (sc_staff_share_ / sc_staff_stats_) ───────────────
  // These must be checked BEFORE the main sc_ router because they don't follow
  // the standard sc_<topic>_<supplierId> pattern - they use a staffCardId.
  if (a.startsWith("sc_staff_")) {
    const _staffHandled = await handleStaffCardAction({ from, action: a });
    if (_staffHandled) return;
  }

  // ── FIX: clear stale sellerRequestReplyState when buyer taps sc_quote_ ───
  // sc_quote_<supplierId> is ALWAYS a buyer-initiated smart-link quote action.
  // If the same phone previously received a marketplace seller notification and
  // still has sellerRequestReplyState in session, that stale state would cause
  // the BuyerRequest intercept (lines ~4746-4880) to fire and return
  // "That request has closed." - completely wrong for a smart-link buyer.
  // Clearing the stale state here prevents the bleed-through entirely.
  if (a.startsWith("sc_quote_") && !a.startsWith("sc_quote_confirm_") &&
      !a.startsWith("sc_quote_edit_") && !a.startsWith("sc_quote_done_") &&
      !a.startsWith("sc_quote_clear_") && !a.startsWith("sc_scope_skip_")) {
    try {
      const _sqCheck = await UserSession.findOne({ phone }).lean();
      if (_sqCheck?.tempData?.sellerRequestReplyState || _sqCheck?.tempData?.sellerRequestId) {
        await UserSession.findOneAndUpdate(
          { phone },
          { $unset: {
              "tempData.sellerRequestReplyState": "",
              "tempData.sellerRequestId":          "",
              "tempData.pendingDraftQuote":        "",
              "tempData.pendingOfferResponse":     ""
          }},
          { upsert: true }
        );
        console.log(`[SC_QUOTE_FIX] Cleared stale sellerRequestReplyState for ${phone} - smart-link quote wins`);
      }
    } catch (_sqErr) { /* non-critical */ }
  }

  // FIX: for no-biz users mid-sc_ flow (e.g. sc_quote_done_ after typing items),
  // reconstruct the virtual biz from UserSession so _scQuoteDone etc. can read
  // scQuoteItems / scRFQ / scSellerId - otherwise biz=null and items=[].
  let _scActionBiz = biz;
  let _scActionSaveBiz = saveBizSafe.bind(null, biz);
  if (!biz) {
    const _scActSess = await UserSession.findOne({ phone });
    const _scActState = _scActSess?.tempData?.scState;
    const _scActSellerId = _scActSess?.tempData?.scSellerId;
    if (_scActState?.startsWith("sc_") && _scActSellerId) {
      const _parseArr = (v) => { try { return typeof v === "string" ? JSON.parse(v) : (v || []); } catch(_){return [];} };
      _scActionBiz = {
        sessionState: _scActState,
        sessionData: {
          scSellerId:      _scActSellerId,
          scQuoteItems:    _parseArr(_scActSess.tempData.scQuoteItems),
          scRFQ:           _scActSess.tempData.scRFQ === true || _scActSess.tempData.scRFQ === "true",
          scIsHospitality: _scActSess.tempData.scIsHospitality === true || _scActSess.tempData.scIsHospitality === "true",
          scIsService:     _scActSess.tempData.scIsService === true || _scActSess.tempData.scIsService === "true",
          scCatalogue:     _scActSess.tempData.scCatalogue || "",
          scCatalogueType: _scActSess.tempData.scCatalogueType || "product",
          scTouristNote:   _scActSess.tempData.scTouristNote || "",
          scPeopleCount:   _scActSess.tempData.scPeopleCount || ""
        }
      };
      _scActionSaveBiz = async (vb) => {
        const sd = vb.sessionData || {};
        const { default: UserSessionModel } = await import("../models/userSession.js");
        const updates = {
          "tempData.scState":         vb.sessionState || "ready",
          "tempData.scSellerId":      sd.scSellerId || _scActSellerId,
          "tempData.scQuoteItems":    JSON.stringify(sd.scQuoteItems || []),
          "tempData.scRFQ":           sd.scRFQ || false,
          "tempData.scIsHospitality": sd.scIsHospitality || false,
          "tempData.scIsService":     sd.scIsService || false,
          "tempData.scCatalogue":     sd.scCatalogue || "",
          "tempData.scCatalogueType": sd.scCatalogueType || "product",
          "tempData.scTouristNote":   sd.scTouristNote || "",
          "tempData.scPeopleCount":   sd.scPeopleCount || ""
        };
        if (!vb.sessionState || vb.sessionState === "ready") {
          await UserSessionModel.findOneAndUpdate(
            { phone },
            { $unset: { "tempData.scState": "", "tempData.scSellerId": "", "tempData.scQuoteItems": "",
                        "tempData.scRFQ": "", "tempData.scIsHospitality": "", "tempData.scIsService": "",
                        "tempData.scCatalogue": "", "tempData.scCatalogueType": "", "tempData.scTouristNote": "", "tempData.scPeopleCount": "" }},
            { upsert: true }
          );
        } else {
          await UserSessionModel.findOneAndUpdate({ phone }, { $set: updates }, { upsert: true });
        }
      };
    }
  }
  const handled = await handleSellerChatAction({ from, action: a, biz: _scActionBiz, saveBiz: _scActionSaveBiz });
  if (handled) return;
}

// ── Smart Card / ZQ Link admin actions ───────────────────────────────────────
if (a === "school_get_zq_link" || a === "school_share_link_wa" ||
    a === "school_smart_card_menu" || a === "school_my_leads" ||
    a.startsWith("school_sc_src_") || a.startsWith("school_followup_") ||
    a.startsWith("school_leads_page_")) {
  const handled = await handleSchoolSearchActions({ action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz) });
  if (handled) return;
}

// ── School registration entry (tapped from main menu or account) ──────────────
if (a === "school_register") {
  return startSchoolRegistration(from, biz);
}
 
// ── School account dashboard (for registered school admins) ──────────────────
if (a === "school_account") {
  const schoolPhone = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone: schoolPhone });
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  return sendSchoolAccountMenu(from, school);
}

// ── School profile summary ────────────────────────────────────────────────────
if (a === "school_my_profile") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { SCHOOL_FACILITIES, SCHOOL_EXTRAMURALACTIVITIES } = await import("./schoolPlans.js");
 const typeLabels    = { ecd: "ECD / Preschool Only", ecd_primary: "ECD + Primary", primary: "Primary (Grade 1–7)", secondary: "Secondary (Form 1–6)", combined: "Combined (ECD–Form 6)" };
  const genderLabels  = { mixed: "Mixed (Co-ed)", boys: "Boys Only", girls: "Girls Only" };
  const boardingLabels= { day: "Day School", boarding: "Boarding", both: "Day & Boarding" };
  const curricText    = (school.curriculum || []).map(c => c.toUpperCase()).join(" + ") || "Not set";
  const facList       = (school.facilities || []).map(id => SCHOOL_FACILITIES.find(f => f.id === id)?.label || id).join("\n  ") || "None added";
  const extList       = (school.extramuralActivities || []).slice(0, 8).map(id => SCHOOL_EXTRAMURALACTIVITIES.find(e => e.id === id)?.label || id).join(", ") || "None added";
  const feeLine       = school.fees?.term1 ? `$${school.fees.term1} / $${school.fees.term2} / $${school.fees.term3} per term (USD)` : "Not set";
const profileMsg = [
    `🏫 *${school.schoolName}*${school.verified ? " ✅" : ""}`,
    `📍 ${school.suburb || ""}, ${school.city}${school.address ? "\n🏠 " + school.address : ""}`,
    school.principalName ? `👤 Principal: ${school.principalName}` : "",
    `📧 ${school.email || "No email set"}`,
    `🌐 ${school.website || "No website set"}`,
    "",
    `📗 *Type:* ${typeLabels[school.type] || school.type}`,
    `📚 *Curriculum:* ${curricText}`,
    `👫 *Gender:* ${genderLabels[school.gender] || school.gender}`,
    `🏠 *Boarding:* ${boardingLabels[school.boarding] || school.boarding}`,
    `📐 *Grades:* ${school.grades?.from || "ECD A"}- ${school.grades?.to || "Form 6"}`,
    "",
    `💵 *Fees:* ${feeLine}`,
    "",
    `🏊 *Facilities (${(school.facilities || []).length}):*`,
    `  ${facList}`,
    "",
    `🏃 *Extramural:* ${extList}`,
    "",
    `📝 *Admissions:* ${school.admissionsOpen ? "🟢 Currently OPEN" : "🔴 Currently CLOSED"}`,
    `🔗 *Apply link:* ${school.registrationLink || "Not set"}`
  ].filter(l => l !== null).join("\n");
  await sendText(from, profileMsg);
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  return sendSchoolAccountMenu(from, school);
}

// ── School facilities manager ─────────────────────────────────────────────────
if (a === "school_my_facilities") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { SCHOOL_FACILITIES } = await import("./schoolPlans.js");
  const selected = (school.facilities || []).map(id => SCHOOL_FACILITIES.find(f => f.id === id)?.label || id).join("\n") || "None selected yet";
  const FAC_PAGE_SIZE = 7;
  const facRows = SCHOOL_FACILITIES.slice(0, FAC_PAGE_SIZE).map(f => ({
    id:    `school_fac_toggle_${f.id}`,
    title: (school.facilities || []).includes(f.id) ? `✅ ${f.label}` : f.label
  }));
  facRows.push({ id: "school_fac_page_1", title: "➡ More Facilities" });
  facRows.push({ id: "school_account",    title: "💾 Done" });
  await sendText(from, `🏊 *Your Current Facilities:*\n\n${selected}\n\nTap to add or remove:`);
  return sendList(from, "🏊 *Manage Facilities* - tap to toggle:", facRows);
}

// ── Facility toggle (school admin toggling their own facilities) ───────────────
if (a.startsWith("school_fac_toggle_")) {
  const facId = a.replace("school_fac_toggle_", "");
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  school.facilities = school.facilities || [];
  if (school.facilities.includes(facId)) {
    school.facilities = school.facilities.filter(f => f !== facId);
  } else {
    school.facilities.push(facId);
  }
  await school.save();
  const { SCHOOL_FACILITIES } = await import("./schoolPlans.js");
  const FAC_PAGE_SIZE = 7;
  const facPage = Number(biz?.sessionData?.schoolFacPage || 0);
  const facRows = SCHOOL_FACILITIES.slice(facPage * FAC_PAGE_SIZE, (facPage + 1) * FAC_PAGE_SIZE).map(f => ({
    id:    `school_fac_toggle_${f.id}`,
    title: school.facilities.includes(f.id) ? `✅ ${f.label}` : f.label
  }));
  const hasMore = (facPage + 1) * FAC_PAGE_SIZE < SCHOOL_FACILITIES.length;
  if (facPage > 0) facRows.push({ id: `school_fac_page_${facPage - 1}`, title: "⬅ Previous" });
  if (hasMore)     facRows.push({ id: `school_fac_page_${facPage + 1}`, title: "➡ More" });
  facRows.push({ id: "school_account", title: "💾 Done" });
  return sendList(from, `🏊 *${school.facilities.length} selected* - tap to toggle:`, facRows);
}

// ── Facility page navigation (school admin) ────────────────────────────────────
if (a.startsWith("school_fac_page_")) {
  const newPage = parseInt(a.replace("school_fac_page_", ""), 10) || 0;
  if (biz) { biz.sessionData = { ...(biz.sessionData || {}), schoolFacPage: newPage }; await saveBizSafe(biz); }
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { SCHOOL_FACILITIES } = await import("./schoolPlans.js");
  const FAC_PAGE_SIZE = 7;
  const facRows = SCHOOL_FACILITIES.slice(newPage * FAC_PAGE_SIZE, (newPage + 1) * FAC_PAGE_SIZE).map(f => ({
    id:    `school_fac_toggle_${f.id}`,
    title: school.facilities.includes(f.id) ? `✅ ${f.label}` : f.label
  }));
  const hasMore = (newPage + 1) * FAC_PAGE_SIZE < SCHOOL_FACILITIES.length;
  if (newPage > 0) facRows.push({ id: `school_fac_page_${newPage - 1}`, title: "⬅ Previous" });
  if (hasMore)     facRows.push({ id: `school_fac_page_${newPage + 1}`, title: "➡ More" });
  facRows.push({ id: "school_account", title: "💾 Done" });
  return sendList(from, `🏊 *Facilities (page ${newPage + 1})* - ${school.facilities.length} selected:`, facRows);
}

// ── Update fees ────────────────────────────────────────────────────────────────
if (a === "school_my_fees") {
  if (biz) { biz.sessionState = "school_admin_update_fees"; await saveBizSafe(biz); }
  return sendText(from,
`💵 *Update School Fees*

Enter your fees per term in USD as: *term1, term2, term3*
Example: *900, 900, 850*

Or one amount if all terms are equal: *900*`
  );
}

// ── Reviews summary ───────────────────────────────────────────────────────────
if (a === "school_my_reviews") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  if (!school.reviewCount) {
    await sendText(from,
`⭐ *My Reviews*

No reviews yet.

Once parents interact with your listing and submit ratings, they will appear here.

💡 Tip: Make sure your admissions are open and your profile is complete - parents are more likely to rate schools they engaged with.`
    );
    return sendSchoolAccountMenu(from, school);
  }
  await sendText(from,
`⭐ *My Reviews*

Rating: ${school.rating.toFixed(1)} / 5
Total reviews: ${school.reviewCount}

${school.verified ? "🏅 Your school is Verified - this builds parent trust." : "💡 Tip: A verified badge from ZimQuote boosts parent confidence. Contact support to apply."}`
  );
  return sendSchoolAccountMenu(from, school);
}

// ── Inquiries summary ─────────────────────────────────────────────────────────
if (a === "school_my_inquiries") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  await sendText(from,
`📬 *Parent Inquiries*

Total inquiries received: *${school.inquiries || 0}*
Profile views this month: *${school.monthlyViews || 0}*

Every time a parent taps "Contact School", "Apply Online", or "Download Profile" on your listing, it counts as an inquiry.

💡 *Tips to get more inquiries:*
- Keep admissions marked as 🟢 Open when accepting
- Add your online application link so parents can apply instantly
- Complete your facilities list - parents filter by swimming pool, lab, etc.
- Ask parents to rate your school after interactions`
  );
  return sendSchoolAccountMenu(from, school);
}

// ── Applications (parents who applied to THIS school) ─────────────────────────
if (a === "school_applications") {
  return _renderSchoolContactList(from, phone, {
    filter: "applications",
    title: "📝 *Applications*",
    emptyMsg: `📝 *Applications*\n\nNo applications yet.\n\n💡 Add your online application link (⚙️ Settings → Registration Form Link) and keep admissions 🟢 Open so parents can apply instantly from your listing.`
  });
}

// ── Enquiries (parent questions / leads) ──────────────────────────────────────
if (a === "school_enquiries") {
  return _renderSchoolContactList(from, phone, {
    filter: "enquiries",
    title: "📬 *Enquiries*",
    emptyMsg: `📬 *Enquiries*\n\nNo enquiries yet.\n\n💡 Share your smart link (📣 Share & Grow) on WhatsApp and Facebook so parents can reach you.`
  });
}

// ── Who viewed my profile (visitor contacts) ─────────────────────────────────
if (a === "school_contacts") {
  return _renderSchoolContactList(from, phone, {
    filter: "all",
    title: "👀 *Who Viewed My Profile*",
    emptyMsg: `👀 *Who Viewed My Profile*\n\nNo one has opened your profile yet.\n\n💡 Share your smart link (📣 Share & Grow) to start capturing parent contacts.`
  });
}

// ── Buy supplies (marketplace submenu) ────────────────────────────────────────
if (a === "school_marketplace") {
  const { sendSchoolMarketplaceMenu } = await import("./metaMenus.js");
  return sendSchoolMarketplaceMenu(from);
}

// ── Share & Grow (smart link + where to share + growth tips) ─────────────────
if (a === "school_share_link") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  const slug = school.zqSlug ? String(school.zqSlug) : "";
  const link = slug
    ? `https://wa.me/263771143904?text=${encodeURIComponent("ZQ:SCHOOL:" + slug)}`
    : "";
  const linkBlock = link
    ? `🔗 *Your smart link:*\n${link}\n\nWhen a parent taps it, your profile opens on WhatsApp and their contact is captured for you (see 👀 Who Viewed Me).`
    : `🔗 Your smart link isn't set up yet - contact ZimQuote to activate it.`;
  await sendText(from,
`📣 *Share & Grow - ${school.schoolName}*

${linkBlock}

*Where to share it:*
• Facebook page & WhatsApp Status
• School gate banner / flyer (as a QR code)
• Parent WhatsApp groups
• SMS to prospective parents

💡 *Get more applications:*
• Keep admissions 🟢 Open
• Add your online application link (⚙️ Settings)
• Complete your fees & facilities - parents filter by these
• Ask happy parents to leave a review`
  );
  return sendSchoolAccountMenu(from, school);
}

// ── More options menu ─────────────────────────────────────────────────────────
if (a === "school_more_options") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  const { sendSchoolMoreOptionsMenu } = await import("./metaMenus.js");
  return sendSchoolMoreOptionsMenu(from, school);
}

// ── Update online application link ────────────────────────────────────────────
if (a === "school_update_reg_link") {
  const school = await SchoolProfile.findOne({ phone });
  if (biz) { biz.sessionState = "school_admin_update_reg_link"; await saveBizSafe(biz); }
  const currentLink = school?.registrationLink
    ? `\n\n_Current link:_ ${school.registrationLink}\n\nSend a new link to replace it, or type *cancel* to keep the current one.`
    : "";
  return sendText(from,
`🔗 *Online Registration Form Link*

Enter the URL of your school's online application form.${currentLink}

_Accepted formats:_
- Google Form: _https://forms.gle/abc123_
- School website: _https://stdavids.ac.zw/apply_
- Any form builder link

Parents tap "📝 Apply Online" and are sent directly to this link.

Type *cancel* to go back.`
  );
}

// ── Update email ──────────────────────────────────────────────────────────────
if (a === "school_update_email") {
  if (biz) { biz.sessionState = "school_admin_update_email"; await saveBizSafe(biz); }
  return sendText(from, "📧 *Update Email*\n\nEnter your school's email address:\n\n_e.g. admin@stjohns.ac.zw_");
}

// ── Update website ────────────────────────────────────────────────────────────
if (a === "school_update_website") {
  if (biz) { biz.sessionState = "school_admin_update_website"; await saveBizSafe(biz); }
  return sendText(from, "🌐 *Update Website*\n\nEnter your school's website:\n\n_e.g. www.stjohns.ac.zw_");
}
 

// ── Upload school brochure / prospectus ───────────────────────────────────────
if (a === "school_upload_brochure") {
  const school = await SchoolProfile.findOne({ phone });
  if (!school) return sendMainMenu(from);
  if (biz) { biz.sessionState = "school_admin_awaiting_brochure"; await saveBizSafe(biz); }
  const currentStatus = school.profilePdfUrl
    ? `✅ *You already have a brochure uploaded.*\n\nSend a new PDF to replace it, or type *cancel* to keep the current one.`
    : `📄 *Upload Your School Brochure*\n\nSend your school prospectus or brochure as a *PDF file*.\n\nParents will be able to download it when they find your school.\n\nType *cancel* to go back.`;
  return sendText(from, currentStatus);
}
// ── School plan selection / activation payment ────────────────────────────────
if (a === "school_pay_plan") {
  const schoolPhone = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone: schoolPhone });
  if (!school) return startSchoolRegistration(from, biz);
  return sendList(from,
    "💳 *Choose Your Plan*\n\nAll plans include:\n✅ Listed in parent search\n✅ Downloadable school profile PDF\n✅ Online application link\n✅ Parent inquiry alerts on WhatsApp",
    [
      { id: "school_plan_basic_monthly",    title: "✅ Basic - $15/month",    description: "Listed in search + profile PDF + application link" },
      { id: "school_plan_basic_annual",     title: "✅ Basic - $150/year",    description: "Save $30 vs monthly" },
      { id: "school_plan_featured_monthly", title: "🔥 Featured $35/mo", description: "Top of results + verified badge + analytics" },
      { id: "school_plan_featured_annual",  title: "🔥 Featured $350/yr", description: "Save $70 vs monthly" }
    ]
  );
}
 
// ── School registration button taps (multi-select steps, confirm, plan pick) ──
// ── School registration + school admin actions (buttons/lists, incl. plan pick) ──
if (
  a.startsWith("school_reg_type_") ||
  a.startsWith("school_reg_city_") ||
  a.startsWith("school_reg_cur_") ||
  a.startsWith("school_reg_gender_") ||
  a.startsWith("school_reg_boarding_") ||
  a.startsWith("school_reg_fac_") ||
  a.startsWith("school_reg_ext_") ||
  a === "school_reg_city_more" ||
  a.startsWith("school_plan_") ||
  a === "school_reg_address_skip" ||
  a === "school_reg_principal_skip" ||
  a === "school_reg_email_skip" ||
  a === "school_reg_cur_done" ||
  a === "school_reg_fac_done" ||
  a === "school_reg_ext_done" ||
  a === "school_reg_city_other" ||
  a === "school_reg_confirm_yes" ||
  a === "school_reg_confirm_no" ||

  // ── school admin actions ───────────────────────────────────────────────
  a === "school_admin_manage_facilities" ||
  a === "school_admin_manage_extramural" ||
  a === "school_admin_edit_fees" ||
  a === "school_admin_edit_reg_link" ||
  a === "school_admin_edit_email" ||
  a === "school_admin_edit_website" ||
  a === "school_admin_upload_brochure" ||
  a.startsWith("school_fac_page_") ||
  a.startsWith("school_fac_toggle_") ||
  a.startsWith("school_ext_page_") ||
  a.startsWith("school_ext_toggle_")
) {
  if (!biz) {
    await sendText(from, "❌ Session expired. Type *menu* to start again.");
    return;
  }

  // school registration actions
  if (
    a.startsWith("school_reg_") ||
    a.startsWith("school_plan_")
  ) {
    const handled = await handleSchoolRegistrationActions({
      action: a, from, biz, saveBiz: saveBizSafe.bind(null, biz)
    });
    if (handled) return;
  }

  // school admin actions
if (
    a === "school_admin_manage_facilities" ||
    a.startsWith("school_fac_page_") ||
    a.startsWith("school_fac_toggle_")
  ) {
    const handled = await handleSchoolSearchActions({
      action: a,
      from,
      biz,
      saveBiz: saveBizSafe.bind(null, biz)   // ← FIXED
    });
    if (handled) return;
  }
  // other school admin actions
  if (
    a === "school_admin_manage_extramural" ||
    a === "school_admin_edit_fees" ||
    a === "school_admin_edit_reg_link" ||
    a === "school_admin_edit_email" ||
    a === "school_admin_edit_website" ||
    a === "school_admin_upload_brochure" ||
    a.startsWith("school_ext_page_") ||
    a.startsWith("school_ext_toggle_")
  ) {
    const handled = await handleSchoolAdminStates({
      state: biz.sessionState,
      from,
      text: "",
      action: a,
      biz,
      saveBiz: saveBizSafe.bind(null, biz)
    });
    if (handled) return;
  }
}

if (a === "my_supplier_account") {
  // Smart router: one button, correct destination based on account state
  const supplier = await SupplierProfile.findOne({ phone });

  if (!supplier) {
    // No supplier profile at all → send to registration
    return startSupplierRegistration(from, biz);
  }

  if (!supplier.active) {
    const isComplete = Boolean(
      supplier.businessName &&
      supplier.products?.length > 0
    );
    if (!isComplete) {
      await sendText(from,
`⚠️ *Your registration is incomplete.*\n\nLet's finish setting up your listing first.`
      );
      return startSupplierRegistration(from, biz);
    }
    await sendText(from,
`🔒 *Listing not yet active.*\n\nYour profile is saved but buyers cannot find you yet. Choose a plan to go live and unlock invoicing, quotes and more.`
    );
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  return sendSupplierAccountMenu(from, supplier);
}

// ── Business tools menu (for active suppliers wanting invoicing etc.) ────
// ── Business tools menu (for active suppliers wanting invoicing etc.) ────
if (a === "biz_tools_menu") {
  if (!biz) {
    await sendText(from, "❌ No business account found. Please register first.");
    return sendMainMenu(from);
  }
  const { sendBusinessToolsMenu } = await import("./metaMenus.js");
  return sendBusinessToolsMenu(from, biz);
}

// Marketplace submenu - the ZimQuote marketplace options that used to sit on
// the main menu. Reached from the "🛍️ Marketplace" row of the business home menu.
if (a === "marketplace_menu") {
  const { sendMarketplaceMenu } = await import("./metaMenus.js");
  let _hasStore = false;
  try { _hasStore = !!(await SupplierProfile.findOne({ phone }).lean()); } catch (_) {}
  return sendMarketplaceMenu(from, biz, { isOwner: _hasStore });
}


if (a === "sup_more_options") {
  const supplier = await SupplierProfile.findOne({ phone });
  return sendSupplierMoreOptionsMenu(from, supplier);
}


if (a === "sup_view_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  const listed = (supplier.listedProducts || []).filter(Boolean);

  if (!listed.length) {
    return sendButtons(from, {
      text: `📋 No listed ${isService ? "services" : "products"} yet.`,
      buttons: [
        { id: "sup_manage_listed_products", title: "⬅ Back" }
      ]
    });
  }

  await sendSupplierItemsInChunks(
    from,
    listed,
    `📋 Current Listed ${isService ? "Services" : "Products"}`
  );

  return sendButtons(from, {
    text: "What would you like to do next?",
    buttons: [
      { id: "sup_add_listed_products", title: "➕ Add More" },
      { id: "sup_remove_listed_products", title: "🗑 Remove" },
      { id: "sup_replace_listed_products", title: "🔄 Replace" }
    ]
  });
}



if (a === "sup_add_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap = capMap[supplier.tier] || 20;
  const listed = supplier.listedProducts || [];
  const uploaded = (supplier.products || []).filter(p => p && p !== "pending_upload");

  const available = uploaded.filter(p =>
    !listed.some(lp => normalizeProductName(lp) === normalizeProductName(p))
  );

  const slotsLeft = cap - listed.length;
  if (slotsLeft <= 0) {
    return sendButtons(from, {
      text: `❌ You have reached your listing limit (${listed.length}/${cap}). Upgrade or replace some listed items first.`,
      buttons: [
        { id: "sup_upgrade_plan", title: "⬆️ Upgrade Plan" },
        { id: "sup_manage_listed_products", title: "⬅ Back" }
      ]
    });
  }

  if (!available.length) {
    return sendButtons(from, {
      text: "✅ All uploaded items are already listed.",
      buttons: [
        { id: "sup_manage_listed_products", title: "⬅ Back" }
      ]
    });
  }

  if (biz) {
    biz.sessionState = "supplier_add_listed_products";
    await saveBizSafe(biz);
  }

  await sendSupplierItemsInChunks(
    from,
    available,
    `➕ Choose Items to Add (${slotsLeft} slot${slotsLeft === 1 ? "" : "s"} left)`
  );

  return sendText(from, `Reply with the numbers you want to add to your live listing.\n\nExample:\n*2, 5, 8*`);
}


if (biz?.sessionState === "supplier_add_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return true;

  const uploaded = (supplier.products || []).filter(p => p && p !== "pending_upload");

  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap = capMap[supplier.tier] || 20;

  const current = supplier.listedProducts || [];
  const remainingSlots = cap - current.length;

  const indexes = findSupplierItemIndexes(text, uploaded);
  if (!indexes.length) {
    await sendText(from, "❌ Invalid selection. Example: 1,2,5");
    return true;
  }

  const selected = indexes.slice(0, remainingSlots).map(i => uploaded[i]);

  supplier.listedProducts = [...current, ...selected].slice(0, cap);
  await supplier.save();

  biz.sessionState = "ready";
  await saveBizSafe(biz);

  await sendText(
    from,
    `✅ Added *${selected.length}* items.\n\nYou now have *${supplier.listedProducts.length}/${cap}* live items.`
  );

  return sendSupplierAccountMenu(from, supplier);
}


if (a === "sup_replace_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap = capMap[supplier.tier] || 20;

  const uploaded = (supplier.products || []).filter(p => p && p !== "pending_upload");

  biz.sessionState = "supplier_replace_listed_products";
  await saveBizSafe(biz);

  const preview = uploaded.map((p, i) => `${i + 1}. ${p}`).join("\n");

  return sendText(
    from,
    `♻️ *Replace Live Items*\n\n` +
    `Choose *up to ${cap}* items to keep live.\n` +
    `_You don't need to fill all slots now._\n\n` +
    `${preview}\n\nExample: *1,2,5*`
  );
}

if (a === "sup_manage_listed_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap = capMap[supplier.tier] || 20;
  const listed = (supplier.listedProducts || []).filter(Boolean);
  const isService = supplier.profileType === "service";

  return sendList(
    from,
    `📋 *Manage Listed ${isService ? "Services" : "Products"}*\n\n` +
    `Live now: ${listed.length}/${cap}\n\nWhat would you like to do?`,
    [
      { id: "sup_view_listed_products", title: `👀 View Listed ${isService ? "Services" : "Products"}` },
      { id: "sup_add_listed_products", title: `➕ Add More Listed ${isService ? "Items" : "Products"}` },
      { id: "sup_remove_listed_products", title: `🗑 Remove Listed ${isService ? "Items" : "Products"}` },
      { id: "sup_replace_listed_products", title: `🔄 Replace Listed ${isService ? "Items" : "Products"}` },
      { id: "my_supplier_account", title: "🏪 My Account" }
    ]
  );
}





  // ── Buyer: My Orders list ─────────────────────────────────────────────────
if (a === "my_orders" || a.startsWith("my_orders_page_")) {
    const PAGE_SIZE = 9;
    const page = a.startsWith("my_orders_page_")
      ? Math.max(0, parseInt(a.replace("my_orders_page_", "")) || 0)
      : 0;

    const totalCount = await SupplierOrder.countDocuments({ buyerPhone: phone });

    if (!totalCount) {
      return sendButtons(from, {
        text: "📋 *My Orders*\n\nYou haven't placed any orders yet.",
        buttons: [
          { id: "find_supplier", title: "🔍 Browse & Shop" },
          { id: "suppliers_home", title: "🛒 Marketplace" }
        ]
      });
    }

    const orders = await SupplierOrder.find({ buyerPhone: phone })
      .sort({ createdAt: -1 })          // ← newest first
      .skip(page * PAGE_SIZE)
      .limit(PAGE_SIZE)
      .populate("supplierId", "businessName");

    const si = { pending: "⏳ Pending", accepted: "✅ Accepted", declined: "❌ Declined", completed: "🏁 Completed" };

    const rows = orders.map(o => {
      const itemCount = o.items?.length || 0;
      const firstItem = o.items?.[0]?.product || "Item";
      const label = itemCount > 1 ? `${firstItem} +${itemCount - 1} more` : firstItem;
      const total = o.totalAmount > 0 ? ` · $${Number(o.totalAmount).toFixed(2)}` : "";
      const date = new Date(o.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "2-digit" });
      return {
        id: `order_detail_${o._id}`,
        title: `${o.supplierId?.businessName || "Supplier"} · ${date}`,
        description: `${si[o.status] || "⏳ Pending"} · ${label}${total}`
      };
    });

    const hasMore = (page + 1) * PAGE_SIZE < totalCount;
    const hasPrev = page > 0;
    if (hasMore) rows.push({ id: `my_orders_page_${page + 1}`, title: `➡ Next page` });
    if (hasPrev) rows.push({ id: `my_orders_page_${page - 1}`, title: `⬅ Previous page` });

    const showing = `${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, totalCount)} of ${totalCount}`;
    return sendList(from, `📋 *My Orders* (${showing})\nNewest first - tap any order to view details.`, rows);
  }

  // ── Buyer: Order detail ───────────────────────────────────────────────────
if (a.startsWith("order_detail_")) {
    const orderId = a.replace("order_detail_", "");
    const order = await SupplierOrder.findById(orderId).populate("supplierId", "businessName phone");
    if (!order) {
      return sendButtons(from, {
        text: "❌ Order not found.",
        buttons: [{ id: "my_orders", title: "⬅ My Orders" }]
      });
    }

    const si = { pending: "⏳ Pending", accepted: "✅ Accepted", declined: "❌ Declined", completed: "🏁 Completed" };
    const isService = order.supplierId?.profileType === "service";

    const itemLines = (order.items || []).map(i => {
      const unitSuffix = i.unit && i.unit !== "units" ? ` ${i.unit}` : "";
      const pricePart = typeof i.pricePerUnit === "number"
        ? ` @ $${Number(i.pricePerUnit).toFixed(2)}${unitSuffix} = $${Number(i.total || 0).toFixed(2)}`
        : unitSuffix;
      return `• ${i.product} x${i.quantity}${pricePart}`;
    }).join("\n");

    const totalLine = order.totalAmount > 0
      ? `\n💵 *Total: $${Number(order.totalAmount).toFixed(2)}*`
      : "\n💵 Total: Pending supplier confirmation";

    const deliveryLine = order.delivery?.required
      ? `🚚 Deliver to: ${order.delivery.address}`
      : isService
        ? `📍 Location: ${order.delivery?.address || "Not specified"}`
        : `🏠 Collection`;

    const date = new Date(order.createdAt).toLocaleDateString("en-GB", {
      day: "numeric", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit"
    });

    const msg = [
      `📋 *Order Details*`,
      ``,
      `🏪 *Supplier:* ${order.supplierId?.businessName || "Unknown"}`,
      `📞 *Contact:* ${order.supplierId?.phone || "-"}`,
      `📅 *Placed:* ${date}`,
      ``,
      `*Items:*`,
      itemLines,
      totalLine,
      ``,
      deliveryLine,
      ``,
      `*Status:* ${si[order.status] || "⏳ Pending"}`,
      order.declineReason ? `❌ *Reason:* ${order.declineReason}` : "",
      order.eta ? `🕐 *ETA:* ${order.eta}` : ""
    ].filter(l => l !== "").join("\n");

    const btns = [];
    if (order.status === "accepted" || order.status === "completed") {
      if (!order.buyerRating) btns.push({ id: `rate_order_${order._id}`, title: "⭐ Rate Order" });
    }
    btns.push({ id: "my_orders", title: "⬅ My Orders" });
    if (btns.length < 3) btns.push({ id: "find_supplier", title: "🔍 Find Suppliers" });

    return sendButtons(from, { text: msg, buttons: btns });
  }
  // ── Supplier account menu actions ─────────────────────────────────────────

if (a === "sup_edit_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first.*\n\nYou can edit products after your listing is live.");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const isService = supplier.profileType === "service";
  const label = isService ? "Services" : "Products";
  const items = (supplier.products || []).filter(p => p !== "pending_upload");

  if (biz) {
    biz.sessionState = "supplier_manage_products_menu";
    await saveBizSafe(biz);
  }

return sendList(from, `✏️ Manage ${label}`, [
  { id: "sup_view_products", title: `📋 View Current ${label}` },
  { id: "sup_add_products", title: `➕ Add ${isService ? "Services" : "Products"}` },
  { id: "sup_delete_products", title: `🗑 Delete ${isService ? "Services" : "Products"}` },
  { id: "sup_quick_edit_products", title: `⚡ Quick Edit ${isService ? "Services" : "Products"}` },
  { id: "sup_replace_products", title: `♻️ Replace Full ${label} List` },
  { id: "my_supplier_account", title: "🏪 My Account" }
]);
}


if (a === "sup_view_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  const label = isService ? "Services" : "Products";
  const capMap = { basic: 20, pro: 60, featured: 150 };
  const cap = capMap[supplier.tier] || 20;

  const allItems = (supplier.products || []).filter(p => p !== "pending_upload");
  const listedSet = new Set(
    (supplier.listedProducts || []).filter(Boolean).map(p => normalizeProductName(p))
  );

  const listed   = allItems.filter(p => listedSet.has(normalizeProductName(p)));
  const unlisted = allItems.filter(p => !listedSet.has(normalizeProductName(p)));

  // ── Listed items ────────────────────────────────────────────────────────
  if (listed.length) {
    await sendSupplierItemsInChunks(
      from,
      listed,
      `🟢 Live ${label} (${listed.length}/${cap})`
    );
  } else {
    await sendText(from, `🟢 *Live ${label}:* None listed yet.`);
  }

  // ── Unlisted items ──────────────────────────────────────────────────────
  if (unlisted.length) {
    await sendSupplierItemsInChunks(
      from,
      unlisted,
      `⚪ Unlisted ${label} (${unlisted.length} - not visible to buyers)`
    );
  } else {
    await sendText(from, `⚪ *Unlisted ${label}:* None - all items are live.`);
  }

  return sendList(from, "What would you like to do next?", [
    { id: "sup_add_products",          title: `➕ Add ${label}` },
    { id: "sup_delete_products",       title: `🗑 Delete ${label}` },
    { id: "sup_replace_products",      title: `♻️ Replace Full ${label} List` },
    { id: "sup_manage_listed_products", title: `🟢 Manage Live ${label}` },
    { id: "my_supplier_account",       title: "🏪 My Account" }
  ]);
}

if (a === "sup_add_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  if (biz) {
    biz.sessionState = "supplier_add_products";
    await saveBizSafe(biz);
  }

  return sendText(
    from,
`➕ *Add ${isService ? "Services" : "Products"}*

Send only the new ${isService ? "services" : "products"} you want to add.
Use commas or one per line.

Example:
${isService ? "geyser fitting, blocked drain, toilet installation" : "25mm pvc elbow, basin mixer, toilet seat"}

Duplicates will be ignored.

Type *cancel* to go back.`
  );
}

if (a === "sup_delete_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  const items = (supplier.products || []).filter(p => p !== "pending_upload");

  if (!items.length) {
    return sendText(from, `❌ No ${isService ? "services" : "products"} listed yet.`);
  }

  if (biz) {
    biz.sessionState = "supplier_delete_products";
    await saveBizSafe(biz);
  }

  const listedSet = new Set(
    (supplier.listedProducts || []).filter(Boolean).map(p => normalizeProductName(p))
  );
  const listedItems   = items.filter(p => listedSet.has(normalizeProductName(p)));
  const unlistedItems = items.filter(p => !listedSet.has(normalizeProductName(p)));

  // Build one combined numbered list with section headers inline
  const allLines = [];
  if (listedItems.length) {
    allLines.push(`🟢 *Live (${listedItems.length}):*`);
    listedItems.forEach((p, i) => allLines.push(`${i + 1}. ${p}`));
  }
  if (unlistedItems.length) {
    allLines.push(`\n⚪ *Unlisted (${unlistedItems.length}):*`);
    unlistedItems.forEach((p, i) => allLines.push(`${listedItems.length + i + 1}. ${p}`));
  }

  const CHUNK = 25;
  for (let i = 0; i < allLines.length; i += CHUNK) {
    const chunk = allLines.slice(i, i + CHUNK).join("\n");
    const isFirst = i === 0;
    await sendText(from,
      isFirst
        ? `🗑 *Select ${isService ? "Services" : "Products"} to Delete*\n\n${chunk}`
        : chunk
    );
  }

  return sendText(
    from,
`Reply with the *numbers* or *exact names* you want to delete.

Examples:
*2, 5, 9*
*5-8*
*basin mixer, shower trap*

⚠️ Deleting a live item will also remove it from your listing.

You can delete just a few items - you do NOT need to resend the whole list.

Type *cancel* to go back.`
  );
}
if (a === "sup_replace_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  if (biz) {
    biz.sessionState = "supplier_replace_products";
    await saveBizSafe(biz);
  }

  return sendText(
    from,
`♻️ *Replace Full ${isService ? "Service" : "Product"} List*

Send the full updated ${isService ? "service" : "product"} list, comma-separated or one per line.

⚠️ This replaces your whole list.
Any old item not included will be removed.

Example:
${isService ? "plumbing, geyser fitting, blocked drain" : "cooking oil, rice, sugar, flour"}

Type *cancel* to go back.`
  );
}



 if (a === "sup_toggle_delivery") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first.*");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const newVal = !supplier.delivery?.available;
    supplier.delivery = { ...(supplier.delivery || {}), available: newVal };
    await supplier.save();
    await sendText(from, newVal
      ? "✅ Delivery enabled. Buyers can now request delivery."
      : "✅ Set to collection only.");
    return sendSupplierAccountMenu(from, supplier);
  }

  if (a === "sup_toggle_active") {
    const supplier = await SupplierProfile.findOne({ phone });
    if (!supplier) return sendSuppliersMenu(from);
    if (!supplier.active && !supplier.tier) {
      return sendButtons(from, {
        text: "⚠️ You need an active subscription to go live.\n\nChoose a plan to activate your listing:",
        buttons: [
          { id: "sup_upgrade_plan", title: "⬆️ Choose Plan" },
          { id: "my_supplier_account", title: "🏪 My Account" }
        ]
      });
    }
    supplier.active = !supplier.active;
    await supplier.save();
    await sendText(from, supplier.active
      ? "✅ Your listing is now *active*. Buyers can find you!"
      : "⏸ Your listing is now *hidden* from search results.");
    return sendSupplierAccountMenu(from, supplier);
  }

if (a === "sup_edit_area") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first.*");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  if (biz) {
    biz.sessionState = "supplier_edit_area";
      await saveBizSafe(biz);
    }
   return sendText(from,
`📍 *Edit Location*

Current: ${supplier.location?.area || "not set"}, ${supplier.location?.city || ""}

Send your area/suburb name:
Example: *Avondale, -*

_Type *cancel* to go back to your account._`
    );
  }

if (a === "sup_my_orders") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from,
`🔒 *Activate your listing first.*

Once your listing is live, buyers will start sending you orders. Choose a plan to activate.`
    );
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const SupplierOrder = (await import("../models/supplierOrder.js")).default;
  const orders = await SupplierOrder.find({ supplierId: supplier._id })
    .sort({ createdAt: -1 })
    .limit(10)
    .lean();

  if (!orders.length) {
    return sendButtons(from, {
      text: "📦 *My Orders*\n\nNo orders yet. Make sure your listing is active so buyers can find you!",
      buttons: [{ id: "my_supplier_account", title: "🏪 My Account" }]
    });
  }

  // Show list of orders - each tappable to drill into
  const rows = orders.map((o) => {
    const statusIcon = { pending: "⏳", accepted: "✅", declined: "❌", completed: "🏁" }[o.status] || "•";
    const date = new Date(o.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
    const orderRef = String(o._id).slice(-6).toUpperCase();
    const amount = typeof o.totalAmount === "number" ? ` · $${o.totalAmount.toFixed(2)}` : "";
    const itemCount = Array.isArray(o.items) ? o.items.length : 0;
    return {
      id: `sup_view_order_${o._id}`,
      title: `${statusIcon} #${orderRef} (${date})`,
      description: `${itemCount} item${itemCount !== 1 ? "s" : ""}${amount} · ${o.status}`
    };
  });

  rows.push({ id: "my_supplier_account", title: "⬅ Back" });

  return sendList(from, `📦 *My Orders* - last ${orders.length}`, rows);
}

// ── Supplier drills into a single order ───────────────────────────────────────
if (a.startsWith("sup_view_order_")) {
  const orderId = a.replace("sup_view_order_", "");
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const SupplierOrder = (await import("../models/supplierOrder.js")).default;
  const order = await SupplierOrder.findById(orderId).lean();
  if (!order) {
    await sendText(from, "❌ Order not found.");
    return sendSupplierAccountMenu(from, supplier);
  }

  const isService = supplier.profileType === "service";
  const orderRef = String(order._id).slice(-6).toUpperCase();
  const date = new Date(order.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  const statusIcon = { pending: "⏳", accepted: "✅", declined: "❌", completed: "🏁" }[order.status] || "•";

  const itemLines = Array.isArray(order.items) && order.items.length
    ? order.items.map(item => {
        const name = item.product || "Item";
        const qty = item.quantity ?? 1;
        const unitSuffix = item.unit && item.unit !== "units" ? ` ${item.unit}` : "";
        const lineTotal = typeof item.total === "number" ? ` = $${item.total.toFixed(2)}` : "";
        const unitPrice = typeof item.pricePerUnit === "number" ? ` @ $${item.pricePerUnit.toFixed(2)}` : "";
        return `• ${name} x${qty}${unitSuffix}${unitPrice}${lineTotal}`;
      }).join("\n")
    : "• No items";

  const deliveryLine = order.delivery?.required
    ? `🚚 Delivery: ${order.delivery.address || "Address not provided"}`
    : isService
      ? `📍 Service location: ${order.delivery?.address || "Not specified"}`
      : "🏠 Collection";

  const amount = typeof order.totalAmount === "number" ? `$${order.totalAmount.toFixed(2)}` : "Pending pricing";

  const detailText =
    `${statusIcon} *Order #${orderRef}*\n` +
    `📅 ${date}\n\n` +
    `${itemLines}\n\n` +
    `${deliveryLine}\n` +
    `💵 Total: ${amount}\n` +
    `📞 Buyer: ${order.buyerPhone}\n` +
    `📌 Status: *${order.status}*`;

  // Pending orders get Accept / Decline / Contact buttons
  if (order.status === "pending") {
    return sendButtons(from, {
      text: detailText,
      buttons: [
        { id: `sup_accept_${order._id}`, title: isService ? "✅ Accept Booking" : "✅ Accept" },
        { id: `sup_decline_${order._id}`, title: "❌ Decline" },
        { id: `sup_contact_buyer_${order._id}`, title: "📞 Contact Buyer" }
      ]
    });
  }

  // Accepted / other statuses - contact + back
  return sendButtons(from, {
    text: detailText,
    buttons: [
      { id: `sup_contact_buyer_${order._id}`, title: "📞 Contact Buyer" },
      { id: "sup_my_orders", title: "⬅ My Orders" }
    ]
  });
}

// ── Supplier contacts buyer from order detail view ────────────────────────────
if (a.startsWith("sup_contact_buyer_")) {
  const orderId = a.replace("sup_contact_buyer_", "");
  const SupplierOrder = (await import("../models/supplierOrder.js")).default;
  const order = await SupplierOrder.findById(orderId).lean();
  if (!order) {
    await sendText(from, "❌ Order not found.");
    return sendSupplierAccountMenu(from, null);
  }
  const orderRef = String(order._id).slice(-6).toUpperCase();
  return sendButtons(from, {
    text:
      `📞 *Contact Buyer*\n\n` +
      `Order #${orderRef}\n` +
      `Buyer's WhatsApp number: *${order.buyerPhone}*\n\n` +
      `You can call or message them directly on WhatsApp.`,
    buttons: [
      { id: `sup_view_order_${order._id}`, title: "⬅ Back to Order" }
    ]
  });
}

if (a === "sup_my_earnings") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first to view earnings.*");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const SupplierOrder = (await import("../models/supplierOrder.js")).default;
    const completed = await SupplierOrder.find({ supplierId: supplier._id, status: "completed" });
   const total = completed.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const thisMonth = completed.filter(o => {
      const d = new Date(o.createdAt);
      const now = new Date();
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
   }).reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    return sendButtons(from, {
      text: `💵 *Earnings Summary*\n\n📦 Completed orders: ${completed.length}\n💰 Total earnings: $${total.toFixed(2)}\n📅 This month: $${thisMonth.toFixed(2)}\n\n⭐ Rating: ${(supplier.rating || 0).toFixed(1)} (${supplier.reviewCount || 0} reviews)\n🏅 Score: ${(supplier.credibilityScore || 0).toFixed(0)}/100`,
      buttons: [{ id: "my_supplier_account", title: "🏪 My Account" }]
    });
  }

if (a === "sup_my_reviews") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first to view reviews.*");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  if (!supplier.reviewCount) {
      return sendButtons(from, {
        text: "⭐ *My Reviews*\n\nNo reviews yet. Complete orders to get rated by buyers!",
        buttons: [{ id: "my_supplier_account", title: "🏪 My Account" }]
      });
    }
    return sendButtons(from, {
      text: `⭐ *My Reviews*\n\nRating: ${(supplier.rating || 0).toFixed(1)}/5\nReviews: ${supplier.reviewCount || 0}\nScore: ${(supplier.credibilityScore || 0).toFixed(0)}/100\n\n${(supplier.credibilityScore || 0) >= 70 && (supplier.completedOrders || 0) >= 10 ? "🏅 You have the Top Supplier badge!" : "Complete more orders to earn the 🏅 Top Supplier badge (score 70+, 10+ orders)"}`,
      buttons: [{ id: "my_supplier_account", title: "🏪 My Account" }]
    });
  }

if (a === "sup_upgrade_plan" || a === "sup_renew_plan") {
    return sendList(from,
      `💳 *Choose Your Plan*\n\nAll plans include:\n✅ Listed in search\n✅ Phone number visible\n✅ Unlimited uploads\n✅ Unlimited orders\n\nPick a plan to continue:`,
      [
        { id: "sup_plan_basic_monthly", title: "✅ Basic - $5/month", description: "Up to 20 live items" },
        { id: "sup_plan_basic_annual", title: "✅ Basic - $50/year", description: "Up to 20 live items · save $10" },
        { id: "sup_plan_pro_monthly", title: "⭐ Pro - $12/month", description: "Up to 60 live items" },
        { id: "sup_plan_pro_annual", title: "⭐ Pro - $120/year", description: "Up to 60 live items · save $24" },
        { id: "sup_plan_featured_monthly", title: "🔥 Featured $25/mo", description: "Up to 150 live items + featured badge" }
      ]
    );
  }


  // ── Supplier city "More Cities" page 2 ───────────────────────────────────────
  if (a === "sup_city_more") {
    const { SUPPLIER_CITIES } = await import("./supplierPlans.js");
    return sendList(from, "📍 Where are you based?\n\n_Not listed? Tap Other_", [
      ...SUPPLIER_CITIES.slice(9).map(c => ({ id: `sup_city_${c.toLowerCase().replace(/\s+/g, "_")}`, title: c })),
      { id: "sup_city_other", title: "📍 Other City" }
    ]);
  }

  // ── Supplier city selected from list during registration ──────────────────
  if (a.startsWith("sup_city_")) {
    const cityRaw = a.replace("sup_city_", "").replace(/_/g, " ");
    const city = cityRaw === "other" ? null : cityRaw.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");

    if (!city) {
      // Ask them to type their city
      if (biz) {
        biz.sessionState = "supplier_reg_area";
        biz.sessionData = biz.sessionData || {};
        biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
        biz.sessionData.supplierReg.city = "Other";
        await saveBizSafe(biz);
      }
  return sendText(from,
        "📍 Please type your city name:\n\n_Type *cancel* to return to main menu._"
      );
    }

    if (biz) {
      biz.sessionData = biz.sessionData || {};
      biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
      biz.sessionData.supplierReg.city = city;
      biz.sessionState = "supplier_reg_area";
      await saveBizSafe(biz);
    }

return sendText(from,
`📍 *${city}*

What area or suburb are you in?

Example: *Avondale, Mbare, Belgravia*

_Type *cancel* to return to main menu._`
    );
  }


  // ── Profile type: Products or Services ───────────────────────────────────

// ── School listing type selected - pivot the entire reg flow into school mode ─
if (a === "reg_type_school") {
  if (!_bizIsOwnedByUser) biz = null;
  if (!biz) {
    const _ep = await Business.findOne({ ownerPhone: phone, name: "pending_supplier_" + phone }).lean();
    if (_ep) { biz = await Business.findById(_ep._id); await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true }); }
    else {
      biz = await Business.create({ name: "pending_supplier_" + phone, currency: "USD", package: "trial", subscriptionStatus: "inactive", isSupplier: false, sessionState: "school_reg_name", sessionData: { supplierReg: { profileType: "school" } }, ownerPhone: phone });
      await UserRole.create({ phone, role: "owner", pending: false, businessId: biz._id });
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    }
  }
  biz.sessionData = { supplierReg: { profileType: "school" } };
  biz.sessionState = "school_reg_name";
  await saveBizSafe(biz);
  return sendText(from, `🏫 *School Registration*\n\nWhat is your *school's full name*?\n\n_Type *cancel* at any time to stop._`);
}

if (a === "reg_type_product" || a === "reg_type_service") {
  console.log("[REG_TYPE] HANDLER REACHED. phone:", phone, "biz:", biz?._id, "state:", biz?.sessionState, "owned:", _bizIsOwnedByUser);
  // ── Ownership guard ───────────────────────────────────────────────────────
  if (!_bizIsOwnedByUser) biz = null;

  // ── Find or create a biz owned by this user ───────────────────────────────
  // getBizForPhone may return a mid-registration biz from a previous attempt.
  // We use it if it exists and belongs to this user; otherwise create fresh.
  if (!biz) {
    // Check for an existing pending biz for this phone (from a previous attempt)
    const _existingPendingBiz = await Business.findOne({ ownerPhone: phone, name: "pending_supplier_" + phone }).lean();
    if (_existingPendingBiz) {
      // Re-use it - update UserSession pointer
      biz = await Business.findById(_existingPendingBiz._id);
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    } else {
      // Create brand new biz
      biz = await Business.create({
        name: "pending_supplier_" + phone,
        currency: "USD",
        package: "trial",
        subscriptionStatus: "inactive",
        isSupplier: false,
        sessionState: "supplier_reg_name",
        sessionData: { supplierReg: {} },
        ownerPhone: phone
      });
      await UserRole.create({ phone, role: "owner", pending: false, businessId: biz._id });
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    }
  }

  // ── Always reset registration state ──────────────────────────────────────
  // If a previous attempt left the biz in a mid-registration state (e.g.
  // supplier_reg_city, supplier_reg_area), clear it so we start fresh.
  const profileType = a === "reg_type_service" ? "service" : "product";
  biz.sessionData = { supplierReg: { profileType } };
  biz.sessionState = "supplier_reg_name";
  await saveBizSafe(biz);

  return sendText(from, `🏪 *What is your business name?*\n\nExample: *Mudziyashe Hardware*`);
}

// ── Hospitality / Tourism registration entry ──────────────────────────────
if (a === "reg_type_hospitality") {
  if (!_bizIsOwnedByUser) biz = null;
  if (!biz) {
    const _ep = await Business.findOne({ ownerPhone: phone, name: "pending_supplier_" + phone }).lean();
    if (_ep) { biz = await Business.findById(_ep._id); await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true }); }
    else {
      biz = await Business.create({ name: "pending_supplier_" + phone, currency: "USD", package: "trial", subscriptionStatus: "inactive", isSupplier: false, sessionState: "supplier_reg_name", sessionData: { supplierReg: { profileType: "hospitality" } }, ownerPhone: phone });
      await UserRole.create({ phone, role: "owner", pending: false, businessId: biz._id });
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    }
  }
  biz.sessionData = { supplierReg: { profileType: "hospitality" } };
  biz.sessionState = "supplier_reg_name";
  await saveBizSafe(biz);
  return sendText(from,
    `🏨 *Lodge / Hotel / Tourism Registration*\n\nWhat is your business name?\n\n_Examples:_\n_Wilderness Lodge Kariba_\n_Safari Dreams Hwange_\n_Victoria Falls Guesthouse_`
  );
}

if (a === "reg_type_school") {
  if (!_bizIsOwnedByUser) biz = null;
  if (biz && (biz.sessionState === "supplier_reg_listing_type" || biz.sessionState === "school_reg_name")) {
    biz.sessionData = biz.sessionData || {};
    biz.sessionData.supplierReg = {};
    await saveBizSafe(biz);
  }

  // ── Create pending biz for brand-new users with no business record ─────────
  if (!biz) {
    const _newSchoolBiz = await Business.create({
      name: "pending_supplier_" + phone,
      currency: "USD",
      package: "trial",
      subscriptionStatus: "inactive",
      isSupplier: false,
      sessionState: "school_reg_name",
      sessionData: { supplierReg: { profileType: "school" } },
      ownerPhone: phone
    });
    await UserRole.create({ phone, role: "owner", pending: false, businessId: _newSchoolBiz._id });
    await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: _newSchoolBiz._id }, { upsert: true });
    biz = _newSchoolBiz;
  }

  // Check if already has a school profile
  const existingSchool = await SchoolProfile.findOne({ phone });
  if (existingSchool?.active) {
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, existingSchool);
  }
  if (existingSchool && !existingSchool.active) {
    return sendList(from, `🏫 *${existingSchool.schoolName}* is saved but not yet live.`, [
      { id: "school_pay_plan",  title: "💳 Activate Listing" },
      { id: "school_account",   title: "👁 View My Profile" },
      { id: "main_menu_back",   title: "⬅ Main Menu" }
    ]);
  }

  biz.sessionData = { supplierReg: { profileType: "school" } };
  biz.sessionState = "school_reg_name";
  await saveBizSafe(biz);

  return sendText(from,
`🏫 *Register Your School on ZimQuote*

Parents across Zimbabwe will be able to find your school, view fees, facilities, and apply online.

What is your *school's full name*?

_Type *cancel* at any time to stop._`
  );
}

if (a === "reg_type_product" || a === "reg_type_service") {
  // ── Ownership guard ───────────────────────────────────────────────────────
  if (!_bizIsOwnedByUser) biz = null;

  // ── Find or create a biz owned by this user ───────────────────────────────
  // getBizForPhone may return a mid-registration biz from a previous attempt.
  // We use it if it exists and belongs to this user; otherwise create fresh.
  if (!biz) {
    // Check for an existing pending biz for this phone (from a previous attempt)
    const _existingPendingBiz = await Business.findOne({ ownerPhone: phone, name: "pending_supplier_" + phone }).lean();
    if (_existingPendingBiz) {
      // Re-use it - update UserSession pointer
      biz = await Business.findById(_existingPendingBiz._id);
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    } else {
      // Create brand new biz
      biz = await Business.create({
        name: "pending_supplier_" + phone,
        currency: "USD",
        package: "trial",
        subscriptionStatus: "inactive",
        isSupplier: false,
        sessionState: "supplier_reg_name",
        sessionData: { supplierReg: {} },
        ownerPhone: phone
      });
      await UserRole.create({ phone, role: "owner", pending: false, businessId: biz._id });
      await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: biz._id }, { upsert: true });
    }
  }

  // ── Always reset registration state ──────────────────────────────────────
  // If a previous attempt left the biz in a mid-registration state (e.g.
  // supplier_reg_city, supplier_reg_area), clear it so we start fresh.
  const profileType = a === "reg_type_service" ? "service" : "product";
  biz.sessionData = { supplierReg: { profileType } };
  biz.sessionState = "supplier_reg_name";
  await saveBizSafe(biz);

  return sendText(from, `🏪 *What is your business name?*\n\nExample: *Mudziyashe Hardware*`);
}

// ── Hospitality / Tourism registration entry ──────────────────────────────
if (a === "reg_type_hospitality") {
  if (!_bizIsOwnedByUser) biz = null;
  if (biz && (biz.sessionState === "supplier_reg_listing_type" || biz.sessionState === "supplier_reg_name")) {
    biz.sessionData = biz.sessionData || {};
    biz.sessionData.supplierReg = {};
    await saveBizSafe(biz);
  }

  // ── Create pending biz for brand-new users with no business record ─────────
  if (!biz) {
    const _newHospBiz = await Business.create({
      name: "pending_supplier_" + phone,
      currency: "USD",
      package: "trial",
      subscriptionStatus: "inactive",
      isSupplier: false,
      sessionState: "supplier_reg_name",
      sessionData: { supplierReg: { profileType: "hospitality" } },
      ownerPhone: phone
    });
    await UserRole.create({ phone, role: "owner", pending: false, businessId: _newHospBiz._id });
    await UserSession.findOneAndUpdate({ phone }, { activeBusinessId: _newHospBiz._id }, { upsert: true });
    biz = _newHospBiz;
  }

  biz.sessionData = biz.sessionData || {};
  biz.sessionData.supplierReg = { profileType: "hospitality" };
  biz.sessionState = "supplier_reg_name";
  await saveBizSafe(biz);

  return sendText(from,
    `🏨 *Lodge / Hotel / Tourism Registration*\n\n` +
    `What is your business name?\n\n` +
    `_Examples:_\n` +
    `_Wilderness Lodge Kariba_\n` +
    `_Safari Dreams Hwange_\n` +
    `_Victoria Falls Guesthouse_\n` +
    `_Lake View Self-Catering Nyanga_`
  );
}


// ── Supplier collar group selected during service registration ────────────
if (a.startsWith("sup_collar_")) {
  if (!biz) return sendMainMenu(from);

  const collarKey = a.replace("sup_collar_", "");
  const validCollars = ["white_collar", "trade", "blue_collar"];
  if (!validCollars.includes(collarKey)) {
    await sendText(from, "❌ Invalid selection. Please try again.");
    return sendMainMenu(from);
  }

  biz.sessionData = biz.sessionData || {};
  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.collarGroup = collarKey;
  biz.sessionState = "supplier_reg_category";
  await saveBizSafe(biz);

  // Show only categories belonging to this collar group
  const filteredCategories = SUPPLIER_CATEGORIES.filter(
    c => c.types.includes("service") && c.collar === collarKey
  );

  const collarLabels = {
    white_collar: "💼 Professional Services",
    trade: "🔧 Trade & Artisan",
    blue_collar: "🧹 General Services"
  };

  const categoryRows = [
    ...filteredCategories.slice(0, 9).map(c => ({
      id: `sup_cat_${c.id}`,
      title: c.label
    })),
    ...(filteredCategories.length > 9
      ? [{ id: `sup_collar_more_${collarKey}`, title: "➕ More Categories" }]
      : [])
  ];

  return sendList(
    from,
    `${collarLabels[collarKey]}\n\n_Choose your main category:_`,
    categoryRows
  );
}

// ── More categories for a specific collar group ───────────────────────────
if (a.startsWith("sup_collar_more_")) {
  if (!biz) return sendMainMenu(from);

  const collarKey = a.replace("sup_collar_more_", "");
  const filteredCategories = SUPPLIER_CATEGORIES.filter(
    c => c.types.includes("service") && c.collar === collarKey
  );

  return sendList(from, "🗂 More Categories", [
    ...filteredCategories.slice(9).map(c => ({
      id: `sup_cat_${c.id}`,
      title: c.label
    })),
    { id: `sup_collar_${collarKey}`, title: "⬅ Back" }
  ]);
}


if (a === "sup_cat_more") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";
  const filteredCategories = getSupplierCategoriesForType(profileType);

  // For services, "More Categories" should return service groups, not a huge flat list
  if (profileType === "service") {
    return sendList(from, "🗂 Service Groups", [
      { id: "sup_grp_trades_technical", title: "🛠️ Trades" },
      { id: "sup_grp_home_property", title: "🏠 Home & Property" },
      { id: "sup_grp_professional_corporate", title: "💼 Professional" },
      { id: "sup_grp_health_personal", title: "🩺 Health & Care" },
      { id: "sup_grp_creative_events_media", title: "🎨 Creative & Media" },
      { id: "sup_grp_education_digital", title: "💻 Education" },
      { id: "sup_grp_transport_logistics", title: "🚚 Transport" },
      { id: "sup_grp_other_services_group", title: "🧰 Other Services" }
    ]);
  }

  // Keep product flow paginated and valid
  const moreRows = filteredCategories.slice(9, 18).map(c => ({
    id: `sup_cat_${c.id}`,
    title: c.label
  }));

  if (filteredCategories.length > 18) {
    moreRows.push({ id: "sup_cat_more_2", title: "➡ More Categories" });
  }

  return sendList(from, "🗂 More Categories", moreRows);
}

if (a === "sup_cat_more_2") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";
  const filteredCategories = getSupplierCategoriesForType(profileType);

  const moreRows = filteredCategories.slice(18, 27).map(c => ({
    id: `sup_cat_${c.id}`,
    title: c.label
  }));

  return sendList(from, "🗂 More Categories (Page 2)", moreRows);
}

  // ── Hospitality subtype selection buttons ────────────────────────────────────
  // sup_hosp_type_lodge__safari_operator → tourismSubtype = ["lodge","safari_operator"]
  if (a.startsWith("sup_hosp_type_")) {
    if (!biz) return sendMainMenu(from);
    const subtypes = a.replace("sup_hosp_type_", "").split("__").filter(Boolean);
    biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
    biz.sessionData.supplierReg.tourismSubtype = subtypes;

    // Determine the categories array from subtypes
    const subtypeCatMap = {
      lodge:           "lodge",          hotel:           "hotel",
      guesthouse:      "guesthouse",     self_catering:   "self_catering",
      campsite:        "campsite",       safari_operator: "safari",
      tour_guide:      "tours",          boat_hire:       "boat_hire",
      travel_agency:   "tourism"
    };
    const cats = [...new Set(subtypes.map(s => subtypeCatMap[s]).filter(Boolean)), "tourism", "hospitality", "accommodation"];
    biz.sessionData.supplierReg.categories = cats;
    biz.sessionState = "supplier_reg_hospitality_areas";
    await saveBizSafe(biz);

    return sendText(from,
      `🌍 *Which areas or destinations do you serve?*\n\n` +
      `Type the areas separated by commas.\n\n` +
      `Examples:\n` +
      `_Kariba, Nyamhunga, Andora_\n` +
      `_Hwange National Park, Victoria Falls_\n` +
      `_Nyanga, Eastern Highlands_\n` +
      `_Harare, Bulawayo (for city tours)_\n` +
      `_Victoria Falls, Zambezi National Park_\n\n` +
      `_Type *skip* to use your main location._`
    );
  }

  if (a === "sup_hosp_facilities_done") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "sup_hosp_facilities_done" });
    return;
  }

  if (a === "sup_skip_rest_rates") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "sup_skip_rest_rates" });
    return;
  }

  if (a === "sup_skip_extra_services") {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: "sup_skip_extra_services" });
    return;
  }

  if (a.startsWith("sup_hosp_fac_toggle_")) {
    if (!biz) return sendMainMenu(from);
    await continueTwilioFlow({ from, text: a });
    return;
  }

  // ── Travel yes/no during service registration ─────────────────────────────
if (a === "sup_travel_yes") {
    if (!biz) return sendMainMenu(from);
    biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
    biz.sessionData.supplierReg.travelAvailable = true;
    biz.sessionData.supplierReg.minOrder = 0;
    biz.sessionState = "supplier_reg_biz_currency";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "💱 *Almost done! What currency does your business use?*\n\nThis will be your default for invoices and quotes.",
      buttons: [
        { id: "sup_biz_cur_USD", title: "💵 USD ($)" },
        { id: "sup_biz_cur_ZWL", title: "🇿🇼 ZWL (Z$)" },
        { id: "sup_biz_cur_ZAR", title: "🇿🇦 ZAR (R)" }
      ]
    });
  }


if (a === "sup_travel_no") {
    if (!biz) return sendMainMenu(from);
    biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
    biz.sessionData.supplierReg.travelAvailable = false;
    biz.sessionData.supplierReg.minOrder = 0;
    biz.sessionState = "supplier_reg_biz_currency";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "💱 *Almost done! What currency does your business use?*\n\nThis will be your default for invoices and quotes.",
      buttons: [
        { id: "sup_biz_cur_USD", title: "💵 USD ($)" },
        { id: "sup_biz_cur_ZWL", title: "🇿🇼 ZWL (Z$)" },
        { id: "sup_biz_cur_ZAR", title: "🇿🇦 ZAR (R)" }
      ]
    });
  }
  // ── Supplier category selected during registration ────────────────────────

if (a.startsWith("sup_grp_")) {
  if (!biz) return sendMainMenu(from);

  const groupId = a.replace("sup_grp_", "");
  const group = SERVICE_CATEGORY_GROUPS.find(g => g.id === groupId);

  if (!group) {
    return sendText(from, "❌ Service group not found. Please try again.");
  }

  const rows = group.categoryIds
    .map(catId => SUPPLIER_CATEGORIES.find(c => c.id === catId && c.types?.includes("service")))
    .filter(Boolean)
    .slice(0, 9)
    .map(c => ({
      id: `sup_cat_${c.id}`,
      title: c.label
    }));

  rows.push({ id: "reg_type_service", title: "⬅ Service Groups" });

  return sendList(from, group.label, rows);
}







if (a.startsWith("sup_cat_")) {
  const catId = a.replace("sup_cat_", "");
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";

  biz.sessionData = biz.sessionData || {};
  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  const existing = biz.sessionData.supplierReg.categories || [];
  if (!existing.includes(catId)) existing.push(catId);
  biz.sessionData.supplierReg.categories = existing;

  // ── NEW: if this category has subcats, ask the supplier to pick one ───────
  const selectedCat = SUPPLIER_CATEGORIES.find(c => c.id === catId);
  if (selectedCat?.subcats?.length) {
    biz.sessionState = "supplier_reg_subcat";
    await saveBizSafe(biz);

    const subcatRows = [
      { id: "sup_subcat_all", title: "📋 All / General" },
      ...selectedCat.subcats.slice(0, 9).map(s => ({
        id: `sup_subcat_${s.id}`,
        title: s.label
      }))
    ];

    return sendList(
      from,
      `📂 *${selectedCat.label}*\n\nWhich area do you specialise in?\n_You can always add more services later._`,
      subcatRows
    );
  }

  // ── No subcats: continue directly to products/services step ──────────────
  biz.sessionState = "supplier_reg_products";
  await saveBizSafe(biz);

  const { CATEGORY_PRODUCT_EXAMPLES, CATEGORY_SERVICE_EXAMPLES } = await import("./supplierRegistration.js");
  const { getTemplateForCategoryWithDB } = await import("./supplierProductTemplates.js");
  const template = await getTemplateForCategoryWithDB(catId);

  if (profileType === "service") {
    const catExamples = CATEGORY_SERVICE_EXAMPLES[catId] || ["service a", "service b"];
    const exampleText = catExamples.slice(0, 2).join(", ");

    return sendButtons(from, {
      text: `✅ *Category selected!*\n\nHow would you like to add your services?\n\n_e.g. ${exampleText}_`,
      buttons: [
        { id: "sup_request_upload",     title: "📤 Send Us Your List" },
        { id: "sup_enter_own_products", title: "✍️ Type My Own" },
        { id: "sup_skip_products",      title: "⏭ Skip For Now" }
      ]
    });
  }

  const catExamples = CATEGORY_PRODUCT_EXAMPLES[catId] || ["product a", "product b", "product c"];
  const exampleText = catExamples.slice(0, 3).join(", ");

  if (template) {
    const preview = template.products.slice(0, 6).join(", ");
    const moreCount = template.products.length - 6;

    return sendButtons(from, {
      text:
`✅ *Category selected!*

📦 *Preset available:* _${preview}${moreCount > 0 ? ` + ${moreCount} more` : ""}_

How would you like to add your products?`,
      buttons: [
        { id: "sup_request_upload",       title: "📤 Send Us Your List" },
        { id: "sup_enter_own_products",   title: "✍️ Type My Own" },
        { id: `sup_load_preset_${catId}`, title: "📦 Use Preset List" }
      ]
    });
  }

  return sendButtons(from, {
    text:
`✅ *Category selected!*

How would you like to add your products?

_Examples: ${exampleText}_`,
    buttons: [
      { id: "sup_request_upload",      title: "📤 Send Us Your List" },
      { id: "sup_enter_own_products",  title: "✍️ Type My Own" },
      { id: "sup_skip_products",       title: "⏭ Skip For Now" }
    ]
  });
}






// ── Supplier subcategory selected during service registration ─────────────
if (a.startsWith("sup_subcat_")) {
  if (!biz) return sendMainMenu(from);

  const subcatId = a.replace("sup_subcat_", "");
  const profileType = biz.sessionData?.supplierReg?.profileType || "service";

  biz.sessionData = biz.sessionData || {};
  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  // Store subcategory (null means "All / General")
  biz.sessionData.supplierReg.subcategory = subcatId === "all" ? null : subcatId;
  biz.sessionState = "supplier_reg_products";
  await saveBizSafe(biz);

 const catId = (biz.sessionData.supplierReg.categories || [])[0];
  const { CATEGORY_SERVICE_EXAMPLES, CATEGORY_PRODUCT_EXAMPLES } = await import("./supplierRegistration.js");

  if (profileType === "service") {
    const catExamples = CATEGORY_SERVICE_EXAMPLES[catId] || ["service a", "service b"];
    const exampleText = catExamples.slice(0, 2).join(", ");

    return sendButtons(from, {
      text: `✅ *Specialisation saved!*\n\nHow would you like to add your services?\n\n_e.g. ${exampleText}_`,
      buttons: [
        { id: "sup_request_upload",     title: "📤 Send Us Your List" },
        { id: "sup_enter_own_products", title: "✍️ Type My Own" },
        { id: "sup_skip_products",      title: "⏭ Skip For Now" }
      ]
    });
  }

  // ── Product path: check for admin preset template (same as sup_cat_ handler) ──
  const { getTemplateForCategoryWithDB } = await import("./supplierProductTemplates.js");
  const template = await getTemplateForCategoryWithDB(catId);
  const catExamples = CATEGORY_PRODUCT_EXAMPLES[catId] || ["product a", "product b"];

  if (template) {
    const preview = template.products.slice(0, 6).join(", ");
    const moreCount = template.products.length - 6;

    return sendButtons(from, {
      text:
`✅ *Subcategory saved!*

📦 *Preset available:* _${preview}${moreCount > 0 ? ` + ${moreCount} more` : ""}_

How would you like to add your products?`,
      buttons: [
        { id: "sup_request_upload",       title: "📤 Send Us Your List" },
        { id: "sup_enter_own_products",   title: "✍️ Type My Own" },
        { id: `sup_load_preset_${catId}`, title: "📦 Use Preset List" }
      ]
    });
  }

  return sendButtons(from, {
    text: `✅ *Subcategory saved!*\n\nHow would you like to add your products?\n\n_e.g. ${catExamples.slice(0, 3).join(", ")}_`,
    buttons: [
      { id: "sup_request_upload",     title: "📤 Send Us Your List" },
      { id: "sup_enter_own_products", title: "✍️ Type My Own" },
      { id: "sup_skip_products",      title: "⏭ Skip For Now" }
    ]
  });
}



// ── Skip or finish pricing during registration ─────────────────────────────
if (a === "sup_skip_prices" || a === "sup_done_prices") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";

  if (profileType === "service") {
    biz.sessionState = "supplier_reg_travel";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "🚗 *Do you travel to clients?*",
      buttons: [
        { id: "sup_travel_yes", title: "✅ Yes I Travel" },
        { id: "sup_travel_no", title: "🏠 Client Comes to Me" }
      ]
    });
  }

  biz.sessionState = "supplier_reg_delivery";
  await saveBizSafe(biz);
  return sendButtons(from, {
    text: "🚚 Do you deliver?",
    buttons: [
      { id: "sup_del_yes", title: "✅ Yes I Deliver" },
      { id: "sup_del_no", title: "🏠 Collection Only" }
    ]
  });
}

// ── Supplier confirms pricing preview ─────────────────────────────────────
if (a === "sup_prices_confirm_yes") {
  if (!biz) return sendMainMenu(from);

  const isService = biz.sessionData?.supplierReg?.profileType === "service";
  const prices = biz.sessionData?.supplierReg?.prices || [];
  const rates  = biz.sessionData?.supplierReg?.rates  || [];
  const count  = isService ? rates.length : prices.length;

  if (isService) {
    biz.sessionState = "supplier_reg_travel";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `✅ *${count} rate(s) confirmed!*\n\n🚗 *Do you travel to clients?*`,
      buttons: [
        { id: "sup_travel_yes", title: "✅ Yes I Travel" },
        { id: "sup_travel_no",  title: "🏠 Client Comes to Me" }
      ]
    });
  }

  biz.sessionState = "supplier_reg_delivery";
  await saveBizSafe(biz);
  return sendButtons(from, {
    text: `✅ *${count} price(s) confirmed!*\n\n🚚 *Do you deliver?*`,
    buttons: [
      { id: "sup_del_yes", title: "✅ Yes I Deliver" },
      { id: "sup_del_no",  title: "🏠 Collection Only" }
    ]
  });
}

// ── Supplier wants to re-enter prices ─────────────────────────────────────
if (a === "sup_prices_edit") {
  if (!biz) return sendMainMenu(from);

  const isService = biz.sessionData?.supplierReg?.profileType === "service";
  const productList = biz.sessionData?.supplierReg?.products || [];

  // Clear existing prices so they re-enter
  if (isService) {
    biz.sessionData.supplierReg.rates = [];
  } else {
    biz.sessionData.supplierReg.prices = [];
  }
  biz.sessionState = "supplier_reg_prices";
  await saveBizSafe(biz);

  const numbered = productList.map((p, i) => `${i + 1}. ${p}`).join("\n");

return sendText(from,
`✏️ *Re-enter Your ${isService ? "Rates" : "Prices"}*

${numbered}

─────────────────
*Fastest way: update by item number*

*Single item:*
_${isService ? "1x20/job" : "1x5.50"}_
_${isService ? "1 x 20/job" : "1 x 5.50"}_

*Same ${isService ? "rate" : "price"} for selected items:*
_${isService ? "1,3,5x20/job" : "1,3,5x5.50"}_
_${isService ? "1,3,5 x 20/job" : "1,3,5 x 5.50"}_

*Same ${isService ? "rate" : "price"} for a range:*
_${isService ? "1-4x15/hr" : "1-4x5.50"}_
_${isService ? "1-4 x 15/hr" : "1-4 x 5.50"}_

*Mixed updates:*
_${isService ? "1x20/job,2x15/trip,3x10/hr" : "1x5.50,2x8.00,3x12.00"}_
_${isService ? "1 x 20/job, 2 x 15/trip, 3 x 10/hr" : "1 x 5.50, 2 x 8.00, 3 x 12.00"}_

*Other options still work:*

*Update ALL in order:*
_${isService
  ? productList.slice(0, 3).map((_, i) => ((i + 1) * 10)).join(", ")
  : productList.slice(0, 4).map((_, i) => ((i + 1) * 3 + 2) + ".00").join(", ")}${productList.length > 4 ? ", ..." : ""}_

*Update selected items by name:*
_${productList.slice(0, 2).map(p => `${p}: ${isService ? "20/job" : "5.00"}`).join(", ")}_

Type *skip* to skip pricing.`);
}

// ── Load preset products - show full preview before confirming ────────────
if (a.startsWith("sup_load_preset_")) {
  if (!biz) return sendMainMenu(from);

  const catId = a.replace("sup_load_preset_", "");
  const { getTemplateForCategoryWithDB } = await import("./supplierProductTemplates.js");
  const template = await getTemplateForCategoryWithDB(catId);

  if (!template?.products?.length) {
    await sendText(from, "❌ No preset found for this category. Please type your products.");
    biz.sessionState = "supplier_reg_products";
    await saveBizSafe(biz);
    return;
  }

  // Store pending catId for confirm step
  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.pendingPresetCatId = catId;
  await saveBizSafe(biz);

  const allProducts = template.products;
  const priceHint = template.prices?.length
    ? `💰 Suggested prices included for ${template.prices.length} items\n\n`
    : "";

  // ── Send the full product list as a plain TEXT message (no 1024 char limit)
  // then send a separate BUTTON message for the confirm/reject action
  const PREVIEW_PER_ROW = 4;
  const rows = [];
  for (let i = 0; i < allProducts.length; i += PREVIEW_PER_ROW) {
    rows.push(
      allProducts.slice(i, i + PREVIEW_PER_ROW)
        .map((p, j) => `${i + j + 1}. ${p}`)
        .join("   ")
    );
  }
  const productPreview = rows.join("\n");

  // Step 1: send the full list as a plain text message (limit = 4096, safe)
  await sendText(from,
`📦 *Preset Product List* (${allProducts.length} items)

${productPreview}

${priceHint}Scroll up to review the full list 👆`
  );

  // Step 2: send confirm buttons as a SHORT separate message
  return sendButtons(from, {
    text: `Load all ${allProducts.length} products to your listing?`,
    buttons: [
      { id: "sup_preset_confirm",     title: "✅ Yes, Load These" },
      { id: "sup_enter_own_products", title: "✍️ No, Type My Own" }
    ]
  });
}

// ── Supplier confirms preset load ─────────────────────────────────────────
if (a === "sup_preset_confirm") {
  if (!biz) return sendMainMenu(from);

  const catId = biz.sessionData?.supplierReg?.pendingPresetCatId;
  if (!catId) {
    await sendText(from, "❌ Session expired. Please select your category again.");
    return sendSuppliersMenu(from);
  }

  const { getTemplateForCategoryWithDB } = await import("./supplierProductTemplates.js");
  const template = await getTemplateForCategoryWithDB(catId);

  if (!template?.products?.length) {
    await sendText(from, "❌ Could not load preset. Please type your products.");
    biz.sessionState = "supplier_reg_products";
    await saveBizSafe(biz);
    return;
  }

  // Load products
  biz.sessionData.supplierReg.products = template.products.map(p => p.toLowerCase());
  delete biz.sessionData.supplierReg.pendingPresetCatId;

  // If template has prices - show price preview and ask to use them
  if (template.prices?.length) {
    biz.sessionData.supplierReg.prices = template.prices;
    await saveBizSafe(biz);

    const priceLines = template.prices.slice(0, 6)
      .map(p => `• ${p.product}: $${p.amount}/${p.unit}`)
      .join("\n");
    const remaining = template.prices.length - 6;

    return sendButtons(from, {
      text:
`✅ *${template.products.length} products loaded!*

💰 *Suggested prices:*
${priceLines}${remaining > 0 ? `\n_...and ${remaining} more_` : ""}

Use these suggested prices?`,
      buttons: [
        { id: "sup_preset_prices_yes", title: "✅ Use These Prices" },
        { id: "sup_prices_edit",        title: "✏️ Set My Own Prices" },
        { id: "sup_skip_prices",        title: "⏭ Skip For Now" }
      ]
    });
  }

  // No preset prices - prompt them to enter prices using numbered list
  biz.sessionData.supplierReg.prices = [];
  biz.sessionState = "supplier_reg_prices";
  await saveBizSafe(biz);

  const numbered = template.products.map((p, i) => `${i + 1}. ${p}`).join("\n");

  return sendButtons(from, {
    text:
`✅ *${template.products.length} products loaded!*

💰 *Now set your prices:*
${numbered}

*Fastest:* Just numbers in order:
_5.50, 8, 0.25, 12_

*Or name them:* _cement 5.50, sand 8_`,
    buttons: [{ id: "sup_skip_prices", title: "⏭ Skip For Now" }]
  });
}

// ── Supplier accepts preset suggested prices ──────────────────────────────
if (a === "sup_preset_prices_yes") {
  if (!biz) return sendMainMenu(from);

  const isService = biz.sessionData?.supplierReg?.profileType === "service";
  const prices = biz.sessionData?.supplierReg?.prices || [];

  if (isService) {
    biz.sessionState = "supplier_reg_travel";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `✅ *Prices accepted!*\n\n🚗 *Do you travel to clients?*`,
      buttons: [
        { id: "sup_travel_yes", title: "✅ Yes I Travel" },
        { id: "sup_travel_no",  title: "🏠 Client Comes to Me" }
      ]
    });
  }

  biz.sessionState = "supplier_reg_delivery";
  await saveBizSafe(biz);
  return sendButtons(from, {
    text: `✅ *${prices.length} prices accepted!*\n\n🚚 *Do you deliver?*`,
    buttons: [
      { id: "sup_del_yes", title: "✅ Yes I Deliver" },
      { id: "sup_del_no",  title: "🏠 Collection Only" }
    ]
  });
}

// ── Enter own products (manual entry) ────────────────────────────────────────
if (a === "sup_enter_own_products") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";
  const catId = biz.sessionData?.supplierReg?.categories?.[0] || "";
  const { CATEGORY_PRODUCT_EXAMPLES, CATEGORY_SERVICE_EXAMPLES } = await import("./supplierRegistration.js");

  const isService = profileType === "service";
  const map = isService ? CATEGORY_SERVICE_EXAMPLES : CATEGORY_PRODUCT_EXAMPLES;
  const catExamples = map[catId] || (isService ? ["service a", "service b"] : ["product a", "product b"]);
  const exampleText = catExamples.slice(0, 3).join(", ");

  biz.sessionState = "supplier_reg_products";
  await saveBizSafe(biz);

  return sendText(from,
`✍️ *Enter Your ${isService ? "Services" : "Products"}*

List them separated by commas, then send.

*Example:*
_${exampleText}_

Type *cancel* to stop registration.`);
}

// ── Skip products entirely during registration ────────────────────────────────
if (a === "sup_skip_products") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.products = ["pending_upload"];
  biz.sessionData.supplierReg.prices = [];
  if (profileType === "service") {
    biz.sessionData.supplierReg.rates = [];
    biz.sessionState = "supplier_reg_travel";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: `🚗 *Do you travel to clients?*\n\n_You can add your services later from your account._`,
      buttons: [
        { id: "sup_travel_yes", title: "✅ Yes I Travel" },
        { id: "sup_travel_no",  title: "🏠 Client Comes to Me" }
      ]
    });
  }
  biz.sessionState = "supplier_reg_delivery";
  await saveBizSafe(biz);
  return sendButtons(from, {
    text: `🚚 *Do you deliver?*\n\n_You can add your products later from your account._`,
    buttons: [
      { id: "sup_del_yes", title: "✅ Yes I Deliver" },
      { id: "sup_del_no",  title: "🏠 Collection Only" }
    ]
  });
}


if (a === "sup_addr_skip") {
  if (!biz) return sendMainMenu(from);

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.address = "";
  biz.sessionState = "supplier_reg_contact_details";
  await saveBizSafe(biz);

  return sendButtons(from, {
    text:
`📞 *Contact Details (Optional)*

Enter any extra contact details buyers should see.

Examples:
_0772123456 / 0712345678_
_Call or WhatsApp 0772123456_
_sales@mybusiness.co.zw_

You can also skip this step.`,
    buttons: [
      { id: "sup_contact_skip", title: "⏭ Skip Contact" }
    ]
  });
}

if (a === "sup_contact_skip") {
  if (!biz) return sendMainMenu(from);

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.contactDetails = "";
  biz.sessionState = "supplier_reg_website";
  await saveBizSafe(biz);

  return sendButtons(from, {
    text:
`🌐 *Website (Optional)*

Enter your website, Facebook page, Instagram page, or business link buyers should see.

Examples:
_www.mybusiness.co.zw_
_facebook.com/mybusiness_
_instagram.com/mybusiness_

You can also skip this step.`,
    buttons: [
      { id: "sup_website_skip", title: "⏭ Skip Website" }
    ]
  });
}

if (a === "sup_website_skip") {
  if (!biz) return sendMainMenu(from);

  biz.sessionData = biz.sessionData || {};
  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.website = "";

  const profileType = biz.sessionData.supplierReg.profileType || "product";

  if (profileType === "service") {
    biz.sessionState = "supplier_reg_collar";
    await saveBizSafe(biz);

    return sendList(from, "🧑‍💼 *What type of services do you offer?*\n\nThis helps buyers find you faster.", [
      { id: "sup_collar_white_collar", title: "💼 Professional" },
      { id: "sup_collar_trade",        title: "🔧 Trade & Artisan" },
      { id: "sup_collar_blue_collar",  title: "🧹 General Services" }
    ]);
  }

  biz.sessionState = "supplier_reg_category";
  await saveBizSafe(biz);

  const filteredCategories = getSupplierCategoriesForType(profileType);

  const categoryRows = [
    ...filteredCategories.slice(0, 9).map(c => ({
      id: `sup_cat_${c.id}`,
      title: c.label
    })),
    ...(filteredCategories.length > 9
      ? [{ id: "sup_cat_more", title: "➕ More Categories" }]
      : [])
  ];

  return sendList(from, "🗂 What product do you mainly offer?", categoryRows);
}

// ── Supplier requests catalogue upload help ───────────────────────────────────
if (a === "sup_request_upload") {
  if (!biz) return sendMainMenu(from);

  const profileType = biz.sessionData?.supplierReg?.profileType || "product";
  const isService = profileType === "service";

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.products = ["pending_upload"];
  biz.sessionData.supplierReg.prices = [];

  const existingSupplierId = biz.sessionData?.pendingSupplierId;
  if (existingSupplierId) {
    await SupplierProfile.findByIdAndUpdate(existingSupplierId, {
      adminNote: `[Requested ${isService ? "service rates" : "catalogue"} upload via WhatsApp]`,
      products: ["pending_upload"]
    });
  }

  if (isService) {
    biz.sessionData.supplierReg.rates = [];
    biz.sessionState = "supplier_reg_travel";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text:
`📤 *Upload Request Noted!*

After you finish registration, send your service list & rates to us:
📱 *WhatsApp:* +263 77 114 3904
📧 *Email:* info@zimquote.co.zw

We'll load it within 24 hours and notify you. ✅

Now one quick question - *do you travel to clients?*`,
      buttons: [
        { id: "sup_travel_yes", title: "✅ Yes I Travel" },
        { id: "sup_travel_no",  title: "🏠 Client Comes to Me" }
      ]
    });
  }

  biz.sessionState = "supplier_reg_delivery";
  await saveBizSafe(biz);
  return sendButtons(from, {
    text:
`📤 *Upload Request Noted!*

After you finish registration, send your product list & prices to us:
📱 *WhatsApp:* +263 78 990 1058
📧 *Email:* info@zimquote.co.zw

You can also send a photo of your price list, Excel file, or typed list.
We'll load it within 24 hours and notify you. ✅

Now one quick question - *do you deliver?*`,
    buttons: [
      { id: "sup_del_yes", title: "✅ Yes I Deliver" },
      { id: "sup_del_no",  title: "🏠 Collection Only" }
    ]
  });
}


  // ── Delivery yes/no during registration ───────────────────────────────────
if (a === "sup_del_yes") {
    if (!biz) return sendMainMenu(from);
    biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
    biz.sessionData.supplierReg.delivery = { available: true, range: "city_wide" };
    biz.sessionData.supplierReg.minOrder = 0;
    biz.sessionState = "supplier_reg_biz_currency";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "💱 *Almost done! What currency does your business use?*\n\nThis will be your default for invoices and quotes.",
      buttons: [
        { id: "sup_biz_cur_USD", title: "💵 USD ($)" },
        { id: "sup_biz_cur_ZWL", title: "🇿🇼 ZWL (Z$)" },
        { id: "sup_biz_cur_ZAR", title: "🇿🇦 ZAR (R)" }
      ]
    });
  }

if (a === "sup_del_no") {
    if (!biz) return sendMainMenu(from);
    biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
    biz.sessionData.supplierReg.delivery = { available: false };
    biz.sessionData.supplierReg.minOrder = 0;
    biz.sessionState = "supplier_reg_biz_currency";
    await saveBizSafe(biz);
    return sendButtons(from, {
      text: "💱 *Almost done! What currency does your business use?*\n\nThis will be your default for invoices and quotes.",
      buttons: [
        { id: "sup_biz_cur_USD", title: "💵 USD ($)" },
        { id: "sup_biz_cur_ZWL", title: "🇿🇼 ZWL (Z$)" },
        { id: "sup_biz_cur_ZAR", title: "🇿🇦 ZAR (R)" }
      ]
    });
  }



  // ── Supplier registration: currency selected → show confirm ──────────────
if (a.startsWith("sup_biz_cur_")) {
  const currency = a.replace("sup_biz_cur_", "").toUpperCase();
  if (!["USD", "ZWL", "ZAR"].includes(currency)) return true;
  if (!biz) return sendMainMenu(from);

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.currency = currency;

  // Pre-fill business name and currency onto the Business record now
  const reg = biz.sessionData.supplierReg;
  if (reg.businessName && (!biz.name || biz.name.startsWith("pending_"))) {
    biz.name = reg.businessName;
  }
  biz.currency = currency;
  biz.isSupplier = true;
  biz.sessionState = "supplier_reg_confirm";
  await saveBizSafe(biz);

  return _sendSupplierConfirmPrompt(from, reg);
}
  // ── Supplier confirms listing → save + show plan picker ──────────────────
  if (a === "sup_confirm_yes") {
    if (!biz) return sendMainMenu(from);
    const reg = biz.sessionData?.supplierReg;
    if (!reg?.businessName) {
      await sendText(from, "❌ Registration data missing. Please start again.");
      biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
      return startSupplierRegistration(from, biz);
    }

// Create inactive supplier profile
const supplier = await SupplierProfile.create({
      phone,
      businessName: reg.businessName,
      businessId: biz._id,                         // ← LINK TO BUSINESS
      location: { city: reg.city || "Harare", area: reg.area || "" },
      address: reg.address || "",
      contactDetails: reg.contactDetails || "",
      website: reg.website || "",
      categories: reg.categories || [],
      products: reg.products || [],
      prices: reg.prices || [],
      delivery: reg.delivery || { available: false },
      minOrder: reg.minOrder || 0,
      profileType: reg.profileType || "product",
      rates: reg.rates || null,
      travelAvailable: reg.travelAvailable ?? null,
      // ── Teacher fields (populated when category = tutoring) ─────────────────
      subjects:      reg.subjects      || [],
      gradesOffered: reg.gradesOffered || [],
      // ── Tourism / Hospitality fields ─────────────────────────────────────────
      tourismType:    reg.tourismType    || "",       // legacy single-string
      tourismAreas:   reg.tourismAreas   || [],
      tourismSubtype: reg.tourismSubtype || [],       // ["lodge","safari_operator",...]
      facilities:     reg.facilities     || [],       // ["wifi","pool","breakfast",...]
      roomTypes:      reg.roomTypes      || [],       // [{ name, capacity, pricePerNight, restRate }]
      extraServices:  reg.extraServices  || [],       // [{ name, price, unit }]
      // ── Sync products[] from roomTypes so smart link + sellerChat can find them ──
      products: (reg.roomTypes || []).length > 0
        ? (reg.roomTypes || []).map(rt => rt.name.toLowerCase()).filter(Boolean)
        : (reg.products || []),
      maxCapacity:    reg.maxCapacity    || 0,
      checkInTime:    reg.checkInTime    || "",
      checkOutTime:   reg.checkOutTime   || "",
      mealPlan:       reg.mealPlan       || "not_applicable",
      active: false,
      subscriptionStatus: "pending",
      priceUpdatedAt: reg.prices?.length ? new Date() : null
    });

    // Link the supplier profile back onto the Business record
      biz.supplierProfileId = supplier._id;
    biz.isSupplier = true;
    if (reg.businessName && (!biz.name || biz.name.startsWith("pending_"))) {
      biz.name = reg.businessName;
    }
    if (reg.address) {
      biz.address = reg.address;
    }
    if (reg.contactDetails) {
      biz.contactDetails = reg.contactDetails;
    }
    if (reg.website) {
      biz.website = reg.website;
    }
    biz.sessionData.pendingSupplierId = supplier._id.toString();
    biz.sessionState = "supplier_reg_choose_plan";
    await saveBizSafe(biz);

    // ── FIX A: Sync supplier products/services → Product model immediately ──────
    // This ensures Business Tools → Products & Services shows items right away,
    // even before payment is confirmed. Payment sync will upsert again with prices.
    try {
      const _itemsToSync = [
        ...(reg.products || []),
        ...(reg.listedProducts || [])
      ].filter(Boolean);
      const _uniqueItems = [...new Set(_itemsToSync.map(n => n.trim()).filter(Boolean))];

      for (const _itemName of _uniqueItems) {
        const _price = (reg.prices || []).find(p => p.product?.toLowerCase() === _itemName.toLowerCase());
        const _rate  = (reg.rates  || []).find(r => r.service?.toLowerCase() === _itemName.toLowerCase());
        await Product.findOneAndUpdate(
          { businessId: biz._id, name: _itemName },
          { $set: {
              businessId: biz._id,
              branchId:   null,
              unitPrice:  _price?.amount || 0,
              description:_rate?.rate    || null,
              isService:  (reg.profileType === "service"),
              isActive:   true
            }
          },
          { upsert: true }
        );
      }
      if (_uniqueItems.length) {
        console.log(`[SYNC-REG] ${_uniqueItems.length} items synced to Product model for biz ${biz._id}`);
      }
    } catch (_syncRegErr) {
      console.error("[SYNC-REG] Initial product sync failed:", _syncRegErr.message);
    }

    // Non-blocking: notify this new supplier of any unmatched open requests
    // that match their categories. This turns onboarding into instant value.
    notifyNewSellerOfUnmatchedRequests(supplier).catch(err =>
      console.error("[RE-NOTIFY NEW SELLER]", err.message)
    );

return sendList(from,
`🎉 *Your listing is ready!*

But right now *buyers cannot find you yet.*

To go live and start receiving orders, you need to choose a plan and pay. It's like paying for a market stall - once you pay, your business shows up when buyers search.

💳 *Choose a plan below to activate your listing:*`,
      [
        { id: "sup_plan_basic_monthly", title: "✅ Basic - $5/month", description: "Up to 20 live items. Good to start." },
        { id: "sup_plan_basic_annual", title: "✅ Basic $50/yr", description: "Pay once for the whole year" },
        { id: "sup_plan_pro_monthly", title: "⭐ Pro - $12/month", description: "Up to 60 live items" },
        { id: "sup_plan_pro_annual", title: "⭐ Pro $120/yr", description: "Most popular choice" },
        { id: "sup_plan_featured_monthly", title: "🔥 Featured $25/mo", description: "Top of search - buyers see you first" }
      ]
    );
  }

  if (a === "sup_confirm_no") {
    if (!biz) return sendMainMenu(from);
    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
    return startSupplierRegistration(from, biz);
  }

  // ── Supplier search: category selected ────────────────────────────────────
if (a.startsWith("sup_search_cat_")) {
  const category = a.replace("sup_search_cat_", "");

  let searchType = biz?.sessionData?.supplierSearch?.type || null;
  if (!searchType) {
    const sess = await UserSession.findOne({ phone });
    searchType = sess?.tempData?.supplierSearchType || "product";
  }

  if (biz) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: {
        ...(biz.sessionData?.supplierSearch || {}),
        type: searchType,
        category
      }
    };
    biz.sessionState = "supplier_search_city";
    await saveBizSafe(biz);
  } else {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.supplierSearchCategory": category,
          "tempData.supplierSearchType": searchType
        }
      },
      { upsert: true }
    );
  }

  return sendList(from, "📍 Which city?", [
    ...SUPPLIER_CITIES.slice(0, 9).map(c => ({
      id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`,
      title: c
    })),
    { id: "sup_search_city_other", title: "📍 Other" }
  ]);
}

  // ── Supplier search: city selected ────────────────────────────────────────
if (a.startsWith("sup_search_city_")) {
  const cityRaw = a.replace("sup_search_city_", "").replace(/_/g, " ");
  const city = cityRaw === "all" ? null : cityRaw.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");

  let category = biz?.sessionData?.supplierSearch?.category || null;
  let product = biz?.sessionData?.supplierSearch?.product || null;
  let profileType = biz?.sessionData?.supplierSearch?.type || null;

  if (!category && !product && !profileType) {
    const sess = await UserSession.findOne({ phone });
    category = sess?.tempData?.supplierSearchCategory || null;
    product = sess?.tempData?.supplierSearchProduct || null;
    profileType = sess?.tempData?.supplierSearchType || null;
  }

  const locationLabel = city || "All Cities";

  // OFFER-FIRST SEARCH FLOW (products + services)
  if (product) {
    const supplierResults = await runSupplierSearch({
      city,
      category,
      product,
      profileType,
      area: null
    });

    const normalizedQuery = normalizeProductName(product);
    const directBusinessMatches = supplierResults.filter(s => {
      const businessName = normalizeProductName(s.businessName || "");
      return businessName === normalizedQuery || businessName.includes(normalizedQuery);
    });

    // Only direct-open when there is one clear business-name hit
    if (directBusinessMatches.length === 1) {
      const supplier = directBusinessMatches[0];
      const cart = await getCurrentOrderCart({ biz, phone });

      await persistOrderFlowState({
        biz,
        phone,
        patch: {
          orderSupplierId: String(supplier._id),
          orderBrowseMode: "catalogue",
          orderCataloguePage: 0,
          orderCatalogueSearch: ""
        }
      });

      return _sendSupplierShoppingHub(from, supplier, cart);
    }

    const offerResults = await runSupplierOfferSearch({
      city,
      category,
      product,
      profileType,
      area: null
    });

    // Use offer-level results first for normal product/service searches
    if (offerResults.length) {
      if (biz) {
        biz.sessionData = {
          ...(biz.sessionData || {}),
          supplierSearch: {
            ...(biz.sessionData?.supplierSearch || {}),
            city
          },
          searchResults: offerResults,
          searchPage: 0,
          searchResultMode: "offers"
        };
        await saveBizSafe(biz);
      } else {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": offerResults,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "offers"
            }
          },
          { upsert: true }
        );
      }

      const pageResults = offerResults.slice(0, 9);
     const rows = formatSupplierOfferResults(pageResults, product);

      if (offerResults.length > 9) {
        rows.push({ id: "sup_search_next_page", title: `➡ More results (${offerResults.length - 9} more)` });
      }

      return sendNumberedSellerResults({
        from, phone,
        offers: offerResults,
        searchTerm: product,
        locationLabel
      });
    }

    // If there are no offer-level matches, then fall back to supplier-level business matches
    if (directBusinessMatches.length > 1) {
      if (biz) {
        biz.sessionData = {
          ...(biz.sessionData || {}),
          supplierSearch: {
            ...(biz.sessionData?.supplierSearch || {}),
            city
          },
          searchResults: directBusinessMatches,
          searchPage: 0,
          searchResultMode: "suppliers"
        };
        await saveBizSafe(biz);
      } else {
        await UserSession.findOneAndUpdate(
          { phone },
          {
            $set: {
              "tempData.searchResults": directBusinessMatches,
              "tempData.searchPage": 0,
              "tempData.searchResultMode": "suppliers"
            }
          },
          { upsert: true }
        );
      }

      const pageResults = directBusinessMatches.slice(0, 9);
      const rows = formatSupplierResults(pageResults, city, product);

      if (directBusinessMatches.length > 9) {
        rows.push({ id: "sup_search_next_page", title: `➡ More results (${directBusinessMatches.length - 9} more)` });
      }

      return sendNumberedSellerResults({
        from, phone,
        suppliers: directBusinessMatches,
        searchTerm: product,
        locationLabel: city || "All Cities"
      });
    }

    return sendButtons(from, {
      text: `😕 No matching offers found for *${product}*${city ? ` in ${city}` : ""}.\n\nTry another search term or city.`,
      buttons: [
        { id: "find_supplier", title: "🔍 Search Again" },
        { id: "suppliers_home", title: "🛒 Marketplace" }
      ]
    });
  }

  // CATEGORY-BROWSE FLOW (category + type, no typed product)
  if (category && profileType) {
    const supplierResults = await runSupplierSearch({
      city,
      category,
      product: null,
      profileType,
      area: null
    });

    if (!supplierResults.length) {
      const label = category.replace(/_/g, " ");
      return sendButtons(from, {
        text: `😕 No matching ${profileType === "service" ? "providers" : "suppliers"} found for *${label}*${city ? ` in ${city}` : ""}.\n\nTry another city or category.`,
        buttons: [
          { id: "find_supplier", title: "🔍 Search Again" },
          { id: "suppliers_home", title: "🛒 Marketplace" }
        ]
      });
    }

    if (biz) {
      biz.sessionData = {
        ...(biz.sessionData || {}),
        supplierSearch: {
          ...(biz.sessionData?.supplierSearch || {}),
          city
        },
        searchResults: supplierResults,
        searchPage: 0,
        searchResultMode: "suppliers"
      };
      await saveBizSafe(biz);
    } else {
      await UserSession.findOneAndUpdate(
        { phone },
        {
          $set: {
            "tempData.searchResults": supplierResults,
            "tempData.searchPage": 0,
            "tempData.searchResultMode": "suppliers"
          }
        },
        { upsert: true }
      );
    }

    const pageResults = supplierResults.slice(0, 9);
    const rows = formatSupplierResults(pageResults, city, null);

    if (supplierResults.length > 9) {
      rows.push({ id: "sup_search_next_page", title: `➡ More results (${supplierResults.length - 9} more)` });
    }

    return sendNumberedSellerResults({
      from, phone,
      suppliers: supplierResults,
      searchTerm: "",
      locationLabel,
      titleLabel: `📂 ${category.replace(/_/g, " ")}`
    });
  }

  return sendButtons(from, {
    text: "❌ Search session expired. Please start again.",
    buttons: [
      { id: "find_supplier", title: "🔍 Search Again" },
      { id: "suppliers_home", title: "🛒 Marketplace" }
    ]
  });
}

if (a.startsWith("sup_offer_pick_")) {
  const raw = a.replace("sup_offer_pick_", "");
  const firstUnderscore = raw.indexOf("_");
  const supplierId = raw.slice(0, firstUnderscore);
  const productName = decodeURIComponent(raw.slice(firstUnderscore + 1));

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

   const matched = findMatchingSupplierPrice(supplier, productName);

  let pricePerUnit = typeof matched?.amount === "number" ? matched.amount : null;
  let unit = matched?.unit || (supplier.profileType === "service" ? "job" : "each");

  const selectedItem = {
    product: productName,
    quantity: 1,
    unit,
    pricePerUnit,
    total: pricePerUnit !== null ? Number((1 * pricePerUnit).toFixed(2)) : null
  };

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: supplier.profileType === "service",
      orderBrowseMode: "selected_offer",
      orderCatalogueSearch: productName,
      selectedSupplierItem: selectedItem
    }
  });

// For services, skip qty picker - default to 1 and go straight to preview
  if (supplier.profileType === "service") {
    return _sendSelectedSupplierItemPreview(from, supplier, selectedItem, cart, {
      quantity: 1,
      searchTerm: productName
    });
  }

  return _sendSupplierQuantityPicker(from, supplier, selectedItem, cart, {
    backId: "sup_offer_results_back"
  });
}

if (a === "sup_offer_results_back") {
  let allResults = [];
  let currentPage = 0;

  if (biz) {
    allResults = biz.sessionData?.searchResults || [];
    currentPage = biz.sessionData?.searchPage || 0;
  } else {
    const sess = await UserSession.findOne({ phone });
    allResults = sess?.tempData?.searchResults || [];
    currentPage = sess?.tempData?.searchPage || 0;
  }

  if (!allResults.length) {
    return sendButtons(from, {
      text: "❌ Search session expired. Please search again.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  const PAGE_SIZE = 9;
  const start = currentPage * PAGE_SIZE;
  const pageResults = allResults.slice(start, start + PAGE_SIZE);
const rows = formatSupplierOfferResults(pageResults, biz?.sessionData?.supplierSearch?.product || "");

  const hasMore = allResults.length > start + PAGE_SIZE;
  const hasPrev = currentPage > 0;

  if (hasPrev) rows.push({ id: "sup_search_prev_page", title: "⬅ Back" });
  if (hasMore) rows.push({ id: "sup_search_next_page", title: `➡ More (${allResults.length - start - PAGE_SIZE} more)` });

  if (rows.length > 10) rows.splice(10);

  return sendList(
    from,
    `🔎 Matching products\nResults ${start + 1}-${Math.min(start + PAGE_SIZE, allResults.length)} of ${allResults.length}`,
    rows
  );
}


  // ── View supplier detail ───────────────────────────────────────────────────
if (a.startsWith("sup_view_")) {
  const supplierId = a.replace("sup_view_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  await SupplierProfile.findByIdAndUpdate(supplierId, {
    $inc: { viewCount: 1, monthlyViews: 1 }
  });

  const sess = await UserSession.findOne({ phone });
  const cart = await getCurrentOrderCart({ biz, phone });
  const fromCategoryBrowse = isCategoryBrowseContext({ biz, sess });

  const deliveryText = supplier.profileType === "service"
    ? (supplier.travelAvailable ? "🚗 Mobile service - travels to you" : "📍 Visit required - client comes to provider")
    : (supplier.delivery?.available
        ? `🚚 Delivers (${(supplier.delivery.range || "").replace("_", " ")})`
        : "🏠 Collection only");

  const badge = supplier.topSupplierBadge ? "\n🏅 Top Supplier" : "";
  const tierBadge = supplier.tier === "featured" ? " 🔥" : supplier.tier === "pro" ? " ⭐" : "";
  const offeringLabel = supplier.profileType === "service" ? "🔧" : "📦";
    const offeringText = getSupplierCatalogueSourceItems(supplier)
    .slice(0, 5)
    .map(item => item.priceLabel ? `${item.name} (${item.priceLabel})` : item.name)
    .join(", ");

  if (fromCategoryBrowse) {
    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderSupplierId: String(supplier._id),
        orderIsService: supplier.profileType === "service",
        orderBrowseMode: "supplier_shop_hub",
        selectedSupplierItem: null
      }
    });

    return _sendSupplierShoppingHub(from, supplier, cart, {
      fromCategory: true
    });
  }

  return sendButtons(from, {
    text: `🏪 *${supplier.businessName}*${tierBadge}\n` +
          `📍 ${supplier.location?.area}, ${supplier.location?.city}\n` +
          `${offeringLabel} ${offeringText}\n` +
          `${deliveryText}${badge}\n` +
          `⭐ ${(supplier.rating || 0).toFixed(1)} (${supplier.reviewCount || 0} reviews)\n` +
          `📞 ${supplier.phone}`,
buttons: [
      {
        id: `sup_order_${supplierId}`,
        title: supplier.profileType === "service" ? "📅 Book Service" : "🛒 Place Order"
      },
      { id: "find_supplier", title: "🔍 Search Again" }
    ]
  });
}


if (a.startsWith("sup_shop_")) {
  const supplierId = a.replace("sup_shop_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: supplier.profileType === "service",
      orderBrowseMode: "supplier_shop_hub",
      selectedSupplierItem: null
    }
  });

  return _sendSupplierShoppingHub(from, supplier, cart, {
    fromCategory: true
  });
}

  // ── Save supplier ──────────────────────────────────────────────────────────
  if (a.startsWith("sup_save_")) {
    const supplierId = a.replace("sup_save_", "");
    await SupplierProfile.findByIdAndUpdate(supplierId, {
      $addToSet: { savedBy: phone }
    });
    await sendText(from, "Supplier saved! Find them in your saved list.");
    return;
  }


if (a === "sup_quick_edit_products") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first.*\n\nYou can edit products after your listing is live.");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const isService = supplier.profileType === "service";
  const items = (supplier.products || []).filter(p => p !== "pending_upload");

  if (!items.length) {
    return sendText(from, `❌ No ${isService ? "services" : "products"} listed yet.`);
  }

  if (biz) {
    biz.sessionState = "supplier_quick_edit_products";
    await saveBizSafe(biz);
  }

   await sendSupplierItemsInChunks(
    from,
    items,
    `⚡ Quick Edit ${isService ? "Services" : "Products"}`
  );

  return sendSupplierQuickEditHelp(from, isService);

}
  // ── Update supplier prices ─────────────────────────────────────────────────
if (a === "sup_update_prices") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  if (!supplier.active) {
    await sendText(from, "🔒 *Activate your listing first.*\n\nYou can update prices after your listing is live.");
    return sendSupplierUpgradeMenu(from, supplier.tier);
  }

  const isService = supplier.profileType === "service";
  const products = (supplier.products || []).filter(p => p !== "pending_upload");

 if (biz) {
  biz.sessionData = {
    ...(biz.sessionData || {}),
    updatingPrices: true
  };
  biz.sessionState = "supplier_update_prices";
  await saveBizSafe(biz);
}

await UserSession.findOneAndUpdate(
  { phone },
  {
    $set: {
      "tempData.supplierAccountState": "supplier_update_prices",
      "tempData.pendingPriceUpdate": [],
      "tempData.supplierAccountType": isService ? "service" : "product"
    },
    $unset: {
      "tempData.supplierSearchMode": "",
      "tempData.supplierSearchProduct": "",
      "tempData.supplierSearchCategory": "",
      "tempData.searchResults": "",
      "tempData.searchPage": "",
      "tempData.lastSearchCity": ""
    }
  },
  { upsert: true }
);

 
  if (!products.length) {
    return sendButtons(from, {
      text: "❌ Add your products first before setting prices.",
      buttons: [{ id: "sup_edit_products", title: "✏️ Add Products" }]
    });
  }

  // ── Send numbered list in chunks of 25 (each chunk safely under 4096) ────
  const listedSet = new Set(
    (supplier.listedProducts || []).filter(Boolean).map(p => normalizeProductName(p))
  );
  const listedProducts   = products.filter(p => listedSet.has(normalizeProductName(p)));
  const unlistedProducts = products.filter(p => !listedSet.has(normalizeProductName(p)));

  function buildPriceLines(items, startIndex) {
    const CHUNK = 25;
    const lines = [];
    for (let i = 0; i < items.length; i++) {
      const p = items[i];
      const globalIdx = startIndex + i;
      const existing = isService
        ? supplier.rates?.find(r => r.service?.toLowerCase() === p.toLowerCase())
        : supplier.prices?.find(pr => pr.product?.toLowerCase() === p.toLowerCase());
      const priceStr = isService
        ? (existing ? ` - ${existing.rate}` : " - _(not set)_")
        : (existing ? ` - $${Number(existing.amount).toFixed(2)}/${existing.unit}` : " - _(not set)_");
      lines.push(`${globalIdx + 1}. ${p}${priceStr}`);
    }
    return lines;
  }

  // ── Section 1: Live (listed) items ───────────────────────────────────────
  if (listedProducts.length) {
    const lines = buildPriceLines(listedProducts, 0);
    const CHUNK = 25;
    for (let i = 0; i < lines.length; i += CHUNK) {
      const chunk = lines.slice(i, i + CHUNK).join("\n");
      const isFirst = i === 0;
      const isLast  = i + CHUNK >= lines.length;
      await sendText(from,
        isFirst
          ? `💰 *Update ${isService ? "Rates" : "Prices"}*\n\n🟢 *Live ${isService ? "Services" : "Products"} (${listedProducts.length})*\n\n${chunk}${isLast ? "" : "\n_(continued...)_"}`
          : `${chunk}${isLast ? "" : "\n_(continued...)_"}`
      );
    }
  }

  // ── Section 2: Unlisted items ────────────────────────────────────────────
  if (unlistedProducts.length) {
    const lines = buildPriceLines(unlistedProducts, listedProducts.length);
    const CHUNK = 25;
    for (let i = 0; i < lines.length; i += CHUNK) {
      const chunk = lines.slice(i, i + CHUNK).join("\n");
      const isFirst = i === 0;
      const isLast  = i + CHUNK >= lines.length;
      await sendText(from,
        isFirst
          ? `⚪ *Unlisted ${isService ? "Services" : "Products"} (${unlistedProducts.length} - not visible to buyers)*\n\n${chunk}${isLast ? "" : "\n_(continued...)_"}`
          : `${chunk}${isLast ? "" : "\n_(continued...)_"}`
      );
    }
  }

  return sendSupplierQuickPriceHelp(from, products, isService);
}


if (biz?.sessionState === "supplier_quick_edit_products" && !isMetaAction) {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const isService = supplier.profileType === "service";
  const items = (supplier.products || []).filter(p => p !== "pending_upload");
  if (!items.length) {
    biz.sessionState = "ready";
    await saveBizSafe(biz);
    await sendText(from, `❌ No ${isService ? "services" : "products"} listed.`);
    return sendSupplierAccountMenu(from, supplier);
  }

  const raw = (text || "").trim();

  // 1) rename: 5=new name
  const renameCmd = parseQuickRenameCommand(raw, items);
  if (renameCmd) {
    const oldName = items[renameCmd.index];
    const nextItems = [...items];
    nextItems[renameCmd.index] = renameCmd.newName;

    supplier.products = dedupeSupplierItems(nextItems);

    if (isService) {
      supplier.rates = (supplier.rates || []).map(r => {
        if (normalizeProductName(r.service) === normalizeProductName(oldName)) {
          return { ...r.toObject?.() || r, service: renameCmd.newName };
        }
        return r;
      });
    } else {
      supplier.prices = (supplier.prices || []).map(pr => {
        if (normalizeProductName(pr.product) === normalizeProductName(oldName)) {
          return { ...pr.toObject?.() || pr, product: renameCmd.newName };
        }
        return pr;
      });
    }

       await supplier.save();

    await sendText(from, `✅ Renamed:\n• ${oldName}\n→ ${renameCmd.newName}`);
    await sendSupplierItemsInChunks(
      from,
      supplier.products,
      `📋 Updated ${isService ? "Services" : "Products"}`
    );
    await sendSupplierQuickEditHelp(from, isService);
    return true;
  }

  // 2) delete: del 5,8,10
  const deleteIndexes = parseQuickDeleteCommand(raw, items);
  if (deleteIndexes.length) {
    const removed = deleteIndexes.map(i => items[i]);
    const remaining = items.filter((_, i) => !deleteIndexes.includes(i));

    supplier.products = remaining;
    if (isService) {
      supplier.rates = filterRatesForRemainingServices(supplier.rates || [], remaining);
    } else {
      supplier.prices = filterPricesForRemainingProducts(supplier.prices || [], remaining);
    }

     await supplier.save();

    await sendText(
      from,
      `✅ Deleted *${removed.length}* ${isService ? "service" : "product"}${removed.length === 1 ? "" : "s"}:\n${removed.map(p => `• ${p}`).join("\n")}`
    );

    if (remaining.length) {
      await sendSupplierItemsInChunks(
        from,
        remaining,
        `📋 Remaining ${isService ? "Services" : "Products"}`
      );
      await sendSupplierQuickEditHelp(from, isService);
      return true;
    }

    await sendText(from, `ℹ️ No ${isService ? "services" : "products"} left.`);
    await sendSupplierQuickEditHelp(from, isService);
    return true;
  }

  // 3) add: add hammer, pliers
  const addItems = parseQuickAddCommand(raw);
  if (addItems.length) {
    const merged = dedupeSupplierItems([...items, ...addItems]);
    const addedCount = merged.length - items.length;

       supplier.products = merged;
    await supplier.save();

    await sendText(
      from,
      `✅ Added *${addedCount}* ${isService ? "service" : "product"}${addedCount === 1 ? "" : "s"}.\n\nTotal now: *${merged.length}*`
    );

    await sendSupplierItemsInChunks(
      from,
      merged,
      `📋 Updated ${isService ? "Services" : "Products"}`
    );
    await sendSupplierQuickEditHelp(from, isService);
    return true;
  }

  await sendText(
    from,
`❌ I couldn't read that quick edit command.

Use:
_5=new name_
_del 5,8,10_
_add hammer, pliers_

Type *cancel* to go back.`
  );
  return true;
}
  // ── Handle price update text input ────────────────────────────────────────
if (biz?.sessionState === "supplier_update_prices" && !isMetaAction) {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const raw = (text || "").trim();
  if (!raw) {
    await sendText(from, "❌ Please send your prices.");
    return;
  }

    const isService = supplier.profileType === "service";
  const products = (supplier.products || []).filter(p => p !== "pending_upload");
  const parts = raw.split(/[,\n]+/).map(s => s.trim()).filter(Boolean);
  const allNumbers = parts.length > 0 && parts.every(s => /^\d+(\.\d+)?$/.test(s));
  const updated = [];
  const failed = [];

  // Supports:
  // 75 x 3.50
  // 5,7,9 x 3.50
  // 20-30 x 1.25
  // 5 x 3.50, 7 x 4.20
  // 3 x 20/job
  const quick = parseQuickPriceUpdates(raw, products, isService);



 if (quick.matchedAny) {
  quick.updates.forEach(u => {
    updated.push({
      product: u.product.toLowerCase(),
      amount: u.amount,
      unit: u.unit,
      inStock: true
    });
  });

  failed.push(...quick.failed);
}
else if (allNumbers) {
    // Strategy 1: numbers in order
    if (parts.length !== products.length) {
      const numbered = products.map((p, i) => `${i + 1}. ${p}`).join("\n");
      await sendText(from,
`❌ You have *${products.length} product${products.length > 1 ? "s" : ""}* but sent *${parts.length} price${parts.length > 1 ? "s" : ""}*.

Send one price per ${isService ? "service" : "product"} in order:
${numbered}

Example: *${products.slice(0, 3).map((_, i) => ((i + 1) * 10)).join(", ")}*`
      );
      return true;
    }
    parts.forEach((numStr, i) => {
      updated.push({
        product: products[i].toLowerCase(),
        amount: parseFloat(numStr),
        unit: isService ? "job" : "each",  // ← FIX: services get "job" not "each"
        inStock: true
      });
    });
 } else {
    // Strategy 2: named pricing OR rate-style "NUMBER/UNIT" format
    for (const line of parts) {
      const clean = line
        .replace(/^[-•*►▪✓]\s*/, "")
        .replace(/^\d+[.)]\s*/, "")
        .replace(/\$/g, "")
        .trim();

      if (!clean) continue;

      // ── Strategy 2a: "NUMBER/UNIT" format e.g. "20/job", "50/hr", "15/trip" ──
      // This is how service suppliers naturally type rates - number/unit without name
      // We assign them positionally to the products list (in order)
      // Accept: 80/person, 80/hr, 80/hour, 80/day, 80/night, 80/trip, 80/group, 80/job, 80/each
      const rateOnlyMatch = clean.match(/^(\d+(?:\.\d+)?)\/([a-zA-Z]+)$/);
      if (rateOnlyMatch) {
        const posIdx = updated.length; // assign to next product in order
        const _rawUnit = rateOnlyMatch[2].toLowerCase();
        // Normalise common aliases
        const _normUnit = { "hour": "hr", "hours": "hr", "persons": "person",
          "people": "person", "nights": "night", "days": "day",
          "trips": "trip", "groups": "group" }[_rawUnit] || _rawUnit;
        if (posIdx < products.length) {
          updated.push({
            product: products[posIdx].toLowerCase(),
            amount: parseFloat(rateOnlyMatch[1]),
            unit: _normUnit,
            inStock: true
          });
        } else {
          failed.push(line); // more rates than products
        }
        continue;
      }

      // ── Strategy 2b: named pricing e.g. "burst pipe repair: 20", "plumbing 50/hr" ──
      let match =
        clean.match(/^(.+?)\s*[:]\s*(\d+(?:\.\d+)?)\s*([a-zA-Z/]*)$/) ||
        clean.match(/^(.+?)\s+(\d+(?:\.\d+)?)\s*([a-zA-Z/]*)$/);

      if (!match) { failed.push(line); continue; }

      const product = match[1].replace(/[$@\-:,]+$/, "").trim().toLowerCase();
      const amount = parseFloat(match[2]);
      // Parse unit: "50/hr" → "hr", "50" alone → default based on type
      const rawUnit = match[3]?.trim().toLowerCase() || "";
      const unit = rawUnit
        ? rawUnit.replace(/^\//, "") // strip leading slash if any
        : (isService ? "job" : "each");  // ← FIX: services default to "job"

      if (!product || isNaN(amount)) { failed.push(line); continue; }
      updated.push({ product, amount, unit, inStock: true });
    }
  }

    if (!updated.length) {
    const numbered = products.map((p, i) => `${i + 1}. ${p}`).join("\n");
    await sendText(from,
`❌ Couldn't read your prices.

*Your items:*
${numbered}

Try any of these:

*Single item:*
_75 x 3.50_
${isService ? `_3 x 20/job_` : ""}

*Same price for selected items:*
_5,7,9 x 3.50_

*Same price for a range:*
_20-30 x 1.25_

*Mixed updates:*
_5 x 3.50, 7 x 4.20${isService ? ", 9 x 15/job" : ""}_

*Update ALL in order:*
_${products.slice(0, 3).map((_, i) => (((i + 1) * 4)).toFixed(2)).join(", ")}_

*Update selected items by name:*
_${products.slice(0, 2).map(p => `${p}: 6.00`).join(", ")}_

Type *cancel* to go back.`
    );
    return true;
  }

  // Preview before saving
  const previewLines = updated.map(u => `• ${u.product} - $${Number(u.amount).toFixed(2)}/${u.unit}`).join("\n");
  const failNote = failed.length ? `\n\n⚠️ Skipped ${failed.length}: _${failed.slice(0, 2).join(", ")}_` : "";

  // Temporarily store pending update
  biz.sessionData.pendingPriceUpdate = updated;
  await saveBizSafe(biz);

  return sendButtons(from, {
    text:
`💰 *Price Preview* (${updated.length} items)

${previewLines}${failNote}

Save these prices?`,
    buttons: [
      { id: "sup_price_update_confirm", title: "✅ Save Prices" },
      { id: "sup_update_prices",         title: "✏️ Re-enter" },
      { id: "my_supplier_account",       title: "🏪 Cancel" }
    ]
  });
}


// ── Supplier confirms price they just entered ─────────────────────────────
  if (a === "sup_price_confirm_yes") {
    const orderId = biz?.sessionData?.pricingOrderId;
    const pendingPrices = biz?.sessionData?.pendingPrices;

    if (!orderId || !pendingPrices?.length) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Pricing session expired. Please check the order and try again.");
      return sendSuppliersMenu(from);
    }

    const order = await SupplierOrder.findById(orderId);
    if (!order) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Order not found.");
      return sendSuppliersMenu(from);
    }

  const supplier = await SupplierProfile.findOne({ phone: from }).lean();
const isServiceSupplier = supplier?.profileType === "service";
const missingIndexes = biz?.sessionData?.pricingMissingIndexes || [];

// Apply prices only to missing items
for (let i = 0; i < missingIndexes.length; i++) {
  const idx = missingIndexes[i];
  const item = order.items[idx];
  const qty = Number(item.quantity) || 1;
  const unitPrice = Number(pendingPrices[i]);

  order.items[idx] = {
    ...item.toObject?.() || item,
    pricePerUnit: unitPrice,
    total: Number((qty * unitPrice).toFixed(2)),
    currency: "USD"
  };
}

const grandTotal = order.items.reduce((sum, item) => sum + Number(item.total || 0), 0);

order.totalAmount = Number(grandTotal.toFixed(2));
order.currency = "USD";
order.status = "accepted";
await order.save();

    await SupplierProfile.findOneAndUpdate(
      { phone: from },
      { $inc: { monthlyOrders: 1, completedOrders: 1 } }
    );

    biz.sessionState = "ready";
    biz.sessionData = {};
    await saveBizSafe(biz);

    // Build confirmed item lines for buyer notification
    const itemLines = order.items.map(i => {
      const unitLabel = i.unit && i.unit !== "units" ? i.unit : (isServiceSupplier ? "job" : "unit");
      return `• ${i.product} × ${i.quantity} ${unitLabel} @ $${Number(i.pricePerUnit).toFixed(2)} = *$${Number(i.total).toFixed(2)}*`;
    }).join("\n");

    const deliveryLine = order.delivery?.required
      ? `🚚 Delivery to: ${order.delivery.address}`
      : isServiceSupplier
        ? `📍 Location: ${order.delivery?.address || "TBC"}`
        : `🏠 Collection`;

    // Notify buyer
    try {
      await sendButtons(order.buyerPhone, {
        text:
          `✅ *${isServiceSupplier ? "Booking" : "Order"} Accepted!*\n\n` +
          `*${supplier?.businessName || from}* has accepted your ${isServiceSupplier ? "booking" : "order"}:\n\n` +
          `${itemLines}\n\n` +
          `${deliveryLine}\n` +
          `💵 *Total: $${grandTotal.toFixed(2)}*\n` +
          `📞 Contact: ${from}\n\n` +
          `They will be in touch to arrange ${isServiceSupplier ? "the service" : "payment & delivery"}.`,
        buttons: [
          { id: `rate_order_${order._id}`, title: isServiceSupplier ? "⭐ Rate Service" : "⭐ Rate Order" },
          { id: "suppliers_home",          title: "🏪 Suppliers" }
        ]
      });
    } catch (err) {
      console.error("[SUPPLIER PRICE CONFIRM → BUYER NOTIFY FAILED]", err?.response?.data || err.message);
    }

    // Ask supplier for ETA
// Ask supplier for ETA -include delivery address so they have it handy
   // Ask supplier for ETA - include delivery address so they have it handy
    const confirmDeliveryLine = order.delivery?.required
      ? `🚚 *Deliver to:* ${order.delivery.address}`
      : isServiceSupplier
        ? `📍 *Service location:* ${order.delivery?.address || "TBC"}`
        : `🏠 *Collection* (buyer will pick up)`;

    // ── Generate PDF order summary and send to supplier ───────────────────
  // ── Generate ORDER PDF and send to supplier ───────────────────────────
    try {
      const orderRef = `ORD-${String(order._id).slice(-8).toUpperCase()}`;
      const deliveryNote = order.delivery?.required
        ? `Deliver to: ${order.delivery.address}`
        : isServiceSupplier
          ? `Service location: ${order.delivery?.address || "TBC"}`
          : "Collection - buyer will pick up";
      const { filename } = await generatePDF({
        type: "order",
        number: orderRef,
        date: new Date(),
        billingTo: `Buyer: ${order.buyerPhone}\n${deliveryNote}`,
        items: order.items.map(i => ({
          item: i.product,
          qty: Number(i.quantity) || 1,
          unit: Number(i.pricePerUnit || 0),
          total: Number(i.total || 0)
        })),
        bizMeta: {
          name: supplier?.businessName || from,
          logoUrl: "",
          address: `${supplier?.location?.area || ""}, ${supplier?.location?.city || ""}`,
          _id: String(order._id),
          status: "accepted"
        }
      });
      const site = (process.env.SITE_URL || "").replace(/\/$/, "");
      await sendDocument(from, { link: `${site}/docs/generated/orders/${filename}`, filename });
    } catch (pdfErr) {
      console.error("[PRICE CONFIRM PDF]", pdfErr.message);
    }

    return sendList(from,
      `✅ *${isServiceSupplier ? "Booking" : "Order"} confirmed at $${grandTotal.toFixed(2)}.*\n\n${confirmDeliveryLine}\n\n${isServiceSupplier ? "When will you do the job?" : "When will the order be ready?"}`,
      [
        { id: `sup_eta_today_${orderId}`,    title: "Today" },
        { id: `sup_eta_tomorrow_${orderId}`, title: "Tomorrow" },
        { id: `sup_eta_twodays_${orderId}`,  title: "2-3 days" },
        { id: `sup_eta_contact_${orderId}`,  title: "I'll contact buyer" }
      ]
    );

  }

  // ── Supplier wants to re-enter prices ─────────────────────────────────────
  if (a === "sup_price_confirm_no") {
    const orderId = biz?.sessionData?.pricingOrderId;
    if (!orderId) return sendSuppliersMenu(from);

    const order = await SupplierOrder.findById(orderId).lean();
    if (!order) return sendSuppliersMenu(from);

    const isServiceSupplier = (await SupplierProfile.findOne({ phone: from }).lean())?.profileType === "service";

    // Reset to enter_price state, clear pending prices
const missingPriceIndexes = (order.items || [])
  .map((item, idx) => (
    typeof item.pricePerUnit === "number" && !Number.isNaN(item.pricePerUnit)
      ? null
      : idx
  ))
  .filter(idx => idx !== null);

biz.sessionState = "supplier_order_enter_price";
biz.sessionData = {
  ...(biz.sessionData || {}),
  pricingOrderId: orderId,
  pricingMissingIndexes: missingPriceIndexes
};
await saveBiz(biz);

  // ── Clear any stale buyer/picking session state for this phone.

  // ── Clear any stale buyer/picking session state for this phone.
  // This prevents the supplier's typed price input (e.g. "12") from being
  // misrouted to the cart picking handler due to stale UserSession data.
  const UserSession = (await import("../models/userSession.js")).default;
  await UserSession.findOneAndUpdate(
    { phone: from.replace(/\D+/g, "") },
    {
      $unset: {
        "tempData.orderState":      "",
        "tempData.orderSupplierId": "",
        "tempData.orderCart":       "",
        "tempData.orderIsService":  "",
        "tempData.orderItems":      ""
      }
    }
  );

  // Build a numbered pricing form -each line shows exactly what needs a price

    // Show the pricing form again
 const pricedItems = (order.items || []).filter(
  item => typeof item.pricePerUnit === "number" && !Number.isNaN(item.pricePerUnit)
);

const pricingTargets = (order.items || []).filter(
  item => !(typeof item.pricePerUnit === "number" && !Number.isNaN(item.pricePerUnit))
);

const pricingLines = pricingTargets.map((item, i) => {
  const qty = Number(item.quantity) || 1;
  const unitLabel = item.unit && item.unit !== "units"
    ? item.unit
    : (isServiceSupplier ? "job" : "unit");

  return `${i + 1}. *${item.product}* × ${qty} ${unitLabel}\n   → Your price per ${unitLabel}: ❓`;
}).join("\n\n");

const alreadyPricedLines = pricedItems.length
  ? pricedItems.map(item => {
      const qty = Number(item.quantity) || 1;
      const unitLabel = item.unit && item.unit !== "units"
        ? item.unit
        : (isServiceSupplier ? "job" : "unit");
      const lineTotal =
        typeof item.total === "number"
          ? item.total
          : qty * Number(item.pricePerUnit || 0);

      return `✅ ${item.product} × ${qty} ${unitLabel} @ $${Number(item.pricePerUnit).toFixed(2)} = $${Number(lineTotal).toFixed(2)}`;
    }).join("\n")
  : "";

const firstItem = pricingTargets[0];
const firstQty = Number(firstItem?.quantity) || 1;
const firstUnit = firstItem?.unit && firstItem.unit !== "units"
  ? firstItem.unit
  : (isServiceSupplier ? "job" : "unit");

let instructions;

if (pricingTargets.length === 1) {
  instructions =
    `💡 *Enter the price only for the missing item.*\n\n` +
    `Example: If *${firstItem?.product}* costs *$12* per ${firstUnit},\n` +
    `and the buyer wants *${firstQty}*, total = *$${12 * firstQty}*.\n\n` +
    `So just type: *12*`;
} else {
  const examplePrices = pricingTargets.map((_, i) => ((i + 1) * 5 + 7)).join(", ");
  const exampleLines = pricingTargets.map((item, i) => {
    const qty = Number(item.quantity) || 1;
    const unitPrice = (i + 1) * 5 + 7;
    const exUnit = item.unit && item.unit !== "units"
      ? item.unit
      : (isServiceSupplier ? "job" : "unit");
    return `  ${i + 1}. ${item.product}: $${unitPrice}/per ${exUnit} × ${qty} = $${unitPrice * qty}`;
  }).join("\n");

  instructions =
    `💡 *Enter price per unit only for the missing items, in order, separated by commas.*\n\n` +
    `Example: *${examplePrices}*\n` +
    `That means:\n${exampleLines}\n\n` +
    `_${pricingTargets.length} price${pricingTargets.length > 1 ? "s" : ""}, separated by commas_`;
}

const pricingDeliveryLine = order.delivery?.required
  ? `🚚 *Deliver to:* ${order.delivery.address}`
  : isServiceSupplier
    ? `📍 *Service location:* ${order.delivery?.address || "TBC"}`
    : `🏠 *Collection* (buyer will pick up)`;

return sendButtons(from, {
  text:
    `✏️ *Re-enter Your Prices*\n` +
    `_Buyer: ${order.buyerPhone}_\n\n` +
    `─────────────────\n` +
    (alreadyPricedLines
      ? `*Already priced:*\n${alreadyPricedLines}\n\n─────────────────\n`
      : "") +
    `*Still needs pricing:*\n\n` +
    `${pricingLines}\n\n` +
    `─────────────────\n` +
    `${pricingDeliveryLine}\n\n` +
    `─────────────────\n` +
    `${instructions}`,
  buttons: [{ id: "suppliers_home", title: "⬅ Cancel" }]
});
  }



// ── Registration: confirm saved price update (no-biz supplier flow) ────────
// ── Registration / supplier account: confirm saved price update ───────────
if (a === "sup_price_update_confirm" && (!biz || isGhostSupplierBiz)) {
  const sess = await UserSession.findOne({ phone });
  const regState = sess?.supplierRegState;
  const reg = sess?.supplierRegData || {};
  const accountState = sess?.tempData?.supplierAccountState;

  // 1) Registration flow confirm
  if (regState === "supplier_reg_prices") {
    const pending = reg.pendingPriceUpdate || [];

    if (!pending.length) {
      await sendText(from, "❌ No pending prices found. Please re-enter.");
      return true;
    }

    const isService = reg.profileType === "service";

    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "supplierRegData.prices": isService ? [] : pending,
          "supplierRegData.rates": isService
            ? pending.map(u => ({ service: u.product, rate: `${u.amount}/${u.unit}` }))
            : [],
          "supplierRegData.pendingPriceUpdate": [],
          supplierRegState: isService ? "supplier_reg_travel" : "supplier_reg_delivery"
        }
      },
      { upsert: true }
    );

    if (isService) {
      return sendButtons(from, {
        text: "✅ *Rates saved!*\n\n🚗 *Do you travel to clients?*",
        buttons: [
          { id: "sup_travel_yes", title: "✅ Yes I Travel" },
          { id: "sup_travel_no", title: "🏠 Client Comes to Me" }
        ]
      });
    }

    return sendButtons(from, {
      text: "✅ *Prices saved!*\n\n🚚 *Do you deliver?*",
      buttons: [
        { id: "sup_del_yes", title: "✅ Yes I Deliver" },
        { id: "sup_del_no", title: "🏠 Collection Only" }
      ]
    });
  }

  // 2) Supplier account price update confirm
  if (accountState === "supplier_update_prices") {
    const supplier = await SupplierProfile.findOne({ phone });
    if (!supplier) return sendSuppliersMenu(from);

    const pending = sess?.tempData?.pendingPriceUpdate || [];

    if (!pending.length) {
      await sendText(from, "❌ No pending prices found. Please re-enter.");
      return true;
    }

if (supplier.profileType === "service") {
  const existingRates = Array.isArray(supplier.rates) ? [...supplier.rates] : [];

  for (const u of pending) {
    const idx = existingRates.findIndex(r =>
      String(r?.service || "").toLowerCase() === String(u.product || "").toLowerCase()
    );

    const nextRate = {
      service: u.product,
      rate: `${u.amount}/${u.unit}`
    };

    if (idx >= 0) existingRates[idx] = nextRate;
    else existingRates.push(nextRate);
  }

  supplier.rates = existingRates;
  supplier.markModified("rates");
} else {
  const existingPrices = Array.isArray(supplier.prices) ? [...supplier.prices] : [];

  for (const u of pending) {
    const idx = existingPrices.findIndex(p =>
      String(p?.product || "").toLowerCase() === String(u.product || "").toLowerCase()
    );

    const nextPrice = {
      ...(idx >= 0 && existingPrices[idx]?._id ? { _id: existingPrices[idx]._id } : {}),
      product: u.product,
      amount: Number(u.amount),
      currency: "USD",
      unit: u.unit || "each",
      inStock: u.inStock !== false
    };

    if (idx >= 0) existingPrices[idx] = nextPrice;
    else existingPrices.push(nextPrice);
  }

  supplier.prices = existingPrices;
  supplier.markModified("prices");
}

supplier.priceUpdatedAt = new Date();
await supplier.save();

    await UserSession.findOneAndUpdate(
      { phone },
      {
        $unset: {
          "tempData.supplierAccountState": "",
          "tempData.pendingPriceUpdate": "",
          "tempData.supplierAccountType": ""
        }
      }
    );

    if (biz && isGhostSupplierBiz) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
    }

    await sendText(
      from,
      `✅ Your ${supplier.profileType === "service" ? "rates" : "prices"} were updated.`
    );
    return sendSupplierAccountMenu(from, supplier);
  }
}

// ── Confirm saved price update from account menu ──────────────────────────
if (a === "sup_price_update_confirm") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);

  const pending = biz?.sessionData?.pendingPriceUpdate;
  if (!pending?.length) {
    await sendText(from, "❌ No pending prices found. Please re-enter.");
    return sendSupplierAccountMenu(from, supplier);
  }

  const existing = supplier.prices || [];
  for (const u of pending) {
    const idx = existing.findIndex(p =>
      p.product?.toLowerCase() === u.product
    );
    if (idx >= 0) existing[idx] = u;
    else existing.push(u);
  }

  supplier.prices = existing;
  supplier.priceUpdatedAt = new Date();
  supplier.markModified("prices");
  await supplier.save();

  if (biz) {
    biz.sessionState = "ready";
    biz.sessionData = {};
    await saveBizSafe(biz);
  }

  const summary = pending.map(u => `✅ ${u.product} - $${Number(u.amount).toFixed(2)}/${u.unit}`).join("\n");
  await sendText(from, `✅ *Prices saved!*\n\n${summary}`);
  return sendSupplierAccountMenu(from, supplier);
}

  // ── Handle edit products text input ───────────────────────────────────────
  if (biz?.sessionState === "supplier_edit_products" && !isMetaAction) {
    const supplier = await SupplierProfile.findOne({ phone });
    if (!supplier) return sendSuppliersMenu(from);
    const products = text.split(",").map(p => p.trim().toLowerCase()).filter(Boolean);
    if (!products.length) {
      await sendText(from, "❌ Please list at least one product, comma-separated.");
      return;
    }
    supplier.products = products;
    await supplier.save();
    if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
    await sendText(from, `✅ Products updated!\n\n${products.map(p => `• ${p}`).join("\n")}`);
    return sendSupplierAccountMenu(from, supplier);
  }

  // ── Handle edit area text input ────────────────────────────────────────────
  if (biz?.sessionState === "supplier_edit_area" && !isMetaAction) {
    const supplier = await SupplierProfile.findOne({ phone });
    if (!supplier) return sendSuppliersMenu(from);
    const parts = text.split(",").map(p => p.trim());
    supplier.location = {
      area: parts[0] || supplier.location?.area,
      city: parts[1] || supplier.location?.city || "Harare"
    };
    await supplier.save();
    if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
    await sendText(from, `✅ Location updated to: ${supplier.location.area}, ${supplier.location.city}`);
    return sendSupplierAccountMenu(from, supplier);
  }


  // ── Buyer types item name while browsing catalogue (supplier_order_picking) ──
// Handles both biz session and no-biz UserSession
// ── Buyer types while browsing catalogue (supplier_order_picking) ──────────
const pickingStateBiz = biz?.sessionState === "supplier_order_picking";

// ── IMPORTANT: Never let stale UserSession picking state interfere when
// the supplier's biz session is in price-entry or confirm-price mode.
// This prevents "12" being treated as a product name instead of a price.
const supplierIsPricingOrder =
  biz?.sessionState === "supplier_order_enter_price" ||
  biz?.sessionState === "supplier_order_confirm_price";

const pickingStateSess = await (async () => {
  if (pickingStateBiz) return null;
  if (supplierIsPricingOrder) return null; // ← KEY FIX: biz pricing takes priority
  const s = await UserSession.findOne({ phone });
  return s?.tempData?.orderState === "supplier_order_picking" ? s : null;
})();

if (
  !isMetaAction &&
  (
    (biz && biz.sessionState === "supplier_order_picking") ||
    (!biz && pickingStateSess?.tempData?.orderState === "supplier_order_picking")
  )
) {


  const raw = text.trim();
  if (!raw || raw.length < 1) return;

  const rawLower = raw.toLowerCase();

  // ── CANCEL ──────────────────────────────────────────────────────────────
  if (rawLower === "cancel") {
    if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
    await UserSession.findOneAndUpdate({ phone }, {
      $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderCart": "", "tempData.orderIsService": "" }
    });
    await sendText(from, "❌ Order cancelled.");
    return sendButtons(from, {
      text: "What would you like to do next?",
      buttons: [
        { id: "find_supplier", title: "🔍 Browse & Shop" },
        { id: "my_orders",     title: "📋 My Orders" }
      ]
    });
  }

const supplierId = biz?.sessionData?.orderSupplierId
    || pickingStateSess?.tempData?.orderSupplierId;
  if (!supplierId) return;

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return;

  const isService = supplier.profileType === "service";

  let cart = [...(biz?.sessionData?.orderCart
    || pickingStateSess?.tempData?.orderCart
    || [])];

  // ── Rebuild source items for numbered selection (Option C) ────────────────
const currentSearchTerm =
  biz?.sessionData?.orderCatalogueSearch ??
  pickingStateSess?.tempData?.orderCatalogueSearch ??
  "";

const sourceItems = getFilteredSupplierCatalogueItems(supplier, currentSearchTerm).map(item => ({
  id: item.name,
  label: item.name,
  price: item.priceLabel || null
}));

  // ── NUMBERED ITEM SELECTION: "1x5, 3x2" or "1x5" or "1 x 5" ─────────────
  // Matches patterns like: 1x5  1x5,3x2  1x5, 3x2  1 x 5  1:5
const numberedSelectionPattern = /^\d+\s*[x:]\s*\d/i;
if (numberedSelectionPattern.test(rawLower.trim())) {
  const pairs = raw.match(/(\d+)\s*[xX:]\s*(\d+(?:\.\d+)?)/g);

  if (pairs && pairs.length) {
    const errors = [];

    for (const pair of pairs) {
      const m = pair.match(/(\d+)\s*[xX:]\s*(\d+(?:\.\d+)?)/);
      if (!m) continue;

      const itemNum = parseInt(m[1]);
      const qty = parseFloat(m[2]);

      if (itemNum < 1 || itemNum > sourceItems.length) {
        errors.push(`❌ No item #${itemNum} -list has ${sourceItems.length} items`);
        continue;
      }

   const selectedItem = sourceItems[itemNum - 1];
const match = findMatchingSupplierPrice(supplier, selectedItem.id);

const cartProduct = match?.product || selectedItem.id;
const cartUnit = match?.unit || (isService ? "job" : "each");
const cartPrice = typeof match?.amount === "number" ? match.amount : null;

const existing = cart.find(c => c.product.toLowerCase() === cartProduct.toLowerCase());

if (existing) {
  existing.quantity += qty;
  if (existing.pricePerUnit !== null && existing.pricePerUnit !== undefined) {
    existing.total = existing.quantity * existing.pricePerUnit;
  }
} else {
  cart.push({
    product: cartProduct,
    quantity: qty,
    unit: cartUnit,
    pricePerUnit: cartPrice,
    total: cartPrice !== null ? qty * cartPrice : null
  });
}
    }

    if (errors.length) {
      await sendText(from, errors.join("\n") + `\n\nList has ${sourceItems.length} items. Check the product list above.`);
    }

    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
      await saveBizSafe(biz);
    }

    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.orderCart": cart } },
      { upsert: true }
    );

    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderBrowseMode: "cart",
        orderSupplierId: String(supplier._id),
        orderCart: cart
      }
    });

    return _sendSupplierCartMenu(from, supplier, cart);
  }
}


  // ── CONFIRM shortcut ─────────────────────────────────────────────────────
if (rawLower === "confirm" || rawLower === "done" || rawLower === "send") {
    if (!cart.length) {
      return sendText(from, "❌ Your cart is empty. Tap items or type to add them first.");
    }
    // For collection-only product suppliers, route straight to sup_cart_confirm_
    // which will skip the address step automatically
  // Only ask for address if: product supplier with delivery, OR service supplier who travels to clients
const needsAddress = (isService && supplier.travelAvailable) || (!isService && supplier.delivery?.available);
    if (!needsAddress) {
      // Redirect to the confirm handler which handles collection-only path
      return handleIncomingMessage({ from, action: `sup_cart_confirm_${supplierId}` });
    }
    if (biz) {
      biz.sessionState = "supplier_order_address";
      await saveBizSafe(biz);
    }
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.orderState": "supplier_order_address" } },
      { upsert: true }
    );
    const previewLines = cart.map(c => {
      const priceStr = c.pricePerUnit ? ` -$${(c.quantity * c.pricePerUnit).toFixed(2)}` : "";
      return `• ${c.product} ×${c.quantity}${priceStr}`;
    }).join("\n");
    const knownTotal = cart.filter(c=>c.pricePerUnit).reduce((s,c)=>s+(c.quantity*c.pricePerUnit),0);
    const totalLine = knownTotal > 0 ? `\n💵 *Estimated total: $${knownTotal.toFixed(2)}*` : "";
    return sendButtons(from, {
      text:
`${isService ? "📅" : "🛒"} *${isService ? "Booking" : "Order"} Summary*

${previewLines}${totalLine}

─────────────────
⚠️ *Your order has NOT been sent yet.*
─────────────────

*Step 2 of 2 -Enter your ${isService ? "location" : "delivery address"}* 👇

${isService
  ? `📍 *Add a contact note for the provider:*\n\nExamples:\n• _Call me on arrival_\n• _Preferred time: Mon 10am_\n• _+263 7XX XXX XXX_`
  : `📍 *Where should we deliver?*\n\nExamples:\n• _123 Samora Machel Ave, Harare_\n• _I will collect - call me_`}
_Type your address below and send_ ✍️`,
   buttons: [
        ...(isService ? [{ id: `sup_skip_note_${supplierId}`, title: "⏭ Skip & Send" }] : []),
        { id: `sup_cart_clear_${supplierId}`, title: "✏️ Edit Order" },
        { id: "find_supplier", title: "❌ Cancel" }
      ].slice(0, 3)
    });
  }

  // ── CLEAR cart ───────────────────────────────────────────────────────────
 // ── CLEAR cart ───────────────────────────────────────────────────────────
if (rawLower === "clear") {
  cart = [];

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: [] };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": [] } },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "cart",
      orderSupplierId: String(supplier._id),
      orderCart: []
    }
  });

  await sendText(from, "🗑 Cart cleared.");
  return _sendSupplierCartMenu(from, supplier, []);
}

  // ── REMOVE by position: r2, r 2, remove 2 ────────────────────────────────
 // ── REMOVE by position: r2, r 2, remove 2 ────────────────────────────────
const removeByPos = rawLower.match(/^(?:remove|r)\s*(\d+)$/);
if (removeByPos) {
  const idx = parseInt(removeByPos[1]) - 1;

  if (idx >= 0 && idx < cart.length) {
    const removed = cart.splice(idx, 1)[0];

    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
      await saveBizSafe(biz);
    }

    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.orderCart": cart } },
      { upsert: true }
    );

    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderBrowseMode: "cart",
        orderSupplierId: String(supplier._id),
        orderCart: cart
      }
    });

    await sendText(from, `✅ Removed *${removed.product}* from cart.`);
    return _sendSupplierCartMenu(from, supplier, cart);
  } else {
    return sendText(from, `❌ No item #${idx + 1} in cart. You have ${cart.length} item${cart.length !== 1 ? "s" : ""}.`);
  }
}
  // ── REMOVE by name: "remove cement" ──────────────────────────────────────
 // ── REMOVE by name: "remove cement" ──────────────────────────────────────
const removeByName = rawLower.match(/^remove\s+(.+)$/);
if (removeByName) {
  const nameToRemove = removeByName[1].trim();
  const idx = cart.findIndex(c => c.product.toLowerCase().includes(nameToRemove));

  if (idx >= 0) {
    const removed = cart.splice(idx, 1)[0];

    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
      await saveBizSafe(biz);
    }

    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.orderCart": cart } },
      { upsert: true }
    );

    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderBrowseMode: "cart",
        orderSupplierId: String(supplier._id),
        orderCart: cart
      }
    });

    await sendText(from, `✅ Removed *${removed.product}* from cart.`);
    return _sendSupplierCartMenu(from, supplier, cart);
  } else {
    return sendText(from, `❌ *${nameToRemove}* not found in cart.`);
  }
}
  // ── HELP command ─────────────────────────────────────────────────────────
  if (rawLower === "help" || rawLower === "?") {
    return sendText(from,
`📋 *Ordering Help -${supplier.businessName}*

*➕ Add items:*
Type: _cement 10_ or _cement 10 bags_
Multiple: _cement 10, sand 2, bricks 500_

*➕ Increase qty:*
Type the item name alone: _cement_ adds 1 more
Or: _cement 5_ adds 5 more

*🗑 Remove items:*
_remove cement_ -remove by name
_r2_ or _remove 2_ -remove item #2

*🗑 Clear cart:*
_clear_ -empty entire cart

*✅ Confirm order:*
_confirm_ -go to delivery step
Or tap ✅ Confirm in the list below

*❌ Cancel:*
_cancel_ -cancel this order`);
  }

  // ── PARSE as order input: "cement 10", "cement 10 bags", "cement 10, sand 2" ──
 const parsedBulk = parseBulkOrderInput(raw);

if (parsedBulk.length && parsedBulk.some(i => i.valid)) {
  const validEntries = parsedBulk.filter(i => i.valid);
  const matchedEntries = [];
  const unmatchedEntries = [];

  for (const entry of validEntries) {
    const match = findMatchingSupplierPrice(supplier, entry.product);
    if (!match) {
      unmatchedEntries.push(entry.product);
      continue;
    }
    matchedEntries.push({ entry, match });
  }

  if (!matchedEntries.length) {
    return sendText(
      from,
      `❌ None of those items were found in *${supplier.businessName}*.\n\n` +
      `Please search the catalogue, use *Quick Order by Number*, or type an exact product name from this supplier.`
    );
  }

  for (const { entry, match } of matchedEntries) {
    const cartProduct = match.product;
    const existing = cart.find(c => c.product.toLowerCase() === cartProduct.toLowerCase());

    if (existing) {
      existing.quantity += entry.quantity;
      if (existing.pricePerUnit) existing.total = existing.quantity * existing.pricePerUnit;
    } else {
      cart.push({
        product: cartProduct,
        quantity: entry.quantity,
        unit: match.unit || entry.unitLabel || (isService ? "job" : "units"),
        pricePerUnit: match.amount || null,
        total: match.amount ? entry.quantity * match.amount : null
      });
    }
  }

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": cart } },
    { upsert: true }
  );

  if (unmatchedEntries.length) {
    await sendText(
      from,
      `⚠️ Some items were not found and were skipped: _${unmatchedEntries.slice(0, 5).join(", ")}_${unmatchedEntries.length > 5 ? "..." : ""}`
    );
  }

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "cart",
      orderSupplierId: String(supplier._id),
      orderCart: cart
    }
  });

  return _sendSupplierCartMenu(from, supplier, cart);
}
  // ── SINGLE WORD -treat as item name, add qty 1 (or increase existing) ───
  // e.g. buyer types "cement" → adds 1 cement or increments qty
  const singleItemName = raw.trim();

if (singleItemName.length >= 2) {
  const match = findMatchingSupplierPrice(supplier, singleItemName);

  if (!match) {
    return sendText(
      from,
      `❌ *${singleItemName}* was not found in *${supplier.businessName}*.\n\n` +
      `Use *Browse Catalogue*, *Quick Order by Number*, or type an exact product name from this supplier.`
    );
  }

  const cartProduct = match.product;
  const existing = cart.find(c => c.product.toLowerCase() === cartProduct.toLowerCase());

  if (existing) {
    existing.quantity += 1;
    if (existing.pricePerUnit) existing.total = existing.quantity * existing.pricePerUnit;
  } else {
    cart.push({
      product: cartProduct,
      quantity: 1,
      unit: match.unit || (isService ? "job" : "units"),
      pricePerUnit: match.amount || null,
      total: match.amount || null
    });
  }

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": cart } },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "cart",
      orderSupplierId: String(supplier._id),
      orderCart: cart
    }
  });

  return _sendSupplierCartMenu(from, supplier, cart);
}
}



if (a === "sup_back_to_search_results") {
  let allResults = [];
  let currentPage = 0;

  if (biz) {
    allResults = biz.sessionData?.searchResults || [];
    currentPage = biz.sessionData?.searchPage || 0;
  } else {
    const sess = await UserSession.findOne({ phone });
    allResults = sess?.tempData?.searchResults || [];
    currentPage = sess?.tempData?.searchPage || 0;
  }

  if (!allResults.length) {
    return sendButtons(from, {
      text: "❌ Search session expired. Please search again.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  const PAGE_SIZE = 9;
  const start = currentPage * PAGE_SIZE;
  const pageResults = allResults.slice(start, start + PAGE_SIZE);
  const rows = formatSupplierResults(pageResults, null, null);
  const hasMore = allResults.length > start + PAGE_SIZE;
  const hasPrev = currentPage > 0;

  if (hasPrev) {
    rows.push({ id: "sup_search_prev_page", title: "⬅ Back" });
  }
  if (hasMore) {
    rows.push({ id: "sup_search_next_page", title: "➡ More results" });
  }

  if (rows.length > 10) rows.splice(10);

  const showing = `${start + 1}–${Math.min(start + PAGE_SIZE, allResults.length)}`;
  return sendList(
    from,
    `🔍 Results ${showing} of ${allResults.length}\n_Tap a supplier to continue shopping_`,
    rows
  );
}

// ── Paginate search results: next page ───────────────────────────────────
if (a === "sup_search_next_page") {
  let allResults = [];
  let currentPage = 0;

  if (biz) {
    allResults = biz.sessionData?.searchResults || [];
    currentPage = (biz.sessionData?.searchPage || 0) + 1;
    biz.sessionData = { ...(biz.sessionData || {}), searchPage: currentPage };
    await saveBizSafe(biz);
  } else {
    const sess = await UserSession.findOne({ phone });
    allResults = sess?.tempData?.searchResults || [];
    currentPage = (sess?.tempData?.searchPage || 0) + 1;
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.searchPage": currentPage } },
      { upsert: true }
    );
  }

  if (!allResults.length) {
    return sendButtons(from, {
      text: "❌ Search session expired. Please search again.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  const PAGE_SIZE = 9;
  const start = currentPage * PAGE_SIZE;
  const pageResults = allResults.slice(start, start + PAGE_SIZE);

  if (!pageResults.length) {
    return sendButtons(from, {
      text: "❌ No more results on this page.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  let resultMode = "suppliers";
  if (biz) {
    resultMode = biz.sessionData?.searchResultMode || "suppliers";
  } else {
    const sess = await UserSession.findOne({ phone });
    resultMode = sess?.tempData?.searchResultMode || "suppliers";
  }

  const rows = resultMode === "offers"
    ? formatSupplierOfferResults(pageResults)
    : formatSupplierResults(pageResults, null, null);
  const hasMore = allResults.length > start + PAGE_SIZE;
  const hasPrev = currentPage > 0;

  // Nav rows -always last, within the 10 row budget
  // rows is max 9 items so we have room for nav
  if (hasPrev) {
    rows.push({ id: "sup_search_prev_page", title: `⬅ Back (prev ${PAGE_SIZE})` });
  }
  if (hasMore) {
    rows.push({ id: "sup_search_next_page", title: `➡ More (${allResults.length - start - PAGE_SIZE} more)` });
  }

  if (rows.length > 10) rows.splice(10);

  const showing = `${start + 1}–${Math.min(start + PAGE_SIZE, allResults.length)}`;
  return sendList(
    from,
    `🔍 Results ${showing} of ${allResults.length}\n_Tap a supplier to view details_`,
    rows
  );
}

// ── Paginate search results: previous page ────────────────────────────────
if (a === "sup_search_prev_page") {
  let allResults = [];
  let currentPage = 0;

  if (biz) {
    allResults = biz.sessionData?.searchResults || [];
    currentPage = Math.max(0, (biz.sessionData?.searchPage || 1) - 1);
    biz.sessionData = { ...(biz.sessionData || {}), searchPage: currentPage };
    await saveBizSafe(biz);
  } else {
    const sess = await UserSession.findOne({ phone });
    allResults = sess?.tempData?.searchResults || [];
    currentPage = Math.max(0, (sess?.tempData?.searchPage || 1) - 1);
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.searchPage": currentPage } },
      { upsert: true }
    );
  }

  if (!allResults.length) {
    return sendButtons(from, {
      text: "❌ Search session expired. Please search again.",
      buttons: [{ id: "find_supplier", title: "🔍 Search Again" }]
    });
  }

  const PAGE_SIZE = 9;
  const start = currentPage * PAGE_SIZE;
  const pageResults = allResults.slice(start, start + PAGE_SIZE);
  let resultMode = "suppliers";
  if (biz) {
    resultMode = biz.sessionData?.searchResultMode || "suppliers";
  } else {
    const sess = await UserSession.findOne({ phone });
    resultMode = sess?.tempData?.searchResultMode || "suppliers";
  }

 const rows = resultMode === "offers"
  ? formatSupplierOfferResults(pageResults, biz?.sessionData?.supplierSearch?.product || "")
    : formatSupplierResults(pageResults, null, null);
  const hasMore = allResults.length > start + PAGE_SIZE;
  const hasPrev = currentPage > 0;

  if (hasPrev) {
    rows.push({ id: "sup_search_prev_page", title: `⬅ Back` });
  }
  if (hasMore) {
    rows.push({ id: "sup_search_next_page", title: `➡ More results` });
  }

  if (rows.length > 10) rows.splice(10);

  const showing = `${start + 1}–${Math.min(start + PAGE_SIZE, allResults.length)}`;
  return sendList(
    from,
    `🔍 Results ${showing} of ${allResults.length}\n_Tap a supplier to view details_`,
    rows
  );
}

// ── Start order: show supplier's product/service list as selectable menu ──
if (a.startsWith("sup_order_")) {
  const supplierId = a.replace("sup_order_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const isService = supplier.profileType === "service";

  const sess = await UserSession.findOne({ phone });
  const searchedProduct =
    sess?.tempData?.supplierSearchProduct ||
    biz?.sessionData?.supplierSearch?.product ||
    "";

  const initialCart = [];

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.orderSupplierId": supplierId,
        "tempData.orderState": "supplier_order_picking",
        "tempData.orderCart": initialCart,
        "tempData.orderIsService": isService
      }
    },
    { upsert: true }
  );

  if (biz) {
    biz.sessionData = {
      ...(biz.sessionData || {}),
      orderSupplierId: supplierId,
      orderCart: initialCart,
      orderIsService: isService
    };
    biz.sessionState = "supplier_order_picking";
    await saveBizSafe(biz);
  }

// For service suppliers, only pre-filter by search term if the supplier
  // actually has a service whose name contains that term.
  // Otherwise open full catalogue - the search found them via synonym/category match,
  // not a literal service name match.
  let effectiveSearch = searchedProduct;
  if (isService && searchedProduct) {
    const { getFilteredSupplierCatalogueItems: _gf } = { getFilteredSupplierCatalogueItems };
    const matched = getFilteredSupplierCatalogueItems(supplier, searchedProduct);
    if (!matched.length) effectiveSearch = "";
  }

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderCart: initialCart,
      orderIsService: isService,
      orderBrowseMode: effectiveSearch ? "search_pick" : "catalogue",
      orderCataloguePage: 0,
      orderCatalogueSearch: effectiveSearch,
      selectedSupplierItem: null
    }
  });

  return _sendSupplierCatalogueBrowser(from, supplier, initialCart, {
    page: 0,
    searchTerm: effectiveSearch,
    selectionMode: effectiveSearch ? "search_pick" : "catalogue"
  });
}


if (a.startsWith("sup_number_page_open_")) {
  const supplierId = a.replace("sup_number_page_open_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const cart = await getCurrentOrderCart({ biz, phone });

  if (biz) {
    biz.sessionState = "supplier_order_picking";
    biz.sessionData = {
      ...(biz.sessionData || {}),
      orderSupplierId: supplierId
    };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.orderState": "supplier_order_picking",
        "tempData.orderSupplierId": supplierId
      }
    },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "numbered_catalogue",
      orderSupplierId: supplierId,
      orderCataloguePage: 0,
      orderCatalogueSearch: ""
    }
  });

  return _sendSupplierNumberedCatalogueText(from, supplier, cart, {
    page: 0,
    searchTerm: ""
  });
}
if (a.startsWith("sup_number_page_next_") || a.startsWith("sup_number_page_prev_")) {
  const isNext = a.startsWith("sup_number_page_next_");
  const supplierId = a.replace(isNext ? "sup_number_page_next_" : "sup_number_page_prev_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const currentPage =
    Number(
      biz?.sessionData?.orderCataloguePage ??
      sess?.tempData?.orderCataloguePage ??
      0
    ) || 0;

  const searchTerm =
    biz?.sessionData?.orderCatalogueSearch ??
    sess?.tempData?.orderCatalogueSearch ??
    "";

  const nextPage = Math.max(0, currentPage + (isNext ? 1 : -1));
  const cart = await getCurrentOrderCart({ biz, phone });

  if (biz) {
    biz.sessionState = "supplier_order_picking";
    biz.sessionData = {
      ...(biz.sessionData || {}),
      orderSupplierId: supplierId
    };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.orderState": "supplier_order_picking",
        "tempData.orderSupplierId": supplierId
      }
    },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "numbered_catalogue",
      orderSupplierId: supplierId,
      orderCataloguePage: nextPage
    }
  });

  return _sendSupplierNumberedCatalogueText(from, supplier, cart, {
    page: nextPage,
    searchTerm
  });
}


if (a.startsWith("sup_number_full_")) {
  const supplierId = a.replace("sup_number_full_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "numbered_catalogue",
      orderSupplierId: supplierId,
      orderCataloguePage: 0,
      orderCatalogueSearch: ""
    }
  });

  return _sendSupplierNumberedCatalogueText(from, supplier, cart, {
    page: 0,
    searchTerm: ""
  });
}

if (a.startsWith("sup_catalog_page_open_")) {
  const supplierId = a.replace("sup_catalog_page_open_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "catalogue",
      orderSupplierId: supplierId,
      orderCataloguePage: 0,
      orderCatalogueSearch: ""
    }
  });

  return _sendSupplierCatalogueBrowser(from, supplier, cart, {
    page: 0,
    searchTerm: ""
  });
}

if (a.startsWith("sup_catalog_page_next_") || a.startsWith("sup_catalog_page_prev_")) {
  const isNext = a.startsWith("sup_catalog_page_next_");
  const supplierId = a.replace(isNext ? "sup_catalog_page_next_" : "sup_catalog_page_prev_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const currentPage =
    Number(
      biz?.sessionData?.orderCataloguePage ??
      sess?.tempData?.orderCataloguePage ??
      0
    ) || 0;

  const searchTerm =
    biz?.sessionData?.orderCatalogueSearch ??
    sess?.tempData?.orderCatalogueSearch ??
    "";

  const nextPage = Math.max(0, currentPage + (isNext ? 1 : -1));
  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "catalogue",
      orderSupplierId: supplierId,
      orderCataloguePage: nextPage
    }
  });

  return _sendSupplierCatalogueBrowser(from, supplier, cart, {
    page: nextPage,
    searchTerm
  });
}


if (a.startsWith("sup_cart_view_")) {
  const supplierId = a.replace("sup_cart_view_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "cart",
      orderSupplierId: supplierId
    }
  });

  return _sendSupplierCartMenu(from, supplier, cart);
}


if (a.startsWith("sup_catalogue_search_")) {
  const supplierId = a.replace("sup_catalogue_search_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "catalogue_search",
      orderSupplierId: supplierId
    }
  });

  return sendButtons(from, {
    text:
      `🔎 *Search ${supplier.businessName} catalogue*\n\n` +
      `Type part of the ${supplier.profileType === "service" ? "service" : "product"} name.\n\n` +
      `Examples:\n` +
      `${supplier.profileType === "service"
        ? "• blocked drain\n• toilet installation"
        : "• ball valve\n• tee 25mm\n• solvent cement"}`,
    buttons: [{ id: "sup_catalogue_search_cancel", title: "⬅ Cancel" }]
  });
}

if (a === "sup_catalogue_search_cancel") {
  const sess = await UserSession.findOne({ phone });
  const supplierId =
    biz?.sessionData?.orderSupplierId ??
    sess?.tempData?.orderSupplierId;

  if (!supplierId) return sendSuppliersMenu(from);

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendSuppliersMenu(from);

  const cart = await getCurrentOrderCart({ biz, phone });

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "catalogue",
      orderCataloguePage: 0,
      orderCatalogueSearch: ""
    }
  });

  return _sendSupplierCatalogueBrowser(from, supplier, cart, {
    page: 0,
    searchTerm: ""
  });
}

// ── Cart: buyer taps an item from catalogue ───────────────────────────────
if (a.startsWith("sup_cart_add_")) {
  const withoutPrefix = a.replace("sup_cart_add_", "");
  const firstUnderscore = withoutPrefix.indexOf("_");
  const supplierId = withoutPrefix.slice(0, firstUnderscore);
  const encodedProduct = withoutPrefix.slice(firstUnderscore + 1);
  const productName = decodeURIComponent(encodedProduct);

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const cart = biz?.sessionData?.orderCart || sess?.tempData?.orderCart || [];

  const currentBrowseMode =
    biz?.sessionData?.orderBrowseMode ??
    sess?.tempData?.orderBrowseMode ??
    "catalogue";

  const currentSearchTerm =
    biz?.sessionData?.orderCatalogueSearch ??
    sess?.tempData?.orderCatalogueSearch ??
    "";

   const isService = supplier.profileType === "service";
  const matched = findMatchingSupplierPrice(supplier, productName);

  const priceInfo = matched
    ? {
        amount: matched.amount,
        unit: matched.unit
      }
    : null;

  const selectedItem = {
    product: productName,
    quantity: 1,
    unit: priceInfo?.unit || (isService ? "job" : "each"),
    pricePerUnit: typeof priceInfo?.amount === "number" ? priceInfo.amount : null,
    total: typeof priceInfo?.amount === "number" ? Number(priceInfo.amount.toFixed(2)) : null
  };

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: isService,
      orderBrowseMode: currentBrowseMode === "numbered_catalogue" ? "numbered_catalogue" : "selected_offer",
      orderCatalogueSearch: currentSearchTerm,
      selectedSupplierItem: selectedItem
    }
  });

// For services, quantity is always 1 - skip the qty picker entirely
  if (isService) {
    selectedItem.quantity = 1;
    selectedItem.total =
      typeof selectedItem.pricePerUnit === "number" && !Number.isNaN(selectedItem.pricePerUnit)
        ? Number((1 * selectedItem.pricePerUnit).toFixed(2))
        : null;

    await persistOrderFlowState({
      biz,
      phone,
      patch: {
        orderSupplierId: String(supplier._id),
        orderIsService: true,
        orderBrowseMode: "selected_offer",
        orderCatalogueSearch: currentSearchTerm,
        selectedSupplierItem: selectedItem
      }
    });

    return _sendSelectedSupplierItemPreview(from, supplier, selectedItem, cart, {
      quantity: 1,
      searchTerm: currentSearchTerm
    });
  }

  return _sendSupplierQuantityPicker(from, supplier, selectedItem, cart, {
    backId: currentSearchTerm && currentBrowseMode !== "numbered_catalogue"
      ? "sup_offer_results_back"
      : `sup_catalog_page_open_${supplier._id}`
  });
}


if (a.startsWith("sup_qty_pick_")) {
  const raw = a.replace("sup_qty_pick_", "");
  const parts = raw.split("_");
  const qty = Number(parts.pop() || 1);
  const supplierId = parts.shift();
  const productName = decodeURIComponent(parts.join("_"));

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const cart = biz?.sessionData?.orderCart || sess?.tempData?.orderCart || [];
  const currentSearchTerm =
    biz?.sessionData?.orderCatalogueSearch ??
    sess?.tempData?.orderCatalogueSearch ??
    "";

  const storedSelected =
    biz?.sessionData?.selectedSupplierItem ||
    sess?.tempData?.selectedSupplierItem;

  let selectedItem = storedSelected?.product === productName
    ? { ...storedSelected }
    : {
        product: productName,
        quantity: qty,
        unit: supplier.profileType === "service" ? "job" : "each",
        pricePerUnit: null,
        total: null
      };

  selectedItem.quantity = qty;
  selectedItem.total =
    typeof selectedItem.pricePerUnit === "number" && !Number.isNaN(selectedItem.pricePerUnit)
      ? Number((qty * selectedItem.pricePerUnit).toFixed(2))
      : null;

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: supplier.profileType === "service",
      orderBrowseMode: "selected_offer",
      selectedSupplierItem: selectedItem
    }
  });

  return _sendSelectedSupplierItemPreview(from, supplier, selectedItem, cart, {
    quantity: qty,
    searchTerm: currentSearchTerm
  });
}


if (a.startsWith("sup_item_preview_add_")) {
  const raw = a.replace("sup_item_preview_add_", "");
  const firstUnderscore = raw.indexOf("_");
  const supplierId = raw.slice(0, firstUnderscore);
  const productName = decodeURIComponent(raw.slice(firstUnderscore + 1));

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  let cart = biz?.sessionData?.orderCart || sess?.tempData?.orderCart || [];

  const storedSelected =
    biz?.sessionData?.selectedSupplierItem ||
    sess?.tempData?.selectedSupplierItem;

  const itemToAdd = storedSelected?.product === productName
    ? {
        ...storedSelected,
        quantity: Number(storedSelected.quantity || 1),
        total:
          typeof storedSelected.pricePerUnit === "number" && !Number.isNaN(storedSelected.pricePerUnit)
            ? Number((Number(storedSelected.quantity || 1) * storedSelected.pricePerUnit).toFixed(2))
            : null
      }
    : {
        product: productName,
        quantity: 1,
        unit: supplier.profileType === "service" ? "job" : "each",
        pricePerUnit: null,
        total: null
      };

  cart = upsertCartItemToFront(cart, itemToAdd);

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": cart } },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: supplier.profileType === "service",
      orderBrowseMode: "cart",
      orderCart: cart,
      selectedSupplierItem: itemToAdd
    }
  });

  return _sendSupplierCartMenu(from, supplier, cart);
}




if (a.startsWith("sup_item_preview_order_")) {
  const raw = a.replace("sup_item_preview_order_", "");
  const firstUnderscore = raw.indexOf("_");
  const supplierId = raw.slice(0, firstUnderscore);
  const productName = decodeURIComponent(raw.slice(firstUnderscore + 1));

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  let cart = biz?.sessionData?.orderCart || sess?.tempData?.orderCart || [];

  const storedSelected =
    biz?.sessionData?.selectedSupplierItem ||
    sess?.tempData?.selectedSupplierItem;

  const itemToAdd = storedSelected?.product === productName
    ? {
        ...storedSelected,
        quantity: Number(storedSelected.quantity || 1),
        total:
          typeof storedSelected.pricePerUnit === "number" && !Number.isNaN(storedSelected.pricePerUnit)
            ? Number((Number(storedSelected.quantity || 1) * storedSelected.pricePerUnit).toFixed(2))
            : null
      }
    : {
        product: productName,
        quantity: 1,
        unit: supplier.profileType === "service" ? "job" : "each",
        pricePerUnit: null,
        total: null
      };

  cart = upsertCartItemToFront(cart, itemToAdd);

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
    await saveBizSafe(biz);
  }

  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": cart } },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderSupplierId: String(supplier._id),
      orderIsService: supplier.profileType === "service",
      orderBrowseMode: "cart",
      orderCart: cart,
      selectedSupplierItem: itemToAdd
    }
  });

  return handleIncomingMessage({ from, action: `sup_cart_confirm_${supplierId}` });
}


// ── Cart: buyer confirms order from catalogue ─────────────────────────────
if (a.startsWith("sup_cart_confirm_")) {
  const supplierId = a.replace("sup_cart_confirm_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  let cart = [];
  if (biz) {
    cart = biz.sessionData?.orderCart || [];
  } else {
    const sess = await UserSession.findOne({ phone });
    cart = sess?.tempData?.orderCart || [];
  }

  if (!cart.length) {
    return sendText(from, "❌ Your cart is empty. Tap items to add them.");
  }

  // Show order summary and ask for address
  const isService = supplier.profileType === "service";
  const sess = await UserSession.findOne({ phone });
  const selectedSupplierItem =
    biz?.sessionData?.selectedSupplierItem ||
    sess?.tempData?.selectedSupplierItem ||
    null;

  const previewLines = cart.map(c => {
    const priceStr = c.pricePerUnit ? ` - $${Number(c.pricePerUnit).toFixed(2)}/${c.unit}` : "";
    return `• ${c.product} x${c.quantity}${priceStr}`;
  }).join("\n");

  const selectedTopLine = selectedSupplierItem?.product
    ? `🎯 *Selected Item:* ${selectedSupplierItem.product}\n\n`
    : "";

  const knownTotal = cart
    .filter(c => c.pricePerUnit)
    .reduce((sum, c) => sum + (c.quantity * c.pricePerUnit), 0);

  const totalLine = knownTotal > 0
    ? `\n💵 *Estimated total: $${knownTotal.toFixed(2)}*`
    : "";

  // Move to address state
  if (biz) {
    biz.sessionState = "supplier_order_address";
    await saveBizSafe(biz);
  }
  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderState": "supplier_order_address" } },
    { upsert: true }
  );

// For collection-only product suppliers, no address needed - use a placeholder
  const needsAddress = isService || supplier.delivery?.available;

  if (!needsAddress) {
    // Collection only - no address needed, send order immediately with placeholder
    if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderCart": "", "tempData.orderIsService": "" } },
      { upsert: true }
    );

    // Build and submit order directly
    let totalAmount = 0;
    let pricedCount = 0;
    const finalItems = cart.map(entry => {
      const quantity = Number(entry.quantity) || 1;
      const pricePerUnit = entry.pricePerUnit || null;
      const total = pricePerUnit ? quantity * pricePerUnit : null;
      if (total) { totalAmount += total; pricedCount++; }
      return { product: entry.product, quantity, unit: entry.unit || "each", pricePerUnit, currency: "USD", total };
    });

    const order = await SupplierOrder.create({
      supplierId: supplier._id,
      supplierPhone: supplier.phone,
      buyerPhone: phone,
      items: finalItems,
      totalAmount,
      currency: "USD",
      delivery: { required: false, address: "Collection" },
      status: "pending"
    });
    await notifySupplierNewOrder(supplier.phone, order);

       const itemSummary = finalItems.map(i => `• ${i.product} ×${i.quantity}`).join("\n");

    const selectedTopLine = selectedSupplierItem?.product
      ? `🎯 *Selected Item:* ${selectedSupplierItem.product}\n\n`
      : "";
    await sendText(from,
`✅ *Order sent to ${supplier.businessName}!*

${selectedTopLine}${itemSummary}
🏠 Collection only - you will pick up from the supplier
${pricedCount > 0 ? `💵 Estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Supplier: ${supplier.phone}

${pricedCount === finalItems.length ? "All items were auto-priced. Supplier can confirm immediately. 🎉" : "Supplier will confirm pricing shortly. 🎉"}`);
    return sendButtons(from, {
      text: "What would you like to do next?",
      buttons: [
        { id: "find_supplier", title: "🔍 Browse & Shop" },
        { id: "my_orders", title: "📋 My Orders" }
      ]
    });
  }

  return sendButtons(from, {
    text:
`${isService ? "📅" : "🛒"} *${isService ? "Booking Summary" : "Order Summary"}*

${selectedTopLine}${previewLines}${totalLine}

─────────────────
⚠️ *Your order has NOT been sent yet.*
─────────────────

*Step 2 of 2 - Enter your ${isService ? "location" : "delivery address"}* 👇

${isService
  ? `📍 *Add a contact note for the provider:*\n\nExamples:\n• _Call me on arrival_\n• _Preferred time: Mon 10am_\n• _+263 7XX XXX XXX_`
  : `📍 *Where should we deliver?*\n\nExamples:\n• _123 Samora Machel Ave, Harare_\n• _Deliver to Avondale after 4pm_\n• _I will collect - call me_`
}

_Type your address below and send to complete your ${isService ? "booking" : "order"}_ ✍️`,
   buttons: [
      ...(isService ? [{ id: `sup_skip_note_${supplierId}`, title: "⏭ Skip & Send" }] : []),
      { id: `sup_cart_clear_${supplierId}`, title: "✏️ Edit Order" },
      { id: "find_supplier", title: "❌ Cancel" }
    ].slice(0, 3)
  });
}

// ── Skip contact note - submit booking without address ────────────────────
if (a.startsWith("sup_skip_note_")) {
  const supplierId = a.replace("sup_skip_note_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const sess = await UserSession.findOne({ phone });
  const cart = biz?.sessionData?.orderCart || sess?.tempData?.orderCart || [];

  if (!cart.length) return sendText(from, "❌ Your cart is empty.");

  let totalAmount = 0;
  let pricedCount = 0;
  const finalItems = cart.map(entry => {
    const quantity = Number(entry.quantity) || 1;
    const pricePerUnit = entry.pricePerUnit || null;
    const total = pricePerUnit ? quantity * pricePerUnit : null;
    if (total) { totalAmount += total; pricedCount++; }
    return { product: entry.product, quantity, unit: entry.unit || "job", pricePerUnit, currency: "USD", total };
  });

  const order = await SupplierOrder.create({
    supplierId: supplier._id,
    supplierPhone: supplier.phone,
    buyerPhone: phone,
    items: finalItems,
    totalAmount,
    currency: "USD",
    delivery: { required: false, address: "Client visits provider" },
    status: "pending"
  });

  await notifySupplierNewOrder(supplier.phone, order, phone, { isBooking: true });

  if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
  await UserSession.findOneAndUpdate(
    { phone },
    { $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderCart": "", "tempData.orderIsService": "" } },
    { upsert: true }
  );

  const itemSummary = finalItems.map(i => `• ${i.product} ×${i.quantity}`).join("\n");
  await sendText(from,
`✅ *Booking sent to ${supplier.businessName}!*

${itemSummary}
📍 You will visit the provider
${pricedCount > 0 ? `💵 Estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Contact: ${supplier.phone}

Supplier will confirm your booking shortly. 🎉`);

  return sendButtons(from, {
    text: "What would you like to do next?",
    buttons: [
      { id: "find_supplier", title: "🔍 Browse & Shop" },
      { id: "my_orders", title: "📋 My Orders" }
    ]
  });
}
// ── Cart: buyer clears cart ───────────────────────────────────────────────
if (a.startsWith("sup_cart_clear_")) {
  const supplierId = a.replace("sup_cart_clear_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: [] };
    biz.sessionState = "supplier_order_picking";
    await saveBizSafe(biz);
  }
  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": [], "tempData.orderState": "supplier_order_picking" } },
    { upsert: true }
  );

  await persistOrderFlowState({
    biz,
    phone,
    patch: {
      orderBrowseMode: "cart",
      orderSupplierId: supplierId,
      orderCart: []
    },
    unset: {
      selectedSupplierItem: ""
    }
  });s

return _sendSupplierCartMenu(from, supplier, []);
}


// ── Cart: buyer removes one unit of an item ───────────────────────────────
if (a.startsWith("sup_cart_remove_")) {
  const withoutPrefix = a.replace("sup_cart_remove_", "");
  const firstUnderscore = withoutPrefix.indexOf("_");
  const supplierId = withoutPrefix.slice(0, firstUnderscore);
  const encodedProduct = withoutPrefix.slice(firstUnderscore + 1);
  const productName = decodeURIComponent(encodedProduct);

  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  let cart = [];
  if (biz) {
    cart = biz.sessionData?.orderCart || [];
  } else {
    const sess = await UserSession.findOne({ phone });
    cart = sess?.tempData?.orderCart || [];
  }

  const idx = cart.findIndex(c => c.product.toLowerCase() === productName.toLowerCase());
  if (idx >= 0) {
    if (cart[idx].quantity > 1) {
      cart[idx].quantity -= 1;
      // Recalculate total
      if (cart[idx].pricePerUnit) {
        cart[idx].total = cart[idx].quantity * cart[idx].pricePerUnit;
      }
    } else {
      cart.splice(idx, 1); // Remove entirely if qty reaches 0
    }
  }

  if (biz) {
    biz.sessionData = { ...(biz.sessionData || {}), orderCart: cart };
    await saveBizSafe(biz);
  }
  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.orderCart": cart } },
    { upsert: true }
  );

await persistOrderFlowState({
  biz,
  phone,
  patch: {
    orderBrowseMode: "cart",
    orderSupplierId: supplierId,
    orderCart: cart
  }
});

return _sendSupplierCartMenu(from, supplier, cart);
}
// ── Cart: buyer wants to type a custom item not in catalogue ─────────────
if (a.startsWith("sup_cart_custom_")) {
  const supplierId = a.replace("sup_cart_custom_", "");
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) return sendText(from, "❌ Supplier not found.");

  const isService = supplier.profileType === "service";

  // Stay in picking state - typed input will be caught by the picking handler above
  if (biz) {
    biz.sessionState = "supplier_order_picking";
    biz.sessionData = { ...(biz.sessionData || {}), orderSupplierId: supplierId };
    await saveBizSafe(biz);
  }
  await UserSession.findOneAndUpdate(
    { phone },
    { $set: {
      "tempData.orderState": "supplier_order_picking",
      "tempData.orderSupplierId": supplierId
    }},
    { upsert: true }
  );

  return sendText(from,
isService
  ? `✍️ *Type the service + quantity*\n\nExamples:\n_plumbing 2 hr_\n_welding 1 job_\n_electrical inspection_\n\nOr multiple:\n_plumbing 2, painting 1_\n\nType *cancel* to go back.`
  : `✍️ *Type item name + quantity*\n\nExamples:\n_cement 10_\n_river sand 2, pit sand 1_\n_roofing sheets 20_\n\nType *cancel* to go back.`
  );
}


// ── Buyer request lane: entry menu ───────────────────────────────────────────
// ── Buyer clarification reply - buyer tapped "I replied below" or typed response ──
// When a seller typed "ask: what size PVC elbow?" the bot asked the buyer.
// Now the buyer's next message (or button tap) is their answer.
// We relay it back to the seller immediately so they can price accurately.
if (a === "buyer_clarif_done" || a?.startsWith("buyer_clarif_done_")) {
  return sendText(from,
    `✅ Thanks! The seller will see your reply below and send you a quote shortly.\n\n` +
    `Type your answer now and it will be sent to the seller:`
  );
}

// ── Check if this message is a clarification reply to a seller ───────────────
// Any buyer message could be a clarification reply if seller has a pendingQuestion for their phone
if (!isMetaAction && text && text.trim().length > 1) {
  const _pendingQuestions = await UserSession.find({
    "tempData.sellerPendingQuestion.buyerPhone": phone
  }).lean();

  if (_pendingQuestions.length > 0) {
    for (const _sellerSess of _pendingQuestions) {
      const _pq = _sellerSess.tempData?.sellerPendingQuestion;
      if (!_pq || Date.now() - (_pq.askedAt || 0) > 24 * 60 * 60 * 1000) continue; // expired

      const _sellerPhone = _pq.sellerPhone;
      const _buyerAnswer = text.trim().slice(0, 500);

      // Clear the pending question
      const _sellerPhoneNorm = _sellerPhone.replace(/\D+/g, "");
      await UserSession.findOneAndUpdate(
        { phone: _sellerPhoneNorm },
        { $unset: { "tempData.sellerPendingQuestion": "" } },
        { upsert: true }
      );

      // Relay buyer's answer to seller
      try {
        const { sendButtons: _relaySendBtn } = await import("./metaSender.js");
        await _relaySendBtn(_sellerPhone, {
          text:
            `💬 *Buyer replied to your question:*\n\n` +
            `_"${_buyerAnswer}"_\n\n` +
            `You can now enter your price or continue editing the quote.`,
          buttons: [
            { id: `req_offer_${_pq.requestId}`, title: "📋 View Request" }
          ]
        });
        console.log(`[CLARIF RELAY] Buyer ${phone} → seller ${_sellerPhone}: "${_buyerAnswer.slice(0,50)}"`);
      } catch (_relayErr) {
        console.warn(`[CLARIF RELAY] Could not send to seller ${_sellerPhone}: ${_relayErr.message}`);
      }

      // Confirm to buyer their reply was sent
      return sendText(from,
        `✅ Your answer has been sent to the seller. They will send you a quote shortly.`
      );
    }
  }

  // ── GUARD: never hijack text input that belongs to an active biz flow ────────
  // If the biz session is in any business-tools state (invoice, quote, receipt,
  // product entry, payment, expense, etc.) let continueTwilioFlow handle it.
  // Without this guard, ANY plain text typed during an invoice flow (e.g. "3x2, 3x3"
  // to pick catalogue items) lands here and shows "Request Sellers" instead.
  const _bizActiveStates = new Set([
    // Invoice
    "creating_invoice_choose_client", "creating_invoice_new_client",
    "creating_invoice_new_client_phone", "creating_invoice_add_items",
    "creating_invoice_pick_product", "creating_invoice_enter_catalogue_prices",
    "creating_invoice_confirm", "creating_invoice_qty", "creating_invoice_add_item_text",
    "creating_invoice_custom_names", "creating_invoice_custom_preview",
    "creating_invoice_custom_edit", "creating_invoice_set_discount",
    "creating_invoice_set_vat", "creating_invoice_enter_prices",
    "creating_invoice_add_note", "invoice_quick_add_product_name",
    "invoice_quick_add_product_price",
    // Quote
    "creating_quote_choose_client", "creating_quote_new_client",
    "creating_quote_new_client_phone", "creating_quote_add_items",
    "creating_quote_pick_product", "creating_quote_enter_catalogue_prices",
    "creating_quote_confirm", "creating_quote_qty", "creating_quote_add_item_text",
    "creating_quote_custom_names", "creating_quote_custom_preview",
    "creating_quote_custom_edit", "creating_quote_set_discount",
    "creating_quote_set_vat", "creating_quote_enter_prices",
    "creating_quote_add_note", "quote_quick_add_product_name",
    "quote_quick_add_product_price",
    // Receipt
    "creating_receipt_choose_client", "creating_receipt_new_client",
    "creating_receipt_new_client_phone", "creating_receipt_add_items",
    "creating_receipt_pick_product", "creating_receipt_enter_catalogue_prices",
    "creating_receipt_confirm", "creating_receipt_qty", "creating_receipt_add_item_text",
    "creating_receipt_custom_names", "creating_receipt_custom_preview",
    "creating_receipt_custom_edit", "creating_receipt_set_discount",
    "creating_receipt_set_vat", "creating_receipt_enter_prices",
    "creating_receipt_add_note", "receipt_quick_add_product_name",
    "receipt_quick_add_product_price",
    // Sales doc list / search / action
    "sales_doc_list", "sales_doc_search", "sales_doc_filter", "sales_doc_action",
    // Payments & expenses
    "payment_amount", "payment_method", "payment_invoice_search",
    "expense_smart_entry", "expense_bulk_confirm", "bulk_expense_input",
    "expense_amount", "expense_category",
    // Cash balance
    "cash_set_opening_balance", "cash_payout_amount", "cash_payout_reason", "cash_payout_source", "cash_payout_recipient",
    // Products
    "product_add_name", "product_add_price", "product_edit_name", "product_edit_price",
    "product_add_name_or_menu",
    // Clients / branches / settings / onboarding
    "add_client_name", "add_client_phone", "adding_client_name",
    "client_statement_choose_client", "client_statement_generate",
    "awaiting_address", "awaiting_business_name",
    "settings_currency", "settings_terms", "settings_inv_prefix",
    "settings_qt_prefix", "settings_rcpt_prefix",
    "branch_add_name", "invite_user_phone",
    "subscription_payment_pending", "subscription_enter_ecocash",
    // Service rate update - text entry states must not be hijacked by Request Sellers
    "service_update_rates", "service_update_rates_confirm_unit", "service_update_rates_confirm",
    // Report text-input states - must not be hijacked by Request Sellers
    "report_date_filter", "report_clerk_pick_custom",
    "report_detailed", "report_detailed_week", "report_detailed_month", "report_detailed_year",
    "report_clerk_statement", "report_clerk_pick", "report_clerk_self", "report_choose_branch",
    "cash_handover_amount", "cash_handover_incoming", "cash_handover_note",
    // Recurring billing states
    "rb_payment_pick_account", "rb_payment_pick_tenant", "rb_payment_review", "rb_payment_enter_amount", "rb_payment_confirm",
    "rb_invoice_pick_account", "rb_invoice_review",
    "rb_acct_stmt_pick_account", "rb_acct_stmt_pick_period", "rb_acct_stmt_custom_date",
    "rb_tenant_stmt_pick_account", "rb_tenant_stmt_pick_tenant", "rb_tenant_stmt_pick_period",
    "rb_billing_stmt_pick_period", "rb_billing_stmt_custom_date",
    "rb_expense_pick_account", "rb_expense_enter_details",
    "rb_expense_confirm",
    "rb_vacate_pick", "rb_vacate_confirm",
    "rb_income_enter_details", "rb_income_confirm",
    // ── FIX: Browse & Shop + buyer order typed-input states ──────────────────
    // These states have dedicated typed-text handlers BELOW this catch-all
    // (supplier_search_product at the "Buyer: free-text product search" block,
    // supplier_order_product / _address / _enter_price further down).
    // Without them here, a buyer who taps Browse & Shop and types
    // "find brakes overhauls harare" is hijacked into ⚡ Request Sellers and
    // the search never runs. Same for typed order items, delivery addresses
    // and price entry.
    "supplier_search_product", "supplier_search_city",
    "supplier_order_product", "supplier_order_address",
    "supplier_order_enter_price", "supplier_order_confirm_price",
    "supplier_order_picking",
    // ── FIX: parent school-search states ─────────────────────────────────────
    // A biz-owner searching for a school sits in one of these states. Their typed
    // text (a city or a school NAME) has a dedicated handler ABOVE this catch-all
    // (the school free-text block). Without registering them here, that typed text
    // was hijacked into ⚡ Request Sellers instead of searching schools.
    "school_search_city", "school_search_results",
    // ── School-admin text-input states ───────────────────────────────────────
    // When a school owner/clerk types their fees, email, website, reg link, etc.,
    // biz.sessionState is one of these. Without registering them here, that typed
    // text was hijacked by the Request Sellers catch-all → the "Which city?" prompt.
    "school_admin_update_fees", "school_admin_update_reg_link",
    "school_admin_update_email", "school_admin_update_website",
    "school_admin_awaiting_brochure", "school_parent_enquiry",
    // Stock Control multi-step states
    "stock_add_name", "stock_add_unit", "stock_add_opening", "stock_add_cost",
    "stock_add_sell", "stock_add_reorder", "stock_add_aliases", "stock_add_pick", "stock_add_qty",
    "stock_in_pick", "stock_in_qty", "stock_adjust_pick", "stock_adjust_qty",
    "stock_report_period", "stock_report_custom_date"
  ]);

  // FIX: no-biz buyers mid-order store their state in UserSession.tempData
  // (orderState = "supplier_order_address" etc). Their typed address/items are
  // handled by dedicated blocks BELOW this catch-all, so they must fall
  // through here too instead of being hijacked into Request Sellers.
  let _noBizOrderActive = false;
  if (!biz) {
    try {
      const _catchSess = await UserSession.findOne({ phone }).lean();
      _noBizOrderActive = !!_catchSess?.tempData?.orderState;
    } catch (_) {}
  }

  if ((biz && _bizActiveStates.has(biz.sessionState)) || _noBizOrderActive) {
    // Let the request fall through to continueTwilioFlow below
  } else {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.buyerRequestState": "awaiting_items",
          "tempData.buyerRequestMode":  "simple",
          "tempData.pendingBuyerRequest": {
            requestType: "simple",
            profileType: "product",
            items: []
          }
        }
      },
      { upsert: true }
    );

    return sendButtons(from, {
      text:
        `⚡ *Request Sellers*\n\n` +
        `Type what you need - *any way you like.*\n` +
        `You can write a full sentence, a short phrase, or a list.\n\n` +
        `─────────────────\n` +
        `*💬 Write naturally:*\n` +
        `_I need a Bill of Quantities for a 4-bed house in Ruwa, 280m², drawings available_\n` +
        `_Need an electrician for DB board fault in Borrowdale Harare_\n` +
        `_Please quote for architectural drawings, 3-bedroom single storey, Greendale_\n\n` +
        `*🔧 Short service request:*\n` +
        `_house rewiring 4 bedroom 280sqm, Borrowdale_\n` +
        `_plumber burst pipe Avondale Harare_\n` +
        `_glass repair 600x900mm, Eastlea_\n\n` +
        `*📦 Products:*\n` +
        `_copper pipe 15mm x5 lengths, Msasa Harare_\n` +
        `_cement 50kg x20 bags, river sand 3m3, Mbare_\n` +
        `_10kw growatt inverter x2, Glen View Harare_\n\n` +
        `*📋 Big list?* Tap *Bulk List* below.\n\n` +
        `💡 _Include your suburb/city so we can find nearby sellers._\n` +
        `_Type *0* for main menu · *00* to cancel_`,
      buttons: [
        { id: "sup_request_mode_bulk", title: "📋 Bulk List" },
        { id: "find_supplier",         title: "🔍 Browse & Shop" }
      ]
    });
  }
}

// ── REQUEST SELLERS (interactive button tap) ────────────────────────────────
// sup_request_sellers arrives as an interactive list_reply (isMetaAction=true).
// The original handler for this action was buried inside an
// `if (!isMetaAction && text && ...)` block which never fires for button taps.
// This top-level block is the canonical handler for ALL users - with or without
// a biz - who tap ⚡ Request Sellers.
if (a === "sup_request_sellers") {
  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.buyerRequestState": "awaiting_items",
        "tempData.buyerRequestMode":  "simple",
        "tempData.pendingBuyerRequest": {
          requestType: "simple",
          profileType: "product",
          items: []
        }
      }
    },
    { upsert: true }
  );

  return sendButtons(from, {
    text:
      `⚡ *Request Sellers*\n\n` +
      `Type what you need - *any way you like.*\n` +
      `You can write a full sentence, a short phrase, or a list.\n\n` +
      `─────────────────\n` +
      `*💬 Write naturally:*\n` +
      `_I need a Bill of Quantities for a 4-bed house in Ruwa, 280m², drawings available_\n` +
      `_Need an electrician for DB board fault in Borrowdale Harare_\n` +
      `_Please quote for architectural drawings, 3-bedroom single storey, Greendale_\n\n` +
      `*🔧 Short service request:*\n` +
      `_house rewiring 4 bedroom 280sqm, Borrowdale_\n` +
      `_plumber burst pipe Avondale Harare_\n` +
      `_glass repair 600x900mm, Eastlea_\n\n` +
      `*📦 Products:*\n` +
      `_copper pipe 15mm x5 lengths, Msasa Harare_\n` +
      `_cement 50kg x20 bags, river sand 3m3, Mbare_\n` +
      `_10kw growatt inverter x2, Glen View Harare_\n\n` +
      `*📋 Big list?* Tap *Bulk List* below.\n\n` +
      `💡 _Include your suburb/city so we can find nearby sellers._\n` +
      `_Type *0* for main menu · *00* to cancel_`,
    buttons: [
      { id: "sup_request_mode_bulk", title: "📋 Bulk List" },
      { id: "find_supplier",         title: "🔍 Browse & Shop" }
    ]
  });
}

if (a === "sup_request_mode_simple" || a === "sup_request_mode_bulk") {
  const requestType = a === "sup_request_mode_bulk" ? "bulk" : "simple";

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.buyerRequestState": "awaiting_items",
        "tempData.buyerRequestMode": requestType,
        "tempData.pendingBuyerRequest": {
          requestType,
          profileType: "product",
          items: []
        }
      }
    },
    { upsert: true }
  );

  return sendText(
    from,
    requestType === "bulk"
      ? `📋 *Bulk Request*\n\nSend your full item list.\nOne item per line or comma-separated.\n\n` +
        `*Examples:*\n` +
        `_110 access tees x2_\n` +
        `_copper pipe 15mm, 5 lengths_\n` +
        `_ball valve brass 20mm x5_\n` +
        `_cement 50kg, 20 bags_\n` +
        `_hp laptop core i7 x3_\n` +
        `_school uniform size 8 x10_\n` +
        `_geyser installation x2_\n\n` +
        `*Quantity rule:* put qty at the end.\n` +
        `_"copper pipe 15mm, 5 lengths"_ → product is "copper pipe 15mm", qty is 5.\n` +
        `_"cement 50kg x20 bags"_ → product is "cement 50kg", qty is 20 bags.\n\n` +
        `After sending your list, reply with your suburb/city.\n\n` +
        `Type *0* for main menu · *00* to cancel`
      : `⚡ *Request Sellers*\n\nType what you need. Add your suburb/city in the same message.\n\n` +
        `*Examples:*\n` +
        `_copper pipe 15mm, 5 lengths, Msasa_\n` +
        `_need plumber, burst pipe, Avondale Harare_\n` +
        `_cement 50kg x20 bags, Mbare_\n` +
        `_electrician for DB board, Chitungwiza_\n\n` +
        `Type *0* for main menu · *00* to cancel`
  );
}

if (a === "sup_request_delivery_yes" || a === "sup_request_delivery_no") {
  const reqSess = await UserSession.findOne({ phone });
  const pendingBuyerRequest = reqSess?.tempData?.pendingBuyerRequest || null;

  if (!pendingBuyerRequest?.items?.length) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $unset: {
          "tempData.buyerRequestState": "",
          "tempData.pendingBuyerRequest": "",
          "tempData.buyerRequestMode": ""
        }
      },
      { upsert: true }
    );

    return sendButtons(from, {
      text: "❌ Request session expired. Please start again.",
      buttons: [{ id: "sup_request_sellers", title: "⚡ Request Sellers" }]
    });
  }

  if (pendingBuyerRequest.city) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.savedCity": pendingBuyerRequest.city,
          "tempData.savedArea": pendingBuyerRequest.area || ""
        }
      },
      { upsert: true }
    );
  }

  if (a === "sup_request_delivery_yes") {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.buyerRequestState": "awaiting_delivery_address",
          "tempData.pendingBuyerRequest": {
            ...pendingBuyerRequest,
            deliveryRequired: true
          }
        }
      },
      { upsert: true }
    );

    return sendText(
      from,
      `📍 *Please send your delivery / pickup address.*\n\n` +
      `Example:\n_24 Mabelreign Drive, Harare_\n_Hotel name / lodge / pickup point_\n\n` +
      `Type *0* for main menu · *cancel* to stop.`
    );
  }

  // ── Collection path: offer photo before finalizing ──────────────────────────
  const _noDelSess = await UserSession.findOne({ phone });
  if (!_noDelSess?.tempData?.photoPromptShown) {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.buyerRequestState":  "awaiting_photo_choice",
          "tempData.pendingBuyerRequest": { ...pendingBuyerRequest, deliveryRequired: false },
          "tempData.photoPromptShown":   true
        }
      },
      { upsert: true }
    );
    return sendButtons(from, {
      text:
        `📷 *Add a photo? (optional)*\n\n` +
        `A photo helps sellers understand exactly what you need.\n\n` +
        `Useful for: repairs, custom items, matching parts or colours.\n\n` +
        `Tap *Add Photo* to send an image, or *Skip* to submit now.`,
      buttons: [
        { id: "sup_req_photo_yes",  title: "📷 Add Photo"       },
        { id: "sup_req_photo_skip", title: "⏭ Skip - submit now" }
      ]
    });
  }

  return finalizeBuyerRequestSubmission({
    from,
    phone,
    pendingRequest: pendingBuyerRequest,
    deliveryRequired: false,
    deliveryAddress: null
  });
}
if (a === "sup_use_saved_location") {
  const reqSess = await UserSession.findOne({ phone });
  const pendingBuyerRequest = reqSess?.tempData?.pendingBuyerRequest || null;
  const savedCity = reqSess?.tempData?.savedCity || null;
  const savedArea = reqSess?.tempData?.savedArea || null;

  if (!pendingBuyerRequest?.items?.length || !savedCity) {
    return sendText(from, "❌ Session expired. Please type your request again.\n\nType *0* for main menu.");
  }

  const updatedRequest = { ...pendingBuyerRequest, city: savedCity, area: savedArea };
  const _isServiceReq = _buyerRequestIsService(updatedRequest.items || []);

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.pendingBuyerRequest": { ...updatedRequest, isServiceRequest: _isServiceReq }
      }
    },
    { upsert: true }
  );

  if (_isServiceReq) {
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.buyerRequestState": "awaiting_service_address" } },
      { upsert: true }
    );
    return sendText(
      from,
      `📍 *Where should the service provider come?*\n\n` +
      `📍 ${savedArea ? `${savedArea}, ` : ""}${savedCity}\n\n` +
      `Type your address or type *skip* to share it directly.\n` +
      `Type *0* for main menu`
    );
  }

  const _isTourismSaved = _buyerRequestIsTourism(updatedRequest.items || []);
  if (_isTourismSaved) {
    return sendButtons(from, {
      text: `📍 *Where will you be? Should the operator come to you?*\n\n📍 ${savedArea ? `${savedArea}, ` : ""}${savedCity}`,
      buttons: [
        { id: "sup_request_delivery_yes", title: "📍 My location" },
        { id: "sup_request_delivery_no",  title: "🏕 I'll go to operator" }
      ]
    });
  }

  return sendButtons(from, {
    text: `🚚 *Do you need delivery?*\n\n📍 ${savedArea ? `${savedArea}, ` : ""}${savedCity}`,
    buttons: [
      { id: "sup_request_delivery_yes", title: "✅ Yes, delivery" },
      { id: "sup_request_delivery_no",  title: "🏠 No, collection" }
    ]
  });
}

// ── Change location ──────────────────────────────────────────────────────────
if (a === "sup_change_location") {
  await UserSession.findOneAndUpdate(
    { phone },
    { $set: { "tempData.buyerRequestState": "awaiting_location" } },
    { upsert: true }
  );
  return sendText(
    from,
    `📍 *Which area are you in?*\n\nReply with suburb or suburb + city:\n` +
    `_Msasa_, _Borrowdale Harare_, _Luveve Bulawayo_\n\n` +
    `Type *0* for main menu`
  );
}

// ── Seller pause / resume receiving requests ──────────────────────────────────
if (al === "pause" || a === "sup_pause_requests") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);
  supplier.pauseRequests = true;
  await supplier.save();
  return sendButtons(from, {
    text: "⏸ *Requests paused.*\n\nYou won't receive new buyer request notifications until you resume.\n\nType *resume* or tap below to start receiving again.",
    buttons: [
      { id: "sup_resume_requests",     title: "▶️ Resume" },
      { id: "my_supplier_account",     title: "🏪 My Store" }
    ]
  });
}

if (al === "resume" || a === "sup_resume_requests") {
  const supplier = await SupplierProfile.findOne({ phone });
  if (!supplier) return sendSuppliersMenu(from);
  supplier.pauseRequests = false;
  await supplier.save();
  return sendButtons(from, {
    text: "▶️ *Requests resumed.*\n\nYou'll now receive new buyer request notifications again.",
    buttons: [
      { id: "my_supplier_account", title: "🏪 My Store" },
      { id: "suppliers_home",      title: "🛒 Marketplace" }
    ]
  });
}

// ── "quotes" shortcut - buyer views current quotes anytime ────────────────────
if (al === "quotes" || al === "my quotes") {
  return handleIncomingMessage({ from, action: "buyer_my_requests" });
}

if (a.startsWith("req_offer_confirm_")) {
  // ── Supplier tapped "Send Quote" from the preview ─────────────────────────
  // Retrieve stored pending response and send it to the buyer.
  // FIX: uppercase extracted ID/ref (WhatsApp lowercases button payloads)
  // and use findBuyerRequestByIdOrRef to handle both ObjectId and ref strings.
  const _confirmReqId  = a.replace("req_offer_confirm_", "").toUpperCase();
  const _confirmReq    = await findBuyerRequestByIdOrRef(_confirmReqId);
  const _confirmSup    = await SupplierProfile.findOne({ phone }).lean();

  if (!_confirmReq || !_confirmSup) {
    return sendText(from, "❌ Request has expired. The buyer may have already received quotes.");
  }

  // Read the pending offer stored during the preview step
  const _confirmSess = await UserSession.findOne({ phone }).lean();
  let _confirmedResp;
  try {
    _confirmedResp = JSON.parse(_confirmSess?.tempData?.pendingOfferResponse || "{}");
  } catch (_) {
    _confirmedResp = null;
  }

  // Clear ALL BuyerRequest state immediately - including the sellerPendingRequests map entry
  // FIX: must remove the entry from sellerPendingRequests map too. If left in,
  // the next message from the seller triggers awaiting_offer_intro showing the same request.
  const _confirmSessForCleanup = await UserSession.findOne({ phone }).lean();
  let _pendingMapForCleanup = {};
  try {
    const _rawMap = _confirmSessForCleanup?.tempData?.sellerPendingRequests;
    _pendingMapForCleanup = _rawMap ? (typeof _rawMap === "object" && !Array.isArray(_rawMap) ? _rawMap : JSON.parse(_rawMap)) : {};
  } catch (_) {}
  // Remove this specific request from the map
  delete _pendingMapForCleanup[String(_confirmReq._id)];
  delete _pendingMapForCleanup[_confirmReqId]; // also try by ref

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set:   { "tempData.sellerPendingRequests": _pendingMapForCleanup },
      $unset: {
        "tempData.sellerRequestReplyState": "",
        "tempData.sellerRequestId":         "",
        "tempData.pendingOfferResponse":    "",
        "tempData.pendingDraftQuote":       ""
      }
    },
    { upsert: true }
  );

 if (!_confirmedResp?.supplierPhone) {
  const fallbackDraft = _confirmSess?.tempData?.pendingDraftQuote;

  if (fallbackDraft?.responseItems?.length) {
    _confirmedResp = {
      supplierId: _confirmSup._id,
      supplierPhone: _confirmSup.phone,
      supplierName: _confirmSup.businessName,
      mode: "manual_offer",
      message: fallbackDraft.skippedItems?.length
        ? `Not in stock: ${fallbackDraft.skippedItems.join(", ")}`
        : "",
      items: fallbackDraft.responseItems.map(item => ({
        product: item.product,
        quantity: Number(item.quantity || 1),
        unit: item.unit || "each",
        pricePerUnit: Number(item.pricePerUnit || 0),
        total: Number(item.total || 0),
        available: true
      })),
      totalAmount: Number(fallbackDraft.totalAmount || 0),
      deliveryAvailable: _confirmSup.delivery?.available ?? null,
      etaText: ""
    };
  }
}

if (!_confirmedResp?.supplierPhone) {
    // Pending response lost - drop back to price entry
    const _lostItems = (_confirmReq.items || []);
    const _lostLines = _lostItems.map((it, i) => `${i+1}. *${it.product}* × ${Number(it.quantity||1)}`).join("\n");
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.sellerRequestReplyState": "awaiting_offer", "tempData.sellerRequestId": _confirmReqId } },
      { upsert: true }
    );
    return sendText(from,
      `⚠️ Session expired - please re-enter your prices.\n\n` +
      `*Items:*\n${_lostLines}\n\n` +
      `Type price(s) e.g. *250* or *1x250  2x80*`
    );
  }

  // Save and send the confirmed response
  _confirmReq.responses.push(_confirmedResp);
  await _confirmReq.save();

  trackSupplierResponseSpeed(_confirmSup.phone, _confirmReq.createdAt).catch(console.error);
  await sendBuyerRequestResponseToBuyer({ request: _confirmReq, supplier: _confirmSup, response: _confirmedResp });

  const _confOtherCount = (_confirmReq.responses || []).filter(
    r => String(r.supplierPhone) !== String(_confirmSup.phone) &&
         r.mode !== "unavailable" && (r.items?.length || r.message)
  ).length;

  const _confCompLine = _confOtherCount > 0
    ? `\n_${_confOtherCount} other seller${_confOtherCount === 1 ? "" : "s"} also quoted this buyer._`
    : `\n_⚡ You're the first to respond - great timing!_`;

  return sendButtons(from, {
    text:
      `✅ *Quote sent successfully!*${_confCompLine}\n\n` +
      `The buyer will see your prices and can contact you directly.`,
    buttons: [
      { id: "my_supplier_account", title: "🏪 My Store"   },
      { id: "suppliers_home",      title: "🛒 Marketplace" }
    ]
  });
}

if (a.startsWith("req_offer_")) {
  const requestId = a.replace("req_offer_", "").trim().toUpperCase();
  const request = await findBuyerRequestByIdOrRef(requestId);
  if (!request) return sendText(from, "❌ Request not found or expired.");

  const supplier = await SupplierProfile.findOne({ phone }).lean();
  if (!supplier) return sendText(from, "❌ Supplier profile not found.");

  const draft = buildDraftQuoteFromRequest(supplier, request);

  await UserSession.findOneAndUpdate(
    { phone },
    {
      $set: {
        "tempData.sellerRequestReplyState": "awaiting_offer",
        "tempData.sellerRequestId": String(request._id),
        "tempData.pendingDraftQuote": draft
      }
    },
    { upsert: true }
  );

  const draftLines = draft.responseItems.length
    ? draft.responseItems
        .map((item, i) =>
          `${i + 1}. ${item.product} x${item.quantity} @ $${Number(item.pricePerUnit).toFixed(2)}/${item.unit} = $${Number(item.total).toFixed(2)}`
        )
        .join("\n")
    : "No auto-priced items found yet.";

  const missingLines = draft.missingItems.length
    ? `\n\n⚠️ *Needs review / no price found yet:*\n${draft.missingItems.map(i => `• ${i}`).join("\n")}`
    : "";

  return sendText(
    from,
    `💬 *Review and send quotation*\n\n` +
      `${formatBuyerRequestItems(request.items || [], 20)}\n\n` +
      `*Suggested draft quote:*\n${draftLines}` +
      `${draft.responseItems.length ? `\n\n💵 Draft total: $${Number(draft.totalAmount || 0).toFixed(2)}` : ""}` +
      `${missingLines}\n\n` +
      `Reply in any of these ways:\n\n` +
      `*1. Send draft as is*\n_send_\n\n` +
      `*2. Edit prices by number*\n_1x12, 2x8.5, 3x4.20_\n\n` +
      `*3. Send prices in order*\n_12, 8.5, 4.20, 16_\n\n` +
      `*4. Send named prices*\n_110 access tees: 12_\n_vent valves: 8.5_\n\n` +
      `*5. Partial quote*\n_110 access tees: 12_\n_vent valves: 8.5_\nOnly these are available now._\n\n` +
      `Type *cancel* to stop.`
  );
}


if (a.startsWith("req_auto_")) {
  const requestId = a.replace("req_auto_", "");
  const request = await findBuyerRequestByIdOrRef(requestId);
  if (!request) return sendText(from, "❌ Request not found or expired.");

  return sendButtons(from, {
    text:
      `⚠️ Auto Quote has been removed for Request Sellers.\n\n` +
      `Please send a manual quotation so the buyer gets the correct item and price.`,
    buttons: [
      { id: `req_offer_${requestId}`, title: "View & Quote" },
      { id: `req_unavail_${requestId}`, title: "Not Available" }
    ]
  });
}

if (a.startsWith("req_unavail_")) {
  const requestId = a.replace("req_unavail_", "");
  const request = await BuyerRequest.findById(requestId);
  if (!request) return sendText(from, "❌ Request not found or expired.");

  const supplier = await SupplierProfile.findOne({ phone }).lean();
  if (!supplier) return sendText(from, "❌ Supplier profile not found.");

  const response = {
    supplierId: supplier._id,
    supplierPhone: supplier.phone,
    supplierName: supplier.businessName,
    mode: "unavailable",
    message: "",
    items: [],
    totalAmount: null,
    deliveryAvailable: supplier.delivery?.available ?? null,
    etaText: ""
  };

  request.responses.push(response);
  await request.save();

  await sendBuyerRequestResponseToBuyer({ request, supplier, response });

  return sendButtons(from, {
    text: "✅ Buyer has been notified that you are unavailable.",
    buttons: [
      { id: "my_supplier_account", title: "🏪 My Store" },
      { id: "suppliers_home", title: "🛒 Marketplace" }
    ]
  });
}

if (a.startsWith("buyer_view_all_quotes_")) {
  const _bvqRequestId = a.replace("buyer_view_all_quotes_", "");
  const _bvqRequest   = await BuyerRequest.findById(_bvqRequestId).lean();
 
  if (!_bvqRequest) {
    return sendButtons(from, {
      text: "❌ Request not found or has expired.",
      buttons: [
        { id: "sup_request_sellers", title: "⚡ New Request" },
        { id: "find_supplier",       title: "🔍 Browse & Shop" }
      ]
    });
  }
 
  const _bvqQuotes = (_bvqRequest.responses || []).filter(
    r => r.mode !== "unavailable" && (r.items?.length || r.message)
  );
 
  if (!_bvqQuotes.length) {
    const _bvqRef = `REQ-${String(_bvqRequest._id).slice(-4).toUpperCase()}`;
    return sendButtons(from, {
      text:
        `📭 *No quotes yet* (${_bvqRef})\n\n` +
        `${formatBuyerRequestItems(_bvqRequest.items || [], 10)}\n\n` +
        `${_bvqRequest.status === "open" ? "🟢 Sellers have been notified. Check back soon." : "🔴 This request is closed with no quotes."}`,
      buttons: [
        { id: "sup_request_sellers", title: "⚡ New Request" },
        { id: "find_supplier",       title: "🔍 Browse & Shop" }
      ]
    });
  }
 
  // Send full comparison as text (can be long - plain text handles it best)
  const _bvqComparison = formatBuyerQuoteComparison(_bvqRequest);
  await sendText(from, _bvqComparison);
 
  return sendButtons(from, {
    text: "What would you like to do next?",
    buttons: [
      { id: "sup_request_sellers", title: "⚡ New Request" },
      { id: "find_supplier",       title: "🔍 Browse & Shop" }
    ]
  });
}
 
// ── View buyer's request history ──────────────────────────────────────────────
if (a === "buyer_my_requests") {
  const _bmrPhone    = from.replace(/\D+/g, "");
  const _bmrRequests = await getBuyerOpenRequests(_bmrPhone, 10);
 
  if (!_bmrRequests.length) {
    return sendButtons(from, {
      text:
        `📋 *My Quote Requests*\n\n` +
        `You haven't submitted any requests yet.\n\n` +
        `Use Request Sellers to ask multiple sellers to quote your exact item.`,
      buttons: [
        { id: "sup_request_sellers", title: "⚡ Request Sellers" },
        { id: "find_supplier",       title: "🔍 Browse & Shop" }
      ]
    });
  }
 
  const _bmrRows = _bmrRequests.slice(0, 7).map(req => {
    const quoteCount   = (req.responses || []).filter(
      r => r.mode !== "unavailable" && (r.items?.length || r.message)
    ).length;
    const statusIcon   = req.status === "open" ? "🟢" : "🔴";
    const firstProduct = (req.items || [])[0]?.product || "Request";
    const ref          = `REQ-${String(req._id).slice(-4).toUpperCase()}`;
    return {
      id:          `buyer_view_all_quotes_${req._id}`,
      title:       firstProduct.slice(0, 24),
      description: `${statusIcon} ${ref} · ${quoteCount} quote${quoteCount === 1 ? "" : "s"}`
    };
  });
 
  _bmrRows.push({ id: "sup_request_sellers", title: "⚡ New Request" });
  _bmrRows.push({ id: "find_supplier",       title: "🔍 Browse & Shop" });
 
  return sendList(
    from,
    `📋 *My Quote Requests* (${_bmrRequests.length} recent)\n_Tap any request to compare quotes_`,
    _bmrRows
  );
}
  // ── sup_search_all: buyer wants to search by product name (free text) ─────
  if (a === "sup_search_all") {

      await clearBuyerOrderContext({ biz, phone, keepSupplierSearch: true });
  let searchType = biz?.sessionData?.supplierSearch?.type || null;

  if (!searchType) {
    const sess = await UserSession.findOne({ phone });
    searchType = sess?.tempData?.supplierSearchType || "product";
  }

if (biz) {
  biz.sessionState = "supplier_search_product";
  biz.sessionData = {
    ...(biz.sessionData || {}),
    supplierSearch: {
      ...(biz.sessionData?.supplierSearch || {}),
      type: searchType
    }
  };

  delete biz.sessionData.orderSupplierId;
  delete biz.sessionData.orderCart;
  delete biz.sessionData.orderItems;
  delete biz.sessionData.orderProduct;
  delete biz.sessionData.orderQuantity;
  delete biz.sessionData.orderIsService;
  delete biz.sessionData.orderBrowseMode;
  delete biz.sessionData.orderCataloguePage;
  delete biz.sessionData.orderCatalogueSearch;

  await saveBizSafe(biz);
} else {
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.supplierSearchMode": "product",
          "tempData.supplierSearchType": searchType
        }
      },
      { upsert: true }
    );
  }

  return sendButtons(from, {
    text: searchType === "service"
      ? "🔍 *Search by service*\n\nType the service you are looking for:\n\nExample: _plumbing_, _car hire_, _delivery_"
      : "🔍 *Search by product*\n\nType the product name you are looking for:\n\nExample: _flour_, _cooking oil_, _tiles_",
    buttons: [{ id: "find_supplier", title: "⬅ Back" }]
  });
}




    // ── Explicit search typed while inside a document-building flow ───────────
  // A buyer stuck in an abandoned invoice/quote/receipt draft (state
  // "creating_*") who types "find plumbers harare" was previously fed into the
  // invoice state machine, which replied with its current step ("➕ How would
  // you like to add an item?") - a confusing hijack. "find X" is never valid
  // invoice input, so instead we offer a clear choice: continue the draft, or
  // drop it and search. Only fires on the explicit find-verb - item names,
  // quantities and prices are untouched and flow to the machine as always.
  if (!isMetaAction && biz &&
      typeof biz.sessionState === "string" && biz.sessionState.startsWith("creating_") &&
      /^find\s+\S/i.test(text.trim())) {
    biz.sessionData = { ...(biz.sessionData || {}), pendingSearchText: text.trim().slice(0, 120) };
    await saveBizSafe(biz);
    const _docWord = (biz.sessionData?.docType === "quote") ? "quote"
                   : (biz.sessionData?.docType === "receipt") ? "receipt" : "invoice";
    return sendButtons(from, {
      text:
        `📄 *You have an unfinished ${_docWord}.*\n\n` +
        `Do you want to continue it, or leave it and search for *${text.trim().replace(/^find\s+/i, "").slice(0, 40)}*?`,
      buttons: [
        { id: "inv_resume_flow",    title: "▶ Continue " + _docWord },
        { id: "inv_search_instead", title: "🔍 Search instead" }
      ]
    });
  }

  // ── IMPORTANT: business-tools text states must be handled BEFORE marketplace free-text search
  // This prevents expense/sales/product-entry text from being hijacked by supplier city search.
  if (!isMetaAction && biz && !biz.name?.startsWith("pending_supplier_")) {
    const handled = await continueTwilioFlow({ from, text });
    if (handled) return;
  }

  // ── Stock: numbered "pick a product to track" → feed into the add-flow ──
  // The catalogue picker (stock_add_item) sets state to stock_add_pick, which the
  // bridge does not own - so continueTwilioFlow above returns false and we handle
  // the reply here. On a valid pick we drop the chosen name into the EXISTING
  // bridge add-flow (stock_add_name) with continueTwilioFlow; that flow is unchanged.
  if (biz?.sessionState === "stock_add_pick" && !isMetaAction) {
    const raw   = String(text || "").trim();
    const lower = raw.toLowerCase();
    const list  = Array.isArray(biz.sessionData?.stockAddPickList) ? biz.sessionData.stockAddPickList : [];
    const branchId = biz.sessionData?.stockAddBranchId || null;

    if (raw === "00") {
      biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendStockMenu(from, biz);
    }

    if (raw === "0") {
      // Type a product that isn't in the catalogue → full detailed add-flow (bridge).
      biz.sessionState = "stock_add_name"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendButtons(from, {
        text: "➕ *Track a Product*\n\nType the product *name* exactly as it appears on your sales (e.g. *Coca-Cola 500ml*).",
        buttons: [{ id: "stock_menu", title: "⬅ Cancel" }]
      });
    }

    // Resolve picked indices - supports "all", "1,3,5", "1 3 5".
    let indices;
    if (lower === "all") {
      indices = list.map((_, i) => i);
    } else {
      const nums = raw.split(/[\s,]+/).filter(Boolean).map(x => parseInt(x, 10));
      const bad  = nums.length === 0 || nums.some(x => !Number.isInteger(x) || x < 1 || x > list.length);
      if (bad) {
        await sendText(from, `❌ Reply with number(s) between *1* and *${list.length}* (e.g. *2* or *1,3,5*), *all*, *0* to type a new product, or *00* to cancel.`);
        return true;
      }
      indices = [...new Set(nums)].map(x => x - 1);
    }

    const chosen = indices.map(i => list[i]).filter(Boolean);   // [{ name, sellPrice }]
    biz.sessionState = "stock_add_qty";
    biz.sessionData  = { stockAddChosen: chosen, stockAddBranchId: branchId };
    await saveBizSafe(biz);

    let msg = "📦 *How many of each do you have on hand right now?*\n";
    msg += "Reply the counts in the *same order*, separated by commas:\n";
    chosen.forEach((it, i) => { msg += `\n*${i + 1}.* ${it.name}`; });
    msg += `\n\n👉 e.g. *${chosen.map(() => "0").join(", ")}*`;
    msg += "\n⏭️ Reply *skip* to set them all to 0 (you can update later).";
    await sendText(from, msg);
    return true;
  }

  // ── Stock: batch opening quantities → create every picked product ──────────
  // Auto-prices from the catalogue; costs / reorder default to 0 and can be set
  // later (web panel, or Record Stock In / Set count here). Fast path: one line.
  if (biz?.sessionState === "stock_add_qty" && !isMetaAction) {
    const raw      = String(text || "").trim();
    const chosen   = Array.isArray(biz.sessionData?.stockAddChosen) ? biz.sessionData.stockAddChosen : [];
    const branchId = biz.sessionData?.stockAddBranchId || null;

    if (!chosen.length || raw === "00" || /^cancel$/i.test(raw)) {
      biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendStockMenu(from, biz);
    }

    let qtys;
    if (/^skip$/i.test(raw)) {
      qtys = chosen.map(() => 0);
    } else {
      const parts = raw.split(/[\s,]+/).filter(Boolean).map(p => parseFloat(String(p).replace(/[^0-9.\-]/g, "")));
      if (parts.length !== chosen.length || parts.some(nn => isNaN(nn))) {
        await sendText(from, `❌ Please reply *${chosen.length}* number(s) in order (e.g. *${chosen.map(() => "0").join(", ")}*), or *skip* to set them all to 0.`);
        return true;
      }
      qtys = parts;
    }

    biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz);

    const created = [];
    try {
      const { createStockItem } = await import("./stockService.js");
      for (let i = 0; i < chosen.length; i++) {
        const it = chosen[i];
        await createStockItem({
          businessId: biz._id, branchId,
          name: it.name, unit: "each",
          sellPrice: Number(it.sellPrice) || 0, costPrice: 0,
          openingQty: Number(qtys[i]) || 0, reorderLevel: 0,
          aliases: [], currency: biz.currency, createdBy: from
        });
        created.push({ name: it.name, qty: Number(qtys[i]) || 0, sellPrice: Number(it.sellPrice) || 0 });
      }
    } catch (e) {
      console.error("[STOCK batch add]", e.message);
      await sendText(from, "❌ Something went wrong saving one or more products. Check *View Stock Levels* and re-add any that are missing.");
      return sendStockMenu(from, biz);
    }

    let msg = `✅ *Now tracking ${created.length} product${created.length === 1 ? "" : "s"}:*\n`;
    created.forEach(c => {
      const price = c.sellPrice ? ` · sell ${formatMoney(c.sellPrice, biz.currency)}` : "";
      msg += `\n• *${c.name}* - ${c.qty} on hand${price}`;
    });
    msg += "\n\nSales of these will reduce stock automatically (when *Sales Auto-Deduct* is ON).";
    msg += "\n💡 Add cost price or a low-stock alert anytime in the web panel, or use *📥 Record Stock In* / *🎯 Set count* here.";
    await sendText(from, msg);
    return sendStockMenu(from, biz);
  }

  // ── Recurring billing: interactive buttons that arrive as isMetaAction but
  // must still be routed through continueTwilioFlow when inside a rb_* state.
  // Without this, rb_acct_*, rb_tenant_*, rb_period_*, rb_pay_method_* button
  // taps are swallowed here and never reach the twilioStateBridge state handlers.
  if (
    isMetaAction && biz &&
    biz.sessionState?.startsWith("rb_") &&
    (
      a?.startsWith("rb_acct_")    ||
      a?.startsWith("rb_tenant_")  ||
      a?.startsWith("rb_period_")  ||
      a?.startsWith("rb_pay_method_") ||
      a === "rb_vacate_yes"           ||
      a === "rb_expense_save"         ||
      a === "rb_period_all"        ||
      a === "rb_period_custom"     ||
      a?.startsWith("rb_more_")     ||
      a === "recurring_billing_menu"
    )
  ) {
    const handled = await continueTwilioFlow({ from, text: a });
    if (handled) return;
  }

  // ── Stock report: the period list ("This month" / "All Time" / "Custom") ──
  // arrives as an interactive list_reply (isMetaAction=true), so it never hits
  // the !isMetaAction bridge handoff above. Route it in explicitly, same as the
  // rb_ block, or the report picker does nothing and the reply looks empty.
  if (
    isMetaAction && biz &&
    biz.sessionState === "stock_report_period" &&
    a?.startsWith("stock_period_")
  ) {
    const handled = await continueTwilioFlow({ from, text: a });
    if (handled) return;
  }

  // ── Buyer: free-text product search ──────────────────────────────────────
if (biz?.sessionState === "supplier_search_product" && !isMetaAction) {
  const rawQuery = text.trim();
  const productQuery = rawQuery.replace(/^find\s+/i, "").trim();

  if (!productQuery || productQuery.length < 1) {
    return sendButtons(from, {
      text: "❌ Please type what you're looking for.\n\nExample:\n_find valve brass_",
      buttons: [{ id: "find_supplier", title: "⬅ Back" }]
    });
  }

  // ── Parse location out of the free-text query ──────────────────────────
  const parsed = parseShortcodeSearch(rawQuery) || { product: productQuery, city: null, area: null };
  const cleanProduct = String(parsed.product || productQuery).trim();

  // ── If city/area was already in the query, search immediately ──────────
  if (parsed.city || parsed.area) {
    const locationLabel = parsed.area ? `${parsed.area}, ${parsed.city}` : parsed.city;
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierSearch: { ...(biz.sessionData?.supplierSearch || {}), product: cleanProduct, city: parsed.city }
    };
    biz.sessionState = "ready";
    await saveBizSafe(biz);

    // ── Step 1: Check for a single direct business-name match first ──────────
    // Mirrors the working sup_search_city_* flow: if exactly 1 supplier's
    // businessName matches the query, open their shopping hub directly.
    const allSupplierResults = await runSupplierSearch({
      city: parsed.city || null,
      product: cleanProduct,
      area: parsed.area || null
    });

    const normalizedQuery = normalizeProductName(cleanProduct);
    const directBusinessMatches = allSupplierResults.filter(s => {
      const bn = normalizeProductName(s.businessName || "");
      return bn === normalizedQuery || bn.includes(normalizedQuery);
    });

    if (directBusinessMatches.length === 1) {
      const supplier = directBusinessMatches[0];
      const cart = await getCurrentOrderCart({ biz, phone });
      await persistOrderFlowState({
        biz,
        phone,
        patch: {
          orderSupplierId: String(supplier._id),
          orderBrowseMode: "catalogue",
          orderCataloguePage: 0,
          orderCatalogueSearch: ""
        }
      });
      return _sendSupplierShoppingHub(from, supplier, cart);
    }

    // ── Step 2: Not a single business-name match - run offer-first search ────
    let offerResults = await runSupplierOfferSearch({ city: parsed.city || null, product: cleanProduct, area: null });

    // Retry across all cities if city-level returns nothing
    if (!offerResults.length) {
      offerResults = await runSupplierOfferSearch({ city: null, product: cleanProduct, area: null });
    }

    if (offerResults.length) {
      biz.sessionData = {
        ...(biz.sessionData || {}),
        supplierSearch: { ...(biz.sessionData?.supplierSearch || {}), product: cleanProduct, city: parsed.city },
        searchResults: offerResults,
        searchPage: 0,
        searchResultMode: "offers"
      };
      await saveBizSafe(biz);
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { "tempData.searchResults": offerResults, "tempData.searchPage": 0, "tempData.searchResultMode": "offers" } },
        { upsert: true }
      );
      const pageOffers = offerResults.slice(0, 9);
      const rows = formatSupplierOfferResults(pageOffers, cleanProduct);
      if (offerResults.length > 9) {
        rows.push({ id: "sup_search_next_page", title: `➡ More results (${offerResults.length - 9} more)` });
      }
      return sendNumberedSellerResults({ from, phone, offers: offerResults, searchTerm: cleanProduct, locationLabel });
    }

    // ── Step 3: No offers - fall back to supplier cards ──────────────────────
    if (!allSupplierResults.length) {
      return sendButtons(from, {
        text: `😕 No results for *${cleanProduct}* in *${locationLabel}*.\n\nTry a different city or search all of Zimbabwe?`,
        buttons: [
          { id: "sup_search_city_all", title: "📍 Search All Cities" },
          { id: "find_supplier", title: "🔍 Search Again" }
        ]
      });
    }

    const pageResults = allSupplierResults.slice(0, 9);
    const rows = formatSupplierResults(pageResults, parsed.city || parsed.area || "", cleanProduct);
    if (allSupplierResults.length > 9) {
      biz.sessionData = { ...(biz.sessionData || {}), searchResults: allSupplierResults, searchPage: 0, searchResultMode: "suppliers" };
      rows.push({ id: "sup_search_next_page", title: `➡ More results (${allSupplierResults.length - 9} more)` });
      await saveBizSafe(biz);
    }
    return sendNumberedSellerResults({ from, phone, suppliers: allSupplierResults, searchTerm: cleanProduct, locationLabel });
  }

  // ── No location found - ask for city ───────────────────────────────────
  biz.sessionData = {
    ...(biz.sessionData || {}),
    supplierSearch: { ...(biz.sessionData?.supplierSearch || {}), product: cleanProduct }
  };
  biz.sessionState = "supplier_search_city";
  await saveBizSafe(biz);

  return sendList(from, `🔍 Looking for: *${cleanProduct}*\n\nWhich city?`, [
    ...SUPPLIER_CITIES.slice(0, 9).map(c => ({
      id: `sup_search_city_${c.toLowerCase().replace(/\s+/g, '_')}`,
      title: c
    })),
    { id: "sup_search_city_all", title: "📍 All Cities" }
  ]);
}

  // ── Buyer order: product name text input ──────────────────────────────────
if (biz?.sessionState === "supplier_order_product" && !isMetaAction) {
  const parsedItems = parseBulkOrderInput(text);

  if (!parsedItems.length || parsedItems.every(i => !i.valid)) {
   return sendText(from,
`❌ Please enter your order in this format:

*product qty, product qty*

Examples:
*sugar 2, bread 3, milk 1*
*cement 10, river sand 2*

You can also send one per line.

Type *cancel* to stop this order.`);
  }

  const _sidBiz = biz.sessionData?.orderSupplierId;
  const _supBiz = _sidBiz ? await SupplierProfile.findById(_sidBiz).lean() : null;
  const isServiceSupplier = _supBiz?.profileType === "service";
 const _needsAddressBiz = (isServiceSupplier && _supBiz?.travelAvailable) || (!isServiceSupplier && _supBiz?.delivery?.available === true);

  const preview = parsedItems
    .map(i => `• ${i.product} x${i.quantity}${i.unitLabel && i.unitLabel !== "units" ? " " + i.unitLabel : ""}`)
    .join("\n");

  if (!_needsAddressBiz && _supBiz) {
    // Collection-only: submit immediately, no address needed
    let totalAmount = 0; let pricedCount = 0;
    const finalItems = parsedItems.filter(i => i.valid).map(entry => {
      const quantity = Number(entry.quantity) || 1;
      const matchedPrice = findMatchingSupplierPrice(_supBiz, entry.product);
      let pricePerUnit = null, total = null, finalUnit = entry.unitLabel || "units";
      if (matchedPrice && typeof matchedPrice.amount === "number") {
        pricePerUnit = matchedPrice.amount;
        total = quantity * matchedPrice.amount;
        finalUnit = matchedPrice.unit || finalUnit;
        totalAmount += total; pricedCount++;
      }
      return { product: entry.product, quantity, unit: finalUnit, pricePerUnit, currency: "USD", total };
    });

    const order = await SupplierOrder.create({
      supplierId: _supBiz._id, supplierPhone: _supBiz.phone,
      buyerPhone: phone, items: finalItems, totalAmount, currency: "USD",
      delivery: { required: false, address: "Collection" }, status: "pending"
    });
    await notifySupplierNewOrder(_supBiz.phone, order);

    biz.sessionState = "ready"; biz.sessionData = {};
    await saveBizSafe(biz);

    const itemSummary = finalItems.map(i => `• ${i.product} x${i.quantity}`).join("\n");
    await sendText(from,
`✅ *Order sent to ${_supBiz.businessName}!*

${itemSummary}
🏠 *Collection only* - contact the supplier to arrange pickup
${pricedCount > 0 ? `💵 Estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Supplier: ${_supBiz.phone}

${pricedCount === finalItems.length ? "All items were auto-priced. Supplier can confirm immediately. 🎉" : "Supplier will confirm pricing shortly. 🎉"}`);
    return sendButtons(from, {
      text: "What would you like to do next?",
      buttons: [
        { id: "find_supplier", title: "🔍 Browse & Shop" },
        { id: "my_orders", title: "📋 My Orders" },
        { id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }
      ]
    });
  }

  // Delivery/service: ask for address
  biz.sessionData = { ...(biz.sessionData || {}), orderItems: parsedItems };
  biz.sessionState = "supplier_order_address";
  await saveBizSafe(biz);

return sendButtons(from, {
  text:
`${isServiceSupplier ? "📅" : "🛒"} *${isServiceSupplier ? "Booking Summary" : "Order Summary"}*

${preview}

─────────────────
⚠️ *Your ${isServiceSupplier ? "booking" : "order"} has NOT been sent yet.*
─────────────────

*Step 2 of 2 - Enter your ${isServiceSupplier ? "location" : "delivery address"}* 👇

${isServiceSupplier
  ? `📍 *Add a contact note for the provider:*\n\nExamples:\n• _Call me on arrival_\n• _Preferred time: Mon 10am_\n• _+263 7XX XXX XXX_`
  : `📍 *Where should we deliver?*\n\nExamples:\n• _123 Samora Machel Ave, Harare_\n• _Deliver to Avondale after 4pm_\n• _I will collect - call me_`
}

_Type your address below and send to complete your ${isServiceSupplier ? "booking" : "order"}_ ✍️`,
 buttons: [
    ...(isServiceSupplier ? [{ id: `sup_skip_note_${supplierId}`, title: "⏭ Skip & Send" }] : []),
    { id: "find_supplier", title: "❌ Cancel Order" }
  ].slice(0, 3)
});
}

  // ── Buyer order: quantity text input ──────────────────────────────────────


  // ── Buyer order: address / contact note text input ────────────────────────
const _addrSess = await UserSession.findOne({ phone });
const _addrViaSess = !biz && _addrSess?.tempData?.orderState === "supplier_order_address";

if ((biz?.sessionState === "supplier_order_address" || _addrViaSess) && !isMetaAction) {
  const address = text.trim();
  if (!address || address.length < 2) {
    return sendText(from, `❌ Please enter your delivery address or contact note:\n\nType *cancel* to stop this order.`);
  }

  const supplierId = biz?.sessionData?.orderSupplierId
    || _addrSess?.tempData?.orderSupplierId;
  const orderItemsInput = biz?.sessionData?.orderCart?.length
    ? biz.sessionData.orderCart
    : _addrSess?.tempData?.orderCart?.length
      ? _addrSess.tempData.orderCart
      : (biz?.sessionData?.orderItems || []);

    if (!supplierId) {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Order session expired. Please search for the supplier again.");
      return sendMainMenu(from);
    }

    const supplier = await SupplierProfile.findById(supplierId).lean();
    if (!supplier) {
      biz.sessionState = "ready"; biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Supplier not found. Please search again.");
      return sendSuppliersMenu(from);
    }

//const qtyNum = isNaN(Number(orderQty)) ? null : Number(orderQty);
const normalizedItems = Array.isArray(orderItemsInput) ? orderItemsInput : [];
if (!normalizedItems.length) {
  biz.sessionState = "ready";
  biz.sessionData = {};
  await saveBizSafe(biz);
  await sendText(from, "❌ Order session expired. Please start again.");
  return sendSuppliersMenu(from);
}

let totalAmount = 0;
let pricedCount = 0;

const finalItems = normalizedItems.map(entry => {
  const quantity = Number(entry.quantity) || 1;
  const requestedUnit = entry.unitLabel || "units";
  const matchedPrice = findMatchingSupplierPrice(supplier, entry.product);

  let pricePerUnit = null;
  let total = null;
  let finalUnit = requestedUnit;

  if (matchedPrice && typeof matchedPrice.amount === "number") {
    pricePerUnit = matchedPrice.amount;
    total = quantity * matchedPrice.amount;
    finalUnit = matchedPrice.unit || requestedUnit;
    totalAmount += total;
    pricedCount++;
  }

  return {
    product: entry.product,
    quantity,
    unit: finalUnit,
    pricePerUnit,
    currency: "USD",
    total
  };
});

const order = await SupplierOrder.create({
  supplierId: supplier._id,
  supplierPhone: supplier.phone,
  buyerPhone: phone,
  items: finalItems,
  totalAmount,
  currency: "USD",
  delivery: {
    required: supplier.delivery?.available || false,
    address
  },
  status: "pending"
});
   await notifySupplierNewOrder(supplier.phone, order);
    if (biz) { biz.sessionState = "ready"; biz.sessionData = {}; await saveBizSafe(biz); }
    await UserSession.findOneAndUpdate(
      { phone },
      { $unset: { "tempData.orderState": "", "tempData.orderSupplierId": "", "tempData.orderCart": "", "tempData.orderIsService": "" } }
    );

const itemSummary = finalItems
  .map(i => `• ${i.product} x${i.quantity}${i.unit && i.unit !== "units" ? " " + i.unit : ""}`)
  .join("\n");

const isServiceSupplier = supplier.profileType === "service";

await sendText(from,
`✅ *${isServiceSupplier ? "Booking sent to" : "Order sent to"} ${supplier.businessName}!*

${itemSummary}
${isServiceSupplier ? `📍 Location/Note: ${address}` : `📍 ${address}`}
${pricedCount > 0 ? `💵 Current estimated total: $${totalAmount.toFixed(2)}\n` : ""}📞 Supplier: ${supplier.phone}

${pricedCount === finalItems.length
  ? `${isServiceSupplier ? "All services were auto-priced. Supplier can confirm immediately. 🎉" : "All items were auto-priced. Supplier can confirm immediately. 🎉"}`
  : pricedCount > 0
    ? `${isServiceSupplier ? "Some services were auto-priced. Supplier will confirm the rest. 🎉" : "Some items were auto-priced. Supplier will confirm the rest. 🎉"}`
    : `${isServiceSupplier ? "Supplier will confirm pricing for the booking shortly. 🎉" : "Supplier will confirm pricing shortly. 🎉"}`}`);

return sendButtons(from, {
  text: "What would you like to do next?",
  buttons: [
    { id: "find_supplier", title: "🔍 Browse & Shop" },
    { id: "my_orders", title: "📋 My Orders" },
    { id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }
  ]
});

  }

  // ── Accept order ──────────────────────────────────────────────────────────
  if (a.startsWith("sup_accept_")) {
    const orderId = a.replace("sup_accept_", "");
    return handleOrderAccepted(from, orderId, biz, saveBizSafe);
  }

 if (a.startsWith("sup_book_confirm_")) {
    const orderId = a.replace("sup_book_confirm_", "");
    await handleBookingAccepted(from, orderId);
    return;
  }
  // ── Decline order ─────────────────────────────────────────────────────────
if (a.startsWith("sup_decline_")) {
    const orderId = a.replace("sup_decline_", "");
    return handleOrderDeclined(from, orderId, biz, saveBizSafe);
  }

  // ── Decline reason selected ────────────────────────────────────────────────
  if (
    a === "dec_out_of_stock" ||
    a === "dec_min_not_met"  ||
    a === "dec_no_delivery"  ||
    a === "dec_price_changed"||
    a === "dec_other"
  ) {
    const reasonMap = {
      dec_out_of_stock:  "Out of stock",
      dec_min_not_met:   "Minimum order not met",
      dec_no_delivery:   "Cannot deliver to area",
      dec_price_changed: "Price has changed",
      dec_other:         "Unable to fulfill"
    };
    const reason = reasonMap[a] || "Declined";
    const orderId = biz?.sessionData?.declineOrderId;

    if (!orderId) {
      await sendText(from, "❌ Session expired. Please try again.");
      return sendMainMenu(from);
    }

    const SupplierOrder = (await import("../models/supplierOrder.js")).default;
    const order = await SupplierOrder.findById(orderId);

    if (!order) {
      await sendText(from, "❌ Order not found.");
      return sendMainMenu(from);
    }

    order.status = "declined";
    order.declineReason = reason;
    await order.save();

    // Notify buyer
    try {
      await sendButtons(order.buyerPhone, {
        text:
          `❌ *Order Declined*\n\n` +
          `Your order has been declined.\n` +
          `*Reason:* ${reason}\n\n` +
          `You can search for another supplier.`,
        buttons: [
          { id: "find_supplier", title: "🔍 Find Another" },
          { id: "suppliers_home", title: "🛒 Marketplace" }
        ]
      });
    } catch (err) {
      console.error("[DECLINE NOTIFY BUYER]", err.message);
    }

    // Reset supplier session
    if (biz) {
      biz.sessionState = "ready";
      biz.sessionData  = {};
      await saveBizSafe(biz);
    }

    return sendButtons(from, {
      text: `✅ Order declined.\n*Reason sent to buyer:* ${reason}`,
      buttons: [
        { id: "my_supplier_account", title: "🏪 My Store" },
        { id: ACTIONS.MAIN_MENU,     title: "🏠 Main Menu" }
      ]
    });
  }


  if (a.startsWith("sup_biz_cur_")) {
  const currency = a.replace("sup_biz_cur_", "").toUpperCase();
  if (!["USD", "ZWL", "ZAR"].includes(currency)) return true;
  if (!biz) return sendMainMenu(from);

  biz.sessionData.supplierReg = biz.sessionData.supplierReg || {};
  biz.sessionData.supplierReg.currency = currency;

  // Pre-fill the Business name and currency from supplier reg data
  const reg = biz.sessionData.supplierReg;
  if (reg.businessName && !biz.name) {
    biz.name = reg.businessName;
  }
  biz.currency = currency;
  biz.isSupplier = true;
  biz.sessionState = "supplier_reg_confirm";
  await saveBizSafe(biz);

  const isService = reg.profileType === "service";
  const itemCount = (reg.products || []).filter(p => p && p !== "pending_upload").length;

  return sendButtons(from, {
    text:
`📋 *Confirm your listing*\n\n🏢 *${reg.businessName}*\n📍 ${reg.city || "-"}, ${reg.area || "-"}\n📦 Type: ${isService ? "Services" : "Products"} (${itemCount} items)\n💱 Currency: *${currency}*\n\n✅ Once you pay, your business listing goes live AND your invoicing/quoting tools unlock automatically.\n\nIs everything correct?`,
    buttons: [
      { id: "sup_confirm_yes", title: "✅ Confirm & Continue" },
      { id: "sup_confirm_no",  title: "✏️ Edit Details" }
    ]
  });
}

if (biz?.sessionState === "supplier_order_enter_price" && !isMetaAction) {
    const orderId = biz.sessionData?.pricingOrderId;
    if (!orderId) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Pricing session expired. Please check your orders.");
      return sendSuppliersMenu(from);
    }

    const order = await SupplierOrder.findById(orderId);
    if (!order) {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Order not found.");
      return sendSuppliersMenu(from);
    }

    const isServiceSupplier = (await SupplierProfile.findOne({ phone: from }).lean())?.profileType === "service";

   const raw = (text || "").trim();

const missingIndexes = biz.sessionData?.pricingMissingIndexes || [];
const pricingTargets = missingIndexes.map(idx => order.items[idx]).filter(Boolean);

// Use one consistent display name everywhere in this pricing step
const getPricingItemName = (item, idx) => {
  const name = String(item?.product || "").trim();
  if (name) return name;

  // Better fallback than plain "Item"
  return `Item #${idx + 1}`;
};

    // ── Handle cancel ────────────────────────────────────────────────────────
    if (raw.toLowerCase() === "cancel") {
      biz.sessionState = "ready";
      biz.sessionData = {};
      await saveBizSafe(biz);
      await sendText(from, "❌ Pricing cancelled. The order is still pending.");
      return sendSuppliersMenu(from);
    }

if (!raw) {
  await sendText(from,
    pricingTargets.length === 1
      ? `❌ Please enter the price per unit.\n\nExample: *12* (means $12 per unit)`
      : `❌ Please enter ${pricingTargets.length} prices separated by commas.\n\nExample: *12, 45, 0.08*`
  );
  return;
}

    // ── Parse the entered values ─────────────────────────────────────────────
    const values = raw
      .split(",")
      .map(v => Number(v.trim()))
      .filter(v => !Number.isNaN(v) && v >= 0);

    if (!values.length) {
  await sendText(from,
    `❌ Couldn't read your prices. Use numbers only, separated by commas.\n\n` +
    `Example for ${pricingTargets.length} item${pricingTargets.length > 1 ? "s" : ""}: ` +
    `*${pricingTargets.map((_, i) => ((i + 1) * 5 + 7)).join(", ")}*`
  );
  return;
}

    // ── Wrong count ───────────────────────────────────────────────────────────
if (values.length !== pricingTargets.length) {
  const itemList = pricingTargets.map((item, i) => {
    const qty = Number(item.quantity) || 1;
    const unitLabel = item.unit && item.unit !== "units"
      ? item.unit
      : (isServiceSupplier ? "job" : "unit");

    return `${i + 1}. ${getPricingItemName(item, i)} × ${qty} ${unitLabel}`;
  }).join("\n");

  await sendText(from,
    `❌ You still need to price *${pricingTargets.length} item${pricingTargets.length > 1 ? "s" : ""}* but sent *${values.length} price${values.length > 1 ? "s" : ""}*.\n\n` +
    `Items to price:\n${itemList}\n\n` +
    `Send exactly *${pricingTargets.length}* price${pricingTargets.length > 1 ? "s" : ""}, one per item, in order.\n` +
    `Example: *${pricingTargets.map((_, i) => ((i + 1) * 5 + 7)).join(", ")}*`
  );
  return;
}
    // ── Build preview -show the supplier exactly what they entered and what it means ──
    // This is the key UX fix: show "per unit × qty = line total" BEFORE saving
  let previewGrandTotal = 0;
const previewLines = pricingTargets.map((item, idx) => {
  const unitPrice = values[idx];
  const qty = Number(item.quantity) || 1;
  const lineTotal = unitPrice * qty;
  previewGrandTotal += lineTotal;

  const unitLabel = item.unit && item.unit !== "units"
    ? item.unit
    : (isServiceSupplier ? "job" : "unit");

  return `${idx + 1}. *${getPricingItemName(item, idx)}*\n   $${unitPrice.toFixed(2)} per ${unitLabel} × ${qty} = *$${lineTotal.toFixed(2)}*`;
}).join("\n\n");

    // ── Save preview to sessionData so the confirm handler can use it ─────────
    biz.sessionData = {
      ...biz.sessionData,
      pendingPrices: values,
      pricingOrderId: orderId
    };
    biz.sessionState = "supplier_order_confirm_price";
    await saveBizSafe(biz);

 // ── Delivery line for price summary ───────────────────────────────────────
    const previewDeliveryLine = order.delivery?.required
      ? `🚚 *Deliver to:* ${order.delivery.address}`
      : isServiceSupplier
        ? `📍 *Service location:* ${order.delivery?.address || "TBC"}`
        : `🏠 *Collection* (buyer will pick up)`;

    return sendButtons(from, {
      text:
        `💰 *Price Summary -Please Confirm*\n` +
        `_Buyer: ${order.buyerPhone}_\n\n` +
        `─────────────────\n` +
        `${previewLines}\n\n` +
        `─────────────────\n` +
        `${previewDeliveryLine}\n` +
        `💵 *Order Total: $${previewGrandTotal.toFixed(2)}*\n\n` +
        `Does this look correct?\n` +
        `_Tap ✅ Confirm to accept the order at these prices._`,
      buttons: [
        { id: "sup_price_confirm_yes", title: "✅ Confirm & Accept" },
        { id: "sup_price_confirm_no",  title: "✏️ Re-enter Prices" },
        { id: "suppliers_home",        title: "⬅ Cancel" }
      ]
    });
  }
  // ── ETA after accepting order ─────────────────────────────────────────────
  if (a.startsWith("sup_eta_")) {
    const parts = a.replace("sup_eta_", "").split("_");
    const orderId = parts[parts.length - 1];
    const etaLabel = parts.slice(0, -1).join(" ");

    const order = await SupplierOrder.findById(orderId);
    if (order) {
      order.supplierNote = etaLabel;
      await order.save();

      await sendButtons(order.buyerPhone, {
        text: `📅 *Order Update*\n\nYour order from the supplier\nwill be ready: *${etaLabel}*\n\n📞 ${from}`,
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }

    await sendText(from, `✅ Buyer notified. Ready: ${etaLabel}`);
    return;
  }

  // ── Supplier plan selection ───────────────────────────────────────────────
if (a.startsWith("sup_plan_")) {
    const parts = a.replace("sup_plan_", "").split("_");
    const tier = parts[0];
    const plan = parts[1];

    const planDetails = SUPPLIER_PLANS[tier]?.[plan];
    if (!planDetails) {
      await sendText(from, "❌ Invalid plan selected.");
      return sendSuppliersMenu(from);
    }

    // Ensure we have a biz session to track payment state
    if (!biz) {
      await sendText(from, "❌ Session expired. Please type *menu* and try again.");
      return;
    }

    // Store plan details and move to EcoCash entry state
    biz.sessionData = {
      ...(biz.sessionData || {}),
      supplierPayment: {
        tier,
        plan,
        amount: planDetails.price,
        currency: planDetails.currency,
        durationDays: planDetails.durationDays,
        supplierId: biz.sessionData?.pendingSupplierId || null
      }
    };
    biz.sessionState = "supplier_reg_enter_ecocash";
    await saveBizSafe(biz);

    const waDigits = from.replace(/\D+/g, "");
    return sendText(from,
`💳 *${SUPPLIER_PLANS[tier].name} Plan - $${planDetails.price} ${planDetails.currency} (${plan})*

To pay, enter your EcoCash number:
*Example: 0772123456*

Or type *same* to use this WhatsApp number (${waDigits}).

_Type *cancel* to go back._`
    );
  }

  // ── Rate order ────────────────────────────────────────────────────────────
  if (a.startsWith("rate_")) {
    const parts = a.split("_");
    // rate_poor_ORDERID / rate_ok_ORDERID / rate_great_ORDERID
    if (parts.length >= 3 && ["poor", "ok", "great"].includes(parts[1])) {
      const rating = parts[1] === "poor" ? 1 : parts[1] === "ok" ? 3 : 5;
      const orderId = parts.slice(2).join("_");
      const order = await SupplierOrder.findById(orderId);
      if (order) {
        order.buyerRating = rating;
        await order.save();
        const supplier = await SupplierProfile.findOne({ phone: order.supplierPhone });
        if (supplier) {
          const totalRatings = supplier.reviewCount + 1;
          supplier.rating = ((supplier.rating * supplier.reviewCount) + rating) / totalRatings;
          supplier.reviewCount = totalRatings;
          await supplier.save();
          await updateSupplierCredibility(supplier._id);
        }
      }
      await sendText(from, "⭐ Thanks for your rating!");
      return;
    }
  }

  // ── Suppliers menu ────────────────────────────────────────────────────────
  if (a === ACTIONS.SUPPLIERS_MENU || a === "suppliers_menu") {
    return sendSuppliersMenu(from);
  }

  // ─────────────────────────────────────────────────────────────────────────

  switch (a) {

    case ACTIONS.SALES_MENU:
      return sendSalesMenu(from);

    case ACTIONS.CLIENTS_MENU:
      return sendClientsMenu(from);

    case ACTIONS.PAYMENTS_MENU:
      return sendPaymentsMenu(from);

    case ACTIONS.CASH_BALANCE_MENU: {
      const { sendCashBalanceMenu } = await import("./metaMenus.js");
      return sendCashBalanceMenu(from);
    }

    // ─── VIEW CASH BALANCE ──────────────────────────────────────────────────
    case ACTIONS.VIEW_CASH_BALANCE: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") {
        const branches = await Branch.find({ businessId: biz._id }).lean();
        if (!branches.length) { await sendText(from, "❌ No branches found."); return sendMainMenu(from); }
        biz.sessionData = { ...(biz.sessionData || {}), cashBalAction: "view" };
        await saveBizSafe(biz);
        return sendList(from, "🏬 Select branch to view balance:", [
          ...branches.map(b => ({ id: `cashbal_branch_${b._id}`, title: `🏬 ${b.name}` })),
          { id: "cashbal_branch_all", title: "📊 All Branches" }
        ]);
      }
      if (!caller?.branchId) { await sendText(from, "❌ No branch assigned. Contact your manager."); return sendMainMenu(from); }
      return showBranchCashBalance(from, biz, caller.branchId.toString());
    }

    // ─── SET OPENING BALANCE ────────────────────────────────────────────────
    case ACTIONS.SET_OPENING_BALANCE: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") {
        const branches = await Branch.find({ businessId: biz._id }).lean();
        if (!branches.length) { await sendText(from, "❌ No branches found."); return sendMainMenu(from); }
        biz.sessionData = { ...(biz.sessionData || {}), cashBalAction: "set_opening" };
        await saveBizSafe(biz);
        return sendList(from, "🏬 Select branch to set opening balance:", [
          ...branches.map(b => ({ id: `cashbal_branch_${b._id}`, title: `🏬 ${b.name}` }))
        ]);
      }
      if (!caller?.branchId) { await sendText(from, "❌ No branch assigned. Contact your manager."); return sendMainMenu(from); }

      const CashBalance = (await import("../models/cashBalance.js")).default;
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const existing = await CashBalance.findOne({ businessId: biz._id, branchId: caller.branchId, date: today }).lean();

      if (existing && existing.openingBalance > 0) {
        await sendText(from, `⚠️ Opening balance already set for today: *${existing.openingBalance} ${biz.currency}*\n\nContact your manager to change it.`);
        const { sendCashBalanceMenu } = await import("./metaMenus.js");
        return sendCashBalanceMenu(from);
      }

      biz.sessionState = "cash_set_opening_balance";
      biz.sessionData = { targetBranchId: caller.branchId.toString() };
      await saveBizSafe(biz);
      return sendButtons(from, { text: `📝 *Set Opening Balance*\n\nEnter the amount of cash in the till at the start of today:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    }

    // ─── RECORD PAYOUT ──────────────────────────────────────────────────────
    case ACTIONS.RECORD_PAYOUT: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") {
        const branches = await Branch.find({ businessId: biz._id }).lean();
        if (!branches.length) { await sendText(from, "❌ No branches found."); return sendMainMenu(from); }
        biz.sessionData = { ...(biz.sessionData || {}), cashBalAction: "payout" };
        await saveBizSafe(biz);
        return sendList(from, "🏬 Select branch to record payout:", [
          ...branches.map(b => ({ id: `cashbal_branch_${b._id}`, title: `🏬 ${b.name}` }))
        ]);
      }
      if (!caller?.branchId) { await sendText(from, "❌ No branch assigned. Contact your manager."); return sendMainMenu(from); }
      biz.sessionState = "cash_payout_amount";
      biz.sessionData = { targetBranchId: caller.branchId.toString() };
      await saveBizSafe(biz);
      return sendButtons(from, { text: `💸 *Record Payout/Drawing*\n\nEnter the amount taken out of the till:`, buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    }

    case ACTIONS.RECORD_HANDOVER: {
      if (!biz) return sendMainMenu(from);
      // Owner with multiple branches → pick branch first
      if (caller?.role === "owner") {
        const branches = await Branch.find({ businessId: biz._id }).lean();
        if (branches.length > 1) {
          biz.sessionData = { ...(biz.sessionData || {}), cashBalAction: "handover" };
          await saveBizSafe(biz);
          return sendList(from, "🏬 Select branch for handover:", [
            ...branches.map(b => ({ id: `cashbal_branch_${b._id}`, title: `🏬 ${b.name}` }))
          ]);
        }
        // Single branch owner - skip picker
        const branchId = branches[0]?._id?.toString() || null;
        biz.sessionState = "cash_handover_amount";
        biz.sessionData  = { targetBranchId: branchId };
        await saveBizSafe(biz);
        return sendButtons(from, {
          text: "🔄 *Shift Cash Handover*\n\nCount the cash in the till and enter the total amount:",
          buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
        });
      }
      // Clerk / manager - use their assigned branch
      if (!caller?.branchId) {
        await sendText(from, "❌ No branch assigned. Contact your manager.");
        return sendMainMenu(from);
      }
      biz.sessionState = "cash_handover_amount";
      biz.sessionData  = { targetBranchId: caller.branchId.toString() };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: "🔄 *Shift Cash Handover*\n\nCount the cash in the till and enter the total amount:",
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }

  case ACTIONS.REPORTS_MENU: {
      if (!biz) return sendMainMenu(from);

      // Allow reports for all active paid packages (bronze/silver/gold/enterprise)
      // Trial only gets blocked
      const PAID_PACKAGES = ["bronze", "silver", "gold", "enterprise"];
      const hasPaidPackage = PAID_PACKAGES.includes(biz.package);
      const isActive = biz.subscriptionStatus === "active";

      if (!hasPaidPackage || !isActive) {
        return promptUpgrade({ biz, from, feature: "Reports" });
      }

      biz.sessionState = "reports_menu"; biz.sessionData = {}; await saveBizSafe(biz);
      const isGold   = biz.package === "gold"   || biz.package === "enterprise";
      const isSilver = biz.package === "silver"  || isGold;
      return sendReportsMenu(from, isGold, isSilver);
    }

case "overall_reports": {
      if (!biz) return sendMainMenu(from);
      const { sendOverallReportsMenu } = await import("./metaMenus.js");
      const isGold   = ["gold", "enterprise"].includes(biz.package);
      const isSilver = ["silver", "gold", "enterprise"].includes(biz.package);
      return sendOverallReportsMenu(from, isGold, isSilver);
    }

    case "branch_reports": {
      if (!biz) return sendMainMenu(from);
      const { sendBranchReportsMenu } = await import("./metaMenus.js");
      const isGold   = ["gold", "enterprise"].includes(biz.package);
      const isSilver = ["silver", "gold", "enterprise"].includes(biz.package);
      return sendBranchReportsMenu(from, isGold, isSilver);
    }

    case "branch_reports": {
      if (!biz) return sendMainMenu(from);
      const { sendBranchReportsMenu } = await import("./metaMenus.js");
      return sendBranchReportsMenu(from, biz.package === "gold");
    }

    case "branch_daily": {
      if (!biz) return sendMainMenu(from);
      biz.sessionState = "report_choose_branch"; biz.sessionData = { reportType: "daily" }; await saveBizSafe(biz);
      return continueTwilioFlow({ from, text: "auto" });
    }
    case "branch_weekly": {
      if (!biz) return sendMainMenu(from);
      biz.sessionState = "report_choose_branch"; biz.sessionData = { reportType: "weekly" }; await saveBizSafe(biz);
      return continueTwilioFlow({ from, text: "auto" });
    }
    case "branch_monthly": {
      if (!biz) return sendMainMenu(from);
      biz.sessionState = "report_choose_branch"; biz.sessionData = { reportType: "monthly" }; await saveBizSafe(biz);
      return continueTwilioFlow({ from, text: "auto" });
    }

    case ACTIONS.BUSINESS_PROFILE: {
      if (!biz) return sendMainMenu(from);
      await sendText(from, `🏢 *Business Profile*\n\nName: ${biz.name}\nCurrency: ${biz.currency}\nPackage: ${biz.package}`);
      return sendMainMenu(from);
    }

    case ACTIONS.USERS_MENU:
      return sendUsersMenu(from);

    case ACTIONS.INVITE_USER: {
      if (!biz) return sendMainMenu(from);
      if (!caller || caller.role !== "owner") return sendText(from, "🔒 Only the business owner can invite users.");
      const pkg = PACKAGES[biz.package] || PACKAGES.trial;
      if (!pkg.features.includes("users")) return promptUpgrade({ biz, from, feature: "User management" });
      const activeUsers = await UserRole.countDocuments({ businessId: biz._id, pending: false });
      if (activeUsers >= pkg.users) return sendText(from, `🚫 User limit reached (${pkg.users}).\n\nUpgrade your package to add more users.`);
      biz.sessionState = "invite_user_choose_branch"; biz.sessionData = {}; await saveBizSafe(biz);
      const branches = await Branch.find({ businessId: biz._id }).lean();
      if (!branches.length) { await sendText(from, "No branches found. Please add a branch first."); return sendBranchesMenu(from); }
      return sendList(from, "Select branch for new user", branches.map(b => ({ id: `invite_branch_${b._id}`, title: b.name })));
    }

    case ACTIONS.BRANCHES_MENU: {
      if (!biz) return sendMainMenu(from);
      const { canAccessSection } = await import("./roleGuard.js");
      if (!caller || !canAccessSection(caller.role, "branches")) return sendText(from, "🔒 You do not have permission to access branches.");
      return sendBranchesMenu(from);
    }

    case ACTIONS.ADD_BRANCH: {
      if (!biz) return sendMainMenu(from);
      if (!canUseFeature(biz, "branches")) return promptUpgrade({ biz, from, feature: "Branches" });
      const count = await Branch.countDocuments({ businessId: biz._id });
      const { branches } = (await import("./packages.js")).PACKAGES[biz.package];
      if (count >= branches) return sendText(from, `🚫 Branch limit reached (${branches}).\nUpgrade your package to add more branches.`);
      biz.sessionState = "branch_add_name"; await saveBizSafe(biz);
      return sendButtons(from, { text: "🏬 *Enter new branch name:*", buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }] });
    }

    case ACTIONS.VIEW_BRANCHES: {
      if (!biz) return sendMainMenu(from);
      const branches = await Branch.find({ businessId: biz._id }).lean();
      if (!branches.length) { await sendText(from, "No branches found."); return sendMainMenu(from); }
      let msg = "🏬 *Branches:*\n";
      branches.forEach((b, i) => { msg += `${i + 1}) ${b.name}\n`; });
      await sendText(from, msg);
      return sendMainMenu(from);
    }

    case ACTIONS.ASSIGN_BRANCH_USERS: {
      if (!biz) return sendMainMenu(from);
      const users = await UserRole.find({ businessId: biz._id, pending: false }).lean();
      if (!users.length) { await sendText(from, "No active users found."); return sendMainMenu(from); }
      biz.sessionState = "assign_branch_pick_user"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendList(from, "Select user", users.map(u => ({ id: `assign_user_${u._id}`, title: u.phone })));
    }

    case ACTIONS.VIEW_INVITES: {
      if (!biz) return sendMainMenu(from);
      const pending = await UserRole.find({ businessId: biz._id, pending: true }).populate("branchId");
      if (!pending.length) return sendText(from, "✅ No pending invitations.");
      let msg = "⏳ *Pending Invites:*\n";
      pending.forEach((u, i) => { msg += `${i + 1}) ${u.phone} | ${u.role} | ${u.branchId?.name || "N/A"}\n`; });
      return sendText(from, msg);
    }

    case ACTIONS.VIEW_USERS: {
      if (!biz) return sendMainMenu(from);
      const users = await UserRole.find({ businessId: biz._id, pending: false }).populate("branchId");
      if (!users.length) return sendText(from, "No active users found.");
      let msg = "👥 *Active Users:*\n";
      users.forEach((u, i) => { msg += `${i + 1}) ${u.phone} | ${u.role} | ${u.branchId?.name || "N/A"}${u.locked ? " 🔒" : ""}\n`; });
      return sendText(from, msg);
    }

    case ACTIONS.PAYMENT_IN: {
      if (!biz) return sendMainMenu(from);
      // Owner: pick a branch to show unpaid invoices from
      if (caller?.role === "owner") return sendBranchSelectorPaymentIn(from);
      await showUnpaidInvoices(from);
      return;
    }

case ACTIONS.PAYMENT_OUT: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorExpense(from);
      biz.sessionState = "expense_smart_entry";
      biz.sessionData  = { bulkExpenses: [] };
      await saveBizSafe(biz);
      return sendButtons(from, {
        text:
`💸 *Record Expenses*

Single:  _fuel 30_
Many:  _fuel 30, lunch 15, zesa 50_
With method:  _salary 850 bank_

Type *done* to save  ·  *cancel* to quit`,
        buttons: [
          { id: "exp_show_categories", title: "📂 Pick by Category" },
          { id: ACTIONS.MAIN_MENU,     title: "❌ Cancel" }
        ]
      });
    }

    case ACTIONS.BUSINESS_MENU: {
      if (!biz) return sendMainMenu(from);
      const { canAccessSection } = await import("./roleGuard.js");
      if (!caller || !canAccessSection(caller.role, "users")) return sendText(from, "🔒 You do not have permission to access Business & Users.");
      return sendBusinessMenu(from);
    }

    // ✅ OWNER ONLY - subscription menu
    case ACTIONS.SUBSCRIPTION_MENU: {
      if (!biz) return sendMainMenu(from);
      if (!caller || caller.role !== "owner") {
        return sendText(from, "🔒 Only the business owner can manage subscriptions.");
      }
      return sendSubscriptionMenu(from);
    }

    case ACTIONS.SETTINGS_MENU: {
      if (!biz) return sendMainMenu(from);
      const { canAccessSection } = await import("./roleGuard.js");
      if (!caller || !canAccessSection(caller.role, "settings")) return sendText(from, "🔒 You do not have permission to access Settings.");
      biz.sessionState = "settings_menu"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendSettingsMenu(from);
    }

    // ✅ OWNER ONLY - upgrade package
    case ACTIONS.UPGRADE_PACKAGE: {
      if (!biz) return sendMainMenu(from);
      if (!caller || caller.role !== "owner") return sendText(from, "🔒 Only the business owner can change the package.");
      biz.sessionState = "choose_package"; await saveBizSafe(biz);
      return sendPackagesMenu(from, biz.package);
    }

    case ACTIONS.BACK:
      return sendMainMenu(from);

    // ─── NEW INVOICE / QUOTE / RECEIPT ────────────────────────────────────
    case ACTIONS.NEW_INVOICE: {
      if (!biz) return sendMainMenu(from);
      // Owner picks which branch the invoice goes to
      if (caller?.role === "owner") return sendBranchSelectorNewDoc(from, "invoice");
      return startInvoiceFlow(from);
    }

    case ACTIONS.NEW_QUOTE: {
      if (!biz) return sendMainMenu(from);
      if (biz.package === "trial") return promptUpgrade({ biz, from, feature: "Quotes" });
      if (caller?.role === "owner") return sendBranchSelectorNewDoc(from, "quote");
      return startQuoteFlow(from);
    }

    case ACTIONS.NEW_RECEIPT: {
      if (!biz) return sendMainMenu(from);
      if (biz.package === "trial") return promptUpgrade({ biz, from, feature: "Receipts" });
      if (caller?.role === "owner") return sendBranchSelectorNewDoc(from, "receipt");
      return startReceiptFlow(from);
    }

    case ACTIONS.VIEW_INVOICES: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorInvoices(from);
      return showSalesDocs(from, "invoice");
    }

    case ACTIONS.VIEW_QUOTES: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorQuotes(from);
      return showSalesDocs(from, "quote");
    }

    case ACTIONS.VIEW_RECEIPTS: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorReceipts(from);
      return showSalesDocs(from, "receipt");
    }

case ACTIONS.ADD_CLIENT: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorAddClient(from);
      biz.sessionState = "adding_client_name";
      biz.sessionData = {};
      await saveBizSafe(biz);
      return sendButtons(from, {
        text: "👥 *Add Client*\n\nEnter client full name:",
        buttons: [{ id: ACTIONS.MAIN_MENU, title: "🏠 Main Menu" }]
      });
    }
    case ACTIONS.PRODUCTS_MENU:
      return sendProductsMenu(from);

     case ACTIONS.VIEW_PRODUCTS: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorProducts(from);
 
      const query = { businessId: biz._id, isActive: true };
      if (caller?.branchId) {
        query.$or = [{ branchId: caller.branchId }, { branchId: null }, { branchId: { $exists: false } }];
      }
 
      const allItems = await Product.find(query).sort({ isService: 1, name: 1 }).lean();
      if (!allItems.length) {
        await sendText(from, "📦 No products or services found.");
        return sendProductsMenu(from);
      }
 
      const products = allItems.filter(p => !p.isService);
      const services = allItems.filter(p => p.isService);
 
      let msg = `📦 *Products & Services (${allItems.length} total)*\n\n`;
 
      if (products.length) {
        msg += `*Products (${products.length}):*\n`;
        products.forEach((p, i) => {
          const price = p.unitPrice > 0 ? formatMoney(p.unitPrice, biz.currency) : "_(no price)_";
          msg += `${i + 1}. *${p.name}* - ${price}\n`;
        });
      }
 
      if (services.length) {
        if (products.length) msg += "\n";
        msg += `*Services (${services.length}):*\n`;
        services.forEach((p, i) => {
          const rate = p.unitPrice > 0 && p.rateUnit
            ? `${formatMoney(p.unitPrice, biz.currency)}/${p.rateUnit}`
            : p.unitPrice > 0 ? formatMoney(p.unitPrice, biz.currency) : "_(no rate)_";
          msg += `${products.length + i + 1}. *${p.name}* 🔧 - ${rate}\n`;
        });
      }
 
      await sendText(from, msg);
      return sendProductsMenu(from);
    }
 

    case ACTIONS.VIEW_CLIENTS: {
      if (!biz) return sendMainMenu(from);
      if (caller?.role === "owner") return sendBranchSelectorViewClients(from);
      return showClientsList(from, biz, caller?.branchId || null);
    }

    case ACTIONS.BULK_UPLOAD_PRODUCTS: {
      if (!biz) return sendMainMenu(from);
      biz.sessionState = "bulk_upload_products"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendText(from,
`📥 *Bulk upload (Products & Services)*

Send in ONE of these ways:

✅ Option A: Upload a CSV file
Columns: name, unitPrice

✅ Option B: Paste lines (one per item)
Format: Name - Price | Name | Price

Example:
Milk 1L - 1.50
Math Lesson | 10

Reply *done* when finished, or *cancel* to exit.`);
    }

    case ACTIONS.BULK_UPLOAD_MENU:
      return sendButtons(from, {
        text: "📋 *Bulk Paste (Products & Services)*\n\nPaste items (one per line).",
        buttons: [{ id: ACTIONS.BULK_PASTE_MODE, title: "📋 Paste list" }, { id: ACTIONS.BACK, title: "⬅ Back" }]
      });

    case ACTIONS.BULK_PASTE_MODE: {
      if (!biz) return sendMainMenu(from);
      biz.sessionState = "bulk_paste_input"; biz.sessionData = {}; await saveBizSafe(biz);
      return sendText(from,
`📋 *Bulk Add Products*

✅ Format: Name, Price | Name, Price

Example:
Milk 1L, 1.50 | Bread, 2 | Math Lesson, 10

Paste now, or reply *done* to finish.`);
    }

 case ACTIONS.BULK_EXPENSE_MODE: {
      if (!biz) return sendMainMenu(from);
      // Owner picks branch first
      if (caller?.role === "owner") return sendBranchSelectorBulkExpense(from);
      biz.sessionState = "bulk_expense_input"; 
      biz.sessionData = { bulkExpenses: [] }; 
      await saveBizSafe(biz);
      return sendText(from,
`💰 *Bulk Expense Mode*

Type expenses separated by commas:
*lunch 10, cables 5, transport 20*

Categories auto-detected ✨

*Commands:*
- 'list' - Show all
- 'remove 2' - Delete #2
- 'done' - Save all
- 'help' - More info`);
    }



    case ACTIONS.SUBSCRIPTION_PAYMENTS: {
      if (!biz) return sendMainMenu(from);
      if (caller && caller.role !== "owner") return sendText(from, "🔒 Only the business owner can view subscription payments.");
      const rows = await SubscriptionPayment.find({ businessId: biz._id }).sort({ createdAt: -1 }).limit(10).lean();
      if (!rows.length) { await sendText(from, "No subscription payments yet."); return sendSubscriptionMenu(from); }
      return sendList(from, "🧾 Subscription payments", rows.map(r => ({
        id: `subpay_${r._id}`,
        title: `${(r.packageKey || "").toUpperCase()} - ${r.amount} ${r.currency}`,
        description: `${r.status}${r.paidAt ? ` • ${new Date(r.paidAt).toDateString()}` : ""}`
      })));
    }

    case ACTIONS.VIEW_EXPENSE_RECEIPTS: {
      if (!biz) return sendMainMenu(from);
      // Owner: pick branch first
      if (caller?.role === "owner") return sendBranchSelectorViewExpenses(from);
      return showExpenseReceipts(from, biz, caller?.branchId || null);
    }

    case ACTIONS.VIEW_PAYMENT_HISTORY: {
      if (!biz) return sendMainMenu(from);
      // Owner: pick branch first
      if (caller?.role === "owner") return sendBranchSelectorPaymentHistory(from);
      return showPaymentHistory(from, biz, caller?.branchId || null);
    }

   case ACTIONS.MAIN_MENU:
      return sendMainMenu(from);

    case ACTIONS.SUPPLIERS_MENU:
      return sendSuppliersMenu(from);

    default: {
      // ── Sales doc branch selectors ─────────────────────────────────────────
      if (a === "view_all_invoices") return showSalesDocs(from, "invoice", null);
      // Paginated doc navigation: view_invoices_page_{branchId|all}_{page}
      if (a.startsWith("view_invoices_page_") || a.startsWith("view_quotes_page_") || a.startsWith("view_receipts_page_")) {
        const typeMap = { view_invoices_page_: "invoice", view_quotes_page_: "quote", view_receipts_page_: "receipt" };
        const prefix = Object.keys(typeMap).find(k => a.startsWith(k));
        const docType = typeMap[prefix];
        const rest = a.replace(prefix, "");
        const lastUnderscore = rest.lastIndexOf("_");
        const branchPart = rest.slice(0, lastUnderscore);
        const pageNum = parseInt(rest.slice(lastUnderscore + 1), 10) || 0;
        const branchId = branchPart === "all" ? null : branchPart;
        return showSalesDocs(from, docType, branchId, pageNum);
      }
      if (a.startsWith("view_invoices_branch_")) return showSalesDocs(from, "invoice", a.replace("view_invoices_branch_", ""));
      if (a === "view_all_quotes") return showSalesDocs(from, "quote", null);
      if (a.startsWith("view_quotes_branch_")) return showSalesDocs(from, "quote", a.replace("view_quotes_branch_", ""));
      if (a === "view_all_receipts") return showSalesDocs(from, "receipt", null);
      if (a.startsWith("view_receipts_branch_")) return showSalesDocs(from, "receipt", a.replace("view_receipts_branch_", ""));

      // ── Product branch selectors ───────────────────────────────────────────
if (a === "view_all_products" || a.startsWith("view_all_products_page_")) {
        if (!biz) return sendMainMenu(from);
        const products = await Product.find({ businessId: biz._id, isActive: true }).sort({ name: 1 }).lean();
        if (!products.length) { await sendText(from, "📦 No products found."); return sendProductsMenu(from); }
        const PAGE = 25;
        const page = a.startsWith("view_all_products_page_") ? parseInt(a.replace("view_all_products_page_", ""), 10) || 0 : 0;
        const totalPages = Math.ceil(products.length / PAGE);
        const slice = products.slice(page * PAGE, page * PAGE + PAGE);
        let msg = `📦 *All Products* - Page ${page + 1}/${totalPages} (${products.length} total)\n\n`;
        slice.forEach((p, i) => { msg += `${page * PAGE + i + 1}. *${p.name}* - ${formatMoney(p.unitPrice, biz.currency)}\n`; });
        await sendText(from, msg);
        const navBtns = [];
        if (page > 0)              navBtns.push({ id: `view_all_products_page_${page - 1}`, title: "⬅ Prev" });
        if (page < totalPages - 1) navBtns.push({ id: `view_all_products_page_${page + 1}`, title: "➡ Next" });
        navBtns.push({ id: ACTIONS.PRODUCTS_MENU, title: "⬅ Back" });
        return sendButtons(from, { text: "Navigate products:", buttons: navBtns.slice(0, 3) });
      }

   if (a.startsWith("view_products_branch_")) {
        // format: view_products_branch_{branchId}  OR  view_products_branch_{branchId}_page_{N}
        if (!biz) return sendMainMenu(from);
        const pageMatch = a.match(/_page_(\d+)$/);
        const page = pageMatch ? parseInt(pageMatch[1], 10) : 0;
        const branchId = a.replace(/_page_\d+$/, "").replace("view_products_branch_", "");
        const branch = await Branch.findById(branchId);
        const products = await Product.find({ businessId: biz._id, isActive: true, $or: [{ branchId }, { branchId: null }, { branchId: { $exists: false } }] }).sort({ name: 1 }).lean();
        if (!products.length) { await sendText(from, `📦 No products for ${branch?.name || "this branch"}.`); return sendProductsMenu(from); }
        const PAGE = 25;
        const totalPages = Math.ceil(products.length / PAGE);
        const slice = products.slice(page * PAGE, page * PAGE + PAGE);
        let msg = `📦 *${branch?.name || "Branch"} Products* - Page ${page + 1}/${totalPages}\n\n`;
        slice.forEach((p, i) => { msg += `${page * PAGE + i + 1}. *${p.name}* - ${formatMoney(p.unitPrice, biz.currency)}\n`; });
        await sendText(from, msg);
        const navBtns = [];
        if (page > 0)              navBtns.push({ id: `view_products_branch_${branchId}_page_${page - 1}`, title: "⬅ Prev" });
        if (page < totalPages - 1) navBtns.push({ id: `view_products_branch_${branchId}_page_${page + 1}`, title: "➡ Next" });
        navBtns.push({ id: ACTIONS.PRODUCTS_MENU, title: "⬅ Back" });
        return sendButtons(from, { text: "Navigate:", buttons: navBtns.slice(0, 3) });
      }

      // "cashbal_branch_all"
      if (a === "cashbal_branch_all") {
        if (!biz) return sendMainMenu(from);
        return showAllBranchesCashBalance(from, biz);
      }

      // ── Branch report selector ─────────────────────────────────────────────
      if (a && (a.startsWith("report_branch_") || a.startsWith("branch_"))) {
        const bizForBranch = biz || await getBizForPhone(from);
        if (!bizForBranch) return sendMainMenu(from);

        let branchId = a.startsWith("report_branch_")
          ? a.replace("report_branch_", "")
          : a.replace("branch_", "");

        if (branchId === "all") {
          bizForBranch.sessionData.reportBranchId = null;
        } else {
          if (!mongoose.Types.ObjectId.isValid(branchId)) {
            await sendText(from, "⚠️ Invalid branch selected. Please try again.");
            return sendMainMenu(from);
          }
          bizForBranch.sessionData.reportBranchId = branchId;
        }

        const reportType = bizForBranch.sessionData?.reportType || "daily";
        bizForBranch.sessionState = "ready";
        await saveBizSafe(bizForBranch);

        if (reportType === "daily") {
          const { runDailyReportMetaEnhanced } = await import("./dailyReportEnhanced.js");
          return runDailyReportMetaEnhanced({ biz: bizForBranch, from });
        }
        if (reportType === "weekly") {
          const { runWeeklyReportMetaEnhanced } = await import("./weeklyReportEnhanced.js");
          return runWeeklyReportMetaEnhanced({ biz: bizForBranch, from });
        }
        if (reportType === "monthly") {
          const { runMonthlyReportMetaEnhanced } = await import("./monthlyReportEnhanced.js");
          return runMonthlyReportMetaEnhanced({ biz: bizForBranch, from });
        }

        return sendMainMenu(from);
      }
    }
  }

}
}
// ─────────────────────────────────────────────────────────────────────────────
// SHARED DISPLAY HELPERS
// ─────────────────────────────────────────────────────────────────────────────

async function showClientsList(from, biz, branchId) {
  const Client = (await import("../models/client.js")).default;
  let clients;

  if (branchId) {
    const branchInvoices = await Invoice.find({ businessId: biz._id, branchId }).distinct("clientId");
    clients = await Client.find({ businessId: biz._id, _id: { $in: branchInvoices } }).lean();
  } else {
    clients = await Client.find({ businessId: biz._id }).lean();
  }

  if (!clients.length) {
    const branch = branchId ? await Branch.findById(branchId) : null;
    await sendText(from, branch ? `📋 No clients found for *${branch.name}*.` : "📋 No clients found.");
    return sendClientsMenu(from);
  }

  const branch = branchId ? await Branch.findById(branchId) : null;
  let msg = branch ? `👥 *Clients - ${branch.name}:*\n\n` : "👥 *All Clients:*\n\n";
  clients.forEach((c, i) => {
    msg += `${i + 1}. *${c.name || "No name"}*\n`;
    if (c.phone) msg += `   📞 ${c.phone}\n`;
    if (c.email) msg += `   📧 ${c.email}\n`;
    msg += "\n";
  });

  await sendText(from, msg);
  return sendClientsMenu(from);
}



// ── Build and send the supplier catalogue as a WhatsApp list ─────────────
async function _sendSupplierCatalogueMenu(from, supplier, cart = []) {
  const isService = supplier.profileType === "service";
  const phone = from.replace(/\D+/g, "");

   const sourceItems = getSupplierCatalogueSourceItems(supplier).map(item => ({
    id: item.name,
    label: item.name,
    price: item.priceLabel || null
  }));
  // ── No products at all ────────────────────────────────────────────────────
  if (!sourceItems.length) {
    if (biz) {
      biz.sessionState = "supplier_order_product";
      biz.sessionData = { ...(biz.sessionData || {}), orderSupplierId: String(supplier._id) };
      await saveBizSafe(biz);
    }
    await UserSession.findOneAndUpdate(
      { phone },
      { $set: { "tempData.orderState": "supplier_order_product", "tempData.orderSupplierId": String(supplier._id) }},
      { upsert: true }
    );
    return sendText(from,
`${isService ? "📅" : "🛒"} *Order from ${supplier.businessName}*

✍️ *Type your order like this:*
_item name quantity, item name quantity_

*Examples:*
${isService
  ? `_plumbing 2 hr_\n_welding 1 job, painting 1 day_`
  : `_sugar 2 kg, bread 3, cooking oil 1_\n_cement 10 bags, river sand 2 trips_`}

📌 *Commands:*
- *cancel* -cancel this order

Send your order now 👇`);
  }

  // ── Cart summary text ─────────────────────────────────────────────────────
  let cartSummary = "";
  if (cart.length) {
    const cartTotal = cart.filter(c => c.pricePerUnit).reduce((s, c) => s + c.quantity * c.pricePerUnit, 0);
    const totalStr  = cartTotal > 0 ? ` · Est. *$${cartTotal.toFixed(2)}*` : "";
    const totalQty  = cart.reduce((s, c) => s + c.quantity, 0);
    cartSummary =
      `🛒 *Cart (${totalQty} item${totalQty > 1 ? "s" : ""}${totalStr}):*\n` +
      cart.map((c, i) => `${i + 1}. ${c.product} ×${c.quantity}${c.pricePerUnit ? ` = $${(c.quantity * c.pricePerUnit).toFixed(2)}` : ""}`).join("\n") +
      "\n";
  }

 const WHATSAPP_MAX   = 10;
  const removeRowCount = cart.length ? Math.min(cart.length, 2) : 0;
  const actionSlots    = cart.length ? (removeRowCount + 2) : 0;
  const productSlots   = WHATSAPP_MAX - actionSlots - 1;

  const isBigCatalogue = sourceItems.length > productSlots;

  // ── BIG CATALOGUE: Option C -numbered text list + minimal action panel ───
  if (isBigCatalogue) {
    // Build numbered price list -plain text, unlimited length, no scrolling trap
    const priceListLines = sourceItems.map((item, i) => {
      const priceStr = item.price ? ` -${item.price}` : "";
      return `${i + 1}. ${item.label}${priceStr}`;
    }).join("\n");

    // Cart status block -shown only when buyer has already selected items
    let cartStatus = "";
    if (cart.length) {
      const cartTotal = cart.filter(c => c.pricePerUnit).reduce((s, c) => s + c.quantity * c.pricePerUnit, 0);
      cartStatus =
        `\n✅ *Items selected so far:*\n` +
        cart.map((c, i) => `${i + 1}. ${c.product} ×${c.quantity}${c.pricePerUnit ? ` = $${(c.quantity * c.pricePerUnit).toFixed(2)}` : ""}`).join("\n") +
        (cartTotal > 0 ? `\n💵 *Running total: $${cartTotal.toFixed(2)}*` : "") +
        "\n";
    }

    // Send the numbered price list as a plain text message -buyer can see ALL items, scroll freely
    await sendText(from,
`${isService ? "🔧" : "📦"} *${supplier.businessName}*
${isService ? "Services & Rates" : "Products & Prices"} -${sourceItems.length} items
${cartStatus}
${priceListLines}

─────────────────
*📌 How to order -choose any style:*

*Style 1 -Item number + quantity:*
_1x5, 3x2, 6x20_
_(item 1 qty 5, item 3 qty 2, item 6 qty 20)_

*Style 2 -Item name + quantity:*
_cement 5, river sand 2, bricks 500_

*Style 3 -Mixed (numbers and names both work):*
_1x5, sand 2, 6x20_

*Increase qty:* type item again e.g. _cement_ or _1x1_ adds 1 more

*Commands:*
- *confirm* -finish and send your order
- *r1* or *remove cement* -remove an item
- *clear* -empty cart and start fresh
- *cancel* -go back`);

    // Minimal action panel -ONLY action buttons, no product rows competing for space
    const actionRows = [];

    if (cart.length) {
      const totalQty = cart.reduce((s, c) => s + c.quantity, 0);
      actionRows.push({
        id: `sup_cart_confirm_${supplier._id}`,
        title: `✅ Confirm Order (${totalQty} item${totalQty !== 1 ? "s" : ""})`
      });
      actionRows.push({
        id: `sup_cart_clear_${supplier._id}`,
        title: "🗑 Clear Cart"
      });
      actionRows.push({
        id: "find_supplier",
        title: "❌ Cancel"
      });
    } else {
      // No cart yet -just show guidance rows
      actionRows.push({
        id: `sup_cart_custom_${supplier._id}`,
        title: "✍️ Type Your Order"
      });
      actionRows.push({
        id: "find_supplier",
        title: "🔍 Other Suppliers"
      });
      actionRows.push({
        id: `sup_cart_clear_${supplier._id}`,
        title: "❌ Cancel"
      });
    }

    return sendList(from,
      cart.length
        ? `🛒 *${supplier.businessName}* · ${cart.reduce((s,c)=>s+c.quantity,0)} item${cart.reduce((s,c)=>s+c.quantity,0) !== 1 ? "s" : ""} selected -tap Confirm or keep adding`
        : `📋 *${supplier.businessName}* · ${sourceItems.length} items -see full list above, type to order`,
      actionRows
    );
  }

  // ── SMALL CATALOGUE (≤ productSlots items): keep original tappable list ───
  const rows = sourceItems.slice(0, productSlots).map(item => ({
    id: `sup_cart_add_${supplier._id}_${encodeURIComponent(item.id)}`,
    title: item.label.slice(0, 24),
    description: item.price ? String(item.price).slice(0, 72) : "Tap to add to cart"
  }));

  if (cart.length) {
    cart.slice(0, removeRowCount).forEach(c => {
      rows.push({
        id: `sup_cart_remove_${supplier._id}_${encodeURIComponent(c.product)}`,
        title: `➖ Remove: ${c.product.slice(0, 18)}`
      });
    });
    rows.push({ id: `sup_cart_confirm_${supplier._id}`, title: "✅ Confirm Order" });
    rows.push({ id: `sup_cart_clear_${supplier._id}`,   title: "🗑 Clear Cart" });
  }

  rows.push({
    id: `sup_cart_custom_${supplier._id}`,
    title: `✍️ Type Custom Item`
  });

  if (rows.length > 10) rows.splice(10);

  const shortCartLine = cart.length
    ? `🛒 ${cart.reduce((s,c)=>s+c.quantity,0)} item${cart.reduce((s,c)=>s+c.quantity,0) !== 1 ? "s" : ""} in cart · `
    : "";

const catalogueHint = cart.length > 0
    ? (isService
        ? `_Tap ✅ Confirm to book, or add more services_`
        : `_Tap ✅ Confirm to order, or add more items_`)
    : `_Tap an item to add it to your ${isService ? "booking" : "order"}_`;

const catalogueActionHint = cart.length > 0
    ? (isService
        ? `_Tap ✅ Confirm to book, or add more services_`
        : `_Tap ✅ Confirm to order, or add more items_`)
    : `_Tap to add to your ${isService ? "booking" : "order"}_`;

  return sendList(from,
    `${shortCartLine}${isService ? "🔧" : "📦"} *${supplier.businessName}*\n${catalogueActionHint}`,
    rows
  );
}

// ── Build and send the supplier registration confirm summary ─────────────
async function _sendSupplierConfirmPrompt(from, reg = {}) {
  const isService = reg.profileType === "service";

  const productList = (reg.products || [])
    .filter(p => p !== "pending_upload")
    .slice(0, 6)
    .join(", ") || "_(to be added)_";

  const priceSummary = isService
    ? (Array.isArray(reg.rates) && reg.rates.length
        ? reg.rates.slice(0, 3).map(r => `${r.service} (${r.rate})`).join(", ") +
          (reg.rates.length > 3 ? ` +${reg.rates.length - 3} more` : "")
        : "_Rates to be added_")
    : (Array.isArray(reg.prices) && reg.prices.length
        ? reg.prices.slice(0, 3).map(p => `${p.product} $${Number(p.amount).toFixed(2)}`).join(", ") +
          (reg.prices.length > 3 ? ` +${reg.prices.length - 3} more` : "")
        : "_Prices to be added_");

  const deliveryLine = isService
    ? (reg.travelAvailable ? "🚗 Travels to clients" : "📍 Clients visit provider")
    : (reg.delivery?.available ? "🚚 Delivers to buyers" : "🏠 Collection only");

  const productLabel = reg.products?.[0] === "pending_upload"
    ? "_(Catalogue to be uploaded)_"
    : productList;

  return sendButtons(from, {
    text:
`✅ *Almost done! Confirm your listing:*

🏪 *${reg.businessName || "Not set"}*
📍 ${reg.area || ""}, ${reg.city || ""}
${isService ? "🔧" : "📦"} ${productLabel}
${deliveryLine}
💰 ${priceSummary}

_Is this correct?_`,
    buttons: [
      { id: "sup_confirm_yes", title: "✅ Confirm & List" },
      { id: "sup_confirm_no",  title: "❌ Start Over" }
    ]
  });
}


async function showExpenseReceipts(from, biz, branchId) {
  const Expense = (await import("../models/expense.js")).default;
  const query = { businessId: biz._id };
  if (branchId) query.branchId = branchId;

  const expenses = await Expense.find(query).sort({ createdAt: -1 }).limit(10).lean();

  if (!expenses.length) {
    const branch = branchId ? await Branch.findById(branchId) : null;
    await sendText(from, branch ? `📋 No expense receipts found for *${branch.name}*.` : "📋 No expense receipts found.");
    return sendPaymentsMenu(from);
  }

  const branch = branchId ? await Branch.findById(branchId) : null;
  let msg = branch
    ? `🧾 *Recent Expense Receipts - ${branch.name}:*\n\n`
    : "🧾 *Recent Expense Receipts (All Branches):*\n\n";

  expenses.forEach((e, i) => {
    const date = new Date(e.createdAt).toLocaleDateString();
    msg += `${i + 1}. *${e.category || "Other"}* - ${e.amount} ${biz.currency}\n`;
    msg += `   ${e.description || "No description"}\n`;
    msg += `   ${date} (${e.method || "Unknown method"})\n\n`;
  });

  await sendText(from, msg);
  return sendPaymentsMenu(from);
}

async function showPaymentHistory(from, biz, branchId) {
  const InvoicePayment = (await import("../models/invoicePayment.js")).default;
  const query = { businessId: biz._id };
  if (branchId) query.branchId = branchId;

  const payments = await InvoicePayment.find(query).sort({ createdAt: -1 }).limit(10).lean();

  if (!payments.length) {
    const branch = branchId ? await Branch.findById(branchId) : null;
    await sendText(from, branch ? `📋 No payment history found for *${branch.name}*.` : "📋 No payment history found.");
    return sendPaymentsMenu(from);
  }

  const branch = branchId ? await Branch.findById(branchId) : null;
  let msg = branch
    ? `💵 *Recent Payments - ${branch.name}:*\n\n`
    : "💵 *Recent Payments (All Branches):*\n\n";

  for (const p of payments) {
    const invoice = await Invoice.findById(p.invoiceId).lean();
    const date = new Date(p.createdAt).toLocaleDateString();
    msg += `• *${p.amount} ${biz.currency}* (${p.method})\n`;
    msg += `  Invoice: ${invoice?.number || "Unknown"}\n`;
    msg += `  Date: ${date}\n\n`;
  }

  await sendText(from, msg);
  return sendPaymentsMenu(from);
}

// ─── Cash balance display helpers ─────────────────────────────────────────────

async function showBranchCashBalance(from, biz, branchId) {
  const CashBalance = (await import("../models/cashBalance.js")).default;
  const CashPayout = (await import("../models/cashPayout.js")).default;
  const InvoicePayment = (await import("../models/invoicePayment.js")).default;
  const BranchModel = (await import("../models/branch.js")).default;
  const InvoiceModel = (await import("../models/invoice.js")).default;
  const Expense = (await import("../models/expense.js")).default;

  const branch = await BranchModel.findById(branchId).lean();
  const branchName = branch?.name || "Branch";

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);

  const balance = await CashBalance.findOne({ businessId: biz._id, branchId, date: today }).lean();

  const cashPayments = await InvoicePayment.find({ businessId: biz._id, branchId, createdAt: { $gte: today, $lt: tomorrow } }).lean();
  const cashReceipts = await InvoiceModel.find({ businessId: biz._id, branchId, type: "receipt", createdAt: { $gte: today, $lt: tomorrow } }).lean();
  const expenses = await Expense.find({ businessId: biz._id, branchId, createdAt: { $gte: today, $lt: tomorrow } }).lean();

  let payouts = [];
  try {
    payouts = await CashPayout.find({ businessId: biz._id, branchId, date: today }).lean();
  } catch (_) {}

  const cur = biz.currency;
  const opening = balance?.openingBalance ?? 0;
  const cashIn = cashPayments.reduce((s, p) => s + p.amount, 0) + cashReceipts.reduce((s, r) => s + r.total, 0);
  const cashOutExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const cashOutPayouts = payouts.reduce((s, p) => s + p.amount, 0);
  const cashOut = cashOutExpenses + cashOutPayouts;
  const closing = opening + cashIn - cashOut;

  let msg = `💰 *Cash Balance - ${branchName}*\n📅 ${today.toDateString()}\n\n`;
  msg += `━━━━━━━━━━━━━━\n`;
  msg += `📂 *Opening Balance:* ${opening} ${cur}\n\n`;
  msg += `📈 *Cash In:* +${cashIn} ${cur}\n`;
  if (cashPayments.length > 0) msg += `   • Invoice payments: ${cashPayments.reduce((s, p) => s + p.amount, 0)} ${cur} (${cashPayments.length})\n`;
  if (cashReceipts.length > 0) msg += `   • Receipt sales: ${cashReceipts.reduce((s, r) => s + r.total, 0)} ${cur} (${cashReceipts.length})\n`;
  msg += `\n📉 *Cash Out:* -${cashOut} ${cur}\n`;
  if (cashOutExpenses > 0) {
    msg += `   • Expenses: ${cashOutExpenses} ${cur} (${expenses.length})\n`;
    const expByCategory = {};
    expenses.forEach(e => { expByCategory[e.category || "Other"] = (expByCategory[e.category || "Other"] || 0) + e.amount; });
    Object.entries(expByCategory).forEach(([cat, amt]) => { msg += `    - ${cat}: ${amt} ${cur}\n`; });
  }
  if (cashOutPayouts > 0) {
    msg += `   • Payouts/Drawings: ${cashOutPayouts} ${cur} (${payouts.length})\n`;
    payouts.forEach(p => { msg += `    - ${p.reason || "No reason"}: ${p.amount} ${cur}\n`; });
  }
  msg += `\n━━━━━━━━━━━━━━\n`;
  msg += `${closing >= opening ? "📈" : "📉"} *Closing Balance: ${closing} ${cur}*\n`;
  msg += `━━━━━━━━━━━━━━\n`;
  if (opening === 0 && cashIn === 0) msg += `\n⚠️ No opening balance set for today.`;

  await sendText(from, msg);
  const { sendCashBalanceMenu } = await import("./metaMenus.js");
  return sendCashBalanceMenu(from);
}

async function showAllBranchesCashBalance(from, biz) {
  const CashBalance = (await import("../models/cashBalance.js")).default;
  const BranchModel = (await import("../models/branch.js")).default;

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const branches = await BranchModel.find({ businessId: biz._id }).lean();
  if (!branches.length) { await sendText(from, "❌ No branches found."); return sendMainMenu(from); }

  const cur = biz.currency;
  let msg = `💰 *Cash Balance Summary - All Branches*\n📅 ${today.toDateString()}\n\n`;
  let totalOpening = 0, totalIn = 0, totalOut = 0;

  for (const branch of branches) {
    const balance = await CashBalance.findOne({ businessId: biz._id, branchId: branch._id, date: today }).lean();
    const opening = balance?.openingBalance ?? 0;
    const cashIn = balance?.cashIn ?? 0;
    const cashOut = balance?.cashOut ?? 0;
    const closing = opening + cashIn - cashOut;
    totalOpening += opening; totalIn += cashIn; totalOut += cashOut;
    msg += `🏬 *${branch.name}*\n`;
    msg += `   Opening: ${opening} ${cur}\n`;
    msg += `   Cash In: +${cashIn} ${cur}\n`;
    msg += `   Cash Out: -${cashOut} ${cur}\n`;
    msg += `   ${closing >= opening ? "📈" : "📉"} Closing: *${closing} ${cur}*\n\n`;
  }

  msg += `━━━━━━━━━━━━━━\n📊 *TOTAL*\n`;
  msg += `   Opening: ${totalOpening} ${cur}\n   Cash In: +${totalIn} ${cur}\n   Cash Out: -${totalOut} ${cur}\n`;
  msg += `   Closing: *${totalOpening + totalIn - totalOut} ${cur}*\n`;

  await sendText(from, msg);
  const { sendCashBalanceMenu } = await import("./metaMenus.js");
  return sendCashBalanceMenu(from);
}