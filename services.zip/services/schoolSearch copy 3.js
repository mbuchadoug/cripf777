// services/schoolSearch.js
// ─── ZimQuote Schools - Parent Search Engine ──────────────────────────────────

import SchoolProfile from "../models/schoolProfile.js";
import { sendText, sendList, sendButtons } from "./metaSender.js";
import {
  SCHOOL_CITIES, SCHOOL_SUBURB_TO_CITY, SCHOOL_FACILITIES,
  SCHOOL_TYPES, SCHOOL_FEE_RANGES, SCHOOL_CURRICULA,
  SCHOOL_GENDERS, SCHOOL_BOARDING, feeRangeLabel, facilityIcon
} from "./schoolPlans.js";

import {
  notifySchoolProfileView,
  notifySchoolEnquiry,
  notifySchoolApplicationInterest,
  notifyAllSchoolProfileView,
  notifyAllSchoolEnquiry,
  notifyAllSchoolApplicationInterest
} from "./schoolNotifications.js";

import { notifySellerSmartLinkOpened } from "./buyerRequestNotifications.js";
import { notifyAllSupplierLinkOpened } from "./supplierNotifications.js";
import {
  handleGroupSmartLink,
  handleGroupSellerTap,
} from "./groupSmartLink.js";

import SupplierProfile from "../models/supplierProfile.js";

// ── ZQ FAQ + Seller Chat (lazy-imported to avoid circular deps) ───────────────
// These are called when a buyer taps a ZimQuote bot link via handleZqDeepLink.
// Imported lazily to prevent circular dependency with chatbotEngine.

// ── ZQ Link base URL ──────────────────────────────────────────────────────────
const BASE_URL   = (process.env.SITE_URL || process.env.APP_BASE_URL || "https://zimquote.co.zw").replace(/\/$/, "");
const BOT_NUMBER = (process.env.WHATSAPP_BOT_NUMBER || "263771143904").replace(/\D/g, "");



const SCHOOL_TYPE_ALIASES = {
  primary: "primary",
  secondary: "secondary",
  combined: "combined",
  preschool: "ecd",
  kindergarten: "ecd",
  ecd: "ecd",
  "ecd only": "ecd",
  "ecd primary": "ecd_primary",
  preparatory: "ecd_primary",
  prep: "ecd_primary",
  highschool: "secondary",
  "high school": "secondary"
};

// Ownership/sector aliases - "private" / "government" etc.
const SCHOOL_OWNERSHIP_ALIASES = {
  private: "private",
  "private school": "private",
  "private schools": "private",
  independent: "private",
  government: "government",
  "government school": "government",
  "government schools": "government",
  state: "government",
  council: "government",
  public: "government",
  mission: "mission",
  "church school": "mission",
  "mission school": "mission"
};

const SCHOOL_FEE_ALIASES = {
  budget: "budget",
  cheap: "budget",
  affordable: "budget",
  low: "budget",
  mid: "mid",
  middle: "mid",
  medium: "mid",
  average: "mid",
  premium: "premium",
  elite: "premium",
  expensive: "premium"
};

const SCHOOL_GENDER_ALIASES = {
  boys: "boys",
  girls: "girls",
  mixed: "mixed",
  coed: "mixed",
  "co-ed": "mixed"
};

const SCHOOL_BOARDING_ALIASES = {
  day: "day",
  boarding: "boarding",
  boarder: "boarding",
  both: "both"
};

function _normSchoolText(value = "") {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, " ")
    .replace(/\s+/g, " ");
}

function _includesWholePhrase(haystack = "", phrase = "") {
  const h = ` ${_normSchoolText(haystack)} `;
  const p = ` ${_normSchoolText(phrase)} `;
  return h.includes(p);
}

function _findSchoolCity(text = "") {
  const normalized = _normSchoolText(text);
  const cities = [...SCHOOL_CITIES].sort((a, b) => b.length - a.length);
  for (const city of cities) {
    if (_includesWholePhrase(normalized, city)) return city;
  }
  return null;
}

// Extra suburbs that may be missing from schoolPlans.js SCHOOL_SUBURB_TO_CITY
const _EXTRA_SCHOOL_SUBURBS = {
  "westgate": "Harare",
  "west gate": "Harare",
  "tynwald": "Harare",
  "kensington": "Harare",
  "queensdale": "Harare",
  "ashdown park": "Harare",
  "helensvale": "Harare",
  "bluffhill": "Harare",
  "sunningdale": "Harare",
  "meyrick park": "Harare",
  "haig park": "Harare",
  "sentosa": "Harare",
  "mount hampden": "Harare",
  "rugare": "Harare",
  "dzivarasekwa": "Harare",
  "st martins": "Harare",
  "prospect": "Harare",
  "marlborough": "Harare",
  "mabelreign": "Harare",
  "avondale": "Harare",
  "avonlea": "Harare",
  "borrowdale": "Harare",
  "highlands": "Harare",
  "mount pleasant": "Harare",
  "glen view": "Harare",
  "glenview": "Harare",
  "kuwadzana": "Harare",
  "warren park": "Harare",
  "hatfield": "Harare",
  "msasa": "Harare",
  "greendale": "Harare",
  "eastlea": "Harare",
  "belgravia": "Harare",
  "milton park": "Harare",
  "newlands": "Harare",
  "chisipite": "Harare",
  "gunhill": "Harare",
  "strathaven": "Harare",
  "braeside": "Harare",
  "southerton": "Harare",
  "workington": "Harare",
  "graniteside": "Harare",
  "budiriro": "Harare",
  "glen norah": "Harare",
  "mufakose": "Harare",
  "mabvuku": "Harare",
  "tafara": "Harare",
  "highfield": "Harare",
  "mbare": "Harare",
  "ruwa": "Harare",
  "zimre park": "Harare",
  "gazebo": "Harare",
  "chitungwiza": "Harare",
  "epworth": "Harare",
  "norton": "Harare",
  "hillside": "Bulawayo",
  "nkulumane": "Bulawayo",
  "luveve": "Bulawayo",
  "entumbane": "Bulawayo",
  "mpopoma": "Bulawayo",
  "lobengula": "Bulawayo",
  "tshabalala": "Bulawayo",
  "pumula": "Bulawayo",
  "mahatshula": "Bulawayo",
  "magwegwe": "Bulawayo",
  "white city": "Bulawayo",
  "cowdray park": "Bulawayo",
  "sakubva": "Mutare",
  "dangamvura": "Mutare",
  "chikanga": "Mutare",
  "mambo": "Gweru",
  "mkoba": "Gweru",
  "senga": "Gweru",
  "ascot": "Gweru",
  "mucheke": "Masvingo",
  "rujeko": "Masvingo",
  "mbizo": "Kwekwe",
  "amaveni": "Kwekwe"
};

function _findSchoolSuburb(text = "") {
  const normalized = _normSchoolText(text);

  // Merge schoolPlans suburbs with local fallback (local takes precedence for gaps)
  const merged = { ..._EXTRA_SCHOOL_SUBURBS, ...(SCHOOL_SUBURB_TO_CITY || {}) };
  const suburbs = Object.keys(merged).sort((a, b) => b.length - a.length);
  for (const suburb of suburbs) {
    if (_includesWholePhrase(normalized, suburb)) {
      return {
        suburb: _titleCase(suburb),
        city: merged[suburb] || null
      };
    }
  }
  return null;
}

function _findSchoolFacility(text = "") {
  const normalized = _normSchoolText(text);

  for (const fac of SCHOOL_FACILITIES) {
    if (_includesWholePhrase(normalized, fac.id)) return fac.id;
    if (_includesWholePhrase(normalized, fac.label)) return fac.id;

    const shortLabel = _normSchoolText(fac.label).replace(/^\S+\s+/, "").trim();
    if (shortLabel && _includesWholePhrase(normalized, shortLabel)) return fac.id;
  }

  if (_includesWholePhrase(normalized, "pool")) return "swimming_pool";
  if (_includesWholePhrase(normalized, "lab")) return "science_lab";
  if (_includesWholePhrase(normalized, "computer")) return "computer_lab";
  if (_includesWholePhrase(normalized, "wifi")) return "wifi";
  if (_includesWholePhrase(normalized, "bus")) return "school_bus";
  if (_includesWholePhrase(normalized, "boarding")) return null;

  return null;
}

function _findSchoolCurriculum(text = "") {
  const normalized = _normSchoolText(text);

  // Check cambridge_primary first (more specific) before cambridge
  if (_includesWholePhrase(normalized, "cambridge primary") ||
      _includesWholePhrase(normalized, "cambridge checkpoint") ||
      _includesWholePhrase(normalized, "cambridge_primary")) {
    return "cambridge_primary";
  }

  for (const cur of SCHOOL_CURRICULA) {
    if (_includesWholePhrase(normalized, cur.id)) return cur.id;
    if (_includesWholePhrase(normalized, cur.label)) return cur.id;
  }

  if (_includesWholePhrase(normalized, "cambridge")) return "cambridge";
  if (_includesWholePhrase(normalized, "zimsec")) return "zimsec";

  return null;
}

// schoolSearch.js - replace the entire _parseSchoolShortcodeSearch function

const SCHOOL_PARSE_TRIGGERS = [
  "find school", "find schools", "find a school",
  "find primary", "find secondary", "find combined",
  "find preschool", "find ecd", "find kindergarten",
  "find boarding", "find day school",
  "find girls school", "find boys school", "find mixed school",
  "find budget school", "find affordable school", "find cheap school", "find premium school",
  "find cambridge", "find zimsec",
  "find private", "find government", "find mission", "find independent",
  "private school", "private schools", "government school", "mission school",
  "school in", "schools in", "primary school in", "secondary school in",
  "look for school", "search school"
];

function _parseSchoolShortcodeSearch(text = "") {
  const raw = String(text || "").trim();
  const normalized = _normSchoolText(raw);

  // Accept if it starts with any known trigger phrase OR contains "school" + location hint
  const isSchoolTrigger =
    SCHOOL_PARSE_TRIGGERS.some(p => normalized.startsWith(p) || normalized.includes(p)) ||
    (normalized.includes("school") && (
      _findSchoolCity(normalized) ||
      _findSchoolSuburb(normalized) ||
      Object.keys(SCHOOL_TYPE_ALIASES).some(k => _includesWholePhrase(normalized, k)) ||
      Object.keys(SCHOOL_OWNERSHIP_ALIASES).some(k => _includesWholePhrase(normalized, k))
    ));

  if (!isSchoolTrigger) return null;

  const search = {
    city: null,
    suburb: null,
    type: null,
    ownership: null,
    feeRange: null,
    facility: null,
    curriculum: null,
    gender: null,
    boarding: null,
    keyword: null,
    admissionsOpen: null,
    page: 0
  };

  // Suburb first (more specific)
  const suburbMatch = _findSchoolSuburb(normalized);
  if (suburbMatch) {
    search.suburb = suburbMatch.suburb;
    if (suburbMatch.city) search.city = suburbMatch.city;
  }

  // City
  const cityMatch = _findSchoolCity(normalized);
  if (cityMatch && !search.city) search.city = cityMatch;

  // Type
  for (const [word, value] of Object.entries(SCHOOL_TYPE_ALIASES)) {
    if (_includesWholePhrase(normalized, word)) { search.type = value; break; }
  }

  // Ownership (private / government / mission)
  for (const [word, value] of Object.entries(SCHOOL_OWNERSHIP_ALIASES)) {
    if (_includesWholePhrase(normalized, word)) { search.ownership = value; break; }
  }

  // Fee range
  for (const [word, value] of Object.entries(SCHOOL_FEE_ALIASES)) {
    if (_includesWholePhrase(normalized, word)) { search.feeRange = value; break; }
  }

  // Facility
  search.facility = _findSchoolFacility(normalized);

  // Curriculum
  search.curriculum = _findSchoolCurriculum(normalized);

  // Gender
  for (const [word, value] of Object.entries(SCHOOL_GENDER_ALIASES)) {
    if (_includesWholePhrase(normalized, word)) { search.gender = value; break; }
  }

  // Boarding
  for (const [word, value] of Object.entries(SCHOOL_BOARDING_ALIASES)) {
    if (_includesWholePhrase(normalized, word)) { search.boarding = value; break; }
  }

  // Grade/level
  if (_includesWholePhrase(normalized, "grade 1") || _includesWholePhrase(normalized, "form 1")) search.type = "primary";
  if (_includesWholePhrase(normalized, "o level") || _includesWholePhrase(normalized, "a level")) search.type = "secondary";

  // Admissions
  if (_includesWholePhrase(normalized, "admissions open") || _includesWholePhrase(normalized, "open admissions") || _includesWholePhrase(normalized, "accepting")) {
    search.admissionsOpen = true;
  } else if (_includesWholePhrase(normalized, "admissions closed") || _includesWholePhrase(normalized, "closed admissions")) {
    search.admissionsOpen = false;
  }

  const hasFilters = Boolean(
    search.city || search.suburb || search.type || search.ownership || search.feeRange ||
    search.facility || search.curriculum || search.gender || search.boarding ||
    typeof search.admissionsOpen === "boolean"
  );

  return { search, hasFilters };
}

export async function runSchoolShortcodeSearch({ from, text, biz, saveBiz }) {
  const parsed = _parseSchoolShortcodeSearch(text);
  if (!parsed) return false;

  if (!parsed.hasFilters) {
    return startSchoolSearch(from, biz, saveBiz);
  }

  if (biz) {
    biz.sessionState = "school_search_results";
    biz.sessionData = {
      ...(biz.sessionData || {}),
      schoolSearch: parsed.search
    };
    await saveBiz(biz);
  }

  return _runSchoolSearch(from, parsed.search);
}

// ─────────────────────────────────────────────────────────────────────────────
// FREE-TEXT SCHOOL SEARCH
// Called when a user typed free text while inside the parent school-search funnel
// (biz state school_search_city / school_search_results, or the non-biz marker).
// Handles BOTH structured phrases ("primary borrowdale") AND a bare school NAME
// ("hellenic academy"). This is what stops a typed school search from being
// hijacked into the ⚡ Request Sellers marketplace flow.
// Returns the send promise, or false if the text is too short to act on.
// ─────────────────────────────────────────────────────────────────────────────
export async function handleSchoolFreeTextSearch({ from, text, biz, saveBiz }) {
  const raw = String(text || "").trim();
  if (raw.length < 2) return false;

  // Try a structured filter parse first (city / type / fees / curriculum / etc.).
  const parsed = _parseSchoolShortcodeSearch(raw);
  const search = (parsed && parsed.hasFilters)
    ? parsed.search
    : { keyword: raw, page: 0 };   // otherwise treat the whole input as a NAME

  if (biz) {
    biz.sessionState = "school_search_results";
    biz.sessionData  = { ...(biz.sessionData || {}), schoolSearch: search };
    await saveBiz(biz);
  } else {
    // Consume the one-shot non-biz marker and stash the search for pagination.
    try {
      const { default: UserSession } = await import("../models/userSession.js");
      const phone = from.replace(/\D+/g, "");
      await UserSession.findOneAndUpdate(
        { phone },
        { $set:   { "tempData.schoolSearch": search },
          $unset: { "tempData.schoolSearchActive": "" } },
        { upsert: true }
      );
    } catch (_) {}
  }

  return _runSchoolSearch(from, search);
}

// ─────────────────────────────────────────────────────────────────────────────
// ZQ DEEP-LINK HANDLER
// Intercepts payloads fired by the ZQ Link landing page via wa.me deep-link.
// Payload format: "ZQ:SCHOOL:<mongoId>"  or  "ZQ:SUPPLIER:<mongoId>"
//
// Wire in chatbotEngine BEFORE the state machine:
//   const deepHandled = await handleZqDeepLink({ from, text, biz, saveBiz });
//   if (deepHandled) return;
// ─────────────────────────────────────────────────────────────────────────────
export async function handleZqDeepLink({ from, text, biz, saveBiz }) {
  const raw = String(text || "").trim();

  // ── SCHOOL deep link: ZQ:SCHOOL:<id> ─────────────────────────────────────
  if (/^ZQ:SCHOOL:[a-f0-9]{24}$/i.test(raw)) {
    const schoolId = raw.split(":")[2];

    // Increment view counters (fire-and-forget)
    SchoolProfile.findByIdAndUpdate(schoolId, {
      $inc: { monthlyViews: 1, zqLinkConversions: 1 }
    }).catch(() => {});

    // Notify school admin - works outside 24hr window via UTILITY template
    SchoolProfile.findById(schoolId).lean().then(school => {
      if (school?.phone) {
        notifyAllSchoolProfileView(school, from).catch(() => {});
      }
    }).catch(() => {});

    try {
      const { showSchoolFAQMenu } = await import("./schoolFAQ.js");
      await showSchoolFAQMenu(from, schoolId, biz, saveBiz, { source: "whatsapp_link" });
    } catch (e) {
      await _showSchoolDetail(from, schoolId, biz, "zq_link");
    }
    return true;
  }

  // ── SUPPLIER deep link: ZQ:SUPPLIER:<id>  or  ZQ:SUPPLIER:<id>:SRC:<src> ──
  if (/^ZQ:SUPPLIER:[a-f0-9]{24}/i.test(raw)) {
    const parts      = raw.split(":");
    const supplierId = parts[2];

    // Parse SRC source code (ZQ:SUPPLIER:<id>:SRC:fb → "fb")
    const srcIdx = parts.indexOf("SRC");
    const source = srcIdx >= 0 && parts[srcIdx + 1] ? parts[srcIdx + 1].toLowerCase() : "direct";

    // Parse any other KV params (name=xxx etc.)
    const supKVs    = parts.slice(3).filter(p => p !== "SRC" && !["fb","wa","tt","qr","sms","ig","yt","direct"].includes(p));
    const supParams = {};
    for (const kv of supKVs) {
      const eq = kv.indexOf("=");
      if (eq > 0) supParams[kv.slice(0, eq)] = decodeURIComponent(kv.slice(eq + 1));
    }

    // Increment view counters (fire-and-forget)
    SupplierProfile.findByIdAndUpdate(supplierId, {
      $inc: { zqLinkViews: 1, zqLinkConversions: 1 }
    }).catch(() => {});

    // Notify supplier + all notification contacts (works outside 24hr via UTILITY template)
    SupplierProfile.findById(supplierId).lean().then(supplier => {
      if (supplier?.phone) {
        notifyAllSupplierLinkOpened(supplier, source, from).catch(() => {});  // `from` = visitor's WhatsApp number
      }
    }).catch(() => {});

    try {
      const { showSellerMenu } = await import("./sellerChat.js");
      await showSellerMenu(from, supplierId, biz, saveBiz, {
        source: "whatsapp_link", parentName: supParams.name || ""
      });
    } catch (e) {
      await _showSupplierCard(from, supplierId);
    }
    return true;
  }

  // ── NAMED SUPPLIER link: ZQ:S:<slug> ────────────────────────────────────────
  if (/^ZQ:S:[a-z0-9-]{2,40}$/i.test(raw)) {
    const slug = raw.split(":")[2].toLowerCase().trim();
    const supplier = await SupplierProfile.findOne({ zqSlug: slug }).lean();
    if (supplier) {
      SupplierProfile.findByIdAndUpdate(supplier._id, {
        $inc: { zqLinkViews: 1, viewCount: 1 }
      }).catch(() => {});
      notifyAllSupplierLinkOpened(supplier, "direct", from).catch(() => {});
      try {
        const { showSellerMenu } = await import("./sellerChat.js");
        await showSellerMenu(from, String(supplier._id), biz, saveBiz, { source: "direct" });
      } catch (_) {
        await _showSupplierCard(from, String(supplier._id));
      }
      return true;
    }
    // Named link not found - silently ignore
    return false;
  }

  // ── GROUP link: ZQ:GROUP:<slug> ──────────────────────────────────────────────
  if (/^ZQ:GROUP:[a-z0-9-]{2,40}$/i.test(raw)) {
    const slug = raw.split(":")[2].toLowerCase().trim();
    const handled = await handleGroupSmartLink({ from, slug, biz, saveBiz });
    return handled;
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// ZQ SLUG SHORTCODE HANDLER
// "zq st-ignatius" or "zq mama-bakers" typed directly in WhatsApp.
//
// Wire in chatbotEngine BEFORE the state machine:
//   const slugHandled = await handleSchoolSlugSearch({ from, text, biz, saveBiz });
//   if (slugHandled) return;
// ─────────────────────────────────────────────────────────────────────────────
export async function handleSchoolSlugSearch({ from, text, biz, saveBiz }) {
  const raw = String(text || "").trim().toLowerCase();
  if (!raw.startsWith("zq ") || raw.length < 5) return false;

  const slug = raw.slice(3).trim().replace(/\s+/g, "-");

  const school = await SchoolProfile.findOne({ zqSlug: slug, active: true }).lean();
  if (school) {
    SchoolProfile.findByIdAndUpdate(school._id, {
      $inc: { monthlyViews: 1, zqLinkConversions: 1 }
    }).catch(() => {});
    // Notify school admin of the profile view (works outside 24hr window)
    if (school.phone) {
      notifyAllSchoolProfileView(school, from).catch(() => {});
    }
    await _showSchoolDetail(from, String(school._id), biz, "slug_search");
    return true;
  }

  const supplier = await SupplierProfile.findOne({ zqSlug: slug }).lean();
  if (supplier) {
    if (supplier.phone) {
      notifyAllSupplierLinkOpened(supplier, "direct", from).catch(() => {});
    }
    // Route through showSellerMenu for full hospitality/service/product experience
    try {
      const { showSellerMenu } = await import("./sellerChat.js");
      await showSellerMenu(from, String(supplier._id), biz, saveBiz, { source: "direct" });
    } catch (_) {
      await _showSupplierCard(from, String(supplier._id));
    }
    return true;
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// SCHOOL ADMIN BOT: "Get My ZQ Link"
// Wire into handleSchoolSearchActions:
//   if (a === "school_get_zq_link")   return handleGetSchoolZqLink(from);
//   if (a === "school_share_link_wa") return handleShareSchoolLinkWa(from);
// ─────────────────────────────────────────────────────────────────────────────
export async function handleGetSchoolZqLink(from) {
  const phone  = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone }).lean();

  if (!school) {
    return sendText(from, "❌ No school profile found for this number.");
  }

  if (!school.zqSlug) {
    return sendText(from,
`⚠️ *Your ZQ Link is not set up yet.*

Please contact ZimQuote to activate your shareable link.

📞 0789 901 058`
    );
  }

  const link = `${BASE_URL}/s/${school.zqSlug}`;

  return sendButtons(from, {
    text:
`🔗 *Your ZimQuote Profile Link*

${link}

*Share this link everywhere you market your school:*

📱 *TikTok* → Paste as your bio link. Every video drives parents straight to your profile.
📘 *Facebook* → Paste in posts, stories, and your page description.
🐦 *Twitter / X* → Add to your profile bio - it shows as a rich preview card.
💬 *WhatsApp Status* → Share it weekly so your contacts can tap and enquire.
🖨️ *Posters* → Your admin can print a QR code for school gates and events.
📧 *Email signature* → One tap takes parents to your profile.

When anyone taps this link, WhatsApp opens and your full profile appears instantly - fees, facilities, admissions, and an Enquire button. No searching needed.`,
    buttons: [
      { id: "school_share_link_wa", title: "📤 Get Share Message" },
      { id: "school_account",       title: "⬅ Back to Menu" }
    ]
  });
}

export async function handleShareSchoolLinkWa(from) {
  const phone  = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone }).lean();
  if (!school || !school.zqSlug) return false;

  const link = `${BASE_URL}/s/${school.zqSlug}`;

  await sendText(from,
`📤 *Copy and paste this into any Facebook post, WhatsApp group, or TikTok caption:*

━━━━━━━━━━━━━━━━━━
🏫 *${school.schoolName}*
📍 ${school.suburb ? school.suburb + ", " : ""}${school.city}
${school.admissionsOpen ? "🟢 Admissions currently OPEN\n" : ""}
See our full profile, fees, facilities & apply online:
👉 ${link}

_Found us on ZimQuote- Zimbabwe's school finder_
━━━━━━━━━━━━━━━━━━

_Tip: Put this link in your TikTok bio. Every video you post drives parents directly to your school profile._`
  );

  const { sendSchoolAccountMenu } = await import("./metaMenus.js");
  return sendSchoolAccountMenu(from, school);
}
// ─────────────────────────────────────────────────────────────────────────────
// ENTRY POINT - called when parent taps "🏫 Find a School"
// ─────────────────────────────────────────────────────────────────────────────
export async function startSchoolSearch(from, biz, saveBiz) {
  if (biz) {
    biz.sessionState = "school_search_city";
    biz.sessionData  = { ...(biz.sessionData || {}), schoolSearch: {} };
    await saveBiz(biz);
  } else {
    // Non-biz parents have no biz.sessionState. Set a one-shot marker so that a
    // typed school name is routed to school search, NOT the Request Sellers flow.
    // It is consumed when the free-text search runs or when results are rendered.
    try {
      const { default: UserSession } = await import("../models/userSession.js");
      const phone = from.replace(/\D+/g, "");
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { "tempData.schoolSearchActive": true, "tempData.schoolSearch": {} } },
        { upsert: true }
      );
    } catch (_) {}
  }

 // WhatsApp limit: 10 rows. Show first 8 cities + More + All Cities.
  const searchCityRows = SCHOOL_CITIES.slice(0, 8).map(c => ({
    id:    `school_search_city_${c.toLowerCase().replace(/\s+/g, "_")}`,
    title: `📍 ${c}`
  }));
  searchCityRows.push({ id: "school_search_city_more", title: "➡ More Cities" });
  searchCityRows.push({ id: "school_search_city_all",  title: "🌍 All Cities" });

 return sendList(
    from,
    `🏫 *Find a School in Zimbabwe*

Which city? Or type a shortcut:

_find primary borrowdale_
_find secondary glen view_
_find boarding school bulawayo_
_find cambridge girls harare_
_find budget primary kuwadzana_
_find school with pool highlands_
_find schools admissions open_`,
    searchCityRows
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ACTION ROUTER - handles all school_search_* button taps
// Returns true if handled, false to fall through.
// ─────────────────────────────────────────────────────────────────────────────
export async function handleSchoolSearchActions({ action: a, from, biz, saveBiz }) {
  // For non-biz users, load search state from UserSession
  let _userSess = null;
  if (!biz) {
    const { default: UserSession } = await import("../models/userSession.js");
    const phone = from.replace(/\D+/g, "");
    _userSess = await UserSession.findOne({ phone });
  }

  const search = biz?.sessionData?.schoolSearch || _userSess?.tempData?.schoolSearch || {};

  // Helper: persist search for both biz and non-biz users
  async function _saveSearch(updatedSearch) {
    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), schoolSearch: updatedSearch };
      await saveBiz(biz);
    } else {
      const { default: UserSession } = await import("../models/userSession.js");
      const phone = from.replace(/\D+/g, "");
      await UserSession.findOneAndUpdate(
        { phone },
        { $set: { "tempData.schoolSearch": updatedSearch } },
        { upsert: true }
      );
    }
  }
// ── More cities page 2 ────────────────────────────────────────────────────
  if (a === "school_search_city_more") {
    const moreCityRows = SCHOOL_CITIES.slice(8).map(c => ({
      id:    `school_search_city_${c.toLowerCase().replace(/\s+/g, "_")}`,
      title: `📍 ${c}`
    }));
    moreCityRows.push({ id: "school_search_city_all", title: "🌍 All Cities" });
    return sendList(from, "🏫 *More Cities* - which city?", moreCityRows);
  }
  // ── Step 1: City selected ─────────────────────────────────────────────────
  if (a.startsWith("school_search_city_")) {
    const cityRaw = a.replace("school_search_city_", "").replace(/_/g, " ");
    const city    = cityRaw === "all" ? null : _titleCase(cityRaw);

    search.city   = city;
    await _saveSearch(search);

    return sendList(from,
      `🏫 *${city || "All Cities"}* - What type of school?`,
      [
        ...SCHOOL_TYPES.map(t => ({ id: `school_search_type_${t.id}`, title: t.label })),
        { id: "school_search_type_any", title: "🔍 Any Type" }
      ]
    );
  }

  // ── Step 2: School type selected ──────────────────────────────────────────
  if (a.startsWith("school_search_type_")) {
    const typeId  = a.replace("school_search_type_", "");
    search.type   = typeId === "any" ? null : typeId;
    await _saveSearch(search);

    return sendList(from,
      "💵 *Fees range per term?*",
      [
        ...SCHOOL_FEE_RANGES.map(f => ({ id: `school_search_fees_${f.id}`, title: f.label })),
        { id: "school_search_fees_any", title: "💰 Any Budget" }
      ]
    );
  }

  // ── Step 3: Fee range selected ────────────────────────────────────────────
  if (a.startsWith("school_search_fees_")) {
    const feeId       = a.replace("school_search_fees_", "");
    search.feeRange   = feeId === "any" ? null : feeId;
    await _saveSearch(search);

    // Build facility filter list (top 10 most common)
 // WhatsApp limit: 10 rows. Cap at 9 facilities + No Filter.
    const topFacilities = SCHOOL_FACILITIES.slice(0, 9);
    return sendList(from,
      "🏊 *Filter by facility?* (optional)\n\nPick one must-have facility, or skip:",
      [
        ...topFacilities.map(f => ({ id: `school_search_fac_${f.id}`, title: f.label })),
        { id: "school_search_fac_any", title: "🔍 No Facility Filter" }
      ]
    );
  }

  // ── Step 4: Facility filter ───────────────────────────────────────────────
  if (a.startsWith("school_search_fac_")) {
    const facId       = a.replace("school_search_fac_", "");
    search.facility   = facId === "any" ? null : facId;
    await _saveSearch(search);
    if (biz) biz.sessionState = "school_search_results";
    return _runSchoolSearch(from, search);
  }

  // ── Result: parent taps a school card ─────────────────────────────────────
  if (a.startsWith("school_view_")) {
    const schoolId = a.replace("school_view_", "");
    return _showSchoolDetail(from, schoolId, biz);
  }

  // ── Download school profile PDF ───────────────────────────────────────────
  if (a.startsWith("school_dl_profile_")) {
    const schoolId = a.replace("school_dl_profile_", "");
    return _downloadSchoolProfile(from, schoolId);
  }

  // ── Get application link ──────────────────────────────────────────────────
  if (a.startsWith("school_apply_")) {
    const schoolId = a.replace("school_apply_", "");
    return _sendApplicationLink(from, schoolId);
  }

  // ── Send Enquiry: parent taps button → bot asks for their message ────────
if (a.startsWith("school_enquiry_")) {
    const schoolId = a.replace("school_enquiry_", "");
    const school   = await SchoolProfile.findById(schoolId).lean();
    if (!school) return false;

    // Store in biz session if available
    if (biz) {
      biz.sessionState = "school_parent_enquiry";
      biz.sessionData  = { ...(biz.sessionData || {}), enquirySchoolId: schoolId };
      await saveBiz(biz);
    }

    // ALWAYS store in UserSession so non-biz parents are covered
    const phone = from.replace(/\D+/g, "");
    const { default: UserSession } = await import("../models/userSession.js");
    await UserSession.findOneAndUpdate(
      { phone },
      {
        $set: {
          "tempData.schoolEnquiryState": "school_parent_enquiry",
          "tempData.enquirySchoolId":    schoolId
        }
      },
      { upsert: true }
    );

    return sendText(from,
`✉️ *Send an Enquiry to ${school.schoolName}*

Type your question or message below and we will send it to the school on your behalf.

_Example: "Do you have space for Grade 3 in 2026?" or "What are your boarding fees?"_

Type *cancel* to go back.`
    );
  }

  // ── Refine search ─────────────────────────────────────────────────────────
  if (a === "school_search_refine") {
    return startSchoolSearch(from, biz, saveBiz);
  }

  // ── Pagination ────────────────────────────────────────────────────────────
  if (a.startsWith("school_search_page_")) {
    const page = parseInt(a.replace("school_search_page_", ""), 10) || 0;
    search.page = page;
    await _saveSearch(search);
    return _runSchoolSearch(from, search);
  }

  // ── Toggle admissions (school admin) ─────────────────────────────────────
  if (a === "school_toggle_admissions") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;
    school.admissionsOpen = !school.admissionsOpen;
    await school.save();
    await sendText(from,
      school.admissionsOpen
        ? "🟢 Admissions are now *OPEN*. Parents searching will see this."
        : "🔴 Admissions are now *CLOSED*. We will hide the 'Admissions Open' badge."
    );
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, school);
  }

  // ── Update fees (school admin) ────────────────────────────────────────────
  // ── Update fees (school admin) ────────────────────────────────────────────
  if (a === "school_update_fees") {
    if (biz) {
      biz.sessionState = "school_admin_update_fees";
      await saveBiz(biz);
    }
    return sendText(from,
`💵 *Update School Fees*

Enter the new fee per term as: *term1, term2, term3*
Example: *900, 900, 850*

Or one number for equal terms: *900*`
    );
  }

  // ── School admin: open facilities manager ────────────────────────────────
  if (a === "school_admin_manage_facilities") {
    const phone = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;

    if (biz) {
      biz.sessionState = "school_admin_manage_facilities";
      biz.sessionData = { ...(biz.sessionData || {}), schoolFacPage: 0 };
      await saveBiz(biz);
    }

    const FAC_PAGE_SIZE = 7;

    const selected = (school.facilities || [])
      .map(id => SCHOOL_FACILITIES.find(f => f.id === id)?.label || id)
      .join("\n") || "None selected yet";

    const facRows = SCHOOL_FACILITIES
      .slice(0, FAC_PAGE_SIZE)
      .map(f => ({
        id: `school_fac_toggle_${f.id}`,
        title: (school.facilities || []).includes(f.id) ? `✅ ${f.label}` : f.label
      }));

    if (SCHOOL_FACILITIES.length > FAC_PAGE_SIZE) {
      facRows.push({ id: "school_fac_page_1", title: "➡ More Facilities" });
    }

    facRows.push({ id: "school_account", title: "💾 Done" });

    await sendText(
      from,
      `🏊 *Your Current Facilities:*\n\n${selected}\n\nTap to add or remove:`
    );

    return sendList(from, "🏊 *Manage Facilities* - tap to toggle:", facRows);
  }

  // ── School admin: toggle facility ────────────────────────────────────────
  if (a.startsWith("school_fac_toggle_")) {
    const phone = from.replace(/\D+/g, "");
    const facId = a.replace("school_fac_toggle_", "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;

    school.facilities = Array.isArray(school.facilities) ? school.facilities : [];

    if (school.facilities.includes(facId)) {
      school.facilities = school.facilities.filter(f => f !== facId);
    } else {
      school.facilities.push(facId);
    }

    await school.save();

    const FAC_PAGE_SIZE = 7;
    const facPage = Number(biz?.sessionData?.schoolFacPage || 0);

    if (biz) {
      biz.sessionState = "school_admin_manage_facilities";
      biz.sessionData = { ...(biz.sessionData || {}), schoolFacPage: facPage };
      await saveBiz(biz);
    }

    const facRows = SCHOOL_FACILITIES
      .slice(facPage * FAC_PAGE_SIZE, (facPage + 1) * FAC_PAGE_SIZE)
      .map(f => ({
        id: `school_fac_toggle_${f.id}`,
        title: school.facilities.includes(f.id) ? `✅ ${f.label}` : f.label
      }));

    const hasMore = (facPage + 1) * FAC_PAGE_SIZE < SCHOOL_FACILITIES.length;

    if (facPage > 0) {
      facRows.push({ id: `school_fac_page_${facPage - 1}`, title: "⬅ Previous" });
    }

    if (hasMore) {
      facRows.push({ id: `school_fac_page_${facPage + 1}`, title: "➡ More" });
    }

    facRows.push({ id: "school_account", title: "💾 Done" });

    return sendList(
      from,
      `🏊 *Manage Facilities* - ${(school.facilities || []).length} selected:`,
      facRows
    );
  }

  // ── School admin: facilities paging ──────────────────────────────────────
  if (a.startsWith("school_fac_page_")) {
    const phone = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;

    const newPage = parseInt(a.replace("school_fac_page_", ""), 10) || 0;
    const FAC_PAGE_SIZE = 7;

    if (biz) {
      biz.sessionState = "school_admin_manage_facilities";
      biz.sessionData = { ...(biz.sessionData || {}), schoolFacPage: newPage };
      await saveBiz(biz);
    }

    const facRows = SCHOOL_FACILITIES
      .slice(newPage * FAC_PAGE_SIZE, (newPage + 1) * FAC_PAGE_SIZE)
      .map(f => ({
        id: `school_fac_toggle_${f.id}`,
        title: (school.facilities || []).includes(f.id) ? `✅ ${f.label}` : f.label
      }));

    const hasMore = (newPage + 1) * FAC_PAGE_SIZE < SCHOOL_FACILITIES.length;

    if (newPage > 0) {
      facRows.push({ id: `school_fac_page_${newPage - 1}`, title: "⬅ Previous" });
    }

    if (hasMore) {
      facRows.push({ id: `school_fac_page_${newPage + 1}`, title: "➡ More" });
    }

    facRows.push({ id: "school_account", title: "💾 Done" });

    return sendList(
      from,
      `🏊 *Manage Facilities* - page ${newPage + 1}:`,
      facRows
    );
  }

  // ── School admin: get ZQ Link ─────────────────────────────────────────────
  if (a === "school_get_zq_link") {
    return handleGetSchoolZqLink(from);
  }

  // ── School admin: get share message ──────────────────────────────────────
  if (a === "school_share_link_wa") {
    return handleShareSchoolLinkWa(from);
  }

  // ── School admin: Smart Card platform-specific link menu ─────────────────
  if (a === "school_smart_card_menu") {
    return handleSmartCardMenu(from);
  }

  // ── School admin: generate a source-tagged link ───────────────────────────
  if (a.startsWith("school_sc_src_")) {
    const src = a.replace("school_sc_src_", "");
    return handleSmartCardSourceLink(from, src);
  }

  // ── School admin: view lead database ─────────────────────────────────────
  if (a === "school_my_leads") {
    return handleMyLeads(from, biz, saveBiz);
  }

  // ── School admin: follow up a specific lead ───────────────────────────────
  if (a.startsWith("school_followup_")) {
    const leadId = a.replace("school_followup_", "");
    return handleFollowUpLead(from, leadId);
  }

  // ── School admin: leads pagination ───────────────────────────────────────
  if (a.startsWith("school_leads_page_")) {
    const page = parseInt(a.replace("school_leads_page_", ""), 10) || 0;
    return handleMyLeads(from, biz, saveBiz, page);
  }

  return false;
}

// ── School admin: update fees state handler ───────────────────────────────────
export async function handleSchoolAdminStates({ state, from, text, biz, saveBiz }) {
  if (state === "school_admin_update_fees") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;

    const parts = text.trim().split(/[,\s\/]+/).map(s => Number(s.replace(/[^\d.]/g, ""))).filter(n => !isNaN(n) && n >= 0);
    if (!parts.length) {
      await sendText(from, "❌ Invalid fees. Try again: *800, 800, 750*");
      return true;
    }

    school.fees = {
      term1: parts[0],
      term2: parts[1] !== undefined ? parts[1] : parts[0],
      term3: parts[2] !== undefined ? parts[2] : parts[0],
      currency: "USD"
    };
    await school.save(); // pre-save hook updates feeRange

    if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }

    await sendText(from,
      `✅ Fees updated:\nTerm 1: $${school.fees.term1} | Term 2: $${school.fees.term2} | Term 3: $${school.fees.term3}`
    );
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, school);
  }

  if (state === "school_admin_update_reg_link") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;
    const link = text.trim();
    if (!link.startsWith("http")) {
      await sendText(from, "❌ Please enter a valid link starting with https://\n\nExample: *https://forms.gle/abc123*");
      return true;
    }
    school.registrationLink = link;
    await school.save();
    if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
    await sendText(from, `✅ *Application link updated!*\n\nParents will now see:\n${link}`);
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, school);
  }

  if (state === "school_admin_update_email") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;
    school.email = text.trim();
    await school.save();
    if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
    await sendText(from, `✅ *Email updated to:* ${school.email}`);
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, school);
  }

  if (state === "school_admin_update_website") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;
    school.website = text.trim();
    await school.save();
    if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
    await sendText(from, `✅ *Website updated to:* ${school.website}`);
    const { sendSchoolAccountMenu } = await import("./metaMenus.js");
    return sendSchoolAccountMenu(from, school);
  }

// ── Brochure upload: school sends a PDF document ──────────────────────────
  if (state === "school_admin_awaiting_brochure") {
    const phone  = from.replace(/\D+/g, "");
    const school = await SchoolProfile.findOne({ phone });
    if (!school) return false;

    // Allow cancellation
    if ((text || "").trim().toLowerCase() === "cancel") {
      if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
      const { sendSchoolMoreOptionsMenu } = await import("./metaMenus.js");
      return sendSchoolMoreOptionsMenu(from, school);
    }

    // The actual PDF URL is set by the webhook route before calling handleIncomingMessage.
    // It is stored on biz.sessionData.pendingDocumentUrl by the webhook handler.
    const docUrl = biz?.sessionData?.pendingDocumentUrl;

    if (!docUrl) {
      await sendText(from,
`📄 *Waiting for your PDF...*

Please send your school brochure as a *PDF file* (tap the 📎 attachment icon in WhatsApp).

Type *cancel* to go back.`
      );
      return true;
    }

    // Save the PDF URL on the school profile
    school.profilePdfUrl = docUrl;
    await school.save();

    // Clear pending doc from session
    if (biz) {
      biz.sessionData = { ...(biz.sessionData || {}), pendingDocumentUrl: null };
      biz.sessionState = "ready";
      await saveBiz(biz);
    }

    await sendText(from,
`✅ *Brochure uploaded successfully!*

Parents who tap "📄 Download Profile" on your listing will now receive this PDF.

You can upload a new one anytime from ⚙️ More Options.`
    );

    const { sendSchoolMoreOptionsMenu } = await import("./metaMenus.js");
    return sendSchoolMoreOptionsMenu(from, school);
  }

  // ── Parent typed their enquiry message ──────────────────────────────────
  if (state === "school_parent_enquiry") {
    const message = (text || "").trim();

    if (message.toLowerCase() === "cancel") {
      if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
      return sendButtons(from, {
        text: "❌ Enquiry cancelled.",
        buttons: [{ id: "school_search_refine", title: "🔄 Back to Schools" }]
      });
    }

    if (!message || message.length < 3) {
      await sendText(from, "❌ Please type your question or message (at least 3 characters).");
      return true;
    }

    const schoolId = biz?.sessionData?.enquirySchoolId;
    if (!schoolId) {
      if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
      return false;
    }

    const school = await SchoolProfile.findById(schoolId).lean();
    if (!school) {
      if (biz) { biz.sessionState = "ready"; await saveBiz(biz); }
      return false;
    }

    // Increment enquiry counter
    await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { inquiries: 1 } });

    // Notify school with the actual parent message via template
    notifyAllSchoolEnquiry(school, from, message).catch(() => {});

    // Reset session
    if (biz) {
      biz.sessionState = "ready";
      biz.sessionData  = { ...(biz.sessionData || {}), enquirySchoolId: null };
      await saveBiz(biz);
    }

    // Confirm to parent
    return sendButtons(from, {
      text:
`✅ *Enquiry Sent to ${school.schoolName}!*

Your message:
_${message}_

The school has been notified and will contact you on this WhatsApp number.

📞 ${school.contactPhone || school.phone}`,
      buttons: [
        { id: `school_apply_${schoolId}`, title: "📝 Apply Online" },
        { id: "school_search_refine",         title: "🔄 More Schools" }
      ]
    });
  }

  return false;
}
// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: run the MongoDB query and format results
// ─────────────────────────────────────────────────────────────────────────────
async function _runSchoolSearch(from, search = {}) {
  const PAGE_SIZE = 5;
  const page      = search.page || 0;
  const skip      = page * PAGE_SIZE;

  // Results are being shown - consume any lingering non-biz school-search marker
  // so later unrelated messages are not misrouted back into school search.
  try {
    const { default: UserSession } = await import("../models/userSession.js");
    await UserSession.updateOne(
      { phone: from.replace(/\D+/g, "") },
      { $unset: { "tempData.schoolSearchActive": "" } }
    );
  } catch (_) {}

// Academic search must exclude specialised institutions (culinary/driving/college
// etc.) which live in the same SchoolProfile collection with institutionType set.
// $in:["academic", null] also matches legacy docs saved before the field existed.
const _ACADEMIC_ONLY = { institutionType: { $in: ["academic", null] } };

const query = { active: true, ..._ACADEMIC_ONLY };
if (search.city)     query.city    = new RegExp(`^${search.city}$`, "i");
if (search.suburb)   query.suburb  = new RegExp(search.suburb, "i");

// ── Free-text NAME / keyword search ─────────────────────────────────────────
// Lets a parent type a school name ("hellenic", "st georges") or a loose phrase.
// We pull any city out of the keyword, then match the remaining significant words
// against schoolName (ANY word matches). Slight over-matching is fine - results
// are ranked, and the zero-match fallback shows available schools anyway.
if (search.keyword) {
  const _kwNorm = _normSchoolText(String(search.keyword));
  const _kwCity = _findSchoolCity(_kwNorm);
  if (_kwCity && !query.city) query.city = new RegExp(`^${_kwCity}$`, "i");
  const _stop = new Set(["school","schools","the","and","for","in","near","at","a","an","of","to","please","need","want","find","looking","me"]);
  const _cityLc = (_kwCity || "").toLowerCase();
  const _esc = w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const _words = _kwNorm.split(/\s+/).filter(w => w.length >= 3 && !_stop.has(w) && w !== _cityLc);
  if (_words.length) {
    query.schoolName = { $in: _words.map(w => new RegExp(_esc(w), "i")) };
  }
}
if (search.type) {
  // "combined" schools span ECD-Form 6, so they must appear in ALL type searches
  if (search.type === "ecd") {
    query.type = { $in: ["ecd", "ecd_primary", "combined"] };
  } else if (search.type === "primary") {
    query.type = { $in: ["primary", "ecd_primary", "combined"] };
  } else if (search.type === "secondary") {
    query.type = { $in: ["secondary", "combined"] };
  } else {
    query.type = search.type;
  }
}
if (search.feeRange)  query.feeRange   = search.feeRange;
if (search.facility)  query.facilities = search.facility;
if (search.curriculum) {
  if (search.curriculum === "cambridge") {
    // matches schools whose curriculum array contains "cambridge" OR "cambridge_primary"
    query.curriculum = { $in: ["cambridge", "cambridge_primary"] };
  } else {
    // for all other curricula (zimsec, ib, combined), match against the array field
    query.curriculum = { $elemMatch: { $eq: search.curriculum } };
  }
}
if (search.gender)    query.gender     = search.gender;
if (search.boarding)  query.boarding   = search.boarding;
if (search.ownership) query.ownership  = search.ownership;
if (typeof search.admissionsOpen === "boolean") {
  query.admissionsOpen = search.admissionsOpen;
}

  const total   = await SchoolProfile.countDocuments(query);
  let schools = await SchoolProfile.find(query)
    .sort({ tier: -1, rating: -1, qualityScore: -1 })  // featured first, then by rating
    .skip(skip)
    .limit(PAGE_SIZE)
    .lean();

  // ── Progressive fallback: relax filters one step at a time ──────────────────
  let fallbackLabel = null;

  if (!schools.length && page === 0) {
    // Step 1: drop suburb, keep city + type
    if (search.suburb && (search.city || search.type)) {
      const q2 = { ...query };
      delete q2.suburb;
      schools = await SchoolProfile.find(q2)
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      if (schools.length) fallbackLabel = `No exact match in *${search.suburb}* - showing nearby schools in *${search.city || "the area"}*:`;
    }

    // Step 2: drop type filter, keep location
    if (!schools.length && search.type && (search.city || search.suburb)) {
      const q3 = { active: true, ..._ACADEMIC_ONLY };
      if (search.city)   q3.city   = query.city;
      if (search.suburb) q3.suburb = query.suburb;
      if (search.feeRange)   q3.feeRange   = search.feeRange;
      if (search.gender)     q3.gender     = search.gender;
      if (search.boarding)   q3.boarding   = search.boarding;
      if (search.ownership)  q3.ownership  = search.ownership;
      if (typeof search.admissionsOpen === "boolean") q3.admissionsOpen = search.admissionsOpen;
      schools = await SchoolProfile.find(q3)
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      const typeLabel = search.type.replace("_", " + ");
      if (schools.length) fallbackLabel = `No *${typeLabel}* schools found - showing all schools in *${search.suburb || search.city || "the area"}*:`;
    }

    // Step 2b: drop ownership, keep type + city (e.g. show all ECD schools even if not "private")
    if (!schools.length && search.ownership && (search.type || search.city)) {
      const q3b = { active: true, ..._ACADEMIC_ONLY };
      if (query.city)   q3b.city = query.city;
      if (query.type)   q3b.type = query.type;
      if (search.feeRange)  q3b.feeRange  = search.feeRange;
      if (search.gender)    q3b.gender    = search.gender;
      if (search.boarding)  q3b.boarding  = search.boarding;
      schools = await SchoolProfile.find(q3b)
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      const typeLabel = search.type ? search.type.replace("_", " + ") + " " : "";
      if (schools.length) fallbackLabel = `No *${search.ownership}* ${typeLabel}schools found - showing all ${typeLabel}schools in *${search.city || "the area"}*:`;
    }

    // Step 3: drop all filters except city
    if (!schools.length && search.city) {
      schools = await SchoolProfile.find({ active: true, ..._ACADEMIC_ONLY, city: query.city })
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      if (schools.length) fallbackLabel = `No exact match - here are schools in *${search.city}* you might like:`;
    }

    // Step 3b: name/keyword search with no location match - retry name-only
    // across ALL cities so "hellenic" finds it wherever it is.
    if (!schools.length && search.keyword && query.schoolName) {
      schools = await SchoolProfile.find({ active: true, ..._ACADEMIC_ONLY, schoolName: query.schoolName })
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      if (schools.length) fallbackLabel = `Showing name matches across all cities:`;
    }

    // Step 4: no match at all - show the schools we DO have (featured / top rated).
    if (!schools.length) {
      schools = await SchoolProfile.find({ active: true, ..._ACADEMIC_ONLY })
        .sort({ tier: -1, rating: -1, qualityScore: -1 })
        .limit(PAGE_SIZE)
        .lean();
      if (schools.length) {
        fallbackLabel = `We couldn't find an exact match - here are schools on ZimQuote you can explore:`;
      }
    }

    // Step 5: the platform truly has zero active schools listed.
    if (!schools.length) {
      const filterSummary = _buildFilterSummary(search);
      await sendText(from,
`🏫 *No schools listed yet*

We don't have any schools on ZimQuote for that search yet.
_Filters tried: ${filterSummary}_

📣 *Know a school we should add?* Ask them to register on ZimQuote - it's free.
📞 ZimQuote Admin: 0789 901 058`
      );
      return sendButtons(from, {
        text: "What would you like to do?",
        buttons: [
          { id: "school_search_refine", title: "🔄 Search Again" },
          { id: "main_menu_back",       title: "🏠 Main Menu" }
        ]
      });
    }
  }

  // ── Build result cards ────────────────────────────────────────────────────
  const rows = schools.map(s => {
    const verifiedBadge  = s.verified ? " ✅" : "";
    const featuredBadge  = s.tier === "featured" ? " 🔥" : "";
    const admissions     = s.admissionsOpen ? "🟢 Open" : "🔴 Closed";
    const topFacilities  = (s.facilities || []).slice(0, 4).map(facilityIcon).join(" ");
    const feeText        = s.fees?.term1 ? `$${s.fees.term1}/term` : feeRangeLabel(s.feeRange);

    return {
      id:          `school_view_${s._id}`,
      title:       `🏫 ${s.schoolName}${verifiedBadge}${featuredBadge}`,
      description: `${s.suburb ? s.suburb + ", " : ""}${s.city} · ${feeText} · ${admissions}`
    };
  });

  // Pagination rows
  const paginationRows = [];
  if (page > 0) {
    paginationRows.push({ id: `school_search_page_${page - 1}`, title: "⬅ Previous" });
  }
  if (skip + PAGE_SIZE < total) {
    paginationRows.push({ id: `school_search_page_${page + 1}`, title: "➡ Next" });
  }
  paginationRows.push({ id: "school_search_refine", title: "🔄 New Search" });

  const filterSummary = _buildFilterSummary(search);
  const headerText = fallbackLabel
    ? `\u26a0\ufe0f ${fallbackLabel}\n\n_Tap a school to see details_`
    : `🏫 *Schools Found: ${total}*\n📍 ${filterSummary}\n\n_Tap a school to see details_`;

  return sendList(from, headerText, [...rows, ...paginationRows]);
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: full school detail card
// source: "zq_link" | "slug_search" | undefined
// ─────────────────────────────────────────────────────────────────────────────
async function _showSchoolDetail(from, schoolId, biz, source) {
  const school = await SchoolProfile.findById(schoolId).lean();
  if (!school) {
    await sendText(from, "❌ School not found.");
    return sendButtons(from, {
      text: "What would you like to do?",
      buttons: [{ id: "school_search_refine", title: "🔄 Search Again" }]
    });
  }

  // Track views
  await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { monthlyViews: 1 } });

  // Notify school admin that a parent opened/clicked their school
// Notify school admin - uses Meta template for out-of-session delivery
  notifyAllSchoolProfileView(school, from).catch(() => {});

  const verifiedBadge  = school.verified  ? " ✅ *Verified*"   : "";
  const featuredBadge  = school.tier === "featured" ? " 🔥 *Featured*" : "";
  const admissions     = school.admissionsOpen ? "🟢 *Admissions Open*" : "🔴 *Admissions Closed*";

 const typeLabels     = { ecd: "ECD / Preschool", ecd_primary: "ECD + Primary", primary: "Primary", secondary: "Secondary", combined: "Combined" };
  const genderLabels   = { mixed: "Mixed (Co-ed)", boys: "Boys Only", girls: "Girls Only" };
  const boardLabels    = { day: "Day School", boarding: "Boarding", both: "Day & Boarding" };

  const curriculumText = (school.curriculum || []).map(c => c.toUpperCase()).join(" + ") || "Not specified";
  const facilitiesList = (school.facilities || [])
    .map(id => SCHOOL_FACILITIES.find(f => f.id === id)?.label || id)
    .join("\n  ") || "Not specified";
  const extraList      = (school.extramuralActivities || [])
    .slice(0, 8)
    .map(id => SCHOOL_EXTRAMURALACTIVITIES_MAP[id] || id)
    .join(", ") || "Not specified";

let feeLine = feeRangeLabel(school.feeRange);
  if (school.fees?.term1) {
    feeLine = `Day: $${school.fees.term1} / $${school.fees.term2} / $${school.fees.term3}`;
    if ((school.fees.boardingTerm1 || 0) > 0) {
      feeLine += `\n  Boarding: $${school.fees.boardingTerm1} / $${school.fees.boardingTerm2} / $${school.fees.boardingTerm3}`;
    }
    if ((school.fees.ecdTerm1 || 0) > 0 && school.fees.ecdTerm1 !== school.fees.term1) {
      feeLine += `\n  ECD: $${school.fees.ecdTerm1} / $${school.fees.ecdTerm2} / $${school.fees.ecdTerm3}`;
    }
    feeLine += " (USD per term)";
  }

  const rating         = school.reviewCount > 0
    ? `⭐ ${school.rating.toFixed(1)} (${school.reviewCount} reviews)`
    : "⭐ No reviews yet";

  const gradeText      = (school.grades?.from && school.grades?.to)
    ? `${school.grades.from}- ${school.grades.to}`
    : "Not specified";

  // ── ZQ Link footer - shown when the school has a slug ────────────────────
  const zqLinkLine = school.zqSlug
    ? `\n\n🔗 *Share this school:*\n${BASE_URL}/s/${school.zqSlug}`
    : "";

  // Source note for parents who arrived via a shared link
  const sourceNote = source === "zq_link" || source === "slug_search"
    ? "\n_You arrived via a ZimQuote share link._"
    : "";

  const detailText =
`🏫 *${school.schoolName}*${verifiedBadge}${featuredBadge}
📍 ${school.suburb ? school.suburb + ", " : ""}${school.city}${school.address ? "\n🏠 " + school.address : ""}

${admissions}${sourceNote}

📗 *Type:* ${typeLabels[school.type] || school.type}
📚 *Curriculum:* ${curriculumText}
👫 *Gender:* ${genderLabels[school.gender] || school.gender}
🏠 *Boarding:* ${boardLabels[school.boarding] || school.boarding}
📐 *Grades:* ${gradeText}

💵 *Fees:*
  ${feeLine}

🏊 *Facilities:*
  ${facilitiesList}

🏃 *Extramural:* ${extraList}

${school.principalName ? `👤 *Principal:* ${school.principalName}\n` : ""}${school.contactPhone ? `📞 *Contact:* ${school.contactPhone}\n` : ""}${school.email ? `📧 ${school.email}\n` : ""}
${rating}
👀 ${school.monthlyViews || 0} views this month${zqLinkLine}`;

 // Show download button only if school has documents
  const hasDocuments = (school.brochures || []).length > 0 || !!school.profilePdfUrl;
  const docCount     = (school.brochures || []).length || (school.profilePdfUrl ? 1 : 0);
  const dlLabel      = docCount > 1 ? `📄 Download (${docCount} docs)` : "📄 Download Profile";

  const buttons = [];
  if (hasDocuments) buttons.push({ id: `school_dl_profile_${schoolId}`, title: dlLabel });
  buttons.push({ id: `school_apply_${schoolId}`,  title: "📝 Apply Online" });
  buttons.push({ id: `school_enquiry_${schoolId}`, title: "✉️ Send Enquiry" });

  return sendButtons(from, { text: detailText, buttons });
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: supplier detail card (for ZQ deep-link / slug search)
// ─────────────────────────────────────────────────────────────────────────────
async function _showSupplierCard(from, supplierId) {
  // Try the full showSellerMenu first - it handles all profileTypes properly
  try {
    const { showSellerMenu } = await import("./sellerChat.js");
    await showSellerMenu(from, supplierId, null, null, { source: "direct" });
    return;
  } catch (sellerChatErr) {
    console.warn("[_showSupplierCard] showSellerMenu failed, using fallback:", sellerChatErr.message);
  }

  // ── Fallback card (should rarely be reached) ──────────────────────────────
  const supplier = await SupplierProfile.findById(supplierId).lean();
  if (!supplier) {
    return sendButtons(from, {
      text: "❌ This seller profile is not currently available.",
      buttons: [{ id: "main_menu_back", title: "🏠 Main Menu" }]
    });
  }

  const isHospitality = supplier.profileType === "hospitality";
  const isService     = supplier.profileType === "service";
  const location      = [supplier.location?.area, supplier.location?.city].filter(Boolean).join(", ");
  const rating        = (supplier.reviewCount || 0) > 0
    ? "⭐ " + Number(supplier.rating).toFixed(1) + " (" + supplier.reviewCount + " review" + (supplier.reviewCount === 1 ? "" : "s") + ")"
    : "";

  let cardText;
  if (isHospitality) {
    const FACILITY_LABELS = {
      wifi:"📶 WiFi", pool:"🏊 Pool", hot_shower:"🚿 Hot shower", breakfast:"🍳 Breakfast",
      en_suite:"🚪 En-suite", generator:"⚡ Power", dstv:"📺 DSTV", braai:"🔥 Braai",
      aircon:"❄️ AC", game_drives:"🦁 Game drives", fishing:"🎣 Fishing",
      conference:"🏢 Conference", restaurant:"🍽 Restaurant", laundry:"👕 Laundry",
      parking:"🅿️ Parking", pets_allowed:"🐕 Pets OK", child_friendly:"👶 Child-friendly"
    };
    const SUBTYPE_LABELS = {
      lodge:"🌿 Lodge", hotel:"🏨 Hotel", guesthouse:"🏡 Guesthouse/B&B",
      self_catering:"🍳 Self-Catering", campsite:"⛺ Campsite",
      safari_operator:"🦁 Safari Operator", tour_guide:"🗺 Tour Guide",
      boat_hire:"⛵ Boat Hire", travel_agency:"✈️ Travel Agency"
    };
    const subtypeLabel = (supplier.tourismSubtype || []).map(s => SUBTYPE_LABELS[s] || s).join(" · ") || "🏨 Hospitality";
    const roomLines = (supplier.roomTypes || []).map(rt => {
      const night = rt.pricePerNight > 0 ? "$" + Number(rt.pricePerNight).toFixed(0) + "/night" : null;
      const rest  = rt.restRate       > 0 ? "$" + Number(rt.restRate).toFixed(0)       + "/rest"  : null;
      const rates = [night, rest].filter(Boolean).join(" · ");
      return "• " + rt.name + (rates ? "  -  " + rates : "  -  price on request") + (rt.capacity > 0 ? " (sleeps " + rt.capacity + ")" : "");
    });
    const extraLines = (supplier.extraServices || []).slice(0, 4).map(es =>
      "• " + es.name + (es.price > 0 ? "  -  $" + Number(es.price).toFixed(0) + "/" + (es.unit || "service") : "")
    );
    const facilLine = (supplier.facilities || []).slice(0, 8).map(f => FACILITY_LABELS[f] || f).join("  ·  ");
    const ciLine = (supplier.checkInTime || supplier.checkOutTime)
      ? "⏰ Check-in: " + (supplier.checkInTime || "?") + "  ·  Check-out: " + (supplier.checkOutTime || "?") : "";

    cardText = [
      "🏨 *" + supplier.businessName + "*" + (supplier.verified ? " ✅" : ""),
      subtypeLabel,
      "📍 " + location,
      rating,
      "",
      "🛏 *Rooms & Rates:*",
      ...roomLines.length ? roomLines : ["_(Contact for availability)_"],
      ...(extraLines.length ? ["", "➕ *Extra Services:*", ...extraLines] : []),
      ...(facilLine ? ["", "🏷 *Facilities:*", facilLine] : []),
      ...(ciLine ? [ciLine] : []),
      "",
      ...(supplier.address        ? ["🏠 " + supplier.address]        : []),
      ...(supplier.contactDetails ? ["📞 " + supplier.contactDetails] : []),
    ].filter(l => l !== null && l !== undefined).join("\n");

    return sendButtons(from, {
      text: cardText,
      buttons: [
        { id: "sc_quote_" + supplierId,   title: "🛏 Book / Get a quote" },
        { id: "sc_enquiry_" + supplierId, title: "💬 Send an enquiry"    }
      ]
    });
  }

  // Standard product/service fallback
  const priceSummary = isService
    ? (Array.isArray(supplier.rates) && supplier.rates.length
        ? supplier.rates.slice(0, 3).map(r => r.service + (r.rate ? " - " + r.rate : "")).join(", ")
        : "_Rates on request_")
    : (Array.isArray(supplier.prices) && supplier.prices.length
        ? supplier.prices.slice(0, 3).map(p => p.product + " $" + Number(p.amount).toFixed(2)).join(", ")
        : "_Prices on request_");

  cardText =
    (isService ? "🔧" : "🏪") + " *" + supplier.businessName + "*" + (supplier.verified ? " ✅" : "") + "\n" +
    "📍 " + location + "\n\n" +
    (isService ? "🛠 *Services:*" : "📦 *Products:*") + " " + priceSummary + "\n" +
    (supplier.address ? "🏠 " + supplier.address + "\n" : "") +
    (supplier.contactDetails ? "📞 " + supplier.contactDetails : "");

  return sendButtons(from, {
    text: cardText,
    buttons: [
      { id: "sc_quote_" + supplierId,   title: isService ? "💵 Request a quote" : "💵 Get instant quote" },
      { id: "sc_enquiry_" + supplierId, title: "💬 Send an enquiry" }
    ]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: download school profile PDF
// ─────────────────────────────────────────────────────────────────────────────
async function _downloadSchoolProfile(from, schoolId) {
  const school = await SchoolProfile.findById(schoolId).lean();
  if (!school) { await sendText(from, "❌ School not found."); return; }

  // Track inquiry
  await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { inquiries: 1 } });

// Collect all available documents: admin brochures first, then legacy profilePdfUrl
  const { sendDocument } = await import("./metaSender.js");
  const allDocs = [];

  // Admin-uploaded brochures (the new system)
  if ((school.brochures || []).length > 0) {
    for (const b of school.brochures) {
      allDocs.push({ label: b.label || "School Brochure", url: b.url });
    }
  }

  // Legacy single PDF (old system - keep working)
  if (school.profilePdfUrl && !allDocs.some(d => d.url === school.profilePdfUrl)) {
    allDocs.push({ label: `${school.schoolName} Profile`, url: school.profilePdfUrl });
  }

if (allDocs.length > 0) {
    // ── Try sendDocument first, fall back to text link ────────────────────────
    for (const doc of allDocs) {
      const directUrl = doc.url;
      const filename  = doc.label.replace(/[^a-zA-Z0-9 _-]/g, "").replace(/\s+/g, "_") + ".pdf";
      try {
        await sendDocument(from, { link: directUrl, filename });
        doc._sent = true; // mark as successfully sent as file
      } catch (docErr) {
        console.error(`[School DL] sendDocument failed for "${doc.label}":`, docErr.message);
        doc._sent = false;
      }
      doc._directUrl = directUrl;
    }

    // ── Build the reply message ───────────────────────────────────────────────
    const sentAsDocs  = allDocs.filter(d => d._sent);
    const failedDocs  = allDocs.filter(d => !d._sent);

    let replyText = `📄 *${school.schoolName} - Documents*\n\n`;

    if (sentAsDocs.length > 0) {
      replyText += `The following ${sentAsDocs.length > 1 ? "documents were" : "document was"} sent above as a file:\n`;
      replyText += sentAsDocs.map(d => `• ${d.label}`).join("\n");
      replyText += `\n\nTap the file${sentAsDocs.length > 1 ? "s" : ""} above to open.\n\n`;
    }

    // For any that failed (e.g. Drive permission issues), send as tappable links
    if (failedDocs.length > 0) {
      replyText += `Tap to open:\n`;
      replyText += failedDocs.map(d => `📎 *${d.label}*\n${d._directUrl}`).join("\n\n");
      replyText += "\n\n";
    }

    replyText += `_Contact the school if you have any questions._`;

    return sendButtons(from, {
      text: replyText,
      buttons: [
        { id: `school_apply_${schoolId}`, title: "📝 Apply Online" },
        { id: "school_search_refine",      title: "🔄 More Schools" }
      ]
    });
  }

  // PDF not yet generated - generate on demand
  try {
    const { generateSchoolProfilePDF } = await import("./schoolPdfGenerator.js");
    const pdfResult = await generateSchoolProfilePDF(school);
 if (pdfResult?.url) {
      await SchoolProfile.findByIdAndUpdate(schoolId, { profilePdfUrl: pdfResult.url });
      const { sendDocument } = await import("./metaSender.js");

      try {
        await sendDocument(from, { link: pdfResult.url, filename: pdfResult.filename });
      } catch (docErr) {
        console.error("[School DL] sendDocument (generated) failed:", docErr.message, "url:", pdfResult.url);
      }

    return sendButtons(from, {
        text:
`📄 *${school.schoolName} - School Profile*

Your download has been sent above as a PDF file. Tap it to open.

_Can't see it? Scroll up or tap 📞 Contact School for a copy._`,

        buttons: [
          { id: `school_apply_${schoolId}`, title: "📝 Apply Online" },
          { id: "school_search_refine",      title: "🔄 More Schools" }
        ]
      });
    }
  } catch (err) {
    console.error("[School Profile PDF]", err.message);
  }

  return sendButtons(from, {
    text: `⚠️ The school profile PDF for *${school.schoolName}* is not yet available. Please contact the school directly.`,
    buttons: [
      { id: `school_enquiry_${schoolId}`, title: "✉️ Send Enquiry" },
      { id: "school_search_refine",        title: "🔄 More Schools" }
    ]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: send online application link
// ─────────────────────────────────────────────────────────────────────────────
async function _sendApplicationLink(from, schoolId) {
  const school = await SchoolProfile.findById(schoolId).lean();
  if (!school) { await sendText(from, "❌ School not found."); return; }

  await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { inquiries: 1 } });

  const admissionsText = school.admissionsOpen
    ? "🟢 *Admissions are currently OPEN.*"
    : "🔴 *Admissions are currently CLOSED.* You can still submit an expression of interest.";

  // Notify the school that a parent wants to apply
notifyAllSchoolApplicationInterest(school, from).catch(() => {});

  if (school.registrationLink) {
    return sendButtons(from, {
      text:
`📝 *Apply to ${school.schoolName}*

${admissionsText}

Tap the link below to fill in your child's application form online:
${school.registrationLink}

After submitting, the school will contact you directly.`,
      buttons: [
        { id: `school_dl_profile_${schoolId}`, title: "📄 Download Profile" },
        { id: "school_search_refine",           title: "🔄 More Schools" }
      ]
    });
  }

  // No online link - fall back to contact
  return sendButtons(from, {
    text:
`📝 *Apply to ${school.schoolName}*

${admissionsText}

This school does not have an online application form yet.
Contact them directly to request an application form.`,
    buttons: [
      { id: `school_enquiry_${schoolId}`, title: "✉️ Send Enquiry" },
      { id: "school_search_refine",        title: "🔄 More Schools" }
    ]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: show school contact details
// ─────────────────────────────────────────────────────────────────────────────
async function _contactSchool(from, schoolId) {
  const school = await SchoolProfile.findById(schoolId).lean();
  if (!school) { await sendText(from, "❌ School not found."); return; }

  await SchoolProfile.findByIdAndUpdate(schoolId, { $inc: { inquiries: 1 } });

  const displayPhone = school.contactPhone || school.phone;

  const contactText =
`📞 *Contact ${school.schoolName}*

📱 Phone: *${displayPhone}*
${school.email    ? `📧 Email: ${school.email}\n`   : ""}${school.address  ? `🏠 Address: ${school.address}\n` : ""}${school.website  ? `🌐 Website: ${school.website}\n` : ""}
📍 ${school.suburb ? school.suburb + ", " : ""}${school.city}

You can message or call the school directly on their number above.`;

  // Notify school of interest
notifyAllSchoolEnquiry(school, from).catch(() => {});

  return sendButtons(from, {
    text: contactText,
    buttons: [
      { id: `school_apply_${schoolId}`, title: "📝 Apply Online" },
      { id: "school_search_refine",      title: "🔄 More Schools" }
    ]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE: helpers
// ─────────────────────────────────────────────────────────────────────────────
function _buildFilterSummary(search = {}) {
  const parts = [];
  if (search.city)     parts.push(search.city);
  if (search.suburb)   parts.push(search.suburb);
 if (search.type)     parts.push({ ecd: "ECD / Preschool", ecd_primary: "ECD + Primary", primary: "Primary", secondary: "Secondary", combined: "Combined" }[search.type] || search.type);
  if (search.feeRange) parts.push(feeRangeLabel(search.feeRange));

  if (search.facility) {
    const fac = SCHOOL_FACILITIES.find(f => f.id === search.facility);
    if (fac) parts.push(fac.label);
  }

 if (search.curriculum) {
    // When search.curriculum is "cambridge", it also matches cambridge_primary schools.
    // Show a broader label so parents aren't confused when they see cambridge_primary results.
    if (search.curriculum === "cambridge") {
      parts.push("🎓 Cambridge (all levels)");
    } else {
      const cur = SCHOOL_CURRICULA.find(c => c.id === search.curriculum);
      if (cur) parts.push(cur.label);
    }
  }

  if (search.gender) {
    const g = SCHOOL_GENDERS.find(x => x.id === search.gender);
    if (g) parts.push(g.label);
  }

  if (search.boarding) {
    const b = SCHOOL_BOARDING.find(x => x.id === search.boarding);
    if (b) parts.push(b.label);
  }

  if (typeof search.admissionsOpen === "boolean") {
    parts.push(search.admissionsOpen ? "Admissions Open" : "Admissions Closed");
  }

  return parts.length ? parts.join(" · ") : "All Schools";
}

function _titleCase(str = "") {
  return str.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}

// Flat lookup map for extramural labels
const SCHOOL_EXTRAMURALACTIVITIES_MAP = {
  football: "⚽ Football", netball: "🏐 Netball", cricket: "🏏 Cricket",
  athletics: "🏃 Athletics", swimming: "🏊 Swimming", tennis: "🎾 Tennis",
  basketball: "🏀 Basketball", volleyball: "🏐 Volleyball", chess: "♟️ Chess",
  debating: "🎤 Debating", music: "🎵 Music", drama: "🎭 Drama",
  dance: "💃 Dance", art: "🎨 Art", scouts: "⚜️ Scouts",
  environmental: "🌿 Env. Club", coding: "💻 Coding Club", science_club: "🔬 Science Club"
};
// ─────────────────────────────────────────────────────────────────────────────
// SMART CARD MENU - school admin picks platform for source-tagged link
// ─────────────────────────────────────────────────────────────────────────────
export async function handleSmartCardMenu(from) {
  const phone  = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone }).lean();
  if (!school) return sendText(from, "❌ No school profile found.");

  if (!school.zqSlug) {
    return sendText(from,
`⚠️ *Your Smart Card link is not set up yet.*

Please contact ZimQuote admin to activate your Smart Card.
📞 0789 901 058`
    );
  }

  const baseLink = `${BASE_URL}/s/${school.zqSlug}`;

  return sendList(from,
`🔗 *Your ZimQuote Smart Card*

${baseLink}

Choose where you want to share it - we will generate a version that tracks leads from that platform:`,
    [
      { id: "school_sc_src_tiktok",          title: "📱 TikTok bio link" },
      { id: "school_sc_src_facebook",         title: "📘 Facebook post / page" },
      { id: "school_sc_src_twitter",          title: "🐦 Twitter / X profile" },
      { id: "school_sc_src_whatsapp_status",  title: "💬 WhatsApp Status" },
      { id: "school_sc_src_qr",              title: "🖨️ QR poster / print" },
      { id: "school_sc_src_sms",             title: "📲 SMS blast" },
      { id: "school_my_leads",               title: "👥 View My Leads" },
      { id: "school_account",                title: "⬅ Back to Menu" }
    ]
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SMART CARD SOURCE LINK - return a source-tagged link + ready-to-paste copy
// ─────────────────────────────────────────────────────────────────────────────
export async function handleSmartCardSourceLink(from, source) {
  const phone  = from.replace(/\D+/g, "");
  const school = await SchoolProfile.findOne({ phone }).lean();
  if (!school || !school.zqSlug) return false;

  const link = `${BASE_URL}/s/${school.zqSlug}?src=${source}`;

  const TIPS = {
    tiktok:         "Paste this in TikTok → Edit Profile → Add link. End every video caption with: \"Link in bio 👆\"",
    facebook:       "Paste this in your Facebook post caption or in your Page's About section → Website field.",
    twitter:        "Add this to your Twitter/X profile bio under the website field. It unfurls into a preview card.",
    whatsapp_status: "Copy the share message below and post it to your WhatsApp Status. Tap it at any time to update.",
    qr:             `Open this URL on your phone or laptop:\n${BASE_URL}/s/${school.zqSlug}/qr\nThen tap 🖨️ Print Poster.`,
    sms:            "Paste this link into your bulk SMS message. It works on all phones, even without data."
  };
  const tip = TIPS[source] || "Share this link on any platform.";

  const admLine = school.admissionsOpen ? "🟢 Admissions currently OPEN" : "";
  const shareMsg =
`🏫 *${school.schoolName}*
📍 ${school.suburb ? school.suburb + ", " : ""}${school.city}
${admLine}

See our full profile, fees & enquire:
👉 ${link}

_Found via ZimQuote- Zimbabwe's school finder_`;

  await sendText(from,
`🔗 *Your ${source.replace("_"," ")} Smart Card link:*

${link}

📋 *Ready-to-paste message:*
━━━━━━━━━━━━━━━━━━
${shareMsg}
━━━━━━━━━━━━━━━━━━

💡 *Tip:* ${tip}`
  );

  return sendButtons(from, {
    text: "What would you like to do next?",
    buttons: [
      { id: "school_smart_card_menu", title: "🔗 Other Platforms" },
      { id: "school_my_leads",        title: "👥 My Leads" },
      { id: "school_account",         title: "⬅ Back to Menu" }
    ]
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// MY LEADS - shows the school's uncontacted leads with follow-up buttons
// ─────────────────────────────────────────────────────────────────────────────
export async function handleMyLeads(from, biz, saveBiz, page = 0) {
  const SchoolLead = (await import("../models/schoolLead.js")).default;
  const phone      = from.replace(/\D+/g, "");
  const school     = await SchoolProfile.findOne({ phone }).lean();
  if (!school) return false;

  const PAGE_SIZE    = 5;
  const totalLeads   = await SchoolLead.countDocuments({ schoolId: school._id });
  const uncontacted  = await SchoolLead.countDocuments({ schoolId: school._id, contacted: false, actionType: { $ne: "view" } });
  const leads        = await SchoolLead.find({ schoolId: school._id, actionType: { $ne: "view" } })
    .sort({ createdAt: -1 })
    .skip(page * PAGE_SIZE)
    .limit(PAGE_SIZE)
    .lean();

  if (!leads.length && page === 0) {
    return sendButtons(from, {
      text:
`👥 *Your Smart Card Leads*

No leads yet.

Share your Smart Card link on TikTok, Facebook, or WhatsApp Status to start receiving leads.`,
      buttons: [
        { id: "school_smart_card_menu", title: "🔗 Get My Smart Card" },
        { id: "school_account",         title: "⬅ Back to Menu" }
      ]
    });
  }

  const ACTION_LABELS = {
    fees: "Requested fees", visit: "Requested visit",
    place: "Asked about place", pdf: "Downloaded profile",
    enquiry: "Sent enquiry", apply: "Wants to apply"
  };
  const SOURCE_ICONS = {
    tiktok:"TikTok", facebook:"FB", twitter:"X", whatsapp_status:"WA Status",
    qr:"QR poster", sms:"SMS", direct:"Direct link", other:"Other"
  };

  let text = `👥 *Smart Card Leads* (page ${page + 1})\n`;
  text    += `📊 Total: ${totalLeads} · ⚠️ Not yet contacted: ${uncontacted}\n\n`;

  for (const lead of leads) {
    const date    = new Date(lead.createdAt).toLocaleDateString("en-GB", { day:"numeric", month:"short" });
    const name    = lead.parentName || "Anonymous";
    const action  = ACTION_LABELS[lead.actionType] || lead.actionType;
    const src     = SOURCE_ICONS[lead.source] || lead.source;
    const status  = lead.contacted ? "✅ Contacted" : "🔴 Not contacted";
    const grade   = lead.gradeInterest ? ` (${lead.gradeInterest})` : "";
    text += `${status} · ${date}\n👤 ${name}${lead.parentPhone ? " · " + lead.parentPhone : ""}\n📌 ${action}${grade} · ${src}\n\n`;
  }

  const buttons = [];
  // Show follow-up button for first uncontacted lead
  const firstUncontacted = leads.find(l => !l.contacted);
  if (firstUncontacted) {
    buttons.push({ id: `school_followup_${firstUncontacted._id}`, title: "📲 Follow Up Next" });
  }
  if ((page + 1) * PAGE_SIZE < totalLeads) {
    buttons.push({ id: `school_leads_page_${page + 1}`, title: "➡ Next Page" });
  }
  buttons.push({ id: "school_account", title: "⬅ Back to Menu" });

  return sendButtons(from, { text: text.trim(), buttons });
}

// ─────────────────────────────────────────────────────────────────────────────
// FOLLOW UP LEAD - mark as contacted, send school admin a pre-filled WA link
// ─────────────────────────────────────────────────────────────────────────────
export async function handleFollowUpLead(from, leadId) {
  const SchoolLead = (await import("../models/schoolLead.js")).default;
  const lead = await SchoolLead.findById(leadId).lean();
  if (!lead) return sendText(from, "❌ Lead not found.");

  // Mark as contacted
  await SchoolLead.findByIdAndUpdate(leadId, {
    $set: { contacted: true, contactedAt: new Date(), contactedBy: from.replace(/\D+/g,"") }
  });

  const ACTION_LABELS = {
    fees:"requested fees", visit:"requested a school visit",
    place:"asked about a place", pdf:"downloaded your school profile",
    enquiry:"sent an enquiry", apply:"asked about applying"
  };
  const actionLabel = ACTION_LABELS[lead.actionType] || "enquired via ZimQuote";

  const greeting = lead.parentName
    ? `Hi ${lead.parentName.split(" ")[0]}`
    : "Good morning";

  const prefilledMsg = lead.gradeInterest
    ? `${greeting}, I'm following up from ${lead.schoolName}. You ${actionLabel} for ${lead.gradeInterest} via ZimQuote. I'd love to help - do you have any questions?`
    : `${greeting}, I'm following up from ${lead.schoolName}. You ${actionLabel} via ZimQuote. I'd love to help - do you have any questions?`;

  const buttons = [];

  if (lead.parentPhone) {
    const waLink = `https://wa.me/${lead.parentPhone.replace(/\D+/g,"")}?text=${encodeURIComponent(prefilledMsg)}`;
    await sendText(from,
`✅ *Lead marked as contacted.*

👤 *${lead.parentName || "Anonymous"}*${lead.parentPhone ? "\n📞 " + lead.parentPhone : ""}
📌 ${ACTION_LABELS[lead.actionType] || lead.actionType}${lead.gradeInterest ? " - " + lead.gradeInterest : ""}

*Tap below to open a pre-filled WhatsApp message to this parent:*
${waLink}`
    );
    buttons.push({ id: "school_my_leads", title: "👥 Back to Leads" });
    buttons.push({ id: "school_account",  title: "⬅ Main Menu" });
  } else {
    await sendText(from,
`✅ *Lead marked as contacted.*

👤 *${lead.parentName || "Anonymous"}*
📌 ${ACTION_LABELS[lead.actionType] || lead.actionType}${lead.gradeInterest ? " - " + lead.gradeInterest : ""}

No phone number captured for this lead (they may not have entered their name on the Smart Card page).`
    );
    buttons.push({ id: "school_my_leads", title: "👥 Back to Leads" });
    buttons.push({ id: "school_account",  title: "⬅ Main Menu" });
  }

  return sendButtons(from, { text: "What would you like to do next?", buttons });
}