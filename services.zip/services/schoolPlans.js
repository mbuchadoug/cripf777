// services/schoolPlans.js
// ─── ZimQuote Schools Module - Plans, Cities, Facilities & Constants ─────────

export const SCHOOL_CITIES = [
  "Harare", "Bulawayo", "Mutare", "Gweru", "Masvingo",
  "Kwekwe", "Kadoma", "Chinhoyi", "Victoria Falls", "Bindura",
  "Zvishavane", "Chegutu", "Rusape", "Kariba", "Hwange"
];

// ── Suburb → City map (mirrors supplierSearch.js pattern) ────────────────────
export const SCHOOL_SUBURB_TO_CITY = {
  // Harare
  "avondale": "Harare", "borrowdale": "Harare", "cbd": "Harare",
  "mbare": "Harare", "highfield": "Harare", "hatfield": "Harare",
  "greendale": "Harare", "msasa": "Harare", "eastlea": "Harare",
  "waterfalls": "Harare", "mufakose": "Harare", "chitungwiza": "Harare",
  "ruwa": "Harare","zimre park":"Harare","gazebo":"Harare","damafalls":"Harare", "highlands": "Harare", "mount pleasant": "Harare",
  "belgravia": "Harare", "milton park": "Harare", "newlands": "Harare",
  "chisipite": "Harare", "gunhill": "Harare", "greystone": "Harare",
  "strathaven": "Harare", "braeside": "Harare", "arcadia": "Harare",
  "southerton": "Harare", "warren park": "Harare", "glen view": "Harare",
  "budiriro": "Harare", "kuwadzana": "Harare", "mabelreign": "Harare",
  "glen norah": "Harare", "dzivarasekwa": "Harare", "tafara": "Harare",
  "mabvuku": "Harare", "norton": "Harare", "kambuzuma": "Harare",
  "epworth": "Harare", "belvedere": "Harare", "westgate": "Harare",
  "sunridge": "Harare", "whitecliff": "Harare", "prospect": "Harare",
  "mbare west": "Harare", "houghton park": "Harare", "tynwald": "Harare",
  "marlborough": "Harare", "borrowdale brooke": "Harare",
  "greystone park": "Harare", "chishawasha": "Harare",
  "mount hampden": "Harare", "ruwa east": "Harare",
  "zengeza": "Harare", "seke": "Harare",
  // Bulawayo
  "nkulumane": "Bulawayo", "luveve": "Bulawayo", "entumbane": "Bulawayo",
  "njube": "Bulawayo", "mpopoma": "Bulawayo", "lobengula": "Bulawayo",
  "makokoba": "Bulawayo", "tshabalala": "Bulawayo", "pumula": "Bulawayo",
  "cowdray park": "Bulawayo", "magwegwe": "Bulawayo", "hillside": "Bulawayo",
 "white city": "Bulawayo", "suburbs": "Bulawayo",
  "famona": "Bulawayo", "barham green": "Bulawayo",
  "queenspark": "Bulawayo", "selbourne park": "Bulawayo",
  "nketa": "Bulawayo", "iminyela": "Bulawayo",
  "mabutweni": "Bulawayo", "makhandeni": "Bulawayo",
  "waterford": "Bulawayo", "whitestone": "Bulawayo",
 "ascot bulawayo": "Bulawayo",
  // Mutare
"sakubva": "Mutare", "dangamvura": "Mutare", "chikanga": "Mutare",
  "hobhouse": "Mutare", "yeovil": "Mutare", "palmerston": "Mutare",
  "cbd":"Mutare","murambi": "Mutare",
  // Gweru
  "mambo": "Gweru", "mkoba": "Gweru", "senga": "Gweru", "ascot": "Gweru",
  // Masvingo
  "mucheke": "Masvingo", "rujeko": "Masvingo", "eastvale": "Masvingo",
  // Kwekwe
 "mbizo": "Kwekwe", "amaveni": "Kwekwe", "redcliff": "Kwekwe",
  // Chinhoyi
  "chinhoyi cbd": "Chinhoyi", "hunyani": "Chinhoyi",
  // Bindura
  "chipadze": "Bindura",
};

// ── School facilities (shown as multi-select checklist during registration) ───
export const SCHOOL_FACILITIES = [
  { id: "swimming_pool",      label: "🏊 Swimming Pool" },
  { id: "science_lab",        label: "🔬 Science Lab" },
  { id: "computer_lab",       label: "💻 Computer Lab" },
  { id: "library",            label: "📚 Library" },
  { id: "sports_fields",      label: "⚽ Sports Fields" },
  { id: "tennis_courts",      label: "🎾 Tennis Courts" },
  { id: "basketball_court",   label: "🏀 Basketball Court" },
  { id: "gymnasium",          label: "🏋️ Gymnasium" },
  { id: "auditorium",         label: "🎭 Auditorium / Hall" },
  { id: "chapel",             label: "⛪ Chapel" },
  { id: "boarding_house",     label: "🏠 Boarding House" },
  { id: "cafeteria",          label: "🍽️ Cafeteria" },
  { id: "transport",          label: "🚌 School Bus / Transport" },
  { id: "wifi",               label: "📶 Wi-Fi Campus" },
  { id: "art_room",           label: "🎨 Art Room" },
  { id: "music_room",         label: "🎵 Music Room" },
  { id: "drama_studio",       label: "🎬 Drama Studio" },
  { id: "home_economics",     label: "🍳 Home Economics" },
  { id: "agriculture",        label: "🌱 Agriculture / Farm" },
  { id: "medical_centre",     label: "🏥 Medical Centre" }
];

// ── Extramural activities (multi-select during registration) ─────────────────
export const SCHOOL_EXTRAMURALACTIVITIES = [
  { id: "football",      label: "⚽ Football" },
  { id: "netball",       label: "🏐 Netball" },
  { id: "cricket",       label: "🏏 Cricket" },
  { id: "athletics",     label: "🏃 Athletics" },
  { id: "swimming",      label: "🏊 Swimming" },
  { id: "tennis",        label: "🎾 Tennis" },
  { id: "basketball",    label: "🏀 Basketball" },
  { id: "volleyball",    label: "🏐 Volleyball" },
  { id: "chess",         label: "♟️ Chess" },
  { id: "debating",      label: "🎤 Debating" },
  { id: "music",         label: "🎵 Music / Band" },
  { id: "drama",         label: "🎭 Drama" },
  { id: "dance",         label: "💃 Dance" },
  { id: "art",           label: "🎨 Art" },
  { id: "scouts",        label: "⚜️ Scouts / Guides" },
  { id: "environmental", label: "🌿 Environmental Club" },
  { id: "coding",        label: "💻 Coding Club" },
{ id: "science_club",  label: "🔬 Science Club" }
];

// ── Facility quick-select bundles ─────────────────────────────────────────────
export const SCHOOL_FACILITY_BUNDLES = [
  {
    id:  "fac_all",
    label: "⭐ Select All Facilities",
    ids: ["swimming_pool","science_lab","computer_lab","library","sports_fields",
          "tennis_courts","basketball_court","gymnasium","auditorium","chapel",
          "boarding_house","cafeteria","transport","wifi","art_room",
          "music_room","drama_studio","home_economics","agriculture","medical_centre"]
  },
  {
    id:  "fac_private",
    label: "🏫 Typical Private School",
    ids: ["swimming_pool","science_lab","computer_lab","library",
          "sports_fields","auditorium","transport","wifi"]
  },
  {
    id:  "fac_none",
    label: "⏭ None / Skip",
    ids: []
  }
];

// ── Extramural quick-select bundles ───────────────────────────────────────────
export const SCHOOL_EXTRAMURAL_BUNDLES = [
  {
    id:  "ext_all",
    label: "⭐ All Sports & Activities",
    ids: ["football","netball","cricket","athletics","swimming","tennis",
          "basketball","volleyball","chess","debating","music","drama",
          "dance","art","scouts","environmental","coding","science_club"]
  },
  {
    id:  "ext_sports",
    label: "⚽ All Sports Only",
    ids: ["football","netball","cricket","athletics","swimming",
          "tennis","basketball","volleyball"]
  },
  {
    id:  "ext_arts",
    label: "🎭 Arts & Clubs Only",
    ids: ["chess","debating","music","drama","dance","art",
          "scouts","environmental","coding","science_club"]
  },
  {
    id:  "ext_none",
    label: "⏭ None / Skip",
    ids: []
  }
];

// ── Curriculum options ────────────────────────────────────────────────────────
export const SCHOOL_CURRICULA = [
  { id: "zimsec",             label: "📘 ZIMSEC" },
  { id: "cambridge",          label: "🎓 Cambridge (IGCSE/A-Level)" },
  { id: "cambridge_primary",  label: "🎓 Cambridge Checkpoint" },
  { id: "ib",                 label: "🌍 IB " },
  { id: "combined",           label: "📚 ZIMSEC + Cambridge" }
];

// ── School types ──────────────────────────────────────────────────────────────
export const SCHOOL_TYPES = [
  { id: "ecd",       label: "🌱 ECD / Preschool Only (ECD A-B)" },
  { id: "primary",   label: "📗 Primary (Grade 1-7)" },
  { id: "ecd_primary", label: "📗 ECD + Primary (ECD A-Grade 7)" },
  { id: "secondary", label: "📙 Secondary (Form 1-6)" },
  { id: "combined",  label: "📘 Combined (ECD-Form 6)" }
];

// ── Fee ranges (auto-computed, also used as search filter) ───────────────────
export const SCHOOL_FEE_RANGES = [
  { id: "budget",  label: "💚 Budget (Under $300/term)" },
  { id: "mid",     label: "💛 Mid-Range ($300-$800/term)" },
  { id: "premium", label: "💎 Premium ($800+/term)" }
];

// ── Gender options ────────────────────────────────────────────────────────────
export const SCHOOL_GENDERS = [
  { id: "mixed", label: "👫 Mixed (Co-ed)" },
  { id: "boys",  label: "👦 Boys Only" },
  { id: "girls", label: "👧 Girls Only" }
];

// ── Boarding options ──────────────────────────────────────────────────────────
export const SCHOOL_BOARDING = [
  { id: "day",      label: "🏠 Day School Only" },
  { id: "boarding", label: "🏫 Boarding Only" },
  { id: "both",     label: "🏠🏫 Day & Boarding" }
];

// ── Grade bands (from/to options) ────────────────────────────────────────────
export const SCHOOL_GRADE_FROM = [
  "ECD A", "ECD B", "Grade 1", "Grade 2", "Grade 3",
  "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Form 1"
];
export const SCHOOL_GRADE_TO = [
  "Grade 7", "Form 1", "Form 2", "Form 3", "Form 4",
  "Form 5", "Form 6", "Upper 6"
];

// ── Subscription plans ────────────────────────────────────────────────────────
export const SCHOOL_PLANS = {
  basic: {
    id:       "basic",
    name:     "Basic",
    monthly:  { price: 15, label: "$15/month", id: "school_plan_basic_monthly" },
    annual:   { price: 150, label: "$150/year (save $30)", id: "school_plan_basic_annual" },
    features: "Listed in search · Profile PDF · Application link"
  },
  featured: {
    id:       "featured",
    name:     "Featured",
    monthly:  { price: 35, label: "$35/month", id: "school_plan_featured_monthly" },
    annual:   { price: 350, label: "$350/year (save $70)", id: "school_plan_featured_annual" },
    features: "Top of results · Verified badge · Analytics · All Basic features"
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// SPECIALISED INSTITUTIONS (culinary, driving, music, vocational, college, ...)
// Registered as SchoolProfile with institutionType !== "academic".
// They use the SAME SCHOOL_PLANS pricing as academic schools, but a LIGHT
// registration branch (courses[] instead of grade-level fee sections) and their
// own "Colleges & Training" search tab.
// ─────────────────────────────────────────────────────────────────────────────
export const INSTITUTION_CATEGORIES = [
  { id: "academic",   label: "🏫 Academic School (ECD-Form 6)", specialised: false },
  { id: "college",    label: "🎓 College / Polytechnic / Tertiary", specialised: true },
  { id: "vocational", label: "🛠 Vocational / Skills Training", specialised: true },
  { id: "culinary",   label: "🍳 Culinary Arts / Catering", specialised: true },
  { id: "computer",   label: "💻 Computer / IT / Coding", specialised: true },
  { id: "driving",    label: "🚗 Driving School", specialised: true },
  { id: "beauty",     label: "💇 Beauty / Cosmetology / Hair", specialised: true },
  { id: "music_arts", label: "🎵 Music / Dance / Drama / Art", specialised: true },
  { id: "language",   label: "🗣 Language School", specialised: true },
  { id: "sports",     label: "⚽ Sports Academy", specialised: true },
  { id: "special_ed", label: "💙 Special Needs / Remedial", specialised: true },
  { id: "other",      label: "➕ Other Institution", specialised: true }
];

export function isSpecialisedInstitution(id = "") {
  const c = INSTITUTION_CATEGORIES.find(x => x.id === id);
  return !!c && c.specialised === true;
}
export function institutionLabel(id = "") {
  return (INSTITUTION_CATEGORIES.find(x => x.id === id)?.label || "Institution").replace(/^[^\w]+/, "").trim();
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE TEACHERS / TUTORS
// Registered as SupplierProfile with profileType = "tutor".
// Billed on the existing $5/mo supplier "basic" plan (no new payment plumbing).
// TUTOR_PLAN is a display reference only - actual activation reuses the supplier
// plan action ids (sup_plan_basic_monthly / sup_plan_basic_annual).
// ─────────────────────────────────────────────────────────────────────────────
export const TUTOR_PLAN = {
  monthly: { price: 5,  label: "$5/month",           actionId: "sup_plan_basic_monthly" },
  annual:  { price: 50, label: "$50/year (save $10)", actionId: "sup_plan_basic_annual"  },
  features: "Listed in tutor search · Shareable smart link · Parent enquiry alerts with their phone number · Seller chat"
};

// Subjects parents actually search for in Zimbabwe. Kept tight for a fast picker;
// tutors can add a custom subject via free text during registration.
export const TUTOR_SUBJECTS = [
  { id: "mathematics",  label: "➗ Mathematics" },
  { id: "english",      label: "📖 English" },
  { id: "sciences",     label: "🔬 Sciences (Bio/Chem/Phys)" },
  { id: "accounts",     label: "📊 Accounts / Commerce" },
  { id: "shona",        label: "🗣 Shona" },
  { id: "ndebele",      label: "🗣 Ndebele" },
  { id: "ict",          label: "💻 ICT / Computers" },
  { id: "geography",    label: "🌍 Geography" },
  { id: "history",      label: "📜 History" },
  { id: "heritage",     label: "🏛 Heritage / FAREME" },
  { id: "agriculture",  label: "🌱 Agriculture" },
  { id: "french",       label: "🇫🇷 French" },
  { id: "art",          label: "🎨 Art & Design" },
  { id: "music",        label: "🎵 Music" },
  { id: "early_learning", label: "🧸 Early Learning (ECD)" }
];

// Levels a tutor teaches / a parent filters by.
export const TUTOR_LEVELS = [
  { id: "ecd",       label: "🧸 ECD / Pre-school" },
  { id: "primary",   label: "📗 Primary (Grade 1-7)" },
  { id: "zjc",       label: "📘 ZJC (Form 1-2)" },
  { id: "olevel",    label: "📙 O-Level (Form 3-4)" },
  { id: "alevel",    label: "📕 A-Level (Form 5-6)" },
  { id: "cambridge", label: "🎓 Cambridge (IGCSE/AS/A)" },
  { id: "college",   label: "🏛 College / University" },
  { id: "adult",     label: "🧑 Adult / Professional" }
];

// How lessons are delivered.
export const TUTOR_MODES = [
  { id: "in_person", label: "🏠 In person" },
  { id: "online",    label: "💻 Online (video/WhatsApp)" },
  { id: "both",      label: "🔁 Both" }
];

// Where in-person lessons happen (multi-select).
export const TUTOR_VENUES = [
  { id: "tutor_place",  label: "🏠 At my place" },
  { id: "student_home", label: "🚗 I travel to student (home visits)" },
  { id: "public",       label: "📚 Library / agreed venue" }
];

// Hourly-rate filter buckets for parent search (USD).
export const TUTOR_RATE_RANGES = [
  { id: "under5",  label: "💚 Under $5/hr",  max: 5 },
  { id: "5to10",   label: "💛 $5-$10/hr",    min: 5,  max: 10 },
  { id: "10to20",  label: "🧡 $10-$20/hr",   min: 10, max: 20 },
  { id: "over20",  label: "💎 $20+/hr",      min: 20 }
];

export function tutorSubjectLabel(id = "") {
  return TUTOR_SUBJECTS.find(s => s.id === id)?.label?.replace(/^[^\w]+/, "").trim() || id;
}
export function tutorLevelLabel(id = "") {
  return TUTOR_LEVELS.find(l => l.id === id)?.label?.replace(/^[^\w]+/, "").trim() || id;
}

// ── Helper: compute fee range string from term fee amount ────────────────────
export function computeSchoolFeeRange(termFee = 0) {
  const n = Number(termFee) || 0;
  if (n < 300)  return "budget";
  if (n <= 800) return "mid";
  return "premium";
}

// ── Helper: readable fee range label ─────────────────────────────────────────
export function feeRangeLabel(range = "") {
  return { budget: "Under $300/term", mid: "$300-$800/term", premium: "$800+/term" }[range] || "Not specified";
}

// ── Helper: emoji icon for facility id ───────────────────────────────────────
export function facilityIcon(id = "") {
  const f = SCHOOL_FACILITIES.find(f => f.id === id);
  return f ? f.label.split(" ")[0] : "•";
}