// ==============================
// 📡 MIKROTIK SERVICE
// The ONLY file that talks to the router. Everything else calls these
// helpers. If the router isn't configured or is unreachable, calls throw
// a MikrotikError and the caller keeps working in "offline mode" (vouchers
// are still saved in Mongo and pushed later by the sync loop).
//
// NOTE: RouterOS 7.20+ replies "!empty" to query-filtered prints that match
// nothing, and node-routeros crashes on that reply. So we NEVER use "?query"
// filters - we print the whole menu and filter in JS. Safe on all versions.
// ==============================

let RouterOSAPI = null;   // lazy-loaded so the app boots even without the package

const CFG = {
  host: process.env.MT_HOST || "",
  user: process.env.MT_USER || "admin",
  password: process.env.MT_PASS || "",
  port: Number(process.env.MT_PORT || 8728),
  tls: String(process.env.MT_TLS || "false") === "true",
  timeout: Number(process.env.MT_TIMEOUT || 8),
  server: process.env.MT_HOTSPOT_SERVER || "all"   // which hotspot server to log users out of
};

export class MikrotikError extends Error {}

export function isConfigured() {
  return Boolean(CFG.host && CFG.password);
}

// Read the ".id" field that RouterOS returns for every row.
function rowId(row) {
  return row?.[".id"] || row?.id || null;
}

// Open a short-lived connection, run fn, always close. Low volume → simple & safe.
async function withConn(fn) {
  if (!isConfigured()) throw new MikrotikError("Router not configured");
  if (!RouterOSAPI) {
    try {
      ({ RouterOSAPI } = await import("node-routeros"));
    } catch {
      throw new MikrotikError("node-routeros not installed (run: npm i node-routeros)");
    }
  }
  const api = new RouterOSAPI({
    host: CFG.host, user: CFG.user, password: CFG.password,
    port: CFG.port, timeout: CFG.timeout, tls: CFG.tls ? {} : undefined
  });
  try {
    await api.connect();
    return await fn(api);
  } catch (err) {
    throw new MikrotikError(err?.message || String(err));
  } finally {
    try { api.close(); } catch { /* ignore */ }
  }
}

// Print a whole menu, always returning an array. Never uses "?query" filters
// (those trigger the !empty crash). Tolerant of empty/odd replies.
async function printAll(api, path) {
  try {
    const res = await api.write(path);
    return Array.isArray(res) ? res : (res ? [res] : []);
  } catch (err) {
    const msg = String(err?.message || err).toLowerCase();
    if (msg.includes("empty") || err?.errno === "UNKNOWNREPLY") return [];
    throw err;
  }
}

const byName = (rows, name) => rows.find((r) => r.name === name) || null;
const byField = (rows, field, val) =>
  rows.filter((r) => String(r[field] || "").toUpperCase() === String(val || "").toUpperCase());

// Convert minutes → RouterOS time string, e.g. 150 → "02:30:00", 1500 → "1d01:00:00".
export function minutesToRos(minutes) {
  let secs = Math.max(0, Math.round(minutes * 60));
  const d = Math.floor(secs / 86400); secs -= d * 86400;
  const h = Math.floor(secs / 3600);  secs -= h * 3600;
  const m = Math.floor(secs / 60);    const s = secs - m * 60;
  const hms =
    `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return d > 0 ? `${d}d${hms}` : hms;
}

// ── Connection check (for the status pill) ──
export async function ping() {
  return withConn(async (api) => {
    const id = await printAll(api, "/system/identity/print");
    const active = await printAll(api, "/ip/hotspot/active/print");
    return {
      ok: true,
      identity: id?.[0]?.name || "MikroTik",
      activeCount: active.length
    };
  });
}

// ── Ensure a user-profile exists for a plan (device cap + speed) ──
export async function ensureProfile({ name, sharedUsers, rateLimit }) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/profile/print");
    const existing = byName(rows, name);
    const params = [
      `=shared-users=${sharedUsers || 1}`,
      "=add-mac-cookie=yes",
      // Phones sleep their WiFi when the screen is off. Without these, RouterOS
      // logs a sleeping phone out (keepalive timeout) and the guest is bounced
      // back to the sign-in page on wake. "none" keeps the session alive; the
      // mac-cookie lets them reconnect for the life of the voucher.
      "=keepalive-timeout=none",
      "=idle-timeout=none",
      `=mac-cookie-timeout=${process.env.MT_MAC_COOKIE_TIMEOUT || "30d"}`
    ];
    if (rateLimit) params.push(`=rate-limit=${rateLimit}`);

    if (existing) {
      await api.write("/ip/hotspot/user/profile/set", [`=.id=${rowId(existing)}`, ...params]);
      return rowId(existing);
    }
    await api.write("/ip/hotspot/user/profile/add", [`=name=${name}`, ...params]);
    const after = await printAll(api, "/ip/hotspot/user/profile/print");
    return rowId(byName(after, name));
  });
}

// ── Add a voucher as a hotspot user. Returns the router id. ──
export async function addVoucherUser({ code, profile, limitUptimeMinutes }) {
  return withConn(async (api) => {
    const params = [`=name=${code}`, `=password=${code}`, `=profile=${profile}`];
    if (limitUptimeMinutes && limitUptimeMinutes > 0) {
      params.push(`=limit-uptime=${minutesToRos(limitUptimeMinutes)}`);
    }
    await api.write("/ip/hotspot/user/add", params);
    const rows = await printAll(api, "/ip/hotspot/user/print");
    return rowId(byName(rows, code));
  });
}

// ── Move a hotspot user to a different profile (changes speed / device cap) ──
export async function setUserProfile(code, profile) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, code);
    if (!u) throw new MikrotikError(`user ${code} not on router`);
    await api.write("/ip/hotspot/user/set", [`=.id=${rowId(u)}`, `=profile=${profile}`]);
    return true;
  });
}

// ── Change a hotspot user's password (used when an account password is reset) ──
export async function setUserPassword(code, password) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, code);
    if (!u) throw new MikrotikError(`user ${code} not on router`);
    await api.write("/ip/hotspot/user/set", [`=.id=${rowId(u)}`, `=password=${password}`]);
    return true;
  });
}

// ── Create OR update a long-lived account user (username + chosen password) ──
// limitUptimeMinutes 0 = no uptime cap (subscription accounts rely on the app's
// validUntil instead). Always leaves the user enabled.
export async function upsertAccountUser({ username, password, profile, limitUptimeMinutes }) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, username);
    const params = [`=password=${password}`, `=profile=${profile}`, "=disabled=no"];
    params.push(`=limit-uptime=${limitUptimeMinutes && limitUptimeMinutes > 0 ? minutesToRos(limitUptimeMinutes) : "0"}`);
    if (u) {
      await api.write("/ip/hotspot/user/set", [`=.id=${rowId(u)}`, ...params]);
      return rowId(u);
    }
    await api.write("/ip/hotspot/user/add", [`=name=${username}`, ...params]);
    const after = await printAll(api, "/ip/hotspot/user/print");
    return rowId(byName(after, username));
  });
}

export async function setUptimeLimit(code, totalMinutes) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, code);
    if (!u) throw new MikrotikError(`voucher ${code} not on router`);
    await api.write("/ip/hotspot/user/set",
      [`=.id=${rowId(u)}`, `=limit-uptime=${minutesToRos(totalMinutes)}`]);
    return true;
  });
}

export async function setUserDisabled(code, disabled) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, code);
    if (!u) return false;
    await api.write("/ip/hotspot/user/set",
      [`=.id=${rowId(u)}`, `=disabled=${disabled ? "yes" : "no"}`]);
    return true;
  });
}

export async function removeVoucherUser(code) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/user/print");
    const u = byName(rows, code);
    if (u) await api.write("/ip/hotspot/user/remove", [`=.id=${rowId(u)}`]);
    return true;
  });
}

// Kick any live sessions for a code (used on revoke / expiry).
export async function kick(code) {
  return withConn(async (api) => {
    const active = await printAll(api, "/ip/hotspot/active/print");
    for (const row of active.filter((a) => a.user === code)) {
      await api.write("/ip/hotspot/active/remove", [`=.id=${rowId(row)}`]);
    }
    return true;
  });
}

// ── Snapshot everything the sync loop needs in as few calls as possible ──
export async function snapshot() {
  return withConn(async (api) => {
    const [active, users, hosts] = await Promise.all([
      printAll(api, "/ip/hotspot/active/print"),
      printAll(api, "/ip/hotspot/user/print"),
      printAll(api, "/ip/hotspot/host/print")
    ]);

    const hostByMac = {};
    for (const h of hosts) {
      const mac = (h["mac-address"] || "").toUpperCase();
      if (mac && h["host-name"]) hostByMac[mac] = h["host-name"];
    }

    const usageByCode = {};
    for (const u of users) {
      usageByCode[u.name] = {
        uptimeUsedSec: parseRosUptime(u.uptime),
        bytesIn: Number(u["bytes-in"] || 0),
        bytesOut: Number(u["bytes-out"] || 0)
      };
    }

    const sessions = active.map((a) => {
      const mac = (a["mac-address"] || "").toUpperCase();
      return {
        code: a.user,
        mac,
        ip: a.address || "",
        hostname: hostByMac[mac] || "",
        uptimeSec: parseRosUptime(a.uptime),
        bytesIn: Number(a["bytes-in"] || 0),
        bytesOut: Number(a["bytes-out"] || 0)
      };
    });

    return { sessions, usageByCode };
  });
}

// ── Bypass devices (cameras, reception, staff) ──
// rateLimit is an optional "up/down" string (e.g. "2000k/8000k"). Empty/"" keeps
// the device UNLIMITED (cameras). A value caps the device while it stays bypassed
// - no login page, just a speed ceiling - so one staff phone can't starve the WiFi.
export async function addBypass(mac, comment, rateLimit) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/ip-binding/print");
    const existing = byField(rows, "mac-address", mac)[0];
    const base = ["=type=bypassed", `=comment=${comment || ""}`];
    if (existing) {
      // On update: set the cap, or UNSET it (=!rate-limit=) when unlimited, so a
      // previously-capped device can be cleared. RouterOS rejects an empty value.
      const setParams = [`=.id=${rowId(existing)}`, ...base];
      setParams.push(rateLimit ? `=rate-limit=${rateLimit}` : "=!rate-limit=");
      await api.write("/ip/hotspot/ip-binding/set", setParams);
      return rowId(existing);
    }
    // On add: only include rate-limit when there's a real cap. Sending an empty
    // rate-limit here is what left unlimited devices stuck on "queued".
    const addParams = [`=mac-address=${mac}`, ...base];
    if (rateLimit) addParams.push(`=rate-limit=${rateLimit}`);
    await api.write("/ip/hotspot/ip-binding/add", addParams);
    const after = await printAll(api, "/ip/hotspot/ip-binding/print");
    return rowId(byField(after, "mac-address", mac)[0]);
  });
}

export async function removeBypass(mac) {
  return withConn(async (api) => {
    const rows = await printAll(api, "/ip/hotspot/ip-binding/print");
    for (const row of byField(rows, "mac-address", mac)) {
      await api.write("/ip/hotspot/ip-binding/remove", [`=.id=${rowId(row)}`]);
    }
    return true;
  });
}

// RouterOS uptime like "1d2h3m4s" → seconds.
function parseRosUptime(str) {
  if (!str) return 0;
  let total = 0;
  const re = /(\d+)([wdhms])/g;
  const mult = { w: 604800, d: 86400, h: 3600, m: 60, s: 1 };
  let m;
  while ((m = re.exec(str)) !== null) total += Number(m[1]) * (mult[m[2]] || 0);
  return total;
}

export const HOTSPOT_SERVER = CFG.server;