import mongoose from "mongoose";

const LearnerProfileSchema = new mongoose.Schema({
  parentUserId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
    index: true
  },

  displayName: {
    type: String,
    required: true
  },

  schoolLevel: {
    type: String,
    enum: ["junior", "high"],
    required: true,
    index: true
  },

  grade: {
    type: Number,
    required: true,
    index: true
  },

  subjects: [{
    type: String,
    enum: ["maths", "english", "science", 'genralknowledge','environmentalstudies','biology','geography','businessstudies', 'history']
  }],

  subscriptionStatus: {
    type: String,
    enum: ["trial", "paid"],
    default: "trial",
    index: true
  },

  trialCounters: {
    maths: { type: Number, default: 0 },
    english: { type: Number, default: 0 },
    science: { type: Number, default: 0 },
    environmentalstudies: { type: Number, default: 0 },
    geography: { type: Number, default: 0 },
    biology: { type: Number, default: 0 },
    businessstudies: { type: Number, default: 0 },
    history: { type: Number, default: 0 },
    generalknowledge: { type: Number, default: 0 },
  },

  createdAt: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("LearnerProfile", LearnerProfileSchema);
