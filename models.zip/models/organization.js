// models/organization.js
import mongoose from "mongoose";

const OrganizationSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  type: { type: String, enum: ["company", "school"], default: "company", index: true },

  slug: { type: String, required: true, unique: true, index: true },
  description: String,
  createdAt: { type: Date, default: Date.now },
  // invite tokens (simple implementation); in production you'd separate to invites collection
  invites: [{
    token: String,
   role: {
  type: String,
  enum: ["employee", "student", "teacher", "org_admin", "super_admin"],
  index: true
}
,
grade: {
  type: Number,
  min: 1,
  max: 6,
  index: true,
  default: null
}
,
studentId: { type: String, index: true },

    createdAt: { type: Date, default: Date.now },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  }]
}, { timestamps: true });

export default mongoose.models.Organization || mongoose.model("Organization", OrganizationSchema);
